# AED / ACCESS

An interactive study of AED accessibility in Singapore, prepared for DEP5118.

Explore historical AED availability, older residents, and a three-dimensional Pearl’s Hill response scenario.

## Scope

AED listings are from 2020. The maps and response scenarios are research outputs, not verified current availability or emergency navigation. Visit reports are demonstrations saved only in the visitor’s browser.

## Sources

Source dates, model assumptions and limitations are documented in the website’s final chapter. Map attribution and bundled library notices are retained.

## Hosting

This repository contains the static website. Serve the root directory through GitHub Pages with HTTPS. No build step or server-side database is required.
