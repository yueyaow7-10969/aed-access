/* AED Access map runtime. Kepler 3.1.10 stays mounted in one store.
 * The parent owns story copy, scenario controls, details and reports.
 * Saved maps and source data are copied assets; only in-memory configs change.
 */
(() => {
  'use strict';
  const DEBUG = false;
  const debug = (...args) => {if(DEBUG)console.info(...args);};
  const CHANNEL = 'aed-access';
  const MAP_ID = 'aed-map';
  const STYLE_ID = 'aed-radix-dark';
  const NATIONAL = {longitude:103.82319293, latitude:1.3503861535, zoom:10.3, pitch:0, bearing:0, dragRotate:false, isSplit:false};
  const CASE_VIEW = {...NATIONAL, longitude:103.8395, latitude:1.2854, zoom:14.4};
  const SCENES = new Set(['inventory','day','transition','time','density','case','shortlist','find']);
  const SCENARIOS = new Set(['wd_day','wd_night','we_day','we_night']);
  const VIEWS = new Set(['overlay','supply','population']);
  const TIME_MAPS = {wd_day:'04a_weekday_day', wd_night:'04b_weekday_night', we_day:'04c_weekend_day', we_night:'04d_weekend_night'};
  const OTHER_MAPS = {inventory:'01_all_aeds', day:'02_weekday_day', transition:'03_weekday_night', density:'06_age_and_density', case:'08_case_context_2d', shortlist:'07_case_shortlist', find:'09_participation_find'};
  const mapControls = Object.fromEntries(['mapLegend','mapInfo','toggle3d','splitMap','visibleLayers','cameraBookmarks','mapDraw','mapLocale'].map(key=>[key,{show:false,active:false}]));
  const UI = {readOnly:true,currentModal:null,activeSidePanel:null,mapControls};
  const mapRoot = document.getElementById('map-root');
  const statusEl = document.getElementById('map-status');
  const savedMaps = new Map();
  const managedOverlayIds = new Set();
  const managedSourceIds = new Set();
  const observedMaps = new WeakSet();
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  let palette, aeds = [], aedById = new Map(), visibleAEDs = [], store, map, deck, root;
  let initialised = false, processing = false, loadFailed = false, sceneRevision = 0;
  let pendingScene = {scene:'inventory',scenario:'wd_night',view:'overlay',requestId:-1};
  let activeScene = null, latestScene = pendingScene, currentCameraGroup = null;
  let selectedId = null, selectionRevision = 0, lastClicked = null, syncQueued = false;
  let loadWaiter = null, registrationWaiter = null, renderWaiter = null, pendingView = null;
  let loggedHeatRequest = null;
  let mapStyle, theme;
  let overviewCamera=true;

  const clone = value => JSON.parse(JSON.stringify(value));
  const cameraTransition = () => ({transitionDuration:reducedMotion.matches?0:250,transitionEasing:progress=>1-Math.pow(1-progress,3)});
  const rgb = hex => hex.slice(1).match(/../g).map(pair=>parseInt(pair,16));
  const token = (family,step) => palette[family][`${family}${step}`];
  const text = value => String(value ?? '').replace(/\s*·\s*/g,' / ');
  const send = (type,payload={}) => {
    if(window.parent !== window) window.parent.postMessage({channel:CHANNEL,type,payload},location.origin);
  };
  const status = (message,error=false) => {
    statusEl.textContent=message;
    statusEl.dataset.error=String(error);
    statusEl.hidden=!message;
  };
  const fail = (error,message='The map could not load. Please retry.') => {
    console.error('[AED map]',error);
    status(message,true);
    send('error',{message,requestId:latestScene?.requestId});
  };
  const dispatch = action => store.dispatch(KeplerGl.wrapTo(MAP_ID,action));
  const state = () => store?.getState().keplerGl[MAP_ID];
  const nationalView = () => {
    const width=Math.max(1,mapRoot.clientWidth-48),height=Math.max(1,mapRoot.clientHeight-64);
    const zoomX=Math.log2(width*360/(512*0.49));
    const zoomY=Math.log2(height*360/(512*0.32));
    return {...NATIONAL,zoom:Math.max(7,Math.min(10.3,zoomX,zoomY))};
  };
  const resetView = () => activeScene?.scene==='case' ? CASE_VIEW : nationalView();

  async function fetchJSON(path) {
    const response=await fetch(path);
    if(!response.ok) throw new Error(`${path}: HTTP ${response.status}`);
    return response.json();
  }
  async function getSavedMap(id) {
    if(!savedMaps.has(id)) {
      const pending=fetchJSON(`../maps/${id}.json`).catch(error=>{savedMaps.delete(id);throw error;});
      savedMaps.set(id,pending);
    }
    return savedMaps.get(id);
  }
  function range(colors,oldRange) {
    const result={...oldRange,name:'AED Access',colors};
    if(oldRange?.colorMap) result.colorMap=oldRange.colorMap.map(([label],index)=>[text(label),colors[Math.min(index,colors.length-1)]]);
    if(oldRange?.colorLegends) result.colorLegends=Object.fromEntries(Object.values(oldRange.colorLegends).map((label,index)=>[colors[Math.min(index,colors.length-1)],text(label)]));
    return result;
  }
  function restyleLayer(layer) {
    const config=layer.config, visual=config.visConfig;
    const population=config.dataId==='population_65_subzones';
    const elderlyArea=config.dataId==='resident_age';
    const nilArea=config.dataId==='resident_age_nil';
    const caseBoundary=config.dataId==='selected_case'||config.dataId==='case_boundary';
    const shortlist=config.dataId==='shortlist';
    const categorical=Boolean(visual.colorRange?.colorMap?.some(([label])=>String(label).includes('closed')));
    let colors=[token('teal',9),token('teal',9)], fill=token('teal',9), stroke=token('teal',9);
    if(layer.type==='heatmap') colors=[3,4,6,8,9,11].map(step=>token('teal',step));
    else if(population) {colors=[token('amber',10),token('amber',10)];fill=stroke=token('amber',10);}
    else if(elderlyArea) {colors=[3,4,5,7,9].map(step=>token('amber',step));fill=token('amber',5);stroke=token('gray',7);}
    else if(nilArea) {colors=[token('gray',4)];fill=token('gray',4);stroke=token('gray',6);}
    else if(caseBoundary) {colors=[token('gray',12)];fill=stroke=token('gray',12);}
    else if(shortlist) {colors=[token('tomato',9)];fill=stroke=token('tomato',9);}
    else if(categorical) colors=[token('teal',9),token('tomato',9)];
    config.label=text(config.label);
    config.color=rgb(fill);
    config.highlightColor=[...rgb(token('gray',12)),255];
    if(visual.strokeColor) visual.strokeColor=rgb(stroke);
    if('thickness' in visual) visual.thickness=0.5;
    visual.colorRange=range(colors,visual.colorRange);
    if(visual.strokeColorRange) visual.strokeColorRange=range(colors,visual.strokeColorRange);
    if(layer.type==='heatmap') {visual.opacity=0.42;visual.radius=22;visual.intensity=0.12;}
    for(const label of config.textLabel||[]) {
      label.color=rgb(token('gray',12));label.outlineColor=[...rgb(token('gray',2)),255];
      label.backgroundColor=[...rgb(token('gray',2)),255];label.size=12;label.outlineWidth=0.5;
    }
  }
  function simplifyAEDTooltips(saved) {
    const tooltip=saved.config.config.visState.interactionConfig?.tooltip;
    if(!tooltip)return;
    for(const dataset of saved.datasets) {
      const table=dataset.data;
      const names=table.fields.map(field=>field.name);
      const isAED=names.includes('aed_id'),isPopulation=table.id==='population_65_subzones';
      if(!isAED&&!isPopulation)continue;
      const fields=isAED
        ?[['Building','building'],['Address',names.includes('full_address')?'full_address':'address'],['Floor','floor_raw'],['Placement','location'],['Listed hours','hours']]
        :[['Area','subzone_name'],['Residents aged 65+','age65_n'],['Share of residents','age65_pct'],['Population year','pop_year']];
      for(const [label,source]of fields) {
        const index=names.indexOf(source);
        const original=table.fields[index]||table.fields.find(field=>field.type==='string');
        table.fields.push({...original,name:label,type:'string',analyzerType:'STRING',format:''});
        for(const row of table.allData) {
          const value=index<0?null:row[index];
          row.push(value===null||value===''?'Not listed':source==='age65_pct'?`${Number(value).toFixed(1)}%`:source==='age65_n'?Number(value).toLocaleString('en-SG'):text(value));
        }
      }
      tooltip.fieldsToShow[table.id]=fields.map(([name])=>({name,format:null}));
    }
  }
  async function prepareScene(command) {
    const id=command.scene==='time'?TIME_MAPS[command.scenario]:OTHER_MAPS[command.scene];
    const saved=clone(await getSavedMap(id));
    const config=saved.config.config;
    delete config.mapStyle; // The same loaded base style stays alive between scenes.
    delete config.mapState; // Camera choreography is explicit, never an incidental dataset reset.
    config.uiState=clone(UI);
    const vis=config.visState;
    vis.layers.forEach(restyleLayer);
    if(vis.interactionConfig?.legend) vis.interactionConfig.legend.enabled=false;
    if(vis.interactionConfig?.geocoder) vis.interactionConfig.geocoder.enabled=false;
    for(const dataset of saved.datasets) {
      dataset.data.color=rgb(token('teal',9));dataset.data.label=text(dataset.data.label);
      const candidateLabel=dataset.data.fields.findIndex(field=>field.name==='candidate_label');
      if(candidateLabel>=0)for(const row of dataset.data.allData)row[candidateLabel]=text(row[candidateLabel]);
    }
    if(command.scene==='density') {
      // The saved heatmap contains only weekday-night records. Always derive other
      // scenarios from the full historical inventory rather than this subset.
      const heat=saved.datasets.find(dataset=>dataset.data.id==='aed_night_heatmap');
      const fields=heat.data.fields.map(field=>field.name);
      heat.data.allData=aeds.filter(aed=>aed[command.scenario]===1).map(aed=>fields.map(name=>name==='display_status'?'Listed open at selected time':(aed[name]??null)));
      heat.data.label='AED concentration at selected time';
      for(const layer of vis.layers) {
        if(layer.type==='heatmap') {layer.config.isVisible=command.view!=='population';layer.config.label='AED concentration at selected time';}
        if(layer.config.dataId==='population_65_subzones') layer.config.isVisible=command.view!=='supply';
      }
    }
    simplifyAEDTooltips(saved);
    return saved;
  }

  function waitForMapRegistration() {
    if(state()) return Promise.resolve();
    return new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{registrationWaiter=null;reject(new Error('Kepler registration timed out'));},20000);
      registrationWaiter=()=>{clearTimeout(timeout);registrationWaiter=null;resolve();};
    });
  }
  function submitSavedMap(saved) {
    const expectedIds=saved.datasets.map(dataset=>dataset.data.id);
    const expectedLayers=saved.config.config.visState.layers.map(layer=>layer.id);
    return new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{
        // Do not submit another dataset Task after an unsettled Task times out.
        // Retry explicitly reloads the isolated frame in that failure case.
        loadFailed=true;loadWaiter=null;reject(new Error('Map data processing timed out'));
      },25000);
      loadWaiter=()=>{
        const vis=state()?.visState;
        if(!vis||vis.loadingIndicatorValue>0) return;
        const ids=Object.keys(vis.datasets);
        if(ids.length!==expectedIds.length||!expectedIds.every(id=>vis.datasets[id]))return;
        if(vis.layers.length!==expectedLayers.length||!expectedLayers.every(id=>vis.layers.some(layer=>layer.id===id)))return;
        clearTimeout(timeout);loadWaiter=null;resolve();
      };
      try {
        const loaded=KeplerGl.KeplerGlSchema.load(saved.datasets,saved.config);
        dispatch(KeplerGl.addDataToMap({...loaded,options:{centerMap:false,readOnly:true,keepExistingConfig:false}}));
        loadWaiter?.();
      }catch(error){clearTimeout(timeout);loadWaiter=null;reject(error);}
    });
  }
  async function drainScenes() {
    if(processing||!initialised||loadFailed)return;
    processing=true;
    while(pendingScene&&!loadFailed) {
      const command=pendingScene;pendingScene=null;
      mapRoot.dataset.ready='false';
      mapRoot.dataset.scene=command.scene;mapRoot.dataset.scenario=command.scenario;mapRoot.dataset.view=command.view;
      status(activeScene?'Updating map':'Loading map');
      try {
        const saved=await prepareScene(command);
        if(pendingScene)continue; // A newer intent arrived while fetching assets.
        await waitForMapRegistration();
        sceneRevision++;
        // Commands are serialised through completion of Kepler's dataset Task.
        // A stale async dataset result therefore cannot join a later scene.
        await submitSavedMap(saved);
        activeScene=command;
        const visibleIds=new Set();
        for(const layer of saved.config.config.visState.layers) {
          if(layer.type!=='point'||!layer.config.isVisible)continue;
          const table=saved.datasets.find(dataset=>dataset.data.id===layer.config.dataId)?.data;
          const idIndex=table?.fields.findIndex(field=>field.name==='aed_id')??-1;
          if(idIndex>=0)for(const row of table.allData)visibleIds.add(row[idIndex]);
        }
        visibleAEDs=Array.from(visibleIds,id=>aedById.get(id)).filter(Boolean);
        const group=command.scene==='case'?'case':command.scene==='find'?'participation':'national';
        if(group!==currentCameraGroup) {
          currentCameraGroup=group;
          overviewCamera=group!=='case';
          dispatch(KeplerGl.updateMap({...resetView(),...cameraTransition()}));
        }
        if(pendingView){const view=pendingView;pendingView=null;setView(view);}
        // Wait two paints so Kepler's own previousLayers reconciliation runs first.
        await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
        queueOverlaySync();
        syncSelection();
        await waitForScenePaint();
        if(!pendingScene){
          status('');mapRoot.dataset.ready='true';
          send('sceneApplied',{requestId:command.requestId,scene:command.scene,scenario:command.scenario,view:command.view});
        }
        debug('[AED map] Scene applied',{scene:command.scene,scenario:command.scenario,view:command.view,requestId:command.requestId,rows:saved.datasets.map(d=>[d.data.id,d.data.allData.length])});
      }catch(error){fail(error);}
    }
    processing=false;
    // Cleanup waits until Kepler has fully committed the new scene. It must
    // never race the native previousLayers removal during an async load.
    requestAnimationFrame(()=>requestAnimationFrame(queueOverlaySync));
    if(pendingScene&&!loadFailed)drainScenes();
  }

  function waitForScenePaint() {
    return new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{renderWaiter=null;reject(new Error('The map did not finish drawing'));},20000);
      renderWaiter=()=>{
        if(!map?.isStyleLoaded())return;
        const vis=state()?.visState;
        if(!vis)return;
        for(const layer of vis.layers) {
          if(layer.overlayType==='mapboxgl'&&layer.config.isVisible&&!map.getLayer(layer.id))return;
          if(layer.type==='heatmap'&&map.getLayer(layer.id)&&JSON.stringify(map.getPaintProperty(layer.id,'heatmap-intensity'))!==JSON.stringify(['interpolate',['linear'],['zoom'],0,0.12,18,0.36]))return;
        }
        clearTimeout(timeout);renderWaiter=null;
        requestAnimationFrame(()=>requestAnimationFrame(resolve));
      };
      queueOverlaySync();
    });
  }

  function synchronizeOverlays() {
    // isStyleLoaded also waits for all remote tiles. A parsed style can accept
    // overlays sooner, so do not leave a native high-intensity layer visible
    // while a remote tile is still arriving. Style mutations are guarded below.
    if(!map?.getStyle()?.layers||!state())return;
    const vis=state().visState;
    // Reconcile all current MapLibre layers, including hidden ones, to cooperate
    // with Kepler's previousLayers bookkeeping instead of racing its removals.
    const currentIds=new Set(),currentSources=new Set();
    vis.layers.forEach((layer,index)=>{
      if(layer.overlayType!=='mapboxgl')return;
      const generated=vis.layerData[index];
      if(!generated?.config||!generated?.data)return;
      const sourceId=generated.config.source;
      currentIds.add(layer.id);currentSources.add(sourceId);
      managedOverlayIds.add(layer.id);managedSourceIds.add(sourceId);
      const source=map.getSource(sourceId);
      if(!source){map.addSource(sourceId,{type:'geojson',data:generated.data});map.getSource(sourceId).__aedData=generated.data;}
      else if(source.__aedData!==generated.data){source.setData(generated.data);source.__aedData=generated.data;}
      if(!map.getLayer(layer.id))map.addLayer(generated.config);
      const visibility=layer.config.isVisible?'visible':'none';
      if(map.getLayoutProperty(layer.id,'visibility')!==visibility)map.setLayoutProperty(layer.id,'visibility',visibility);
      if(layer.type==='heatmap') {
        const intensity=['interpolate',['linear'],['zoom'],0,0.12,18,0.36];
        const expectedPaint={
          'heatmap-intensity':intensity,
          'heatmap-radius':['interpolate',['linear'],['zoom'],0,2,18,22],
          'heatmap-opacity':0.42,
          'heatmap-weight':1
        };
        for(const [key,value]of Object.entries(expectedPaint))if(JSON.stringify(map.getPaintProperty(layer.id,key))!==JSON.stringify(value))map.setPaintProperty(layer.id,key,value);
      }
    });
    // Kepler removes obsolete native layers itself. Its remover has no exists
    // check, so we only collect leftovers after the new scene is fully ready.
    // In particular, the transient empty visState during dataset creation must
    // not cause us to remove a layer that Kepler still plans to remove.
    if(!processing&&mapRoot.dataset.ready==='true') {
      for(const id of managedOverlayIds)if(!currentIds.has(id)&&map.getLayer(id))map.removeLayer(id);
      for(const sourceId of managedSourceIds) {
        const used=map.getStyle().layers.some(layer=>layer.source===sourceId);
        if(!currentSources.has(sourceId)&&!used&&map.getSource(sourceId))map.removeSource(sourceId);
      }
    }
    syncSelection();
    if(map.isStyleLoaded()) {
      const request=activeScene?.requestId;
      if(activeScene?.scene==='density'&&loggedHeatRequest!==request) {
        const heat=vis.layers.find(layer=>layer.type==='heatmap');
        if(heat&&map.getLayer(heat.id)) {
          const index=vis.layers.indexOf(heat);
          debug('[AED map] Heatmap paint',JSON.stringify({
            requestId:request,scene:activeScene.scene,scenario:activeScene.scenario,view:activeScene.view,
            zoom:map.getZoom(),layerId:heat.id,visibility:map.getLayoutProperty(heat.id,'visibility'),
            intensity:map.getPaintProperty(heat.id,'heatmap-intensity'),radius:map.getPaintProperty(heat.id,'heatmap-radius'),
            opacity:map.getPaintProperty(heat.id,'heatmap-opacity'),weight:map.getPaintProperty(heat.id,'heatmap-weight'),
            color:map.getPaintProperty(heat.id,'heatmap-color'),
            features:vis.layerData[index]?.data?.features?.length,
            configuredThreshold:heat.config.visConfig.threshold,
            mapLayerOrder:map.getStyle().layers.map(layer=>layer.id),
            keplerLayerOrder:vis.layers.map(layer=>({id:layer.id,visible:layer.config.isVisible,type:layer.type}))
          }));
          loggedHeatRequest=request;
        }
      }
      renderWaiter?.();
    }
  }
  function queueOverlaySync() {
    if(syncQueued)return;
    syncQueued=true;const revision=sceneRevision;
    requestAnimationFrame(()=>{
      syncQueued=false;
      if(revision!==sceneRevision)return;
      try{synchronizeOverlays();}catch(error){console.warn('[AED map] Overlay not ready',error);}
    });
  }
  function receiveMapReference(reference) {
    if(!reference)return;
    map=reference.getMap();
    if(!map||observedMaps.has(map))return;
    observedMaps.add(map);
    map.scrollZoom?.disable();map.dragRotate?.disable();map.touchZoomRotate?.disable();
    map.on('idle',queueOverlaySync);
    map.on('style.load',queueOverlaySync);
    // Kepler can replace native paint after data or visibility changes. An
    // idempotent post-render correction keeps its fixed low intensity in force.
    map.on('render',queueOverlaySync);
    map.on('error',event=>console.warn('[AED map] Basemap resource',event.error?.message||event));
    queueOverlaySync();
  }

  function syncSelection() {
    if(!map?.isStyleLoaded())return;
    const sourceId='aed-selected-location',layerId='aed-selected-location-ring';
    const aed=selectedId?aedById.get(selectedId):null;
    const data={type:'FeatureCollection',features:aed?[{type:'Feature',geometry:{type:'Point',coordinates:[aed.longitude,aed.latitude]},properties:{aed_id:aed.aed_id}}]:[]};
    let source=map.getSource(sourceId);
    if(!source){map.addSource(sourceId,{type:'geojson',data});source=map.getSource(sourceId);}
    if(source.__aedSelectionRevision!==selectionRevision){source.setData(data);source.__aedSelectionRevision=selectionRevision;}
    if(!map.getLayer(layerId))map.addLayer({id:layerId,type:'circle',source:sourceId,paint:{'circle-radius':12,'circle-color':token('gray',1),'circle-opacity':0,'circle-stroke-color':token('teal',11),'circle-stroke-width':0.5,'circle-stroke-opacity':1}});
  }
  function selectAED(payload) {
    if(payload.aedId!==null&&!aedById.has(payload.aedId))return;
    selectedId=payload.aedId;selectionRevision++;
    syncSelection();
    if(payload.focus&&selectedId){const aed=aedById.get(selectedId);setView({longitude:aed.longitude,latitude:aed.latitude,zoom:16});}
    if(payload.aedId===null&&state())dispatch(KeplerGl.onMapClick());
  }
  function recordFromPicking(click) {
    const vis=state()?.visState;
    if(!click?.picked||!vis)return null;
    const layer=vis.layers[click.layer?.props?.idx]||vis.layers.find(item=>item.id===click.layer?.id||item.id===click.sourceLayer?.id);
    if(!layer||layer.type!=='point')return null;
    const dataset=vis.datasets[layer.config.dataId];
    const row=layer.getHoverData(click.object,dataset.dataContainer,dataset.fields,vis.animationConfig,click);
    const idField=dataset.fields.findIndex(field=>field.name==='aed_id');
    if(!row||idField<0)return null;
    const field=dataset.fields[idField];
    return aedById.get(String(row[idField]??row[field.fieldIdx]??click.object?.aed_id))||null;
  }
  function emitSelection(aed,via) {
    selectedId=aed.aed_id;selectionRevision++;overviewCamera=false;syncSelection();
    send('aedSelected',{aedId:aed.aed_id,coordinates:[aed.longitude,aed.latitude]});
    debug('[AED map] Selection',JSON.stringify({via,aedId:aed.aed_id}));
  }
  function pickVisibleAED(x,y) {
    try {
      if(deck?.pickObject) {
        const hit=recordFromPicking(deck.pickObject({x,y,radius:6}));
        if(hit)return {aed:hit,via:'pointer/deck'};
      }
      const hover=state()?.visState.hoverInfo;
      if(hover?.picked&&Math.hypot((hover.x??Infinity)-x,(hover.y??Infinity)-y)<=12) {
        const hit=recordFromPicking(hover);
        if(hit)return {aed:hit,via:'pointer/hover'};
      }
      // The fallback uses only AEDs actually drawn in the current point scene.
      // Coincident devices keep their real coordinates; the parent presents the
      // complete same-location list instead of inventing separated positions.
      if(map) {
        let best=null,bestDistance=81;
        for(const aed of visibleAEDs) {
          const pixel=map.project([aed.longitude,aed.latitude]);
          const distance=(pixel.x-x)**2+(pixel.y-y)**2;
          if(distance<bestDistance){bestDistance=distance;best=aed;}
        }
        if(best)return{aed:best,via:'pointer/projected'};
      }
    }catch(error){console.warn('[AED map] Point picking failed',error);}
    return null;
  }
  function handleStoreChange() {
    if(state())registrationWaiter?.();
    loadWaiter?.();
    const vis=state()?.visState;
    if(!vis||vis.clicked===lastClicked)return;
    lastClicked=vis.clicked;
    const click=vis.clicked;
    if(!click)return;
    debug('[AED map] Click',JSON.stringify({
      keys:Object.keys(click),picked:click.picked,idx:click.layer?.props?.idx,
      layerId:click.layer?.id,sourceLayerId:click.sourceLayer?.id,
      objectKeys:click.object&&typeof click.object==='object'?Object.keys(click.object):[],
      objectIndex:click.object?.index,index:click.index,processing,ready:mapRoot.dataset.ready
    }));
    if(!click.picked)return;
    try {
      const aed=recordFromPicking(click);
      if(!aed)return;
      emitSelection(aed,'kepler');
    }catch(error){console.warn('[AED map] Selection could not be resolved',error);}
  }
  function setView(payload) {
    if(!state()||!activeScene){pendingView=payload;return;}
    const current=state().mapState;
    overviewCamera=Boolean(payload.reset)&&currentCameraGroup!=='case';
    const view=payload.reset?resetView():{};
    if(Number.isFinite(payload.longitude))view.longitude=Math.max(-180,Math.min(180,payload.longitude));
    if(Number.isFinite(payload.latitude))view.latitude=Math.max(-85,Math.min(85,payload.latitude));
    if(Number.isFinite(payload.zoom))view.zoom=Math.max(8,Math.min(19,payload.zoom));
    if(Number.isFinite(payload.zoomDelta))view.zoom=Math.max(8,Math.min(19,current.zoom+payload.zoomDelta));
    dispatch(KeplerGl.updateMap({...view,pitch:0,bearing:0,dragRotate:false,...cameraTransition()}));
  }

  window.addEventListener('message',event=>{
    if(event.origin!==location.origin||event.source!==window.parent||event.data?.channel!==CHANNEL)return;
    const {type,payload}=event.data;
    if(type==='setScene'&&payload&&SCENES.has(payload.scene)&&Number.isFinite(payload.requestId)) {
      const command={scene:payload.scene,scenario:SCENARIOS.has(payload.scenario)?payload.scenario:'wd_night',view:VIEWS.has(payload.view)?payload.view:'overlay',requestId:payload.requestId};
      latestScene=command;pendingScene=command;mapRoot.dataset.ready='false';drainScenes();
    }else if(type==='setView'&&payload&&typeof payload==='object')setView(payload);
    else if(type==='selectAED'&&payload&&(typeof payload.aedId==='string'||payload.aedId===null))selectAED(payload);
    else if(type==='retry') {
      if(loadFailed||!initialised){location.reload();return;}
      pendingScene=latestScene;drainScenes();
    }
  });
  // Kepler 3.1.10 overrides deckGlProps.controller internally. Capture scroll
  // gestures and forward only their vertical distance to the same-origin parent.
  window.addEventListener('wheel',event=>{
    event.stopImmediatePropagation();
    if(event.ctrlKey)return;
    event.preventDefault();
    const scale=event.deltaMode===1?16:event.deltaMode===2?innerHeight:1;
    send('scroll',{deltaY:event.deltaY*scale});
  },{capture:true,passive:false});
  window.addEventListener('dblclick',event=>event.stopImmediatePropagation(),{capture:true});
  let touchY=null,touchStartY=null,touchMoved=false,suppressClickUntil=0;
  window.addEventListener('touchstart',event=>{
    event.stopImmediatePropagation();
    if(event.touches.length===1){touchY=touchStartY=event.touches[0].clientY;touchMoved=false;}
    else touchY=null;
  },{capture:true,passive:true});
  window.addEventListener('touchmove',event=>{
    event.stopImmediatePropagation();
    if(event.touches.length!==1||touchY===null)return;
    const y=event.touches[0].clientY;
    if(Math.abs(y-touchStartY)>6)touchMoved=true;
    if(touchMoved){event.preventDefault();send('scroll',{deltaY:touchY-y});}
    touchY=y;
  },{capture:true,passive:false});
  window.addEventListener('touchend',()=>{if(touchMoved)suppressClickUntil=Date.now()+350;touchY=null;},{capture:true,passive:true});
  window.addEventListener('click',event=>{if(Date.now()<suppressClickUntil){event.preventDefault();event.stopImmediatePropagation();}},{capture:true});
  let pointerStart=null;
  window.addEventListener('pointerdown',event=>{
    if(event.isPrimary===false||event.button>0||event.target.closest?.('a,button')){pointerStart=null;return;}
    pointerStart={id:event.pointerId,x:event.clientX,y:event.clientY,moved:false};
  },{capture:true,passive:true});
  window.addEventListener('pointermove',event=>{
    if(pointerStart?.id===event.pointerId&&Math.hypot(event.clientX-pointerStart.x,event.clientY-pointerStart.y)>6)pointerStart.moved=true;
  },{capture:true,passive:true});
  window.addEventListener('pointerup',event=>{
    const start=pointerStart;pointerStart=null;
    if(!start||start.id!==event.pointerId||start.moved||Date.now()<suppressClickUntil||mapRoot.dataset.ready!=='true')return;
    const result=pickVisibleAED(event.clientX,event.clientY);
    if(result)emitSelection(result.aed,result.via);
  },{capture:true,passive:true});
  window.addEventListener('pointercancel',()=>{pointerStart=null;},{capture:true,passive:true});

  function MapCanvas() {
    const [size,setSize]=React.useState(()=>({width:Math.max(1,mapRoot.clientWidth),height:Math.max(1,mapRoot.clientHeight)}));
    React.useEffect(()=>{
      const observer=new ResizeObserver(entries=>{
        const box=entries[0].contentRect;
        const next={width:Math.max(1,Math.round(box.width)),height:Math.max(1,Math.round(box.height))};
        setSize(previous=>previous.width===next.width&&previous.height===next.height?previous:next);
        if(overviewCamera&&state()&&activeScene&&currentCameraGroup!=='case'&&!selectedId)requestAnimationFrame(()=>dispatch(KeplerGl.updateMap({...nationalView(),transitionDuration:0})));
      });
      observer.observe(mapRoot);return()=>observer.disconnect();
    },[]);
    return React.createElement(KeplerGl.KeplerGl,{id:MAP_ID,width:size.width,height:size.height,mint:true,mapboxApiAccessToken:'',mapStyles:[mapStyle],mapStylesReplaceDefault:true,initialUiState:UI,getMapboxRef:receiveMapReference,onMapStyleLoaded:queueOverlaySync,onDeckInitialized:instance=>{if(instance)deck=instance;},theme,locale:'en',deckGlProps:{touchAction:'pan-y'}});
  }
  async function boot() {
    try {
      if(!window.React||!window.ReactDOM||!window.Redux||!window.ReactRedux||!window.KeplerGl?.KeplerGlSchema?.load)throw new Error('The local map runtime did not load');
      [palette,aeds]=await Promise.all([fetchJSON('radix-palette.json'),fetchJSON('../data/aeds.json')]);
      aedById=new Map(aeds.map(aed=>[aed.aed_id,aed]));
      for(const values of Object.values(palette))for(const [name,value]of Object.entries(values))document.documentElement.style.setProperty(`--${name}`,value);
      mapStyle={id:STYLE_ID,label:'AED Access',url:new URL('basemap-radix.json',location.href).href};
      theme={fontFamily:'Arial, Helvetica, sans-serif',fontSize:'12px',fontSizeSmall:'12px',fontSizeMedium:'12px',fontSizeLarge:'16px',titleFontSize:'16px',textColor:token('gray',12),textColorHl:token('gray',12),subtextColor:token('gray',11),labelColor:token('gray',11),textColorLT:token('gray',11),panelBackground:token('gray',2),panelBackgroundHover:token('gray',3),panelBorderColor:token('gray',6),inputBgd:token('gray',3),inputColor:token('gray',12),inputBorderColor:token('gray',7),tooltipBg:token('gray',2),tooltipColor:token('gray',12),tooltipFontSize:'12px',modalBackground:token('gray',2),mapPanelBackgroundColor:token('gray',2),mapPanelColor:token('gray',12),mapPanelColorMuted:token('gray',11),mapPanelHeaderBorderColor:token('gray',6),mapControlButtonBgColor:token('gray',2),mapControlButtonTextColor:token('gray',11),mapControlButtonHoverBgColor:token('gray',3),primaryBtnBgd:token('teal',9),primaryBtnActBgd:token('teal',10),linkColor:token('teal',11),errorColor:token('tomato',11),warningColor:token('amber',11)};
      const reducer=KeplerGl.keplerGlReducer.initialState({uiState:UI,mapState:nationalView(),mapStyle:{styleType:STYLE_ID,mapStyles:{[STYLE_ID]:mapStyle}}});
      store=Redux.createStore(Redux.combineReducers({keplerGl:reducer}),{},Redux.applyMiddleware(...KeplerGl.enhanceReduxMiddleware([])));
      store.subscribe(handleStoreChange);
      class MapErrorBoundary extends React.Component {
        constructor(props){super(props);this.state={failed:false};}
        static getDerivedStateFromError(){return{failed:true};}
        componentDidCatch(error){loadFailed=true;fail(error);}
        render(){return this.state.failed?null:this.props.children;}
      }
      root=ReactDOM.createRoot(mapRoot);
      root.render(React.createElement(ReactRedux.Provider,{store},React.createElement(MapErrorBoundary,null,React.createElement(MapCanvas))));
      initialised=true;
      await waitForMapRegistration();
      send('ready');
      drainScenes();
    }catch(error){loadFailed=true;fail(error);}
  }
  boot();
})();
