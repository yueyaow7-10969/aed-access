const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./index-BOotR11c.js","./expression-Bl_GL2tO.js","./index-DbGrL1aJ.js","./index-DOLaeFR9.css","./maplibre-gl-Dypa9OOQ.js","./maplibre-gl-B-YMMjus.css","./index-B_hu9CzQ.js"])))=>i.map(i=>d[i]);
var om=Object.defineProperty;var am=(i,e,t)=>e in i?om(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var h=(i,e,t)=>am(i,typeof e!="symbol"?e+"":e,t);import{_ as Os,g as cm,r as Ce,j as le,P as lm,M as um,A as fm,a as dm,C as hm,b as gm,R as pm}from"./index-DbGrL1aJ.js";import{m as mm}from"./maplibre-gl-Dypa9OOQ.js";function Bs(i,e){if(!i)throw new Error(e||"loader assertion failed.")}const wc=!!(typeof process!="object"||String(process)!=="[object process]"||process.browser),El=typeof process<"u"&&process.version&&/v([0-9]*)/.exec(process.version);El&&parseFloat(El[1]);const Pt=globalThis,Yt=globalThis.process||{},_m=globalThis.navigator||{};function Vd(i){var n,s;if(typeof window<"u"&&((n=window.process)==null?void 0:n.type)==="renderer"||typeof process<"u"&&((s=process.versions)!=null&&s.electron))return!0;const t=typeof navigator<"u"&&navigator.userAgent;return!!(t&&t.indexOf("Electron")>=0)}function Pi(){return!(typeof process=="object"&&String(process)==="[object process]"&&!(process!=null&&process.browser))||Vd()}function ym(i){return Pi()?Vd()?"Electron":(_m.userAgent||"").indexOf("Edge")>-1?"Edge":globalThis.chrome?"Chrome":globalThis.safari?"Safari":globalThis.mozInnerScreenX?"Firefox":"Unknown":"Node"}const Wd="4.1.2";function xc(i,e){if(!i)throw new Error("Assertion failed")}function Hd(i){if(!i)return 0;let e;switch(typeof i){case"number":e=i;break;case"object":e=i.logLevel||i.priority||0;break;default:return 0}return xc(Number.isFinite(e)&&e>=0),e}function bm(i){const{logLevel:e,message:t}=i;i.logLevel=Hd(e);const n=i.args?Array.from(i.args):[];for(;n.length&&n.shift()!==t;);switch(typeof e){case"string":case"function":t!==void 0&&n.unshift(t),i.message=e;break;case"object":Object.assign(i,e);break}typeof i.message=="function"&&(i.message=i.message());const s=typeof i.message;return xc(s==="string"||s==="object"),Object.assign(i,{args:n},i.opts)}const ii=()=>{};class vm{constructor({level:e=0}={}){this.userData={},this._onceCache=new Set,this._level=e}set level(e){this.setLevel(e)}get level(){return this.getLevel()}setLevel(e){return this._level=e,this}getLevel(){return this._level}warn(e,...t){return this._log("warn",0,e,t,{once:!0})}error(e,...t){return this._log("error",0,e,t)}log(e,t,...n){return this._log("log",e,t,n)}info(e,t,...n){return this._log("info",e,t,n)}once(e,t,...n){return this._log("once",e,t,n,{once:!0})}_log(e,t,n,s,r={}){const o=bm({logLevel:t,message:n,args:this._buildArgs(t,n,s),opts:r});return this._createLogFunction(e,o,r)}_buildArgs(e,t,n){return[e,t,...n]}_createLogFunction(e,t,n){if(!this._shouldLog(t.logLevel))return ii;const s=this._getOnceTag(n.tag??t.tag??t.message);if((n.once||t.once)&&s!==void 0){if(this._onceCache.has(s))return ii;this._onceCache.add(s)}return this._emit(e,t)}_shouldLog(e){return this.getLevel()>=Hd(e)}_getOnceTag(e){if(e!==void 0)try{return typeof e=="string"?e:String(e)}catch{return}}}function wm(i){try{const e=window[i],t="__storage_test__";return e.setItem(t,t),e.removeItem(t),e}catch{return null}}class xm{constructor(e,t,n="sessionStorage"){this.storage=wm(n),this.id=e,this.config=t,this._loadConfiguration()}getConfiguration(){return this.config}setConfiguration(e){if(Object.assign(this.config,e),this.storage){const t=JSON.stringify(this.config);this.storage.setItem(this.id,t)}}_loadConfiguration(){let e={};if(this.storage){const t=this.storage.getItem(this.id);e=t?JSON.parse(t):{}}return Object.assign(this.config,e),this}}function Pm(i){let e;return i<10?e=`${i.toFixed(2)}ms`:i<100?e=`${i.toFixed(1)}ms`:i<1e3?e=`${i.toFixed(0)}ms`:e=`${(i/1e3).toFixed(2)}s`,e}function Sm(i,e=8){const t=Math.max(e-i.length,0);return`${" ".repeat(t)}${i}`}var ks;(function(i){i[i.BLACK=30]="BLACK",i[i.RED=31]="RED",i[i.GREEN=32]="GREEN",i[i.YELLOW=33]="YELLOW",i[i.BLUE=34]="BLUE",i[i.MAGENTA=35]="MAGENTA",i[i.CYAN=36]="CYAN",i[i.WHITE=37]="WHITE",i[i.BRIGHT_BLACK=90]="BRIGHT_BLACK",i[i.BRIGHT_RED=91]="BRIGHT_RED",i[i.BRIGHT_GREEN=92]="BRIGHT_GREEN",i[i.BRIGHT_YELLOW=93]="BRIGHT_YELLOW",i[i.BRIGHT_BLUE=94]="BRIGHT_BLUE",i[i.BRIGHT_MAGENTA=95]="BRIGHT_MAGENTA",i[i.BRIGHT_CYAN=96]="BRIGHT_CYAN",i[i.BRIGHT_WHITE=97]="BRIGHT_WHITE"})(ks||(ks={}));const Em=10;function Cl(i){return typeof i!="string"?i:(i=i.toUpperCase(),ks[i]||ks.WHITE)}function Cm(i,e,t){return!Pi&&typeof i=="string"&&(e&&(i=`\x1B[${Cl(e)}m${i}\x1B[39m`),t&&(i=`\x1B[${Cl(t)+Em}m${i}\x1B[49m`)),i}function Lm(i,e=["constructor"]){const t=Object.getPrototypeOf(i),n=Object.getOwnPropertyNames(t),s=i;for(const r of n){const o=s[r];typeof o=="function"&&(e.find(a=>r===a)||(s[r]=o.bind(i)))}}class Yd{getHighResolutionTimer(){var t,n,s;let e;if(Pi()&&Pt.performance)e=(n=(t=Pt==null?void 0:Pt.performance)==null?void 0:t.now)==null?void 0:n.call(t);else if("hrtime"in Yt){const r=(s=Yt==null?void 0:Yt.hrtime)==null?void 0:s.call(Yt);e=r[0]*1e3+r[1]/1e6}else e=Date.now();return e}getMemoryUsageMB(){var n;const e=Pt==null?void 0:Pt.performance,t=(n=e==null?void 0:e.memory)==null?void 0:n.usedJSHeapSize;return t==null?null:Math.trunc(t/1024/1024)}}const Lt=new Yd;globalThis.Probe=Yd;globalThis.probe=Lt;const qt={debug:Pi()&&console.debug||console.log,log:console.log,info:console.info,warn:console.warn,error:console.error},Jr={enabled:!0,level:0};class Tn extends vm{constructor({id:e}={id:""}){super({level:0}),this.VERSION=Wd,this._startTs=Lt.getHighResolutionTimer(),this._deltaTs=Lt.getHighResolutionTimer(),this.userData={},this.LOG_THROTTLE_TIMEOUT=0,this.id=e,this.userData={},this._storage=new xm(`__probe-${this.id}__`,{[this.id]:Jr}),this.timeStamp(`${this.id} started`),Lm(this),Object.seal(this)}isEnabled(){return this._getConfiguration().enabled}getLevel(){return this._getConfiguration().level}getTotal(){return Number((Lt.getHighResolutionTimer()-this._startTs).toPrecision(10))}getDelta(){return Number((Lt.getHighResolutionTimer()-this._deltaTs).toPrecision(10))}set priority(e){this.level=e}get priority(){return this.level}getPriority(){return this.level}enable(e=!0){return this._updateConfiguration({enabled:e}),this}setLevel(e){return this._updateConfiguration({level:e}),this}get(e){return this._getConfiguration()[e]}set(e,t){this._updateConfiguration({[e]:t})}settings(){console.table?console.table(this._storage.config):console.log(this._storage.config)}assert(e,t){if(!e)throw new Error(t||"Assertion failed")}warn(e,...t){return this._log("warn",0,e,t,{method:qt.warn,once:!0})}error(e,...t){return this._log("error",0,e,t,{method:qt.error})}deprecated(e,t){return this.warn(`\`${e}\` is deprecated and will be removed in a later version. Use \`${t}\` instead`)}removed(e,t){return this.error(`\`${e}\` has been removed. Use \`${t}\` instead`)}probe(e,t,...n){const s=Lt.getMemoryUsageMB();if(s!==null){const r=`${s}MB `;typeof t=="function"?t=()=>`${r}${t()}`:typeof t=="string"&&(t=`${r}${t}`)}return this._log("log",e,t,n,{method:qt.log,time:!0,once:!0})}log(e,t,...n){return this._log("log",e,t,n,{method:qt.debug})}info(e,t,...n){return this._log("info",e,t,n,{method:console.info})}once(e,t,...n){return this._log("once",e,t,n,{method:qt.debug||qt.info,once:!0})}table(e,t,n){return t?this._log("table",e,t,n&&[n]||[],{method:console.table||ii,tag:Am(t)}):ii}time(e,t){return this._log("time",e,t,[],{method:console.time?console.time:console.info})}timeEnd(e,t){return this._log("time",e,t,[],{method:console.timeEnd?console.timeEnd:console.info})}timeStamp(e,t){return this._log("time",e,t,[],{method:console.timeStamp||ii})}group(e,t,n={collapsed:!1}){const s=(n.collapsed?console.groupCollapsed:console.group)||console.info;return this._log("group",e,t,[],{method:s})}groupCollapsed(e,t,n={}){return this.group(e,t,Object.assign({},n,{collapsed:!0}))}groupEnd(e){return this._log("groupEnd",e,"",[],{method:console.groupEnd||ii})}withGroup(e,t,n){this.group(e,t)();try{n()}finally{this.groupEnd(e)()}}trace(){console.trace&&console.trace()}_shouldLog(e){return this.isEnabled()&&super._shouldLog(e)}_emit(e,t){const n=t.method;xc(n),t.total=this.getTotal(),t.delta=this.getDelta(),this._deltaTs=Lt.getHighResolutionTimer();const s=Tm(this.id,t.message,t);return n.bind(console,s,...t.args)}_getConfiguration(){return this._storage.config[this.id]||this._updateConfiguration(Jr),this._storage.config[this.id]}_updateConfiguration(e){const t=this._storage.config[this.id]||{...Jr};this._storage.setConfiguration({[this.id]:{...t,...e}})}}Tn.VERSION=Wd;function Tm(i,e,t){if(typeof e=="string"){const n=t.time?Sm(Pm(t.total)):"";e=t.time?`${i}: ${n}  ${e}`:`${i}: ${e}`,e=Cm(e,t.color,t.background)}return e}function Am(i){for(const e in i)for(const t in i[e])return t||"untitled";return"empty"}const eo="4.5.4",Mm=eo[0]>="0"&&eo[0]<="9"?`v${eo}`:"";function Im(){const i=new Tn({id:"loaders.gl"});return globalThis.loaders||(globalThis.loaders={}),globalThis.loaders.log=i,globalThis.loaders.version=Mm,globalThis.probe||(globalThis.probe={}),globalThis.probe.loaders=i,i}const Rm=Im(),Om=i=>typeof i=="boolean",Je=i=>typeof i=="function",jt=i=>i!==null&&typeof i=="object",Ll=i=>jt(i)&&i.constructor==={}.constructor,qd=i=>typeof SharedArrayBuffer<"u"&&i instanceof SharedArrayBuffer,Pc=i=>jt(i)&&typeof i.byteLength=="number"&&typeof i.slice=="function",Bm=i=>!!i&&Je(i[Symbol.iterator]),km=i=>!!i&&Je(i[Symbol.asyncIterator]),Vt=i=>typeof Response<"u"&&i instanceof Response||jt(i)&&Je(i.arrayBuffer)&&Je(i.text)&&Je(i.json),Wt=i=>typeof Blob<"u"&&i instanceof Blob,Dm=i=>typeof ReadableStream<"u"&&i instanceof ReadableStream||jt(i)&&Je(i.tee)&&Je(i.cancel)&&Je(i.getReader),Fm=i=>jt(i)&&Je(i.read)&&Je(i.pipe)&&Om(i.readable),Zd=i=>Dm(i)||Fm(i);function zm(i,e){return Xd(i||{},e)}function Xd(i,e,t=0){if(t>3)return e;const n={...i};for(const[s,r]of Object.entries(e))r&&typeof r=="object"&&!Array.isArray(r)?n[s]=Xd(n[s]||{},e[s],t+1):n[s]=e[s];return n}const Nm="latest";function Um(){var i;return(i=globalThis._loadersgl_)!=null&&i.version||(globalThis._loadersgl_=globalThis._loadersgl_||{},globalThis._loadersgl_.version="4.5.4"),globalThis._loadersgl_.version}const $m=Um();function yt(i,e){if(!i)throw new Error(e||"loaders.gl assertion failed.")}const It=typeof process!="object"||String(process)!=="[object process]"||process.browser,Gm=typeof window<"u"&&typeof window.orientation<"u",Tl=typeof process<"u"&&process.version&&/v([0-9]*)/.exec(process.version);Tl&&parseFloat(Tl[1]);class jm{constructor(e,t){h(this,"name");h(this,"workerThread");h(this,"isRunning",!0);h(this,"result");h(this,"_resolve",()=>{});h(this,"_reject",()=>{});this.name=e,this.workerThread=t,this.result=new Promise((n,s)=>{this._resolve=n,this._reject=s})}postMessage(e,t){this.workerThread.postMessage({source:"loaders.gl",type:e,payload:t})}done(e){yt(this.isRunning),this.isRunning=!1,this._resolve(e)}error(e){yt(this.isRunning),this.isRunning=!1,this._reject(e)}}class to{terminate(){}}const io=new Map;function Vm(i){yt(i.source&&!i.url||!i.source&&i.url);let e=io.get(i.source||i.url);return e||(i.url&&(e=Wm(i.url),io.set(i.url,e)),i.source&&(e=Kd(i.source),io.set(i.source,e))),yt(e),e}function Wm(i){if(!i.startsWith("http"))return i;const e=Hm(i);return Kd(e)}function Kd(i){const e=new Blob([i],{type:"application/javascript"});return URL.createObjectURL(e)}function Hm(i){return`try {
  importScripts('${i}');
} catch (error) {
  console.error(error);
  throw error;
}`}function Qd(i,e=!0,t){const n=t||new Set;if(i){if(Al(i))n.add(i);else if(Al(i.buffer))n.add(i.buffer);else if(!ArrayBuffer.isView(i)){if(e&&typeof i=="object")for(const s in i)Qd(i[s],e,n)}}return t===void 0?Array.from(n):[]}function Al(i){return i?i instanceof ArrayBuffer||typeof MessagePort<"u"&&i instanceof MessagePort||typeof ImageBitmap<"u"&&i instanceof ImageBitmap||typeof OffscreenCanvas<"u"&&i instanceof OffscreenCanvas:!1}const no=()=>{};class ca{constructor(e){h(this,"name");h(this,"source");h(this,"url");h(this,"terminated",!1);h(this,"worker");h(this,"onMessage");h(this,"onError");h(this,"_loadableURL","");const{name:t,source:n,url:s}=e;yt(n||s),this.name=t,this.source=n,this.url=s,this.onMessage=no,this.onError=r=>console.log(r),this.worker=It?this._createBrowserWorker():this._createNodeWorker()}static isSupported(){return typeof Worker<"u"&&It||typeof to<"u"&&!It}destroy(){this.onMessage=no,this.onError=no,this.worker.terminate(),this.terminated=!0}get isRunning(){return!!this.onMessage}postMessage(e,t){t=t||Qd(e),this.worker.postMessage(e,t)}_getErrorFromErrorEvent(e){let t="Failed to load ";return t+=`worker ${this.name} from ${this.url}. `,e.message&&(t+=`${e.message} in `),e.lineno&&(t+=`:${e.lineno}:${e.colno}`),new Error(t)}_createBrowserWorker(){this._loadableURL=Vm({source:this.source,url:this.url});const e=new Worker(this._loadableURL,{name:this.name});return e.onmessage=t=>{t.data?this.onMessage(t.data):this.onError(new Error("No data received"))},e.onerror=t=>{this.onError(this._getErrorFromErrorEvent(t)),this.terminated=!0},e.onmessageerror=t=>console.error(t),e}_createNodeWorker(){let e;if(this.url){const n=this.url.includes(":/")||this.url.startsWith("/")?this.url:`./${this.url}`,s=this.url.endsWith(".ts")||this.url.endsWith(".mjs")?"module":"commonjs";e=new to(n,{eval:!1,type:s})}else if(this.source)e=new to(this.source,{eval:!0});else throw new Error("no worker");return e.on("message",t=>{this.onMessage(t)}),e.on("error",t=>{this.onError(t)}),e.on("exit",t=>{}),e}}class Ym{constructor(e){h(this,"name","unnamed");h(this,"source");h(this,"url");h(this,"maxConcurrency",1);h(this,"maxMobileConcurrency",1);h(this,"onDebug",()=>{});h(this,"reuseWorkers",!0);h(this,"props",{});h(this,"jobQueue",[]);h(this,"idleQueue",[]);h(this,"count",0);h(this,"isDestroyed",!1);this.source=e.source,this.url=e.url,this.setProps(e)}static isSupported(){return ca.isSupported()}destroy(){this.idleQueue.forEach(e=>e.destroy()),this.isDestroyed=!0}setProps(e){this.props={...this.props,...e},e.name!==void 0&&(this.name=e.name),e.maxConcurrency!==void 0&&(this.maxConcurrency=e.maxConcurrency),e.maxMobileConcurrency!==void 0&&(this.maxMobileConcurrency=e.maxMobileConcurrency),e.reuseWorkers!==void 0&&(this.reuseWorkers=e.reuseWorkers),e.onDebug!==void 0&&(this.onDebug=e.onDebug)}async startJob(e,t=(s,r,o)=>s.done(o),n=(s,r)=>s.error(r)){const s=new Promise(r=>(this.jobQueue.push({name:e,onMessage:t,onError:n,onStart:r}),this));return this._startQueuedJob(),await s}async _startQueuedJob(){if(!this.jobQueue.length)return;const e=this._getAvailableWorker();if(!e)return;const t=this.jobQueue.shift();if(t){this.onDebug({message:"Starting job",name:t.name,workerThread:e,backlog:this.jobQueue.length});const n=new jm(t.name,e);e.onMessage=s=>t.onMessage(n,s.type,s.payload),e.onError=s=>t.onError(n,s),t.onStart(n);try{await n.result}catch(s){console.error(`Worker exception: ${s}`)}finally{this.returnWorkerToQueue(e)}}}returnWorkerToQueue(e){!It||this.isDestroyed||!this.reuseWorkers||this.count>this._getMaxConcurrency()?(e.destroy(),this.count--):this.idleQueue.push(e),this.isDestroyed||this._startQueuedJob()}_getAvailableWorker(){if(this.idleQueue.length>0)return this.idleQueue.shift()||null;if(this.count<this._getMaxConcurrency()){this.count++;const e=`${this.name.toLowerCase()} (#${this.count} of ${this.maxConcurrency})`;return new ca({name:e,source:this.source,url:this.url})}return null}_getMaxConcurrency(){return Gm?this.maxMobileConcurrency:this.maxConcurrency}}const qm={maxConcurrency:3,maxMobileConcurrency:1,reuseWorkers:!0,onDebug:()=>{}},ft=class ft{constructor(e){h(this,"props");h(this,"workerPools",new Map);this.props={...qm},this.setProps(e),this.workerPools=new Map}static isSupported(){return ca.isSupported()}static getWorkerFarm(e={}){return ft._workerFarm=ft._workerFarm||new ft({}),ft._workerFarm.setProps(e),ft._workerFarm}destroy(){for(const e of this.workerPools.values())e.destroy();this.workerPools=new Map}setProps(e){this.props={...this.props,...e};for(const t of this.workerPools.values())t.setProps(this._getWorkerPoolProps())}getWorkerPool(e){const{name:t,source:n,url:s}=e;let r=this.workerPools.get(t);return r||(r=new Ym({name:t,source:n,url:s}),r.setProps(this._getWorkerPoolProps()),this.workerPools.set(t,r)),r}_getWorkerPoolProps(){return{maxConcurrency:this.props.maxConcurrency,maxMobileConcurrency:this.props.maxMobileConcurrency,reuseWorkers:this.props.reuseWorkers,onDebug:this.props.onDebug}}};h(ft,"_workerFarm");let Ds=ft;function Zm(i,e={}){var o;const t=e[i.id]||{},n=It?i.workerFile||`${i.id}-worker.js`:`${i.id}-worker-node.js`;let s=t.workerUrl;if(!s&&i.id==="compression"&&(s=e.workerUrl),(e._workerType||((o=e==null?void 0:e.core)==null?void 0:o._workerType))==="test"&&(It?s=`modules/${i.module}/dist/${n}`:s=`modules/${i.module}/src/workers/${i.id}-worker-node.ts`),!s){let a=i.version;a==="latest"&&(a=Nm);const c=a?`@${a}`:"";s=`https://unpkg.com/@loaders.gl/${i.module}${c}/dist/${n}`}return yt(s),s}function Xm(i,e=$m){yt(i,"no worker provided");const t=i.version;return!(!e||!t)}function Km(i,e){var s,r;if(!Ds.isSupported())return!1;const t=(e==null?void 0:e._nodeWorkers)??((s=e==null?void 0:e.core)==null?void 0:s._nodeWorkers);if(!It&&!t)return!1;const n=(e==null?void 0:e.worker)??((r=e==null?void 0:e.core)==null?void 0:r.worker);return!!(i.worker&&n)}async function Qm(i,e,t,n,s){const r=i.id,o=Zm(i,t),c=Ds.getWorkerFarm(t==null?void 0:t.core).getWorkerPool({name:r,url:o});t=JSON.parse(JSON.stringify(t||{})),t._workerLoaderId=i.id,n=JSON.parse(JSON.stringify(n||{}));const l=await c.startJob("process-on-worker",Jm.bind(null,s));return l.postMessage("process",{input:e,options:t,context:n}),await(await l.result).result}async function Jm(i,e,t,n){switch(t){case"done":e.done(n);break;case"error":e.error(new Error(n.error));break;case"process":const{id:s,input:r,options:o}=n;try{const a=await i(r,o);e.postMessage("done",{id:s,result:a})}catch(a){const c=a instanceof Error?a.message:"unknown error";e.postMessage("error",{id:s,error:c})}break;default:console.warn(`parse-with-worker unknown message ${t}`)}}function e_(i,e,t){if(t=t||i.byteLength,i.byteLength<t||e.byteLength<t)return!1;const n=new Uint8Array(i),s=new Uint8Array(e);for(let r=0;r<n.length;++r)if(n[r]!==s[r])return!1;return!0}function t_(...i){return i_(i)}function i_(i){const e=i.map(r=>r instanceof ArrayBuffer?new Uint8Array(r):r),t=e.reduce((r,o)=>r+o.byteLength,0),n=new Uint8Array(t);let s=0;for(const r of e)n.set(r,s),s+=r.byteLength;return n.buffer}async function n_(i){const e=[];for await(const t of i)e.push(s_(t));return t_(...e)}function s_(i){if(i instanceof ArrayBuffer)return i;if(ArrayBuffer.isView(i)){const{buffer:e,byteOffset:t,byteLength:n}=i;return Ml(e,t,n)}return Ml(i)}function Ml(i,e=0,t=i.byteLength-e){const n=new Uint8Array(i,e,t),s=new Uint8Array(n.length);return s.set(n),s.buffer}function Il(){let i;if(typeof window<"u"&&window.performance)i=window.performance.now();else if(typeof process<"u"&&process.hrtime){const e=process.hrtime();i=e[0]*1e3+e[1]/1e6}else i=Date.now();return i}class Rl{constructor(e,t){this.sampleSize=1,this.time=0,this.count=0,this.samples=0,this.lastTiming=0,this.lastSampleTime=0,this.lastSampleCount=0,this._count=0,this._time=0,this._samples=0,this._startTime=0,this._timerPending=!1,this.name=e,this.type=t,this.reset()}reset(){return this.time=0,this.count=0,this.samples=0,this.lastTiming=0,this.lastSampleTime=0,this.lastSampleCount=0,this._count=0,this._time=0,this._samples=0,this._startTime=0,this._timerPending=!1,this}setSampleSize(e){return this.sampleSize=e,this}incrementCount(){return this.addCount(1),this}decrementCount(){return this.subtractCount(1),this}addCount(e){return this._count+=e,this._samples++,this._checkSampling(),this}subtractCount(e){return this._count-=e,this._samples++,this._checkSampling(),this}addTime(e){return this._time+=e,this.lastTiming=e,this._samples++,this._checkSampling(),this}timeStart(){return this._startTime=Il(),this._timerPending=!0,this}timeEnd(){return this._timerPending?(this.addTime(Il()-this._startTime),this._timerPending=!1,this._checkSampling(),this):this}getSampleAverageCount(){return this.sampleSize>0?this.lastSampleCount/this.sampleSize:0}getSampleAverageTime(){return this.sampleSize>0?this.lastSampleTime/this.sampleSize:0}getSampleHz(){return this.lastSampleTime>0?this.sampleSize/(this.lastSampleTime/1e3):0}getAverageCount(){return this.samples>0?this.count/this.samples:0}getAverageTime(){return this.samples>0?this.time/this.samples:0}getHz(){return this.time>0?this.samples/(this.time/1e3):0}_checkSampling(){this._samples===this.sampleSize&&(this.lastSampleTime=this._time,this.lastSampleCount=this._count,this.count+=this._count,this.time+=this._time,this.samples+=this._samples,this._time=0,this._count=0,this._samples=0)}}class Rr{constructor(e){this.stats={},this.id=e.id,this.stats={},this._initializeStats(e.stats),Object.seal(this)}get(e,t="count"){return this._getOrCreate({name:e,type:t})}get size(){return Object.keys(this.stats).length}reset(){for(const e of Object.values(this.stats))e.reset();return this}forEach(e){for(const t of Object.values(this.stats))e(t)}getTable(){const e={};return this.forEach(t=>{e[t.name]={time:t.time||0,count:t.count||0,average:t.getAverageTime()||0,hz:t.getHz()||0}}),e}_initializeStats(e=[]){e.forEach(t=>this._getOrCreate(t))}_getOrCreate(e){const{name:t,type:n}=e;let s=this.stats[t];return s||(e instanceof Rl?s=e:s=new Rl(t,n),this.stats[t]=s),s}}let r_="";const Ol={};function o_(i){for(const e in Ol)if(i.startsWith(e)){const t=Ol[e];i=i.replace(e,t)}return!i.startsWith("http://")&&!i.startsWith("https://")&&(i=`${r_}${i}`),i}function Jd(i){return i&&typeof i=="object"&&i.isBuffer}function Sc(i){if(Jd(i))return i;if(i instanceof ArrayBuffer)return i;if(qd(i))return la(i);if(ArrayBuffer.isView(i)){const e=i.buffer;return i.byteOffset===0&&i.byteLength===i.buffer.byteLength?e:e.slice(i.byteOffset,i.byteOffset+i.byteLength)}if(typeof i=="string"){const e=i;return new TextEncoder().encode(e).buffer}if(i&&typeof i=="object"&&i._toArrayBuffer)return i._toArrayBuffer();throw new Error("toArrayBuffer")}function eh(i){if(i instanceof ArrayBuffer)return i;if(qd(i))return la(i);const{buffer:e,byteOffset:t,byteLength:n}=i;return e instanceof ArrayBuffer&&t===0&&n===e.byteLength?e:la(e,t,n)}function la(i,e=0,t=i.byteLength-e){const n=new Uint8Array(i,e,t),s=new Uint8Array(n.length);return s.set(n),s.buffer}function a_(i){return ArrayBuffer.isView(i)?i:new Uint8Array(i)}function th(i){const e=i?i.lastIndexOf("/"):-1;return e>=0?i.substr(e+1):i}function ih(i){const e=i?i.lastIndexOf("/"):-1;return e>=0?i.substr(0,e):""}class c_ extends Error{constructor(t,n){super(t);h(this,"reason");h(this,"url");h(this,"response");this.reason=n.reason,this.url=n.url,this.response=n.response}}const l_=/^data:([-\w.]+\/[-\w.+]+)(;|,)/,u_=/^([-\w.]+\/[-\w.+]+)/;function Bl(i,e){return i.toLowerCase()===e.toLowerCase()}function f_(i){const e=u_.exec(i);return e?e[1]:i}function kl(i){const e=l_.exec(i);return e?e[1]:""}const nh=/\?.*/;function d_(i){const e=i.match(nh);return e&&e[0]}function Or(i){return i.replace(nh,"")}function h_(i){if(i.length<50)return i;const e=i.slice(i.length-15);return`${i.substr(0,32)}...${e}`}function Br(i){return Vt(i)?i.url:Wt(i)?("name"in i?i.name:"")||"":typeof i=="string"?i:""}function kr(i){if(Vt(i)){const e=i.headers.get("content-type")||"",t=Or(i.url);return f_(e)||kl(t)}return Wt(i)?i.type||"":typeof i=="string"?kl(i):""}function g_(i){return Vt(i)?i.headers["content-length"]||-1:Wt(i)?i.size:typeof i=="string"?i.length:i instanceof ArrayBuffer||ArrayBuffer.isView(i)?i.byteLength:-1}async function sh(i){if(Vt(i))return i;const e={},t=g_(i);t>=0&&(e["content-length"]=String(t));const n=Br(i),s=kr(i);s&&(e["content-type"]=s);const r=await __(i);r&&(e["x-first-bytes"]=r),typeof i=="string"&&(i=new TextEncoder().encode(i));const o=new Response(i,{headers:e});return Object.defineProperty(o,"url",{value:n}),o}async function p_(i){if(!i.ok)throw await m_(i)}async function m_(i){const e=h_(i.url);let t=`Failed to fetch resource (${i.status}) ${i.statusText}: ${e}`;t=t.length>100?`${t.slice(0,100)}...`:t;const n={reason:i.statusText,url:i.url,response:i};try{const s=i.headers.get("Content-Type");n.reason=!i.bodyUsed&&(s!=null&&s.includes("application/json"))?await i.json():await i.text()}catch{}return new c_(t,n)}async function __(i){if(typeof i=="string")return`data:,${i.slice(0,5)}`;if(i instanceof Blob){const t=i.slice(0,5);return await new Promise(n=>{const s=new FileReader;s.onload=r=>{var o;return n((o=r==null?void 0:r.target)==null?void 0:o.result)},s.readAsDataURL(t)})}if(i instanceof ArrayBuffer){const t=i.slice(0,5);return`data:base64,${y_(t)}`}return null}function y_(i){let e="";const t=new Uint8Array(i);for(let n=0;n<t.byteLength;n++)e+=String.fromCharCode(t[n]);return btoa(e)}function b_(i){return!v_(i)&&!w_(i)}function v_(i){return i.startsWith("http:")||i.startsWith("https:")}function w_(i){return i.startsWith("data:")}async function Dl(i,e){var t,n;if(typeof i=="string"){const s=o_(i);return b_(s)&&(t=globalThis.loaders)!=null&&t.fetchNode?(n=globalThis.loaders)==null?void 0:n.fetchNode(s,e):await fetch(s,e)}return await sh(i)}const Gn=new Tn({id:"loaders.gl"});class x_{log(){return()=>{}}info(){return()=>{}}warn(){return()=>{}}error(){return()=>{}}}class P_{constructor(){h(this,"console");this.console=console}log(...e){return this.console.log.bind(this.console,...e)}info(...e){return this.console.info.bind(this.console,...e)}warn(...e){return this.console.warn.bind(this.console,...e)}error(...e){return this.console.error.bind(this.console,...e)}}const ua={core:{baseUrl:void 0,fetch:null,mimeType:void 0,fallbackMimeType:void 0,ignoreRegisteredLoaders:void 0,nothrow:!1,log:new P_,useLocalLibraries:!1,CDN:"https://unpkg.com/@loaders.gl",worker:!0,maxConcurrency:3,maxMobileConcurrency:1,reuseWorkers:wc,_nodeWorkers:!1,_workerType:"",limit:0,_limitMB:0,batchSize:"auto",batchDebounceMs:0,metadata:!1,transforms:[]}},S_={baseUri:"core.baseUrl",fetch:"core.fetch",mimeType:"core.mimeType",fallbackMimeType:"core.fallbackMimeType",ignoreRegisteredLoaders:"core.ignoreRegisteredLoaders",nothrow:"core.nothrow",log:"core.log",useLocalLibraries:"core.useLocalLibraries",CDN:"core.CDN",worker:"core.worker",maxConcurrency:"core.maxConcurrency",maxMobileConcurrency:"core.maxMobileConcurrency",reuseWorkers:"core.reuseWorkers",_nodeWorkers:"core.nodeWorkers",_workerType:"core._workerType",_worker:"core._workerType",limit:"core.limit",_limitMB:"core._limitMB",batchSize:"core.batchSize",batchDebounceMs:"core.batchDebounceMs",metadata:"core.metadata",transforms:"core.transforms",throws:"nothrow",dataType:"(no longer used)",uri:"core.baseUrl",method:"core.fetch.method",headers:"core.fetch.headers",body:"core.fetch.body",mode:"core.fetch.mode",credentials:"core.fetch.credentials",cache:"core.fetch.cache",redirect:"core.fetch.redirect",referrer:"core.fetch.referrer",referrerPolicy:"core.fetch.referrerPolicy",integrity:"core.fetch.integrity",keepalive:"core.fetch.keepalive",signal:"core.fetch.signal"},Ec=["baseUrl","fetch","mimeType","fallbackMimeType","ignoreRegisteredLoaders","nothrow","log","useLocalLibraries","CDN","worker","maxConcurrency","maxMobileConcurrency","reuseWorkers","_nodeWorkers","_workerType","limit","_limitMB","batchSize","batchDebounceMs","metadata","transforms"];function rh(){globalThis.loaders=globalThis.loaders||{};const{loaders:i}=globalThis;return i._state||(i._state={}),i._state}function oh(){const i=rh();return i.globalOptions=i.globalOptions||{...ua,core:{...ua.core}},zt(i.globalOptions)}function E_(i,e,t,n){return t=t||[],t=Array.isArray(t)?t:[t],C_(i,t),zt(T_(e,i,n))}function zt(i){const e=M_(i);ah(e);for(const t of Ec)e.core&&e.core[t]!==void 0&&delete e[t];return e.core&&e.core._workerType!==void 0&&delete e._worker,e}function C_(i,e){Fl(i,null,ua,S_,e);for(const t of e){const n=i&&i[t.id]||{},s=t.options&&t.options[t.id]||{},r=t.deprecatedOptions&&t.deprecatedOptions[t.id]||{};Fl(n,t.id,s,r,e)}}function Fl(i,e,t,n,s){const r=e||"Top level",o=e?`${e}.`:"";for(const a in i){const c=!e&&jt(i[a]),l=a==="baseUri"&&!e,u=a==="workerUrl"&&e;if(!(a in t)&&!l&&!u){if(a in n)Gn.level>0&&Gn.warn(`${r} loader option '${o}${a}' no longer supported, use '${n[a]}'`)();else if(!c&&Gn.level>0){const f=L_(a,s);Gn.warn(`${r} loader option '${o}${a}' not recognized. ${f}`)()}}}}function L_(i,e){const t=i.toLowerCase();let n="";for(const s of e)for(const r in s.options){if(i===r)return`Did you mean '${s.id}.${r}'?`;const o=r.toLowerCase();(t.startsWith(o)||o.startsWith(t))&&(n=n||`Did you mean '${s.id}.${r}'?`)}return n}function T_(i,e,t){var o;const n=i.options||{},s={...n};n.core&&(s.core={...n.core}),ah(s),((o=s.core)==null?void 0:o.log)===null&&(s.core={...s.core,log:new x_}),zl(s,zt(oh()));const r=zt(e);return zl(s,r),A_(s,t),I_(s),s}function zl(i,e){for(const t in e)if(t in e){const n=e[t];Ll(n)&&Ll(i[t])?i[t]={...i[t],...e[t]}:i[t]=e[t]}}function A_(i,e){var n;if(!e)return;((n=i.core)==null?void 0:n.baseUrl)!==void 0||(i.core||(i.core={}),i.core.baseUrl=ih(Or(e)))}function M_(i){const e={...i};return i.core&&(e.core={...i.core}),e}function ah(i){i.baseUri!==void 0&&(i.core||(i.core={}),i.core.baseUrl===void 0&&(i.core.baseUrl=i.baseUri));for(const t of Ec)if(i[t]!==void 0){const s=i.core=i.core||{};s[t]===void 0&&(s[t]=i[t])}const e=i._worker;e!==void 0&&(i.core||(i.core={}),i.core._workerType===void 0&&(i.core._workerType=e))}function I_(i){const e=i.core;if(e)for(const t of Ec)e[t]!==void 0&&(i[t]=e[t])}function Cc(i){return i?(Array.isArray(i)&&(i=i[0]),Array.isArray(i==null?void 0:i.extensions)):!1}function Lc(i){Bs(i,"null loader"),Bs(Cc(i),"invalid loader");let e;return Array.isArray(i)&&(e=i[1],i=i[0],i={...i,options:{...i.options,...e}}),(i!=null&&i.parseTextSync||i!=null&&i.parseText)&&(i.text=!0),i.text||(i.binary=!0),i}const ch=()=>{const i=rh();return i.loaderRegistry=i.loaderRegistry||[],i.loaderRegistry};function R_(i){const e=ch();i=Array.isArray(i)?i:[i];for(const t of i){const n=Lc(t);e.find(s=>n===s)||e.unshift(n)}}function O_(){return ch()}const B_=/\.([^.]+)$/;async function k_(i,e=[],t,n){if(!lh(i))return null;const s=zt(t||{});if(s.core||(s.core={}),i instanceof Response&&Nl(i)){const o=await i.clone().text(),a=jn(o,e,{...s,core:{...s.core,nothrow:!0}},n);if(a)return a}let r=jn(i,e,{...s,core:{...s.core,nothrow:!0}},n);if(r)return r;if(Wt(i)&&(i=await i.slice(0,10).arrayBuffer(),r=jn(i,e,s,n)),!r&&i instanceof Response&&Nl(i)){const o=await i.clone().text();r=jn(o,e,s,n)}if(!r&&!s.core.nothrow)throw new Error(uh(i));return r}function Nl(i){const e=kr(i);return!!(e&&(e.startsWith("text/")||e==="application/json"||e.endsWith("+json")))}function jn(i,e=[],t,n){if(!lh(i))return null;const s=zt(t||{});if(s.core||(s.core={}),e&&!Array.isArray(e))return Lc(e);let r=[];e&&(r=r.concat(e)),s.core.ignoreRegisteredLoaders||r.push(...O_()),F_(r);const o=D_(i,r,s,n);if(!o&&!s.core.nothrow)throw new Error(uh(i));return o}function D_(i,e,t,n){var l,u,f,d,g;const s=Br(i),r=kr(i),o=Or(s)||(n==null?void 0:n.url);let a=null,c="";return(l=t==null?void 0:t.core)!=null&&l.mimeType&&(a=so(e,(u=t==null?void 0:t.core)==null?void 0:u.mimeType),c=`match forced by supplied MIME type ${(f=t==null?void 0:t.core)==null?void 0:f.mimeType}`),a=a||z_(e,o),c=c||(a?`matched url ${o}`:""),a=a||so(e,r),c=c||(a?`matched MIME type ${r}`:""),a=a||U_(e,i),c=c||(a?`matched initial data ${fh(i)}`:""),(d=t==null?void 0:t.core)!=null&&d.fallbackMimeType&&(a=a||so(e,(g=t==null?void 0:t.core)==null?void 0:g.fallbackMimeType),c=c||(a?`matched fallback MIME type ${r}`:"")),c&&Rm.log(1,`selectLoader selected ${a==null?void 0:a.name}: ${c}.`),a}function lh(i){return!(i instanceof Response&&i.status===204)}function uh(i){const e=Br(i),t=kr(i);let n="No valid loader found (";n+=e?`${th(e)}, `:"no url provided, ",n+=`MIME type: ${t?`"${t}"`:"not provided"}, `;const s=i?fh(i):"";return n+=s?` first bytes: "${s}"`:"first bytes: not available",n+=")",n}function F_(i){for(const e of i)Lc(e)}function z_(i,e){const t=e&&B_.exec(e),n=t&&t[1];return n?N_(i,n):null}function N_(i,e){e=e.toLowerCase();for(const t of i)for(const n of t.extensions)if(n.toLowerCase()===e)return t;return null}function so(i,e){var t;for(const n of i)if((t=n.mimeTypes)!=null&&t.some(s=>Bl(e,s))||Bl(e,`application/x.${n.id}`))return n;return null}function U_(i,e){if(!e)return null;for(const t of i)if(typeof e=="string"){if($_(e,t))return t}else if(ArrayBuffer.isView(e)){if(Ul(e.buffer,e.byteOffset,t))return t}else if(e instanceof ArrayBuffer&&Ul(e,0,t))return t;return null}function $_(i,e){return e.testText?e.testText(i):(Array.isArray(e.tests)?e.tests:[e.tests]).some(n=>i.startsWith(n))}function Ul(i,e,t){return(Array.isArray(t.tests)?t.tests:[t.tests]).some(s=>G_(i,e,t,s))}function G_(i,e,t,n){if(Pc(n))return e_(n,i,n.byteLength);switch(typeof n){case"function":return n(eh(i));case"string":const s=fa(i,e,n.length);return n===s;default:return!1}}function fh(i,e=5){return typeof i=="string"?i.slice(0,e):ArrayBuffer.isView(i)?fa(i.buffer,i.byteOffset,e):i instanceof ArrayBuffer?fa(i,0,e):""}function fa(i,e,t){if(i.byteLength<e+t)return"";const n=new DataView(i);let s="";for(let r=0;r<t;r++)s+=String.fromCharCode(n.getUint8(e+r));return s}const j_=256*1024;function*V_(i,e){const t=(e==null?void 0:e.chunkSize)||j_;let n=0;const s=new TextEncoder;for(;n<i.length;){const r=Math.min(i.length-n,t),o=i.slice(n,n+r);n+=r,yield eh(s.encode(o))}}const W_=256*1024;function*H_(i,e={}){const{chunkSize:t=W_}=e;let n=0;for(;n<i.byteLength;){const s=Math.min(i.byteLength-n,t),r=new ArrayBuffer(s),o=new Uint8Array(i,n,s);new Uint8Array(r).set(o),n+=s,yield r}}const Y_=1024*1024;async function*q_(i,e){const t=(e==null?void 0:e.chunkSize)||Y_;let n=0;for(;n<i.size;){const s=n+t,r=await i.slice(n,s).arrayBuffer();n=s,yield r}}function $l(i,e){return wc?Z_(i,e):X_(i)}async function*Z_(i,e){const t=i.getReader();let n;try{for(;;){const s=n||t.read();e!=null&&e._streamReadAhead&&(n=t.read());const{done:r,value:o}=await s;if(r)return;yield Sc(o)}}catch{t.releaseLock()}}async function*X_(i,e){for await(const t of i)yield Sc(t)}function K_(i,e){if(typeof i=="string")return V_(i,e);if(i instanceof ArrayBuffer)return H_(i,e);if(Wt(i))return q_(i,e);if(Zd(i))return $l(i,e);if(Vt(i)){const t=i.body;if(!t)throw new Error("Readable stream not available on Response");return $l(t,e)}throw new Error("makeIterator")}const dh="Cannot convert supplied data type";function Q_(i,e,t){if(e.text&&typeof i=="string")return i;if(Jd(i)&&(i=i.buffer),Pc(i)){const n=a_(i);return e.text&&!e.binary?new TextDecoder("utf8").decode(n):Sc(n)}throw new Error(dh)}async function J_(i,e,t){if(typeof i=="string"||Pc(i))return Q_(i,e);if(Wt(i)&&(i=await sh(i)),Vt(i))return await p_(i),e.binary?await i.arrayBuffer():await i.text();if(Zd(i)&&(i=K_(i,t)),Bm(i)||km(i))return n_(i);throw new Error(dh)}function hh(i,e){var r;const t=oh(),n=i||t,s=n.fetch??((r=n.core)==null?void 0:r.fetch);return typeof s=="function"?s:jt(s)?o=>Dl(o,s):e!=null&&e.fetch?e==null?void 0:e.fetch:Dl}function ey(i,e,t){if(t)return t;const n={fetch:hh(e,i),...i};if(n.url){const s=Or(n.url);n.baseUrl=s,n.queryString=d_(n.url),n.filename=th(s),n.baseUrl=ih(s)}return Array.isArray(n.loaders)||(n.loaders=null),n}function ty(i,e){if(i&&!Array.isArray(i))return i;let t;if(i&&(t=Array.isArray(i)?i:[i]),e&&e.loaders){const n=Array.isArray(e.loaders)?e.loaders:[e.loaders];t=t?[...t,...n]:n}return t&&t.length?t:void 0}async function Fs(i,e,t,n){e&&!Array.isArray(e)&&!Cc(e)&&(n=void 0,t=e,e=void 0),i=await i,t=t||{};const s=Br(i),o=ty(e,n),a=await k_(i,o,t);if(!a)return null;const c=E_(t,a,o,s);return n=ey({url:s,_parse:Fs,loaders:o},c,n||null),await iy(a,i,c,n)}async function iy(i,e,t,n){if(Xm(i),t=zm(i.options,t),Vt(e)){const{ok:r,redirected:o,status:a,statusText:c,type:l,url:u}=e,f=Object.fromEntries(e.headers.entries());n.response={headers:f,ok:r,redirected:o,status:a,statusText:c,type:l,url:u}}e=await J_(e,i,t);const s=i;if(s.parseTextSync&&typeof e=="string")return s.parseTextSync(e,t,n);if(Km(i,t))return await Qm(i,e,t,n,Fs);if(s.parseText&&typeof e=="string")return await s.parseText(e,t,n);if(s.parse)return await s.parse(e,t,n);throw yt(!s.parseSync),new Error(`${i.id} loader - no parser found and worker is disabled`)}function ny(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function sy(i){return Array.isArray(i)?i.length===0||typeof i[0]=="number":!1}function gh(i){return ny(i)||sy(i)}async function zs(i,e,t,n){var c;let s,r;!Array.isArray(e)&&!Cc(e)?(s=[],r=e):(s=e,r=t);const o=hh(r);let a=i;return typeof i=="string"&&(a=await o(i)),Wt(i)&&(a=await o(i)),typeof i=="string"&&((c=zt(r||{}).core)!=null&&c.baseUrl||(r={...r,core:{...r==null?void 0:r.core,baseUrl:i}})),Array.isArray(s)?await Fs(a,s,r):await Fs(a,s,r)}const ry="4.5.4";var jd;const oy=(jd=globalThis.loaders)==null?void 0:jd.parseImageNode,da=typeof Image<"u",ha=typeof ImageBitmap<"u",ay=!!oy,ga=wc?!0:ay;function cy(i){switch(i){case"auto":return ha||da||ga;case"imagebitmap":return ha;case"image":return da;case"data":return ga;default:throw new Error(`@loaders.gl/images: image ${i} not supported in this environment`)}}function ly(){if(ha)return"imagebitmap";if(da)return"image";if(ga)return"data";throw new Error("Install '@loaders.gl/polyfills' to parse images under Node.js")}function uy(i){const e=dy(i);if(!e)throw new Error("Not an image");return e}function fy(i){switch(uy(i)){case"data":return i;case"image":case"imagebitmap":const e=document.createElement("canvas"),t=e.getContext("2d");if(!t)throw new Error("getImageData");return e.width=i.width,e.height=i.height,t.drawImage(i,0,0),t.getImageData(0,0,i.width,i.height);default:throw new Error("getImageData")}}function dy(i){return typeof ImageBitmap<"u"&&i instanceof ImageBitmap?"imagebitmap":typeof Image<"u"&&i instanceof Image?"image":i&&typeof i=="object"&&i.data&&i.width&&i.height?"data":null}const hy=/^data:image\/svg\+xml/,gy=/\.svg((\?|#).*)?$/;function Tc(i){return i&&(hy.test(i)||gy.test(i))}function py(i,e){if(Tc(e)){let n=new TextDecoder().decode(i);try{typeof unescape=="function"&&typeof encodeURIComponent=="function"&&(n=unescape(encodeURIComponent(n)))}catch(r){throw new Error(r.message)}return`data:image/svg+xml;base64,${btoa(n)}`}return ph(i,e)}function ph(i,e){if(Tc(e))throw new Error("SVG cannot be parsed directly to imagebitmap");return new Blob([new Uint8Array(i)])}async function mh(i,e,t){const n=py(i,t),s=self.URL||self.webkitURL,r=typeof n!="string"&&s.createObjectURL(n);try{return await my(r||n,e)}finally{r&&s.revokeObjectURL(r)}}async function my(i,e){const t=new Image;return t.src=i,e.image&&e.image.decode&&t.decode?(await t.decode(),t):await new Promise((n,s)=>{try{t.onload=()=>n(t),t.onerror=r=>{const o=r instanceof Error?r.message:"error";s(new Error(o))}}catch(r){s(r)}})}let Gl=!0;async function _y(i,e,t){let n;Tc(t)?n=await mh(i,e,t):n=ph(i,t);const s=e&&e.imagebitmap;return await yy(n,s)}async function yy(i,e=null){if((by(e)||!Gl)&&(e=null),e)try{return await createImageBitmap(i,e)}catch(t){console.warn(t),Gl=!1}return await createImageBitmap(i)}function by(i){if(!i)return!0;for(const e in i)if(Object.prototype.hasOwnProperty.call(i,e))return!1;return!0}function vy(i){return!Sy(i,"ftyp",4)||(i[8]&96)===0?null:wy(i)}function wy(i){switch(xy(i,8,12).replace("\0"," ").trim()){case"avif":case"avis":return{extension:"avif",mimeType:"image/avif"};default:return null}}function xy(i,e,t){return String.fromCharCode(...i.slice(e,t))}function Py(i){return[...i].map(e=>e.charCodeAt(0))}function Sy(i,e,t=0){const n=Py(e);for(let s=0;s<n.length;++s)if(n[s]!==i[s+t])return!1;return!0}const Ze=!1,Ki=!0;function _h(i){const e=An(i);return Cy(e)||Ay(e)||Ly(e)||Ty(e)||Ey(e)}function Ey(i){const e=new Uint8Array(i instanceof DataView?i.buffer:i),t=vy(e);return t?{mimeType:t.mimeType,width:0,height:0}:null}function Cy(i){const e=An(i);return e.byteLength>=24&&e.getUint32(0,Ze)===2303741511?{mimeType:"image/png",width:e.getUint32(16,Ze),height:e.getUint32(20,Ze)}:null}function Ly(i){const e=An(i);return e.byteLength>=10&&e.getUint32(0,Ze)===1195984440?{mimeType:"image/gif",width:e.getUint16(6,Ki),height:e.getUint16(8,Ki)}:null}function Ty(i){const e=An(i);return e.byteLength>=14&&e.getUint16(0,Ze)===16973&&e.getUint32(2,Ki)===e.byteLength?{mimeType:"image/bmp",width:e.getUint32(18,Ki),height:e.getUint32(22,Ki)}:null}function Ay(i){const e=An(i);if(!(e.byteLength>=3&&e.getUint16(0,Ze)===65496&&e.getUint8(2)===255))return null;const{tableMarkers:n,sofMarkers:s}=My();let r=2;for(;r+9<e.byteLength;){const o=e.getUint16(r,Ze);if(s.has(o))return{mimeType:"image/jpeg",height:e.getUint16(r+5,Ze),width:e.getUint16(r+7,Ze)};if(!n.has(o))return null;r+=2,r+=e.getUint16(r,Ze)}return null}function My(){const i=new Set([65499,65476,65484,65501,65534]);for(let t=65504;t<65520;++t)i.add(t);return{tableMarkers:i,sofMarkers:new Set([65472,65473,65474,65475,65477,65478,65479,65481,65482,65483,65485,65486,65487,65502])}}function An(i){if(i instanceof DataView)return i;if(ArrayBuffer.isView(i))return new DataView(i.buffer);if(i instanceof ArrayBuffer)return new DataView(i);throw new Error("toDataView")}async function Iy(i,e){var s;const{mimeType:t}=_h(i)||{},n=(s=globalThis.loaders)==null?void 0:s.parseImageNode;return Bs(n),await n(i,t)}async function Ry(i,e,t){e=e||{};const s=(e.image||{}).type||"auto",{url:r}=t||{},o=Oy(s);let a;switch(o){case"imagebitmap":a=await _y(i,e,r);break;case"image":a=await mh(i,e,r);break;case"data":a=await Iy(i);break;default:Bs(!1)}return s==="data"&&(a=fy(a)),a}function Oy(i){switch(i){case"auto":case"data":return ly();default:return cy(i),i}}const By=["png","jpg","jpeg","gif","webp","bmp","ico","svg","avif"],ky=["image/png","image/jpeg","image/gif","image/webp","image/avif","image/bmp","image/vnd.microsoft.icon","image/svg+xml"],Dy={image:{type:"auto",decode:!0}},Fy={dataType:null,batchType:null,id:"image",module:"images",name:"Images",version:ry,mimeTypes:ky,extensions:By,parse:Ry,tests:[i=>!!_h(new DataView(i))],options:Dy},Y=new Tn({id:"deck"});let pa={};function zy(i){pa=i}function ye(i,e,t,n){Y.level>0&&pa[i]&&pa[i].call(null,e,t,n)}function Ny(i){const e=i[0],t=i[i.length-1];return e==="{"&&t==="}"||e==="["&&t==="]"}const Uy={dataType:null,batchType:null,id:"JSON",name:"JSON",module:"",version:"",options:{},extensions:["json","geojson"],mimeTypes:["application/json","application/geo+json"],testText:Ny,parseTextSync:JSON.parse};function $y(){const i="9.4.1",e=globalThis.deck&&globalThis.deck.VERSION;if(e&&e!==i)throw new Error(`deck.gl - multiple versions detected: ${e} vs ${i}`);return e||(Y.log(1,`deck.gl ${i}`)(),globalThis.deck={...globalThis.deck,VERSION:i,version:i,log:Y,_registerLoggers:zy},R_([Uy,[Fy,{imagebitmap:{premultiplyAlpha:"none"}}]])),i}const Gy=$y(),Re="(?:var<\\s*(uniform|storage(?:\\s*,\\s*[A-Za-z_][A-Za-z0-9_]*)?)\\s*>|var)\\s+([A-Za-z_][A-Za-z0-9_]*)",Oe="\\s*",mn=[new RegExp(`@binding\\(\\s*(auto|\\d+)\\s*\\)${Oe}@group\\(\\s*(\\d+)\\s*\\)${Oe}${Re}`,"g"),new RegExp(`@group\\(\\s*(\\d+)\\s*\\)${Oe}@binding\\(\\s*(auto|\\d+)\\s*\\)${Oe}${Re}`,"g")],ma=[new RegExp(`@binding\\(\\s*(auto|\\d+)\\s*\\)${Oe}@group\\(\\s*(\\d+)\\s*\\)${Oe}${Re}`,"g"),new RegExp(`@group\\(\\s*(\\d+)\\s*\\)${Oe}@binding\\(\\s*(auto|\\d+)\\s*\\)${Oe}${Re}`,"g")],jy=[new RegExp(`@binding\\(\\s*(\\d+)\\s*\\)${Oe}@group\\(\\s*(\\d+)\\s*\\)${Oe}${Re}`,"g"),new RegExp(`@group\\(\\s*(\\d+)\\s*\\)${Oe}@binding\\(\\s*(\\d+)\\s*\\)${Oe}${Re}`,"g")],Vy=[new RegExp(`@binding\\(\\s*(auto)\\s*\\)\\s*@group\\(\\s*(\\d+)\\s*\\)\\s*${Re}`,"g"),new RegExp(`@group\\(\\s*(\\d+)\\s*\\)\\s*@binding\\(\\s*(auto)\\s*\\)\\s*${Re}`,"g"),new RegExp(`@binding\\(\\s*(auto)\\s*\\)\\s*@group\\(\\s*(\\d+)\\s*\\)(?:[\\s\\n\\r]*@[A-Za-z_][^\\n\\r]*)*[\\s\\n\\r]*${Re}`,"g"),new RegExp(`@group\\(\\s*(\\d+)\\s*\\)\\s*@binding\\(\\s*(auto)\\s*\\)(?:[\\s\\n\\r]*@[A-Za-z_][^\\n\\r]*)*[\\s\\n\\r]*${Re}`,"g")];function Dr(i){const e=i.split("");let t=0,n=0,s=!1,r=!1,o=!1;for(;t<i.length;){const a=i[t],c=i[t+1];if(r){o?o=!1:a==="\\"?o=!0:a==='"'&&(r=!1),t++;continue}if(s){a===`
`||a==="\r"?s=!1:e[t]=" ",t++;continue}if(n>0){if(a==="/"&&c==="*"){e[t]=" ",e[t+1]=" ",n++,t+=2;continue}if(a==="*"&&c==="/"){e[t]=" ",e[t+1]=" ",n--,t+=2;continue}a!==`
`&&a!=="\r"&&(e[t]=" "),t++;continue}if(a==='"'){r=!0,t++;continue}if(a==="/"&&c==="/"){e[t]=" ",e[t+1]=" ",s=!0,t+=2;continue}if(a==="/"&&c==="*"){e[t]=" ",e[t+1]=" ",n=1,t+=2;continue}t++}return e.join("")}function Si(i,e){var s;const t=Dr(i),n=[];for(const r of e){r.lastIndex=0;let o;for(o=r.exec(t);o;){const a=r===e[0],c=o.index,l=o[0].length;n.push({match:i.slice(c,c+l),index:c,length:l,bindingToken:o[a?1:2],groupToken:o[a?2:1],accessDeclaration:(s=o[3])==null?void 0:s.trim(),name:o[4]}),o=r.exec(t)}}return n.sort((r,o)=>r.index-o.index)}function yh(i,e,t){const n=Si(i,e);if(!n.length)return i;let s="",r=0;for(const o of n)s+=i.slice(r,o.index),s+=t(o),r=o.index+o.length;return s+=i.slice(r),s}function bh(i){return/@binding\(\s*auto\s*\)/.test(Dr(i))}function Wy(i,e){return Si(i,e===mn||e===ma?Vy:e).find(n=>n.bindingToken==="auto")}function vh(i,e={}){const t=wh(i),n=Hy(t);if(!n)return null;const s=Yy(t,n);if(!s)return null;const r=Zy(t,n,s);if(!r)return null;if(e.scanVertexAttributes===!1)return{attributes:[],bindings:r};const o=qy(t,n);if(!o)return null;const a=eb(t,n,s,o,e.vertexEntryPoint);return a?{attributes:a,bindings:r}:null}function wh(i){const e=Dr(i),t=/[A-Za-z_][A-Za-z0-9_]*|(?:0[xX][0-9A-Fa-f]+|\d+)|[@(){}<>\[\]:,;=]/g,n=[];let s=t.exec(e);for(;s;)n.push({value:s[0],index:s.index}),s=t.exec(e);return n}function Hy(i){const e=[];let t=0;for(const n of i){if(n.value==="}"&&t===0)return null;e.push(t),n.value==="{"?t++:n.value==="}"&&t--}return t===0?e:null}function Yy(i,e){var n,s;const t=new Map;for(let r=0;r<i.length;r++){if(e[r]!==0||i[r].value!=="alias")continue;const o=(n=i[r+1])==null?void 0:n.value;if(!Mn(o)||((s=i[r+2])==null?void 0:s.value)!=="="||t.has(o))return null;const a=Sh(i,e,r+3,";");if(a<0||a===r+3)return null;t.set(o,Ns(i.slice(r+3,a))),r=a}return t}function qy(i,e){var n,s;const t=new Map;for(let r=0;r<i.length;r++){if(e[r]!==0||i[r].value!=="struct")continue;const o=(n=i[r+1])==null?void 0:n.value,a=r+2;if(!Mn(o)||t.has(o)||((s=i[a])==null?void 0:s.value)!=="{")return null;const c=Mc(i,a,"{","}");if(c<0)return null;t.set(o,i.slice(a+1,c)),r=c}return t}function Zy(i,e,t){var o,a,c;const n=[],s=new Set,r=new Set;for(let l=0;l<i.length;l++){if(e[l]!==0||i[l].value!=="var")continue;const u=Eh(i,e,l),f=i.slice(u,l),d=_a(f,"group"),g=_a(f,"binding");if(d===null||g===null||d===void 0!=(g===void 0))return null;if(d===void 0||g===void 0)continue;let p=l+1,m=[];if(((o=i[p])==null?void 0:o.value)==="<"){const S=Mc(i,p,"<",">");if(S<0)return null;const C=Fr(i.slice(p+1,S),",");if(!C)return null;m=C.map(Ns),p=S+1}const _=(a=i[p])==null?void 0:a.value;if(!Mn(_)||((c=i[p+1])==null?void 0:c.value)!==":")return null;const v=Sh(i,e,p+2,";");if(v<0||v===p+2)return null;const w=Ac(Ns(i.slice(p+2,v)),t);if(!w)return null;const y=Xy({name:_,group:d,location:g,addressSpace:m,resourceType:w}),x=`${d}:${g}`;if(!y||s.has(x)||r.has(_))return null;n.push(y),s.add(x),r.add(_),l=v}return Jy(n),n.sort((l,u)=>l.group-u.group||l.location-u.location||l.name.localeCompare(u.name))}function Xy(i){const{name:e,group:t,location:n,addressSpace:s,resourceType:r}=i,o={name:e,group:t,location:n};if(s[0]==="uniform"&&s.length===1)return{...o,type:"uniform"};if(s[0]==="storage"&&s.length<=2){const a=s[1]||"read";return a==="read"?{...o,type:"read-only-storage"}:a==="read_write"?{...o,type:"storage"}:null}return s.length>0?null:r==="sampler"||r==="sampler_comparison"?{...o,type:"sampler",...r==="sampler_comparison"?{samplerType:"comparison"}:{}}:r==="texture_external"?{...o,type:"external-texture"}:Ky(o,r)||Qy(o,r)}function Ky(i,e){const t=/^texture_storage_(1d|2d|2d_array|3d)<([A-Za-z0-9_]+),(read|write|read_write)>$/.exec(e);if(!t)return null;const n={read:"read-only",write:"write-only",read_write:"read-write"}[t[3]];return{...i,type:"storage",format:t[2],access:n,viewDimension:ya(t[1])}}function Qy(i,e){const t=/^texture_(multisampled_)?(1d|2d|2d_array|cube|cube_array|3d)<(f32|i32|u32)>$/.exec(e);if(t){if(t[1]&&t[2]!=="2d")return null;const s={f32:"float",i32:"sint",u32:"uint"}[t[3]];return{...i,type:"texture",viewDimension:ya(t[2]),sampleType:s,multisampled:!!t[1]}}const n=/^texture_depth_(multisampled_)?(2d|2d_array|cube|cube_array)$/.exec(e);return!n||n[1]&&n[2]!=="2d"?null:{...i,type:"texture",viewDimension:ya(n[2]),sampleType:"depth",multisampled:!!n[1]}}function Jy(i){for(const e of i){if(e.type!=="sampler"||e.samplerType||!e.name.endsWith("Sampler"))continue;const t=e.name.slice(0,-7),n=i.find(s=>s.type==="texture"&&s.name===t&&s.group===e.group);(n==null?void 0:n.sampleType)==="depth"&&(e.samplerType="non-filtering")}}function eb(i,e,t,n,s){const r=tb(i,e);if(!r)return null;const o=r.filter(g=>g.vertex),a=s?o.find(g=>g.name===s):o.length===1?o[0]:void 0;if(!a)return o.length===0&&!s?[]:null;const c=Fr(a.parameters,",");if(!c)return null;const l=[],u=new Set,f=new Set,d=new Set;for(const g of c)if(g.length>0&&!xh({declaration:g,aliases:t,structures:n,attributes:l,attributeLocations:u,attributeNames:f,visitedStructures:d}))return null;return l.sort((g,p)=>g.location-p.location||g.name.localeCompare(p.name))}function tb(i,e){var s,r;const t=[],n=new Set;for(let o=0;o<i.length;o++){if(e[o]!==0||i[o].value!=="fn")continue;const a=(s=i[o+1])==null?void 0:s.value,c=o+2;if(!Mn(a)||n.has(a)||((r=i[c])==null?void 0:r.value)!=="(")return null;const l=Mc(i,c,"(",")");if(l<0)return null;const u=Eh(i,e,o);t.push({name:a,vertex:Ph(i.slice(u,o),"vertex"),parameters:i.slice(c+1,l)}),n.add(a),o=l}return t}function xh(i){const{declaration:e,aliases:t,structures:n,attributes:s,attributeLocations:r,attributeNames:o,visitedStructures:a}=i,c=sb(e,":");if(c<1||c===e.length-1)return!1;const l=rb(e.slice(0,c)),u=_a(e.slice(0,c),"location"),f=Ph(e.slice(0,c),"builtin"),d=Ac(Ns(e.slice(c+1)),t);if(!l||u===null||!d||u!==void 0&&f)return!1;if(u!==void 0){const m=nb(d);return!m||r.has(u)||o.has(l)?!1:(s.push({name:l,location:u,type:m}),r.add(u),o.add(l),!0)}if(f)return!0;const g=n.get(d);if(!g||a.has(d))return!1;const p=Fr(g,",");if(!p)return!1;a.add(d);for(const m of p)if(m.length>0&&!xh({...i,declaration:m}))return!1;return a.delete(d),!0}function Ac(i,e,t=new Set){const n=wh(i);let s="";for(const r of n){const o=e.get(r.value);if(!o){s+=ib(r.value);continue}if(t.has(r.value))return null;const a=new Set(t);a.add(r.value);const c=Ac(o,e,a);if(!c)return null;s+=c}return s}function ib(i){const e=/^(vec[234]|mat[234]x[234])([fiuh])$/.exec(i);if(!e)return i;const t={f:"f32",i:"i32",u:"u32",h:"f16"}[e[2]];return`${e[1]}<${t}>`}function nb(i){return/^(?:i32|u32|f32|f16|vec[234]<(?:i32|u32|f32|f16)>)$/.test(i)?i:null}function _a(i,e){var n,s,r,o;let t;for(let a=0;a<i.length;a++)if(!(i[a].value!=="@"||((n=i[a+1])==null?void 0:n.value)!==e)){if(t!==void 0||((s=i[a+2])==null?void 0:s.value)!=="("||!/^\d+$/.test(((r=i[a+3])==null?void 0:r.value)||"")||((o=i[a+4])==null?void 0:o.value)!==")")return null;t=Number(i[a+3].value)}return t}function Ph(i,e){return i.some((t,n)=>{var s;return t.value==="@"&&((s=i[n+1])==null?void 0:s.value)===e})}function ya(i){return i.replace("_","-")}function Mc(i,e,t,n){let s=0;for(let r=e;r<i.length;r++)if(i[r].value===t)s++;else if(i[r].value===n&&--s===0)return r;return-1}function Fr(i,e){const t=[];let n=0;const s={"(":0,"<":0,"[":0,"{":0},r=Object.keys(s),o={")":"(",">":"<","]":"[","}":"{"};for(let a=0;a<i.length;a++){const c=i[a].value;if(c===e&&r.every(l=>s[l]===0)){t.push(i.slice(n,a)),n=a+1;continue}if(c in s)s[c]++;else if(c in o){const l=o[c];if(s[l]--,s[l]<0)return null}}return r.every(a=>s[a]===0)?(t.push(i.slice(n)),t):null}function sb(i,e){const t=Fr(i,e);return t&&t.length===2?t[0].length:-1}function Sh(i,e,t,n){for(let s=t;s<i.length;s++)if(e[s]===0&&i[s].value===n)return s;return-1}function Eh(i,e,t){for(let n=t-1;n>=0;n--)if(i[n].value===";"&&e[n]===0||i[n].value==="}"&&e[n]===1)return n+1;return 0}function rb(i){for(let e=i.length-1;e>=0;e--)if(Mn(i[e].value))return i[e].value;return null}function Ns(i){return i.map(e=>e.value).join("")}function Mn(i){return!!(i&&/^[A-Za-z_][A-Za-z0-9_]*$/.test(i))}function Ei(i,e){var t;if(!i){const n=new Error(e||"shadertools: assertion failed.");throw(t=Error.captureStackTrace)==null||t.call(Error,n,Ei),n}}const ro={number:{type:"number",validate(i,e){return Number.isFinite(i)&&typeof e=="object"&&(e.max===void 0||i<=e.max)&&(e.min===void 0||i>=e.min)}},array:{type:"array",validate(i,e){return Array.isArray(i)||ArrayBuffer.isView(i)}}};function ob(i){const e={};for(const[t,n]of Object.entries(i))e[t]=ab(n);return e}function ab(i){let e=jl(i);if(e!=="object")return{value:i,...ro[e],type:e};if(typeof i=="object")return i?i.type!==void 0?{...i,...ro[i.type],type:i.type}:i.value===void 0?{type:"object",value:i}:(e=jl(i.value),{...i,...ro[e],type:e}):{type:"object",value:null};throw new Error("props")}function jl(i){return Array.isArray(i)||ArrayBuffer.isView(i)?"array":typeof i}const cb=`#ifdef MODULE_LOGDEPTH
  logdepth_adjustPosition(gl_Position);
#endif
`,lb=`#ifdef MODULE_MATERIAL
  fragColor = material_filterColor(fragColor);
#endif

#ifdef MODULE_LIGHTING
  fragColor = lighting_filterColor(fragColor);
#endif

#ifdef MODULE_FOG
  fragColor = fog_filterColor(fragColor);
#endif

#ifdef MODULE_PICKING
  fragColor = picking_filterHighlightColor(fragColor);
  fragColor = picking_filterPickingColor(fragColor);
#endif

#ifdef MODULE_LOGDEPTH
  logdepth_setFragDepth();
#endif
`,ub={vertex:cb,fragment:lb},Vl=/void\s+main\s*\([^)]*\)\s*\{\n?/,Wl=/}\n?[^{}]*$/,oo=[],ys="__LUMA_INJECT_DECLARATIONS__";function fb(i){const e={vertex:{},fragment:{}};for(const t in i){let n=i[t];const s=db(t);typeof n=="string"&&(n={order:0,injection:n}),e[s][t]=n}return e}function db(i){const e=i.slice(0,2);switch(e){case"vs":return"vertex";case"fs":return"fragment";default:throw new Error(e)}}function Us(i,e,t,n=!1,s="glsl",r={}){const o=e==="vertex";for(const a in t){const c=t[a];c.sort((u,f)=>u.order-f.order),oo.length=c.length;for(let u=0,f=c.length;u<f;++u)oo[u]=c[u].injection;const l=`${oo.join(`
`)}
`;switch(a){case"vs:#decl":(s==="wgsl"||o)&&(i=i.replace(ys,l));break;case"vs:#main-start":(s==="wgsl"||o)&&(i=s==="wgsl"?Vn(i,"vertex",l,"start",r.vertex):i.replace(Vl,u=>u+l));break;case"vs:#main-end":(s==="wgsl"||o)&&(i=s==="wgsl"?Vn(i,"vertex",l,"end",r.vertex):i.replace(Wl,u=>l+u));break;case"fs:#decl":(s==="wgsl"||!o)&&(i=i.replace(ys,l));break;case"fs:#main-start":(s==="wgsl"||!o)&&(i=s==="wgsl"?Vn(i,"fragment",l,"start",r.fragment):i.replace(Vl,u=>u+l));break;case"fs:#main-end":(s==="wgsl"||!o)&&(i=s==="wgsl"?Vn(i,"fragment",l,"end",r.fragment):i.replace(Wl,u=>l+u));break;default:i=i.replace(a,u=>u+l)}}return i=i.replace(ys,""),n&&(i=i.replace(/\}\s*$/,a=>a+ub[e])),i}function Vn(i,e,t,n,s){const r=hb(i,e,s);if(!r)return i;if(n==="start"){const o=r.openBraceIndex+1;return`${i.slice(0,o)}
${t}${i.slice(o)}`}return`${i.slice(0,r.closeBraceIndex)}${t}${i.slice(r.closeBraceIndex)}`}function hb(i,e,t){const n=e==="vertex"?"@vertex":"@fragment",s=i.indexOf(n);if(s<0)return null;const r=t?i.search(new RegExp(`\\bfn\\s+${gb(t)}\\s*\\(`)):i.indexOf("fn",s);if(r<0)return null;const o=i.indexOf("{",r);if(o<0)return null;let a=0;for(let c=o;c<i.length;c++){const l=i[c];if(l==="{")a++;else if(l==="}"&&(a--,a===0))return{openBraceIndex:o,closeBraceIndex:c}}return null}function gb(i){return i.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function $s(i){i.map(e=>pb(e))}function pb(i){if(i.instance)return;$s(i.dependencies||[]);const{propTypes:e={},deprecations:t=[],inject:n={}}=i,s={normalizedInjections:fb(n),parsedDeprecations:mb(t)};e&&(s.propValidators=ob(e)),i.instance=s;let r={};e&&(r=Object.entries(e).reduce((o,[a,c])=>{const l=c==null?void 0:c.value;return l&&(o[a]=l),o},{})),i.defaultUniforms={...i.defaultUniforms,...r}}function Ch(i,e,t){var n;(n=i.deprecations)==null||n.forEach(s=>{var r;(r=s.regex)!=null&&r.test(e)&&(s.deprecated?t.deprecated(s.old,s.new)():t.removed(s.old,s.new)())})}function mb(i){return i.forEach(e=>{switch(e.type){case"function":e.regex=new RegExp(`\\b${e.old}\\(`);break;default:e.regex=new RegExp(`${e.type} ${e.old};`)}}),i}function Gs(i){$s(i);const e={},t={};Lh({modules:i,level:0,moduleMap:e,moduleDepth:t});const n=Object.keys(t).sort((s,r)=>t[r]-t[s]).map(s=>e[s]);return $s(n),n}function Lh(i){const{modules:e,level:t,moduleMap:n,moduleDepth:s}=i;if(t>=5)throw new Error("Possible loop in shader dependency graph");for(const r of e)n[r.name]=r,(s[r.name]===void 0||s[r.name]<t)&&(s[r.name]=t);for(const r of e)r.dependencies&&Lh({modules:r.dependencies,level:t+1,moduleMap:n,moduleDepth:s})}const M=new Tn({id:"luma.gl"}),Th={id:null,powerPreference:"high-performance",failIfMajorPerformanceCaveat:!1,featureLevel:void 0,optionalFeatures:[],xrCompatible:!1,createCanvasContext:void 0,webgl:{},onError:(i,e)=>{},onResize:(i,e)=>{const[t,n]=i.getDevicePixelSize();M.log(1,`${i} resized => ${t}x${n}px`)()},onPositionChange:(i,e)=>{const[t,n]=i.getPosition();M.log(1,`${i} repositioned => ${t},${n}`)()},onVisibilityChange:i=>M.log(1,`${i} Visibility changed ${i.isVisible}`)(),onDevicePixelRatioChange:(i,e)=>M.log(1,`${i} DPR changed ${e.oldRatio} => ${i.devicePixelRatio}`)(),debug:yb(),debugGPUTime:!1,debugShaders:M.get("debug-shaders")||void 0,debugFramebuffers:!!M.get("debug-framebuffers"),debugFactories:!!M.get("debug-factories"),debugWebGL:!!M.get("debug-webgl"),debugSpectorJS:void 0,debugSpectorJSUrl:void 0,_reuseDevices:!1,_cacheShaders:!0,_destroyShaders:!1,_cachePipelines:!0,_sharePipelines:!0,_destroyPipelines:!1,_initializeFeatures:!0,_disabledFeatures:{"compilation-status-async-webgl":!0},_handle:void 0};function _b(i,e){return i!=null?!!i:e!==void 0?e!=="production":!1}function yb(){return _b(M.get("debug"),bb())}function bb(){const i=globalThis.process;if(i!=null&&i.env)return i.env.NODE_ENV}const vb="GPU Time and Memory",wb=["Adapter","GPU","GPU Type","GPU Backend","Frame Rate","CPU Time","GPU Time","GPU Memory","Buffer Memory","Texture Memory","External Buffer Memory","External Texture Memory","Swap Chain Texture"],Hl=new WeakMap,Yl=new WeakMap;class xb{constructor(){h(this,"stats",new Map)}getStats(e){return this.get(e)}get(e){this.stats.has(e)||this.stats.set(e,new Rr({id:e}));const t=this.stats.get(e);return e===vb&&Pb(t,wb),t}}const Ah=new xb;function Pb(i,e){const t=i.stats;let n=!1;for(const c of e)t[c]||(i.get(c),n=!0);const s=Object.keys(t).length,r=Hl.get(i);if(!n&&(r==null?void 0:r.orderedStatNames)===e&&r.statCount===s)return;const o={};let a=Yl.get(e);a||(a=new Set(e),Yl.set(e,a));for(const c of e)t[c]&&(o[c]=t[c]);for(const[c,l]of Object.entries(t))a.has(c)||(o[c]=l);for(const c of Object.keys(t))delete t[c];Object.assign(t,o),Hl.set(i,{orderedStatNames:e,statCount:s})}const Sb="set luma.log.level=1 (or higher) to trace rendering",ql="No matching device found. Ensure `@luma.gl/webgl` and/or `@luma.gl/webgpu` modules are imported.",fn=class fn{constructor(){h(this,"stats",Ah);h(this,"log",M);h(this,"VERSION","9.4.2");h(this,"spector");h(this,"preregisteredAdapters",new Map);if(globalThis.luma){if(globalThis.luma.VERSION!==this.VERSION)throw M.error(`Found luma.gl ${globalThis.luma.VERSION} while initialzing ${this.VERSION}`)(),M.error("'yarn why @luma.gl/core' can help identify the source of the conflict")(),new Error("luma.gl - multiple versions detected: see console log");M.error("This version of luma.gl has already been initialized")()}M.log(1,`${this.VERSION} - ${Sb}`)(),globalThis.luma=this}async createDevice(e={}){const t={...fn.defaultProps,...e},n=this.selectAdapter(t.type,t.adapters);if(!n)throw new Error(ql);return t.waitForPageLoad&&await n.pageLoaded,await n.create(t)}async attachDevice(e,t){var r;const n=this._getTypeFromHandle(e,t.adapters),s=n&&this.selectAdapter(n,t.adapters);if(!s)throw new Error(ql);return await((r=s==null?void 0:s.attach)==null?void 0:r.call(s,e,t))}registerAdapters(e){for(const t of e)this.preregisteredAdapters.set(t.type,t)}getSupportedAdapters(e=[]){const t=this._getAdapterMap(e);return Array.from(t).map(([,n])=>n).filter(n=>{var s;return(s=n.isSupported)==null?void 0:s.call(n)}).map(n=>n.type)}getBestAvailableAdapterType(e=[]){var s,r;const t=["webgpu","webgl","null"],n=this._getAdapterMap(e);for(const o of t)if((r=(s=n.get(o))==null?void 0:s.isSupported)!=null&&r.call(s))return o;return null}selectAdapter(e,t=[]){let n=e;e==="best-available"&&(n=this.getBestAvailableAdapterType(t));const s=this._getAdapterMap(t);return n&&s.get(n)||null}enforceWebGL2(e=!0,t=[]){var r;const s=this._getAdapterMap(t).get("webgl");s||M.warn("enforceWebGL2: webgl adapter not found")(),(r=s==null?void 0:s.enforceWebGL2)==null||r.call(s,e)}setDefaultDeviceProps(e){Object.assign(fn.defaultProps,e)}_getAdapterMap(e=[]){const t=new Map(this.preregisteredAdapters);for(const n of e)t.set(n.type,n);return t}_getTypeFromHandle(e,t=[]){return e instanceof WebGL2RenderingContext?"webgl":typeof GPUDevice<"u"&&e instanceof GPUDevice||e!=null&&e.queue?"webgpu":e===null?"null":(e instanceof WebGLRenderingContext?M.warn("WebGL1 is not supported",e)():M.warn("Unknown handle type",e)(),null)}};h(fn,"defaultProps",{...Th,type:"best-available",adapters:void 0,waitForPageLoad:!0});let ba=fn;const va=new ba;class Eb{get pageLoaded(){return Tb()}}const Cb=Pi()&&typeof document<"u",Lb=()=>Cb&&document.readyState==="complete";let Wn=null;function Tb(){return Wn||(Lb()||typeof window>"u"?Wn=Promise.resolve():Wn=new Promise(i=>window.addEventListener("load",()=>i()))),Wn}const ao={};function In(i="id"){ao[i]=ao[i]||1;const e=ao[i]++;return`${i}-${e}`}const Ab="cpu-hotspot-profiler",Zl="GPU Resource Counts",Xl="Resource Counts",Kl="GPU Time and Memory",Mb=["Resources","Buffers","Textures","Samplers","TextureViews","Framebuffers","QuerySets","Shaders","RenderPipelines","ComputePipelines","PipelineLayouts","VertexArrays","RenderPasss","RenderBundleEncoders","RenderBundles","ComputePasss","CommandEncoders","CommandBuffers"],Ib=["Resources","Buffers","Textures","Samplers","TextureViews","Framebuffers","QuerySets","Shaders","RenderPipelines","SharedRenderPipelines","ComputePipelines","PipelineLayouts","VertexArrays","RenderPasss","RenderBundleEncoders","RenderBundles","ComputePasss","CommandEncoders","CommandBuffers"],Rb=Mb.flatMap(i=>[`${i} Created`,`${i} Active`]),Ob=Ib.flatMap(i=>[`${i} Created`,`${i} Active`]),Ql=new WeakMap,Jl=new WeakMap;var aa;let q=(aa=class{constructor(e,t,n){h(this,"id");h(this,"props");h(this,"userData",{});h(this,"_device");h(this,"destroyed",!1);h(this,"allocatedBytes",0);h(this,"allocatedBytesName",null);h(this,"_attachedResources",new Set);if(!e)throw new Error("no device");this._device=e,this.props=Bb(t,n);const s=this.props.id!=="undefined"?this.props.id:In(this[Symbol.toStringTag]);this.props.id=s,this.id=s,this.userData=this.props.userData||{},this.addStats()}toString(){return`${this[Symbol.toStringTag]||this.constructor.name}:"${this.id}"`}toJSON(){return this.toString()}get ownsHandle(){return(this.props.handle===void 0||this.props.handle===null)&&!this.isHandleBorrowed}get isHandleBorrowed(){return!!this.props._isHandleBorrowed}destroy(){this.destroyed||this.destroyResource()}delete(){return this.destroy(),this}getProps(){return this.props}attachResource(e){this._attachedResources.add(e)}detachResource(e){this._attachedResources.delete(e)}destroyAttachedResource(e){this._attachedResources.delete(e)&&e.destroy()}destroyAttachedResources(){for(const e of this._attachedResources)e.destroy();this._attachedResources=new Set}destroyResource(){this.destroyed||(this.destroyAttachedResources(),this.removeStats(),this.destroyed=!0)}removeStats(){const e=Hi(this._device),t=e?lt():0,n=[this._device.statsManager.getStats(Zl),this._device.statsManager.getStats(Xl)],s=tu(this._device);for(const o of n)eu(o,s);const r=this.getStatsName();for(const o of n)o.get("Resources Active").decrementCount(),o.get(`${r}s Active`).decrementCount();e&&(e.statsBookkeepingCalls=(e.statsBookkeepingCalls||0)+1,e.statsBookkeepingTimeMs=(e.statsBookkeepingTimeMs||0)+(lt()-t))}trackAllocatedMemory(e,t=this.getStatsName()){const n=Hi(this._device),s=n?lt():0,r=this._device.statsManager.getStats(Kl);this.allocatedBytes>0&&this.allocatedBytesName&&(r.get("GPU Memory").subtractCount(this.allocatedBytes),r.get(`${this.allocatedBytesName} Memory`).subtractCount(this.allocatedBytes)),r.get("GPU Memory").addCount(e),r.get(`${t} Memory`).addCount(e),n&&(n.statsBookkeepingCalls=(n.statsBookkeepingCalls||0)+1,n.statsBookkeepingTimeMs=(n.statsBookkeepingTimeMs||0)+(lt()-s)),this.allocatedBytes=e,this.allocatedBytesName=t}trackReferencedMemory(e,t=this.getStatsName()){this.trackAllocatedMemory(e,`External ${t}`)}trackDeallocatedMemory(e=this.getStatsName()){if(this.allocatedBytes===0){this.allocatedBytesName=null;return}const t=Hi(this._device),n=t?lt():0,s=this._device.statsManager.getStats(Kl);s.get("GPU Memory").subtractCount(this.allocatedBytes),s.get(`${this.allocatedBytesName||e} Memory`).subtractCount(this.allocatedBytes),t&&(t.statsBookkeepingCalls=(t.statsBookkeepingCalls||0)+1,t.statsBookkeepingTimeMs=(t.statsBookkeepingTimeMs||0)+(lt()-n)),this.allocatedBytes=0,this.allocatedBytesName=null}trackDeallocatedReferencedMemory(e=this.getStatsName()){this.trackDeallocatedMemory(`Referenced ${e}`)}addStats(){const e=this.getStatsName(),t=Hi(this._device),n=t?lt():0,s=[this._device.statsManager.getStats(Zl),this._device.statsManager.getStats(Xl)],r=tu(this._device);for(const o of s)eu(o,r);for(const o of s)o.get("Resources Created").incrementCount(),o.get("Resources Active").incrementCount(),o.get(`${e}s Created`).incrementCount(),o.get(`${e}s Active`).incrementCount();t&&(t.statsBookkeepingCalls=(t.statsBookkeepingCalls||0)+1,t.statsBookkeepingTimeMs=(t.statsBookkeepingTimeMs||0)+(lt()-n)),kb(this._device,e)}getStatsName(){return Db(this)}},h(aa,"defaultProps",{id:"undefined",handle:void 0,_isHandleBorrowed:!1,userData:void 0}),aa);function Bb(i,e){const t={...e};for(const n in i)i[n]!==void 0&&(t[n]=i[n]);return t}function eu(i,e){const t=i.stats;let n=!1;for(const c of e)t[c]||(i.get(c),n=!0);const s=Object.keys(t).length,r=Ql.get(i);if(!n&&(r==null?void 0:r.orderedStatNames)===e&&r.statCount===s)return;const o={};let a=Jl.get(e);a||(a=new Set(e),Jl.set(e,a));for(const c of e)t[c]&&(o[c]=t[c]);for(const[c,l]of Object.entries(t))a.has(c)||(o[c]=l);for(const c of Object.keys(t))delete t[c];Object.assign(t,o),Ql.set(i,{orderedStatNames:e,statCount:s})}function tu(i){return i.type==="webgl"?Ob:Rb}function Hi(i){const e=i.userData[Ab];return e!=null&&e.enabled?e:null}function lt(){var i,e;return((e=(i=globalThis.performance)==null?void 0:i.now)==null?void 0:e.call(i))??Date.now()}function kb(i,e){const t=Hi(i);if(!(!t||!t.activeDefaultFramebufferAcquireDepth))switch(t.transientCanvasResourceCreates=(t.transientCanvasResourceCreates||0)+1,e){case"Texture":t.transientCanvasTextureCreates=(t.transientCanvasTextureCreates||0)+1;break;case"TextureView":t.transientCanvasTextureViewCreates=(t.transientCanvasTextureViewCreates||0)+1;break;case"Sampler":t.transientCanvasSamplerCreates=(t.transientCanvasSamplerCreates||0)+1;break;case"Framebuffer":t.transientCanvasFramebufferCreates=(t.transientCanvasFramebufferCreates||0)+1;break}}function Db(i){let e=Object.getPrototypeOf(i);for(;e;){const t=Object.getPrototypeOf(e);if(!t||t===q.prototype)return Fb(e)||i[Symbol.toStringTag]||i.constructor.name;e=t}return i[Symbol.toStringTag]||i.constructor.name}function Fb(i){const e=Object.getOwnPropertyDescriptor(i,Symbol.toStringTag);return typeof(e==null?void 0:e.get)=="function"?e.get.call(i):typeof(e==null?void 0:e.value)=="string"?e.value:null}const ge=class ge extends q{constructor(t,n){const s={...n};(n.usage||0)&ge.INDEX&&!n.indexType&&(n.data instanceof Uint32Array?s.indexType="uint32":n.data instanceof Uint16Array?s.indexType="uint16":n.data instanceof Uint8Array&&(s.indexType="uint8")),delete s.data;super(t,s,ge.defaultProps);h(this,"usage");h(this,"indexType");h(this,"updateTimestamp");h(this,"debugData",new ArrayBuffer(0));this.usage=s.usage||0,this.indexType=s.indexType,this.updateTimestamp=t.incrementTimestamp()}get[Symbol.toStringTag](){return"Buffer"}clone(t){return this.device.createBuffer({...this.props,...t})}_setDebugData(t,n,s){if(!this.device.props.debug)return;let r=null,o;ArrayBuffer.isView(t)?(r=t,o=t.buffer):o=t;const a=Math.min(t?t.byteLength:s,ge.DEBUG_DATA_MAX_LENGTH);if(o===null)this.debugData=new ArrayBuffer(a);else{const c=Math.min((r==null?void 0:r.byteOffset)||0,o.byteLength),l=Math.max(0,o.byteLength-c),u=Math.min(a,l);this.debugData=new Uint8Array(o,c,u).slice().buffer}}};h(ge,"INDEX",16),h(ge,"VERTEX",32),h(ge,"UNIFORM",64),h(ge,"STORAGE",128),h(ge,"INDIRECT",256),h(ge,"QUERY_RESOLVE",512),h(ge,"MAP_READ",1),h(ge,"MAP_WRITE",2),h(ge,"COPY_SRC",4),h(ge,"COPY_DST",8),h(ge,"DEBUG_DATA_MAX_LENGTH",32),h(ge,"defaultProps",{...q.defaultProps,handle:void 0,usage:0,byteLength:0,byteOffset:0,data:null,indexType:"uint16",onMapped:void 0});let W=ge;const wa=globalThis.Float16Array;function zb(){return wa??Uint16Array}function Nb(i){return!!(wa&&i===wa)}function Ub(i){const e=i.includes("norm"),t=!e&&!i.startsWith("float"),n=i.startsWith("s"),s=Rc[i],[r,o,a]=s||["uint8 ","i32",1];return{signedType:r,primitiveType:o,byteLength:a,normalized:e,integer:t,signed:n}}function $b(i){const e=i;switch(e){case"uint8":return"unorm8";case"sint8":return"snorm8";case"uint16":return"unorm16";case"sint16":return"snorm16";default:return e}}function Xe(i,e){switch(e){case 1:return i;case 2:return i+i%2;default:return i+(4-i%4)%4}}function Mh(i){const e=ArrayBuffer.isView(i)?i.constructor:i;if(Nb(e))return"float16";if(e===Uint8ClampedArray)return"uint8";const t=Object.values(Rc).find(n=>e===n[4]);if(!t)throw new Error(e.name);return t[0]}function Gb(i){return Mh(i)}function Qi(i){if(i==="float16")return zb();const e=Rc[i];if(!e)throw new Error(i);const[,,,,t]=e;return t}function Ic(i){return Qi(i)}const Rc={uint8:["uint8","u32",1,!1,Uint8Array],sint8:["sint8","i32",1,!1,Int8Array],unorm8:["uint8","f32",1,!0,Uint8Array],snorm8:["sint8","f32",1,!0,Int8Array],uint16:["uint16","u32",2,!1,Uint16Array],sint16:["sint16","i32",2,!1,Int16Array],unorm16:["uint16","u32",2,!0,Uint16Array],snorm16:["sint16","i32",2,!0,Int16Array],float16:["float16","f16",2,!1,Uint16Array],float32:["float32","f32",4,!1,Float32Array],uint32:["uint32","u32",4,!1,Uint32Array],sint32:["sint32","i32",4,!1,Int32Array]};class jb{getDataTypeInfo(e){return Ub(e)}getNormalizedDataType(e){return $b(e)}alignTo(e,t){return Xe(e,t)}getDataType(e){return Gb(e)}getTypedArrayConstructor(e){return Ic(e)}}const et=new jb;class Vb{getVertexFormatInfo(e){if(e==="unorm10-10-10-2")return{type:"unorm8",components:4,byteLength:4,integer:!1,signed:!1,normalized:!0};let t=e==="unorm8x4-bgra"?"unorm8x4":e,n;t.endsWith("-webgl")&&(t=t.slice(0,-6),n=!0);const s=t.split("x");if(s.length>2)throw new Error(`Unsupported vertex format: ${e}`);const[r,o]=s,a=r,c=Hb(e,o),l=Wb(e,a);let u;try{u=n?Yb(e,a,c):this.makeVertexFormat(l.signedType,c,l.normalized)}catch{throw new Error(`Unsupported vertex format: ${e}`)}if(u!==(n?e:t))throw new Error(`Unsupported vertex format: ${e}`);const f={type:a,components:c,byteLength:l.byteLength*c,integer:l.integer,signed:l.signed,normalized:l.normalized};return n&&(f.webglOnly=!0),f}makeVertexFormat(e,t,n){const s=n?et.getNormalizedDataType(e):e;switch(s){case"unorm8":return t===1?"unorm8":t===3?"unorm8x3-webgl":`${s}x${t}`;case"snorm8":return t===1?"snorm8":t===3?"snorm8x3-webgl":`${s}x${t}`;case"uint8":case"sint8":if(t===3)throw new Error(`size: ${t}`);return t===1?s:`${s}x${t}`;case"uint16":return t===1?"uint16":t===3?"uint16x3-webgl":`${s}x${t}`;case"sint16":return t===1?"sint16":t===3?"sint16x3-webgl":`${s}x${t}`;case"unorm16":return t===1?"unorm16":t===3?"unorm16x3-webgl":`${s}x${t}`;case"snorm16":return t===1?"snorm16":t===3?"snorm16x3-webgl":`${s}x${t}`;case"float16":if(t===3)throw new Error(`size: ${t}`);return t===1?s:`${s}x${t}`;default:return t===1?s:`${s}x${t}`}}getVertexFormatFromAttribute(e,t,n){if(!t||t>4)throw new Error(`size ${t}`);const s=t,r=et.getDataType(e);return this.makeVertexFormat(r,s,n)}getCompatibleVertexFormat(e){let t;switch(e.primitiveType){case"f32":t="float32";break;case"i32":t="sint32";break;case"u32":t="uint32";break;case"f16":return e.components<=2?"float16x2":"float16x4"}return e.components===1?t:`${t}x${e.components}`}}const be=new Vb;function Wb(i,e){try{return et.getDataTypeInfo(e)}catch{throw new Error(`Unsupported vertex format: ${i}`)}}function Hb(i,e){if(!e)return 1;const t=Number(e);if(t===2||t===3||t===4)return t;throw new Error(`Unsupported vertex format: ${i}`)}function Yb(i,e,t){if(t!==3)throw new Error(`Unsupported vertex format: ${i}`);switch(e){case"uint8":case"sint8":case"unorm8":case"snorm8":case"uint16":case"sint16":case"unorm16":case"snorm16":return`${e}x3-webgl`;default:throw new Error(`Unsupported vertex format: ${i}`)}}const _e="texture-compression-bc",J="texture-compression-astc",je="texture-compression-etc2",qb="texture-compression-etc1-webgl",Hn="texture-compression-pvrtc-webgl",co="texture-compression-atc-webgl",Yn="float32-renderable-webgl",lo="float16-renderable-webgl",Zb="rgb9e5ufloat-renderable-webgl",uo="snorm8-renderable-webgl",ut="norm16-webgl",fo="norm16-renderable-webgl",ho="snorm16-renderable-webgl",qn="float32-filterable",iu="float16-filterable-webgl",Rn=1,On=2,Oc=4,Bc=8,Ci=16,zr=5,Ih=10,fe=Rn|On,Zn=Rn|Oc,st=Rn|On|Oc|Bc,Ve=Rn|On|Ci,Xb=Rn|Oc|Ci,xa=st|Ci,nu=(On|Bc|Ci)<<zr,Kb=(On|Bc)<<zr,ve=Ci<<zr,Zt=xa<<zr,Qb=st<<Ih,go=Ci<<Ih;function kc(i){const e=Rh[i];if(!e)throw new Error(`Unsupported texture format ${i}`);return e}function Jb(){return Rh}const ev={r8unorm:{webgpu:st|ve},rg8unorm:{webgpu:st|ve},"rgb8unorm-webgl":{},rgba8unorm:{webgpu:xa},"rgba8unorm-srgb":{webgpu:st},r8snorm:{render:uo,webgpu:Zn|nu},rg8snorm:{render:uo,webgpu:Zn|nu},"rgb8snorm-webgl":{},rgba8snorm:{render:uo,webgpu:Xb|Kb},r8uint:{webgpu:fe|ve},rg8uint:{webgpu:fe|ve},rgba8uint:{webgpu:Ve},r8sint:{webgpu:fe|ve},rg8sint:{webgpu:fe|ve},rgba8sint:{webgpu:Ve},bgra8unorm:{webgpu:st},"bgra8unorm-srgb":{webgpu:Qb},r16unorm:{f:ut,render:fo,webgpu:Zt},rg16unorm:{f:ut,render:fo,webgpu:Zt},"rgb16unorm-webgl":{f:ut,render:!1},rgba16unorm:{f:ut,render:fo,webgpu:Zt},r16snorm:{f:ut,render:ho,webgpu:Zt},rg16snorm:{f:ut,render:ho,webgpu:Zt},"rgb16snorm-webgl":{f:ut,render:!1},rgba16snorm:{f:ut,render:ho,webgpu:Zt},r16uint:{webgpu:fe|ve},rg16uint:{webgpu:fe|ve},rgba16uint:{webgpu:Ve},r16sint:{webgpu:fe|ve},rg16sint:{webgpu:fe|ve},rgba16sint:{webgpu:Ve},r16float:{render:lo,filter:"float16-filterable-webgl",webgpu:st|ve},rg16float:{render:lo,filter:iu,webgpu:st|ve},rgba16float:{render:lo,filter:iu,webgpu:xa},r32uint:{webgpu:Ve},rg32uint:{webgpu:fe|go},rgba32uint:{webgpu:Ve},r32sint:{webgpu:Ve},rg32sint:{webgpu:fe|go},rgba32sint:{webgpu:Ve},r32float:{render:Yn,filter:qn,webgpu:Ve},rg32float:{render:!1,filter:qn,webgpu:fe|go},"rgb32float-webgl":{render:Yn,filter:qn},rgba32float:{render:Yn,filter:qn,webgpu:Ve},"rgba4unorm-webgl":{channels:"rgba",bitsPerChannel:[4,4,4,4],packed:!0},"rgb565unorm-webgl":{channels:"rgb",bitsPerChannel:[5,6,5,0],packed:!0},"rgb5a1unorm-webgl":{channels:"rgba",bitsPerChannel:[5,5,5,1],packed:!0},rgb9e5ufloat:{channels:"rgb",packed:!0,render:Zb,webgpu:Zn},rg11b10ufloat:{channels:"rgb",bitsPerChannel:[11,11,10,0],packed:!0,p:1,render:Yn,webgpu:Zn|ve},rgb10a2unorm:{channels:"rgba",bitsPerChannel:[10,10,10,2],packed:!0,p:1,webgpu:st|ve},rgb10a2uint:{channels:"rgba",bitsPerChannel:[10,10,10,2],packed:!0,p:1,webgpu:fe|ve},stencil8:{attachment:"stencil",bitsPerChannel:[8,0,0,0],dataType:"uint8",webgpu:fe},depth16unorm:{attachment:"depth",bitsPerChannel:[16,0,0,0],dataType:"uint16",webgpu:fe},depth24plus:{attachment:"depth",bitsPerChannel:[24,0,0,0],dataType:"uint32",webgpu:fe},depth32float:{attachment:"depth",bitsPerChannel:[32,0,0,0],dataType:"float32",webgpu:fe},"depth24plus-stencil8":{attachment:"depth-stencil",bitsPerChannel:[24,8,0,0],packed:!0,webgpu:fe},"depth32float-stencil8":{attachment:"depth-stencil",bitsPerChannel:[32,8,0,0],packed:!0,f:"depth32float-stencil8",webgpu:fe}},tv={"bc1-rgb-unorm-webgl":{f:_e},"bc1-rgb-unorm-srgb-webgl":{f:_e},"bc1-rgba-unorm":{f:_e},"bc1-rgba-unorm-srgb":{f:_e},"bc2-rgba-unorm":{f:_e},"bc2-rgba-unorm-srgb":{f:_e},"bc3-rgba-unorm":{f:_e},"bc3-rgba-unorm-srgb":{f:_e},"bc4-r-unorm":{f:_e},"bc4-r-snorm":{f:_e},"bc5-rg-unorm":{f:_e},"bc5-rg-snorm":{f:_e},"bc6h-rgb-ufloat":{f:_e},"bc6h-rgb-float":{f:_e},"bc7-rgba-unorm":{f:_e},"bc7-rgba-unorm-srgb":{f:_e},"etc2-rgb8unorm":{f:je},"etc2-rgb8unorm-srgb":{f:je},"etc2-rgb8a1unorm":{f:je},"etc2-rgb8a1unorm-srgb":{f:je},"etc2-rgba8unorm":{f:je},"etc2-rgba8unorm-srgb":{f:je},"eac-r11unorm":{f:je},"eac-r11snorm":{f:je},"eac-rg11unorm":{f:je},"eac-rg11snorm":{f:je},"astc-4x4-unorm":{f:J},"astc-4x4-unorm-srgb":{f:J},"astc-5x4-unorm":{f:J},"astc-5x4-unorm-srgb":{f:J},"astc-5x5-unorm":{f:J},"astc-5x5-unorm-srgb":{f:J},"astc-6x5-unorm":{f:J},"astc-6x5-unorm-srgb":{f:J},"astc-6x6-unorm":{f:J},"astc-6x6-unorm-srgb":{f:J},"astc-8x5-unorm":{f:J},"astc-8x5-unorm-srgb":{f:J},"astc-8x6-unorm":{f:J},"astc-8x6-unorm-srgb":{f:J},"astc-8x8-unorm":{f:J},"astc-8x8-unorm-srgb":{f:J},"astc-10x5-unorm":{f:J},"astc-10x5-unorm-srgb":{f:J},"astc-10x6-unorm":{f:J},"astc-10x6-unorm-srgb":{f:J},"astc-10x8-unorm":{f:J},"astc-10x8-unorm-srgb":{f:J},"astc-10x10-unorm":{f:J},"astc-10x10-unorm-srgb":{f:J},"astc-12x10-unorm":{f:J},"astc-12x10-unorm-srgb":{f:J},"astc-12x12-unorm":{f:J},"astc-12x12-unorm-srgb":{f:J},"pvrtc-rgb4unorm-webgl":{f:Hn},"pvrtc-rgba4unorm-webgl":{f:Hn},"pvrtc-rgb2unorm-webgl":{f:Hn},"pvrtc-rgba2unorm-webgl":{f:Hn},"etc1-rbg-unorm-webgl":{f:qb},"atc-rgb-unorm-webgl":{f:co},"atc-rgba-unorm-webgl":{f:co},"atc-rgbai-unorm-webgl":{f:co}},Rh={...ev,...tv},iv=/^(r|rg|rgb|rgba|bgra)([0-9]*)([a-z]*)(-srgb)?(-webgl)?$/,nv=["rgb","rgba","bgra"],sv=["depth","stencil"],rv=5,ov=["bc1","bc2","bc3","bc4","bc5","bc6","bc7","etc1","etc2","eac","atc","astc","pvrtc"];class av{isColor(e){return nv.some(t=>e.startsWith(t))}isDepthStencil(e){return sv.some(t=>e.startsWith(t))}isCompressed(e){return ov.some(t=>e.startsWith(t))}getInfo(e){return Oh(e)}getCapabilities(e){return lv(e)}getWebGPUCapabilities(e){const t=kc(e);return t.webgpu!==void 0?t.webgpu:this.isCompressed(e)&&!e.endsWith("-webgl")?rv:0}computeMemoryLayout(e){return cv(e)}}const Fe=new av;function cv({format:i,width:e,height:t,depth:n,byteAlignment:s}){const r=Fe.getInfo(i),{bytesPerPixel:o,bytesPerBlock:a=o,blockWidth:c=1,blockHeight:l=1,compressed:u=!1}=r,f=u?Math.ceil(e/c):e,d=u?Math.ceil(t/l):t,g=f*a,p=Math.ceil(g/s)*s,m=d,_=p*m*n;return{bytesPerPixel:o,bytesPerRow:p,rowsPerImage:m,depthOrArrayLayers:n,bytesPerImage:p*m,byteLength:_}}function lv(i){const e=kc(i),t={format:i,create:e.f??!0,render:e.render??!0,filter:e.filter??!0,blend:e.blend??!0,store:e.store??!0},n=Oh(i),s=i.startsWith("depth")||i.startsWith("stencil"),r=n==null?void 0:n.signed,o=n==null?void 0:n.integer,a=n==null?void 0:n.webgl,c=!!(n!=null&&n.compressed);return t.render&&(t.render=!s&&!c),t.filter&&(t.filter=!s&&!r&&!o&&!a),t}function Oh(i){let e=uv(i);if(Fe.isCompressed(i)){e.channels="rgb",e.components=3,e.bytesPerPixel=1,e.srgb=!1,e.compressed=!0,e.bytesPerBlock=dv(i);const n=fv(i);n&&(e.blockWidth=n.blockWidth,e.blockHeight=n.blockHeight)}const t=e.packed?null:iv.exec(i);if(t){const[,n,s,r,o,a]=t,c=`${r}${s}`,l=et.getDataTypeInfo(c),u=l.byteLength*8,f=(n==null?void 0:n.length)??1,d=[u,f>=2?u:0,f>=3?u:0,f>=4?u:0];e={format:i,attachment:e.attachment,dataType:l.signedType,components:f,channels:n,integer:l.integer,signed:l.signed,normalized:l.normalized,bitsPerChannel:d,bytesPerPixel:l.byteLength*f,packed:e.packed,srgb:e.srgb},a==="-webgl"&&(e.webgl=!0),o==="-srgb"&&(e.srgb=!0)}return i.endsWith("-webgl")&&(e.webgl=!0),i.endsWith("-srgb")&&(e.srgb=!0),e}function uv(i){var r;const e={...kc(i)},t=e.bytesPerPixel||1,n=e.bitsPerChannel||[8,8,8,8];return delete e.bitsPerChannel,delete e.bytesPerPixel,delete e.f,delete e.render,delete e.filter,delete e.blend,delete e.store,delete e.webgpu,{...e,format:i,attachment:e.attachment||"color",channels:e.channels||"r",components:e.components||((r=e.channels)==null?void 0:r.length)||1,bytesPerPixel:t,bitsPerChannel:n,dataType:e.dataType||"uint8",srgb:e.srgb??!1,packed:e.packed??!1,webgl:e.webgl??!1,integer:e.integer??!1,signed:e.signed??!1,normalized:e.normalized??!1,compressed:e.compressed??!1}}function fv(i){const t=/.*-(\d+)x(\d+)-.*/.exec(i);if(t){const[,n,s]=t;return{blockWidth:Number(n),blockHeight:Number(s)}}return i.startsWith("bc")||i.startsWith("etc1")||i.startsWith("etc2")||i.startsWith("eac")||i.startsWith("atc")?{blockWidth:4,blockHeight:4}:i.startsWith("pvrtc-rgb4")||i.startsWith("pvrtc-rgba4")?{blockWidth:4,blockHeight:4}:i.startsWith("pvrtc-rgb2")||i.startsWith("pvrtc-rgba2")?{blockWidth:8,blockHeight:4}:null}function dv(i){return i.startsWith("bc1")||i.startsWith("bc4")||i.startsWith("etc1")||i.startsWith("etc2-rgb8")||i.startsWith("etc2-rgb8a1")||i.startsWith("eac-r11")||i==="atc-rgb-unorm-webgl"?8:i.startsWith("bc2")||i.startsWith("bc3")||i.startsWith("bc5")||i.startsWith("bc6h")||i.startsWith("bc7")||i.startsWith("etc2-rgba8")||i.startsWith("eac-rg11")||i.startsWith("astc")||i==="atc-rgba-unorm-webgl"||i==="atc-rgbai-unorm-webgl"?16:i.startsWith("pvrtc")?8:16}function hv(i){return typeof ImageData<"u"&&i instanceof ImageData||typeof ImageBitmap<"u"&&i instanceof ImageBitmap||typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement||typeof VideoFrame<"u"&&i instanceof VideoFrame||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof OffscreenCanvas<"u"&&i instanceof OffscreenCanvas}function gv(i){if(typeof ImageData<"u"&&i instanceof ImageData||typeof ImageBitmap<"u"&&i instanceof ImageBitmap||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof OffscreenCanvas<"u"&&i instanceof OffscreenCanvas)return{width:i.width,height:i.height};if(typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement)return{width:i.naturalWidth,height:i.naturalHeight};if(typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement)return{width:i.videoWidth,height:i.videoHeight};if(typeof VideoFrame<"u"&&i instanceof VideoFrame)return{width:i.displayWidth,height:i.displayHeight};throw new Error("Unknown image type")}class pv{}function mv(i,e){const t=Pa(i),n=e.map(Pa).filter(s=>s!==void 0);return[t,...n].filter(s=>s!==void 0)}function Pa(i){var e;if(i!==void 0){if(i===null||typeof i=="string"||typeof i=="number"||typeof i=="boolean")return i;if(i instanceof Error)return i.message;if(Array.isArray(i))return i.map(Pa);if(typeof i=="object"){if(_v(i)){const t=String(i);if(t!=="[object Object]")return t}return yv(i)?bv(i):((e=i.constructor)==null?void 0:e.name)||"Object"}return String(i)}}function _v(i){return"toString"in i&&typeof i.toString=="function"&&i.toString!==Object.prototype.toString}function yv(i){return"message"in i&&"type"in i}function bv(i){const e=typeof i.type=="string"?i.type:"message",t=typeof i.message=="string"?i.message:"",n=typeof i.lineNum=="number"?i.lineNum:null,s=typeof i.linePos=="number"?i.linePos:null,r=n!==null&&s!==null?` @ ${n}:${s}`:n!==null?` @ ${n}`:"";return`${e}${r}: ${t}`.trim()}class vv{constructor(e=[],t){h(this,"features");h(this,"disabledFeatures");this.features=new Set(e),this.disabledFeatures=t||{}}*[Symbol.iterator](){yield*this.features}has(e){var t;return!((t=this.disabledFeatures)!=null&&t[e])&&this.features.has(e)}}function wv(){if(typeof HTMLCanvasElement>"u")return!1;const i=HTMLCanvasElement.prototype;return"layoutSubtree"in i&&typeof i.requestPaint=="function"}const mr=class mr{constructor(e){h(this,"id");h(this,"props");h(this,"userData",{});h(this,"statsManager",Ah);h(this,"_factories",{});h(this,"timestamp",0);h(this,"_reused",!1);h(this,"_moduleData",{});h(this,"wgslLanguageFeatures",new Set);h(this,"_textureCaps",{});h(this,"_debugGPUTimeQuery",null);this.props={...mr.defaultProps,...e},this.id=this.props.id||In(this[Symbol.toStringTag].toLowerCase())}get[Symbol.toStringTag](){return"Device"}toString(){return`Device(${this.id})`}toJSON(){return this.toString()}getVertexFormatInfo(e){return be.getVertexFormatInfo(e)}isVertexFormatSupported(e){return!0}getTextureFormatInfo(e){return Fe.getInfo(e)}getTextureFormatCapabilities(e){let t=this._textureCaps[e];if(!t){const n=this._getDeviceTextureFormatCapabilities(e);t=this._getDeviceSpecificTextureFormatCapabilities(n),this._textureCaps[e]=t}return t}getMipLevelCount(e,t,n=1){const s=Math.max(e,t,n);return 1+Math.floor(Math.log2(s))}isExternalImage(e){return hv(e)}getExternalImageSize(e){return gv(e)}isTextureFormatSupported(e){return this.getTextureFormatCapabilities(e).create}isTextureFormatFilterable(e){return this.getTextureFormatCapabilities(e).filter}isTextureFormatRenderable(e){return this.getTextureFormatCapabilities(e).render}isTextureFormatCompressed(e){return Fe.isCompressed(e)}getSupportedCompressedTextureFormats(){const e=[];for(const t of Object.keys(Jb()))this.isTextureFormatCompressed(t)&&this.isTextureFormatSupported(t)&&e.push(t);return e}pushDebugGroup(e){this.commandEncoder.pushDebugGroup(e)}popDebugGroup(){var e;(e=this.commandEncoder)==null||e.popDebugGroup()}insertDebugMarker(e){var t;(t=this.commandEncoder)==null||t.insertDebugMarker(e)}loseDevice(){return!1}incrementTimestamp(){return this.timestamp++}reportError(e,t,...n){if(!this.props.onError(e,t)){const r=mv(t,n);return M.error(this.type==="webgl"?"%cWebGL":"%cWebGPU","color: white; background: red; padding: 2px 6px; border-radius: 3px;",e.message,...r)}return()=>{}}debug(){if(this.props.debug)debugger;else M.once(0,`'Type luma.log.set({debug: true}) in console to enable debug breakpoints',
or create a device with the 'debug: true' prop.`)()}getDefaultCanvasContext(){if(!this.canvasContext)throw new Error("Device has no default CanvasContext. See props.createCanvasContext");return this.canvasContext}createFence(){throw new Error("createFence() not implemented")}beginRenderPass(e){return this.commandEncoder.beginRenderPass(e)}beginComputePass(e){return this.commandEncoder.beginComputePass(e)}writeBufferViaCommandEncoder(e,t,n,s=0){throw new Error("writeBufferViaCommandEncoder() not implemented")}generateMipmapsWebGPU(e){throw new Error("not implemented")}_createSharedRenderPipelineWebGL(e){throw new Error("_createSharedRenderPipelineWebGL() not implemented")}_createBindGroupLayoutWebGPU(e,t){throw new Error("_createBindGroupLayoutWebGPU() not implemented")}_createBindGroupWebGPU(e,t,n,s,r){throw new Error("_createBindGroupWebGPU() not implemented")}_supportsDebugGPUTime(){return this.features.has("timestamp-query")&&!!(this.props.debug||this.props.debugGPUTime)}_enableDebugGPUTime(e=256){if(!this._supportsDebugGPUTime())return null;if(this._debugGPUTimeQuery)return this._debugGPUTimeQuery;try{this._debugGPUTimeQuery=this.createQuerySet({type:"timestamp",count:e}),this.commandEncoder=this.createCommandEncoder({id:this.commandEncoder.props.id,timeProfilingQuerySet:this._debugGPUTimeQuery})}catch{this._debugGPUTimeQuery=null}return this._debugGPUTimeQuery}_disableDebugGPUTime(){this._debugGPUTimeQuery&&(this.commandEncoder.getTimeProfilingQuerySet()===this._debugGPUTimeQuery&&(this.commandEncoder=this.createCommandEncoder({id:this.commandEncoder.props.id})),this._debugGPUTimeQuery.destroy(),this._debugGPUTimeQuery=null)}_isDebugGPUTimeEnabled(){return this._debugGPUTimeQuery!==null}getCanvasContext(){return this.getDefaultCanvasContext()}readPixelsToArrayWebGL(e,t){throw new Error("not implemented")}readPixelsToBufferWebGL(e,t){throw new Error("not implemented")}setParametersWebGL(e){throw new Error("not implemented")}getParametersWebGL(e){throw new Error("not implemented")}withParametersWebGL(e,t){throw new Error("not implemented")}clearWebGL(e){throw new Error("not implemented")}resetWebGL(){throw new Error("not implemented")}getModuleData(e){var t;return(t=this._moduleData)[e]||(t[e]={}),this._moduleData[e]}static _getCanvasContextProps(e){return e.createCanvasContext===!0?{}:e.createCanvasContext}_getDeviceTextureFormatCapabilities(e){const t=Fe.getCapabilities(e),n=r=>(typeof r=="string"?this.features.has(r):r)??!0,s=n(t.create);return{format:e,create:s,render:s&&n(t.render),filter:s&&n(t.filter),blend:s&&n(t.blend),store:s&&n(t.store)}}_normalizeBufferProps(e){(e instanceof ArrayBuffer||ArrayBuffer.isView(e))&&(e={data:e});const t={...e};if((e.usage||0)&W.INDEX&&(e.indexType||(e.data instanceof Uint32Array?t.indexType="uint32":e.data instanceof Uint16Array?t.indexType="uint16":e.data instanceof Uint8Array&&(t.data=new Uint16Array(e.data),t.indexType="uint16")),!t.indexType))throw new Error("indices buffer content must be of type uint16 or uint32");return t}};h(mr,"defaultProps",{...Th});let gi=mr;class xv{constructor(e){h(this,"props");h(this,"_resizeObserver");h(this,"_intersectionObserver");h(this,"_observeDevicePixelRatioTimeout",null);h(this,"_observeDevicePixelRatioMediaQuery",null);h(this,"_handleDevicePixelRatioChange",()=>this._refreshDevicePixelRatio());h(this,"_trackPositionInterval",null);h(this,"_started",!1);this.props=e}get started(){return this._started}start(){if(this._started||!this.props.canvas)return;this._started=!0,this._intersectionObserver||(this._intersectionObserver=new IntersectionObserver(t=>this.props.onIntersection(t))),this._resizeObserver||(this._resizeObserver=new ResizeObserver(t=>this.props.onResize(t))),this._intersectionObserver.observe(this.props.canvas);const e=this.props.resizeObserverBox;try{this._resizeObserver.observe(this.props.canvas,{box:e})}catch{this._resizeObserver.observe(this.props.canvas,{box:"content-box"})}this._observeDevicePixelRatioTimeout=setTimeout(()=>this._refreshDevicePixelRatio(),0),this.props.trackPosition&&this._trackPosition()}stop(){var e,t;this._started&&(this._started=!1,this._observeDevicePixelRatioTimeout&&(clearTimeout(this._observeDevicePixelRatioTimeout),this._observeDevicePixelRatioTimeout=null),this._observeDevicePixelRatioMediaQuery&&(this._observeDevicePixelRatioMediaQuery.removeEventListener("change",this._handleDevicePixelRatioChange),this._observeDevicePixelRatioMediaQuery=null),this._trackPositionInterval&&(clearInterval(this._trackPositionInterval),this._trackPositionInterval=null),(e=this._resizeObserver)==null||e.disconnect(),(t=this._intersectionObserver)==null||t.disconnect())}_refreshDevicePixelRatio(){var e;this._started&&(this.props.onDevicePixelRatioChange(),(e=this._observeDevicePixelRatioMediaQuery)==null||e.removeEventListener("change",this._handleDevicePixelRatioChange),this._observeDevicePixelRatioMediaQuery=matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),this._observeDevicePixelRatioMediaQuery.addEventListener("change",this._handleDevicePixelRatioChange,{once:!0}))}_trackPosition(e=100){this._trackPositionInterval||(this._trackPositionInterval=setInterval(()=>{this._started?this.props.onPositionChange():this._trackPositionInterval&&(clearInterval(this._trackPositionInterval),this._trackPositionInterval=null)},e))}}function Pv(){let i,e;return{promise:new Promise((n,s)=>{i=n,e=s}),resolve:i,reject:e}}function _n(i,e){var t;if(!i){const n=new Error(e??"luma.gl assertion failed.");throw(t=Error.captureStackTrace)==null||t.call(Error,n,_n),n}}function js(i,e){return _n(i,e),i}const ai=class ai{constructor(e){h(this,"id");h(this,"props");h(this,"canvas");h(this,"htmlCanvas");h(this,"offscreenCanvas");h(this,"type");h(this,"initialized");h(this,"isInitialized",!1);h(this,"isVisible",!0);h(this,"cssWidth");h(this,"cssHeight");h(this,"devicePixelRatio");h(this,"devicePixelWidth");h(this,"devicePixelHeight");h(this,"drawingBufferWidth");h(this,"drawingBufferHeight");h(this,"_initializedResolvers",Pv());h(this,"_canvasObserver");h(this,"_position",[0,0]);h(this,"destroyed",!1);h(this,"_needsDrawingBufferResize",!0);h(this,"_configuredDrawingBufferSize",[0,0]);var t,n;this.props={...ai.defaultProps,...e},e=this.props,this.initialized=this._initializedResolvers.promise,Pi()?e.canvas?typeof e.canvas=="string"?this.canvas=Ev(e.canvas):this.canvas=e.canvas:this.canvas=Cv(e):this.canvas={width:e.width||1,height:e.height||1},ai.isHTMLCanvas(this.canvas)?(this.id=e.id||this.canvas.id,this.type="html-canvas",this.htmlCanvas=this.canvas):ai.isOffscreenCanvas(this.canvas)?(this.id=e.id||"offscreen-canvas",this.type="offscreen-canvas",this.offscreenCanvas=this.canvas):(this.id=e.id||"node-canvas-context",this.type="node"),this.cssWidth=((t=this.htmlCanvas)==null?void 0:t.clientWidth)||this.canvas.width,this.cssHeight=((n=this.htmlCanvas)==null?void 0:n.clientHeight)||this.canvas.height,this.devicePixelWidth=this.canvas.width,this.devicePixelHeight=this.canvas.height,this.drawingBufferWidth=this.canvas.width,this.drawingBufferHeight=this.canvas.height,this._configuredDrawingBufferSize=[this.canvas.width,this.canvas.height],this.devicePixelRatio=globalThis.devicePixelRatio||1,this._position=[0,0],this._canvasObserver=new xv({canvas:this.htmlCanvas,trackPosition:this.props.trackPosition,resizeObserverBox:this.props.pixelSizeSource==="css-dpr"?"content-box":"device-pixel-content-box",onResize:s=>this._handleResize(s),onIntersection:s=>this._handleIntersection(s),onDevicePixelRatioChange:()=>this._observeDevicePixelRatio(),onPositionChange:()=>this.updatePosition()})}static isHTMLCanvas(e){return typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement}static isOffscreenCanvas(e){return typeof OffscreenCanvas<"u"&&e instanceof OffscreenCanvas}toString(){return`${this[Symbol.toStringTag]}(${this.id})`}destroy(){this.destroyed||(this.destroyed=!0,this._stopObservers(),this.device=null)}setProps(e){return"useDevicePixels"in e&&(this.props.useDevicePixels=e.useDevicePixels||!1,this._updateDrawingBufferSize()),this}getCurrentFramebuffer(e){return this._resizeDrawingBufferIfNeeded(),this._getCurrentFramebuffer(e)}getCSSSize(){return[this.cssWidth,this.cssHeight]}getPosition(){return this._position}getDevicePixelSize(){return[this.devicePixelWidth,this.devicePixelHeight]}getDrawingBufferSize(){return[this.drawingBufferWidth,this.drawingBufferHeight]}getMaxDrawingBufferSize(){const e=this.device.limits.maxTextureDimension2D;return[e,e]}setDrawingBufferSize(e,t){e=Math.floor(e),t=Math.floor(t),!(this.drawingBufferWidth===e&&this.drawingBufferHeight===t)&&(this.drawingBufferWidth=e,this.drawingBufferHeight=t,this._needsDrawingBufferResize=!0)}getDevicePixelRatio(){return typeof window<"u"&&window.devicePixelRatio||1}cssToDevicePixels(e,t=!0){const n=this.cssToDeviceRatio(),[s,r]=this.getDrawingBufferSize();return Lv(e,n,s,r,t)}getPixelSize(){return this.getDevicePixelSize()}getAspect(){const[e,t]=this.getDrawingBufferSize();return e>0&&t>0?e/t:1}cssToDeviceRatio(){try{const[e]=this.getDrawingBufferSize(),[t]=this.getCSSSize();return t?e/t:1}catch{return 1}}resize(e){this.setDrawingBufferSize(e.width,e.height)}_setAutoCreatedCanvasId(e){var t;((t=this.htmlCanvas)==null?void 0:t.id)==="lumagl-auto-created-canvas"&&(this.htmlCanvas.id=e)}_startObservers(){this.destroyed||this._canvasObserver.start()}_stopObservers(){this._canvasObserver.stop()}_handleIntersection(e){if(this.destroyed)return;const t=e.find(s=>s.target===this.canvas);if(!t)return;const n=t.isIntersecting;this.isVisible!==n&&(this.isVisible=n,this.device.props.onVisibilityChange(this))}_handleResize(e){var r;if(this.destroyed)return;const t=e.find(o=>o.target===this.canvas);if(!t)return;const n=js((r=t.contentBoxSize)==null?void 0:r[0]);this.cssWidth=n.inlineSize,this.cssHeight=n.blockSize;const s=this.getDevicePixelSize();this._setDevicePixelSize(this._getDevicePixelSizeFromResizeEntry(t)),this._updateDrawingBufferSize(),this.device.props.onResize(this,{oldPixelSize:s})}_updateDrawingBufferSize(){if(this.props.autoResize)if(typeof this.props.useDevicePixels=="number"){const e=this.props.useDevicePixels;this.setDrawingBufferSize(this.cssWidth*e,this.cssHeight*e)}else this.props.useDevicePixels?this.setDrawingBufferSize(this.devicePixelWidth,this.devicePixelHeight):this.setDrawingBufferSize(this.cssWidth,this.cssHeight);this._initializedResolvers.resolve(),this.isInitialized=!0,this.updatePosition()}_getDevicePixelSizeFromResizeEntry(e){var n,s,r,o,a;const t=js((n=e.contentBoxSize)==null?void 0:n[0]);return this.props.pixelSizeSource==="css-dpr"?this._getDevicePixelSizeFromCSSSize(t.inlineSize,t.blockSize):{devicePixelWidth:((r=(s=e.devicePixelContentBoxSize)==null?void 0:s[0])==null?void 0:r.inlineSize)||t.inlineSize*devicePixelRatio,devicePixelHeight:((a=(o=e.devicePixelContentBoxSize)==null?void 0:o[0])==null?void 0:a.blockSize)||t.blockSize*devicePixelRatio}}_getDevicePixelSizeFromCSSSize(e,t){const n=this.getDevicePixelRatio();return{devicePixelWidth:Math.floor(e*n),devicePixelHeight:Math.floor(t*n)}}_setDevicePixelSize({devicePixelWidth:e,devicePixelHeight:t}){const[n,s]=this.getMaxDrawingBufferSize();this.devicePixelWidth=Math.max(1,Math.min(e,n)),this.devicePixelHeight=Math.max(1,Math.min(t,s))}_resizeDrawingBufferIfNeeded(){if(this._needsDrawingBufferResize){this._needsDrawingBufferResize=!1,(this.drawingBufferWidth!==this.canvas.width||this.drawingBufferHeight!==this.canvas.height)&&(this.canvas.width=this.drawingBufferWidth,this.canvas.height=this.drawingBufferHeight);const[t,n]=this._configuredDrawingBufferSize;(this.drawingBufferWidth!==t||this.drawingBufferHeight!==n)&&(this._configureDevice(),this._configuredDrawingBufferSize=[this.drawingBufferWidth,this.drawingBufferHeight])}}_observeDevicePixelRatio(){var t,n;if(this.destroyed||!this._canvasObserver.started)return;const e=this.devicePixelRatio;if(this.devicePixelRatio=window.devicePixelRatio,this.props.pixelSizeSource==="css-dpr"){const s=this.getDevicePixelSize();this._setDevicePixelSize(this._getDevicePixelSizeFromCSSSize(this.cssWidth,this.cssHeight)),this._updateDrawingBufferSize(),this.device.props.onResize(this,{oldPixelSize:s})}this.updatePosition(),(n=(t=this.device.props).onDevicePixelRatioChange)==null||n.call(t,this,{oldRatio:e})}updatePosition(){var t,n,s;if(this.destroyed)return;const e=(t=this.htmlCanvas)==null?void 0:t.getBoundingClientRect();if(e){const r=[e.left,e.top];if(this._position??(this._position=r),r[0]!==this._position[0]||r[1]!==this._position[1]){const a=this._position;this._position=r,(s=(n=this.device.props).onPositionChange)==null||s.call(n,this,{oldPosition:a})}}}};h(ai,"defaultProps",{id:void 0,canvas:null,width:800,height:600,useDevicePixels:!0,pixelSizeSource:"exact",autoResize:!0,container:null,visible:!0,alphaMode:"opaque",colorSpace:"srgb",colorFormat:void 0,toneMapping:"standard",trackPosition:!1});let pi=ai;function Sv(i){if(typeof i=="string"){const e=document.getElementById(i);if(!e)throw new Error(`${i} is not an HTML element`);return e}return i||document.body}function Ev(i){const e=document.getElementById(i);if(!pi.isHTMLCanvas(e))throw new Error("Object is not a canvas element");return e}function Cv(i){const{width:e,height:t}=i,n=document.createElement("canvas");n.id=In("lumagl-auto-created-canvas"),n.width=e||1,n.height=t||1,n.style.width=Number.isFinite(e)?`${e}px`:"100%",n.style.height=Number.isFinite(t)?`${t}px`:"100%",i!=null&&i.visible||(n.style.visibility="hidden");const s=Sv((i==null?void 0:i.container)||null);return s.insertBefore(n,s.firstChild),n}function Lv(i,e,t,n,s){const r=i,o=su(r[0],e,t);let a=ru(r[1],e,n,s),c=su(r[0]+1,e,t);const l=c===t-1?c:c-1;c=ru(r[1]+1,e,n,s);let u;return s?(c=c===0?c:c+1,u=a,a=c):u=c===n-1?c:c-1,{x:o,y:a,width:Math.max(l-o+1,1),height:Math.max(u-a+1,1)}}function su(i,e,t){return Math.min(Math.round(i*e),t-1)}function ru(i,e,t,n){return n?Math.max(0,t-1-Math.round(i*e)):Math.min(Math.round(i*e),t-1)}class Bh extends pi{}h(Bh,"defaultProps",pi.defaultProps);class Tv extends pi{}const dn=class dn extends q{get[Symbol.toStringTag](){return"Sampler"}constructor(e,t){t=dn.normalizeProps(e,t),super(e,t,dn.defaultProps)}static normalizeProps(e,t){return t}};h(dn,"defaultProps",{...q.defaultProps,type:"color-sampler",addressModeU:"clamp-to-edge",addressModeV:"clamp-to-edge",addressModeW:"clamp-to-edge",magFilter:"nearest",minFilter:"nearest",mipmapFilter:"none",lodMinClamp:0,lodMaxClamp:32,compare:"less-equal",maxAnisotropy:1});let Vs=dn;const Av={"1d":"1d","2d":"2d","2d-array":"2d",cube:"2d","cube-array":"2d","3d":"3d"},ee=class ee extends q{constructor(t,n,s){n=ee.normalizeProps(t,n);super(t,n,ee.defaultProps);h(this,"dimension");h(this,"baseDimension");h(this,"format");h(this,"width");h(this,"height");h(this,"depth");h(this,"mipLevels");h(this,"samples");h(this,"byteAlignment");h(this,"ready",Promise.resolve(this));h(this,"isReady",!0);h(this,"updateTimestamp");if(this.dimension=this.props.dimension,this.baseDimension=Av[this.dimension],this.format=this.props.format,this.width=this.props.width,this.height=this.props.height,this.depth=this.props.depth,this.mipLevels=this.props.mipLevels,this.samples=this.props.samples||1,this.dimension==="cube"&&(this.depth=6),this.props.width===void 0||this.props.height===void 0)if(t.isExternalImage(n.data)){const r=t.getExternalImageSize(n.data);this.width=(r==null?void 0:r.width)||1,this.height=(r==null?void 0:r.height)||1}else this.width=1,this.height=1,(this.props.width===void 0||this.props.height===void 0)&&M.warn(`${this} created with undefined width or height. This is deprecated. Use DynamicTexture instead.`)();this.byteAlignment=(s==null?void 0:s.byteAlignment)||1,this.updateTimestamp=t.incrementTimestamp()}get[Symbol.toStringTag](){return"Texture"}toString(){return`Texture(${this.id},${this.format},${this.width}x${this.height})`}clone(t){return this.device.createTexture({...this.props,...t})}setSampler(t){this.sampler=t instanceof Vs?t:this.device.createSampler(t)}copyImageData(t){const{data:n,depth:s,...r}=t;this.writeData(n,{...r,depthOrArrayLayers:r.depthOrArrayLayers??s})}computeMemoryLayout(t={}){const n=this._normalizeTextureReadOptions(t),{width:s=this.width,height:r=this.height,depthOrArrayLayers:o=this.depth}=n,{format:a,byteAlignment:c}=this;return Fe.computeMemoryLayout({format:a,width:s,height:r,depth:o,byteAlignment:c})}readBuffer(t,n){throw new Error("readBuffer not implemented")}readDataAsync(t){throw new Error("readBuffer not implemented")}writeBuffer(t,n){throw new Error("readBuffer not implemented")}writeData(t,n){throw new Error("readBuffer not implemented")}readDataSyncWebGL(t){throw new Error("readDataSyncWebGL not available")}generateMipmapsWebGL(){throw new Error("generateMipmapsWebGL not available")}static normalizeProps(t,n){const s={...n},{width:r,height:o}=s;return typeof r=="number"&&(s.width=Math.max(1,Math.ceil(r))),typeof o=="number"&&(s.height=Math.max(1,Math.ceil(o))),s}_initializeData(t){this.device.isExternalImage(t)?this.copyExternalImage({image:t,width:this.width,height:this.height,depth:this.depth,mipLevel:0,x:0,y:0,z:0,aspect:"all",colorSpace:"srgb",premultipliedAlpha:!1,flipY:!1}):t&&this.copyImageData({data:t,mipLevel:0,x:0,y:0,z:0,aspect:"all"})}_normalizeCopyImageDataOptions(t){const{data:n,depth:s,...r}=t,o=this._normalizeTextureWriteOptions({...r,depthOrArrayLayers:r.depthOrArrayLayers??s});return{data:n,depth:o.depthOrArrayLayers,...o}}_normalizeCopyExternalImageOptions(t){const n=ee._omitUndefined(t),s=n.mipLevel??0,r=this._getMipLevelSize(s),o=this.device.getExternalImageSize(t.image),a={...ee.defaultCopyExternalImageOptions,...r,...o,...n};return a.width=Math.min(a.width,r.width-a.x),a.height=Math.min(a.height,r.height-a.y),a.depth=Math.min(a.depth,r.depthOrArrayLayers-a.z),a}_normalizeCopyElementImageOptions(t){const n=ee._omitUndefined(t),s=n.mipLevel??0,r=this._getMipLevelSize(s),o={...ee.defaultCopyElementImageOptions,...r,...n};return o.width=Math.min(o.width,r.width-o.x),o.height=Math.min(o.height,r.height-o.y),o.depth=Math.min(o.depth,r.depthOrArrayLayers-o.z),o}_normalizeTextureReadOptions(t){const n=ee._omitUndefined(t),s=n.mipLevel??0,r=this._getMipLevelSize(s),o={...ee.defaultTextureReadOptions,...r,...n};return o.width=Math.min(o.width,r.width-o.x),o.height=Math.min(o.height,r.height-o.y),o.depthOrArrayLayers=Math.min(o.depthOrArrayLayers,r.depthOrArrayLayers-o.z),o}_getSupportedColorReadOptions(t){const n=this._normalizeTextureReadOptions(t),s=Fe.getInfo(this.format);switch(this._validateColorReadAspect(n),this._validateColorReadFormat(s),this.dimension){case"2d":case"cube":case"cube-array":case"2d-array":case"3d":return n;default:throw new Error(`${this} color readback does not support ${this.dimension} textures`)}}_validateColorReadAspect(t){if(t.aspect!=="all")throw new Error(`${this} color readback only supports aspect 'all'`)}_validateColorReadFormat(t){if(t.compressed)throw new Error(`${this} color readback does not support compressed formats (${this.format})`);switch(t.attachment){case"color":return;case"depth":throw new Error(`${this} color readback does not support depth formats (${this.format})`);case"stencil":throw new Error(`${this} color readback does not support stencil formats (${this.format})`);case"depth-stencil":throw new Error(`${this} color readback does not support depth-stencil formats (${this.format})`);default:throw new Error(`${this} color readback does not support format ${this.format}`)}}_normalizeTextureWriteOptions(t){const n=ee._omitUndefined(t),s=n.mipLevel??0,r=this._getMipLevelSize(s),o={...ee.defaultTextureWriteOptions,...r,...n};o.width=Math.min(o.width,r.width-o.x),o.height=Math.min(o.height,r.height-o.y),o.depthOrArrayLayers=Math.min(o.depthOrArrayLayers,r.depthOrArrayLayers-o.z);const a=Fe.computeMemoryLayout({format:this.format,width:o.width,height:o.height,depth:o.depthOrArrayLayers,byteAlignment:this.byteAlignment}),c=a.bytesPerPixel*o.width;if(o.bytesPerRow=n.bytesPerRow??a.bytesPerRow,o.rowsPerImage=n.rowsPerImage??o.height,o.bytesPerRow<c)throw new Error(`bytesPerRow (${o.bytesPerRow}) must be at least ${c} for ${this.format}`);if(o.rowsPerImage<o.height)throw new Error(`rowsPerImage (${o.rowsPerImage}) must be at least ${o.height} for ${this.format}`);const l=this.device.getTextureFormatInfo(this.format).bytesPerPixel;if(l&&o.bytesPerRow%l!==0)throw new Error(`bytesPerRow (${o.bytesPerRow}) must be a multiple of bytesPerPixel (${l}) for ${this.format}`);return o}_getMipLevelSize(t){const n=Math.max(1,this.width>>t),s=this.baseDimension==="1d"?1:Math.max(1,this.height>>t),r=this.dimension==="3d"?Math.max(1,this.depth>>t):this.depth;return{width:n,height:s,depthOrArrayLayers:r}}getAllocatedByteLength(){let t=0;for(let n=0;n<this.mipLevels;n++){const{width:s,height:r,depthOrArrayLayers:o}=this._getMipLevelSize(n);t+=Fe.computeMemoryLayout({format:this.format,width:s,height:r,depth:o,byteAlignment:1}).byteLength}return t*this.samples}static _omitUndefined(t){return Object.fromEntries(Object.entries(t).filter(([,n])=>n!==void 0))}};h(ee,"SAMPLE",4),h(ee,"STORAGE",8),h(ee,"RENDER",16),h(ee,"COPY_SRC",1),h(ee,"COPY_DST",2),h(ee,"TEXTURE",4),h(ee,"RENDER_ATTACHMENT",16),h(ee,"defaultProps",{...q.defaultProps,data:null,dimension:"2d",format:"rgba8unorm",usage:ee.SAMPLE|ee.RENDER|ee.COPY_DST,width:void 0,height:void 0,depth:1,mipLevels:1,samples:void 0,sampler:{},view:void 0}),h(ee,"defaultCopyDataOptions",{data:void 0,byteOffset:0,bytesPerRow:void 0,rowsPerImage:void 0,width:void 0,height:void 0,depthOrArrayLayers:void 0,depth:1,mipLevel:0,x:0,y:0,z:0,aspect:"all"}),h(ee,"defaultCopyExternalImageOptions",{image:void 0,sourceX:0,sourceY:0,width:void 0,height:void 0,depth:1,mipLevel:0,x:0,y:0,z:0,aspect:"all",colorSpace:"srgb",premultipliedAlpha:!1,flipY:!1}),h(ee,"defaultCopyElementImageOptions",{element:void 0,width:void 0,height:void 0,sourceX:0,sourceY:0,sourceWidth:void 0,sourceHeight:void 0,depth:1,mipLevel:0,x:0,y:0,z:0,aspect:"all",colorSpace:"srgb",premultipliedAlpha:!1,flipY:!1}),h(ee,"defaultTextureReadOptions",{x:0,y:0,z:0,width:void 0,height:void 0,depthOrArrayLayers:1,mipLevel:0,aspect:"all"}),h(ee,"defaultTextureWriteOptions",{byteOffset:0,bytesPerRow:void 0,rowsPerImage:void 0,x:0,y:0,z:0,width:void 0,height:void 0,depthOrArrayLayers:1,mipLevel:0,aspect:"all"});let he=ee;const _r=class _r extends q{get[Symbol.toStringTag](){return"TextureView"}constructor(e,t){super(e,t,_r.defaultProps)}};h(_r,"defaultProps",{...q.defaultProps,format:void 0,dimension:void 0,aspect:"all",baseMipLevel:0,mipLevelCount:void 0,baseArrayLayer:0,arrayLayerCount:void 0});let Ws=_r;const yr=class yr extends q{constructor(t,n){super(t,n,yr.defaultProps);h(this,"width");h(this,"height");h(this,"updateTimestamp");const s=this.props.source?t.getExternalImageSize(this.props.source):null;this.width=this.props.width||(s==null?void 0:s.width)||0,this.height=this.props.height||(s==null?void 0:s.height)||0,this.updateTimestamp=t.incrementTimestamp()}get[Symbol.toStringTag](){return"ExternalTexture"}};h(yr,"defaultProps",{...q.defaultProps,source:void 0,width:0,height:0,colorSpace:"srgb",sampler:{}});let Sa=yr;function Mv(i,e,t){let n="";const s=e.split(/\r?\n/),r=i.slice().sort((o,a)=>o.lineNum-a.lineNum);switch((t==null?void 0:t.showSourceCode)||"no"){case"all":let o=0;for(let a=1;a<=s.length;a++){const c=s[a-1],l=r[o];for(c&&l&&(n+=kh(c,a,t));r.length>o&&l.lineNum===a;){const u=r[o++];u&&(n+=po(u,s,u.lineNum,{...t,inlineSource:!1}))}}for(;r.length>o;){const a=r[o++];a&&(n+=po(a,[],0,{...t,inlineSource:!1}))}return n;case"issues":case"no":for(const a of i)n+=po(a,s,a.lineNum,{inlineSource:(t==null?void 0:t.showSourceCode)!=="no"});return n}}function po(i,e,t,n){if(n!=null&&n.inlineSource){const r=Iv(e,t),o=i.linePos>0?`${" ".repeat(i.linePos+5)}^^^
`:"";return`
${r}${o}${i.type.toUpperCase()}: ${i.message}

`}const s=i.type==="error"?"red":"orange";return n!=null&&n.html?`<div class='luma-compiler-log-${i.type}' style="color:${s};"><b> ${i.type.toUpperCase()}: ${i.message}</b></div>`:`${i.type.toUpperCase()}: ${i.message}`}function Iv(i,e,t){let n="";for(let s=e-2;s<=e;s++){const r=i[s-1];r!==void 0&&(n+=kh(r,e,t))}return n}function kh(i,e,t){const n=t!=null&&t.html?Ov(i):i;return`${Rv(String(e),4)}: ${n}${t!=null&&t.html?"<br/>":`
`}`}function Rv(i,e){let t="";for(let n=i.length;n<e;++n)t+=" ";return t+i}function Ov(i){return i.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}const br=class br extends q{constructor(t,n){n={...n,debugShaders:n.debugShaders||t.props.debugShaders||"errors"};super(t,{id:Bv(n),...n},br.defaultProps);h(this,"stage");h(this,"source");h(this,"compilationStatus","pending");this.stage=this.props.stage,this.source=this.props.source}get[Symbol.toStringTag](){return"Shader"}getCompilationInfoSync(){return null}getTranslatedSource(){return null}async debugShader(){const t=this.props.debugShaders;switch(t){case"never":return;case"errors":if(this.compilationStatus==="success")return;break}try{const n=await this.getCompilationInfo();if(t==="warnings"&&(n==null?void 0:n.length)===0)return;this._displayShaderLog(n,this.id)}catch(n){M.warn(`Shader ${this.id}: failed to fetch compilation info during debug logging`,n)()}}_displayShaderLog(t,n){if(typeof document>"u"||!(document!=null&&document.createElement))return;const s=n,r=`${this.stage} shader "${s}"`,o=Mv(t,this.source,{showSourceCode:"all",html:!0}),a=this.getTranslatedSource(),c=document.createElement("div");c.innerHTML=`<h1>Compilation error in ${r}</h1>
<div style="display:flex;position:fixed;top:10px;right:20px;gap:2px;">
<button id="copy">Copy source</button><br/>
<button id="close">Close</button>
</div>
<code><pre>${o}</pre></code>`,a&&(c.innerHTML+=`<br /><h1>Translated Source</h1><br /><br /><code><pre>${a}</pre></code>`),c.style.top="0",c.style.left="0",c.style.background="white",c.style.position="fixed",c.style.zIndex="9999",c.style.maxWidth="100vw",c.style.maxHeight="100vh",c.style.overflowY="auto",document.body.appendChild(c);const l=c.querySelector(".luma-compiler-log-error");l==null||l.scrollIntoView(),c.querySelector("button#close").onclick=()=>{c.remove()},c.querySelector("button#copy").onclick=()=>{navigator.clipboard.writeText(this.source)}}};h(br,"defaultProps",{...q.defaultProps,language:"auto",stage:void 0,source:"",sourceMap:null,entryPoint:"main",debugShaders:void 0});let Hs=br;function Bv(i){return kv(i.source)||i.id||In(`unnamed ${i.stage}-shader`)}function kv(i,e="unnamed"){const n=/#define[\s*]SHADER_NAME[\s*]([A-Za-z0-9_-]+)[\s*]/.exec(i);return(n==null?void 0:n[1])??e}const vr=class vr extends q{constructor(t,n={}){super(t,n,vr.defaultProps);h(this,"width");h(this,"height");this.width=this.props.width,this.height=this.props.height}get[Symbol.toStringTag](){return"Framebuffer"}clone(t){const n=this.colorAttachments.map(r=>r.texture.clone(t)),s=this.depthStencilAttachment&&this.depthStencilAttachment.texture.clone(t);return this.device.createFramebuffer({...this.props,...t,colorAttachments:n,depthStencilAttachment:s})}resize(t){let n=!t;if(t){const[s,r]=Array.isArray(t)?t:[t.width,t.height];n=n||r!==this.height||s!==this.width,this.width=s,this.height=r}n&&(M.log(2,`Resizing framebuffer ${this.id} to ${this.width}x${this.height}`)(),this.resizeAttachments(this.width,this.height))}autoCreateAttachmentTextures(){if(this.props.colorAttachments.length===0&&!this.props.depthStencilAttachment)throw new Error("Framebuffer has noattachments");this.colorAttachments=this.props.colorAttachments.map((n,s)=>{if(typeof n=="string"){const r=this.createColorTexture(n,s);return this.attachResource(r),r.view}return n instanceof he?n.view:n});const t=this.props.depthStencilAttachment;if(t)if(typeof t=="string"){const n=this.createDepthStencilTexture(t);this.attachResource(n),this.depthStencilAttachment=n.view}else t instanceof he?this.depthStencilAttachment=t.view:this.depthStencilAttachment=t}createColorTexture(t,n){return this.device.createTexture({id:`${this.id}-color-attachment-${n}`,usage:he.RENDER_ATTACHMENT,format:t,width:this.width,height:this.height,sampler:{magFilter:"linear",minFilter:"linear"}})}createDepthStencilTexture(t){return this.device.createTexture({id:`${this.id}-depth-stencil-attachment`,usage:he.RENDER_ATTACHMENT|he.SAMPLE,format:t,width:this.width,height:this.height})}resizeAttachments(t,n){if(this.colorAttachments.forEach((s,r)=>{const o=s.texture.clone({width:t,height:n});this.destroyAttachedResource(s),this.colorAttachments[r]=o.view,this.attachResource(o.view)}),this.depthStencilAttachment){const s=this.depthStencilAttachment.texture.clone({width:t,height:n});this.destroyAttachedResource(this.depthStencilAttachment),this.depthStencilAttachment=s.view,this.attachResource(s)}this.updateAttachments()}};h(vr,"defaultProps",{...q.defaultProps,width:1,height:1,colorAttachments:[],depthStencilAttachment:null});let Ys=vr;const wr=class wr extends q{constructor(t,n){super(t,n,wr.defaultProps);h(this,"shaderLayout");h(this,"bufferLayout");h(this,"linkStatus","pending");h(this,"hash","");h(this,"sharedRenderPipeline",null);this.shaderLayout=this.props.shaderLayout,this.bufferLayout=this.props.bufferLayout||[],this.sharedRenderPipeline=this.props._sharedRenderPipeline||null}get[Symbol.toStringTag](){return"RenderPipeline"}get isPending(){var t;return this.linkStatus==="pending"||this.vs.compilationStatus==="pending"||((t=this.fs)==null?void 0:t.compilationStatus)==="pending"}get isErrored(){var t;return this.linkStatus==="error"||this.vs.compilationStatus==="error"||((t=this.fs)==null?void 0:t.compilationStatus)==="error"}};h(wr,"defaultProps",{...q.defaultProps,vs:null,vertexEntryPoint:"vertexMain",vsConstants:{},fs:null,fragmentEntryPoint:"fragmentMain",fsConstants:{},shaderLayout:null,bufferLayout:[],topology:"triangle-list",colorAttachmentFormats:void 0,depthStencilAttachmentFormat:void 0,parameters:{},varyings:void 0,bufferMode:void 0,disableWarnings:!1,_sharedRenderPipeline:void 0,_uniformBlockLayouts:[],bindings:void 0,bindGroups:void 0});let ht=wr;class Dv extends q{get[Symbol.toStringTag](){return"SharedRenderPipeline"}constructor(e,t){super(e,t,{...q.defaultProps,handle:void 0,vs:void 0,fs:void 0,varyings:void 0,bufferMode:void 0})}}const xr=class xr extends q{constructor(t,n){super(t,n,xr.defaultProps);h(this,"hash","");h(this,"shaderLayout");this.shaderLayout=n.shaderLayout}get[Symbol.toStringTag](){return"ComputePipeline"}};h(xr,"defaultProps",{...q.defaultProps,shader:void 0,entryPoint:void 0,constants:{},shaderLayout:void 0});let yn=xr;const Pr=class Pr{constructor(e){h(this,"device");h(this,"_hashCounter",0);h(this,"_hashes",{});h(this,"_renderPipelineCache",{});h(this,"_computePipelineCache",{});h(this,"_sharedRenderPipelineCache",{});this.device=e}static getDefaultPipelineFactory(e){const t=e.getModuleData("@luma.gl/core");return t.defaultPipelineFactory||(t.defaultPipelineFactory=new Pr(e)),t.defaultPipelineFactory}get[Symbol.toStringTag](){return"PipelineFactory"}toString(){return`PipelineFactory(${this.device.id})`}createRenderPipeline(e){var o;if(!this.device.props._cachePipelines)return this.device.createRenderPipeline(e);const t={...ht.defaultProps,...e},n=this._renderPipelineCache,s=this._hashRenderPipeline(t);let r=(o=n[s])==null?void 0:o.resource;if(r)n[s].useCount++,this.device.props.debugFactories&&M.log(3,`${this}: ${n[s].resource} reused, count=${n[s].useCount}, (id=${e.id})`)();else{const a=this.device.type==="webgl"&&this.device.props._sharePipelines?this.createSharedRenderPipeline(t):void 0;r=this.device.createRenderPipeline({...t,id:t.id?`${t.id}-cached`:In("unnamed-cached"),_sharedRenderPipeline:a}),r.hash=s,n[s]={resource:r,useCount:1},this.device.props.debugFactories&&M.log(3,`${this}: ${r} created, count=${n[s].useCount}`)()}return r}createComputePipeline(e){var o;if(!this.device.props._cachePipelines)return this.device.createComputePipeline(e);const t={...yn.defaultProps,...e},n=this._computePipelineCache,s=this._hashComputePipeline(t);let r=(o=n[s])==null?void 0:o.resource;return r?(n[s].useCount++,this.device.props.debugFactories&&M.log(3,`${this}: ${n[s].resource} reused, count=${n[s].useCount}, (id=${e.id})`)()):(r=this.device.createComputePipeline({...t,id:t.id?`${t.id}-cached`:void 0}),r.hash=s,n[s]={resource:r,useCount:1},this.device.props.debugFactories&&M.log(3,`${this}: ${r} created, count=${n[s].useCount}`)()),r}release(e){if(!this.device.props._cachePipelines){e.destroy();return}const t=this._getCache(e),n=e.hash;t[n].useCount--,t[n].useCount===0?(this._destroyPipeline(e),this.device.props.debugFactories&&M.log(3,`${this}: ${e} released and destroyed`)()):t[n].useCount<0?(M.error(`${this}: ${e} released, useCount < 0, resetting`)(),t[n].useCount=0):this.device.props.debugFactories&&M.log(3,`${this}: ${e} released, count=${t[n].useCount}`)()}createSharedRenderPipeline(e){const t=this._hashSharedRenderPipeline(e);let n=this._sharedRenderPipelineCache[t];return n||(n={resource:this.device._createSharedRenderPipelineWebGL(e),useCount:0},this._sharedRenderPipelineCache[t]=n),n.useCount++,n.resource}releaseSharedRenderPipeline(e){if(!e.sharedRenderPipeline)return;const t=this._hashSharedRenderPipeline(e.sharedRenderPipeline.props),n=this._sharedRenderPipelineCache[t];n&&(n.useCount--,n.useCount===0&&(n.resource.destroy(),delete this._sharedRenderPipelineCache[t]))}_destroyPipeline(e){const t=this._getCache(e);return this.device.props._destroyPipelines?(delete t[e.hash],e.destroy(),e instanceof ht&&this.releaseSharedRenderPipeline(e),!0):!1}_getCache(e){let t;if(e instanceof yn&&(t=this._computePipelineCache),e instanceof ht&&(t=this._renderPipelineCache),!t)throw new Error(`${this}`);if(!t[e.hash])throw new Error(`${this}: ${e} matched incorrect entry`);return t}_hashComputePipeline(e){const{type:t}=this.device,n=this._getHash(e.shader.source),s=this._getHash(JSON.stringify(e.shaderLayout));return`${t}/C/${n}SL${s}`}_hashRenderPipeline(e){const t=e.vs?this._getHash(e.vs.source):0,n=e.fs?this._getHash(e.fs.source):0,s=this._getWebGLVaryingHash(e),r=this._getHash(JSON.stringify(e.shaderLayout)),o=this._getHash(JSON.stringify(e._uniformBlockLayouts)),a=this._getHash(JSON.stringify(e.bufferLayout)),{type:c}=this.device;switch(c){case"webgl":const l=this._getHash(JSON.stringify(e.parameters));return`${c}/R/${t}/${n}V${s}T${e.topology}P${l}SL${r}UBL${o}BL${a}`;case"webgpu":default:const u=this._getHash(JSON.stringify({vertexEntryPoint:e.vertexEntryPoint,fragmentEntryPoint:e.fragmentEntryPoint})),f=this._getHash(JSON.stringify(e.parameters)),d=this._getWebGPUAttachmentHash(e);return`${c}/R/${t}/${n}V${s}T${e.topology}EP${u}P${f}SL${r}BL${a}A${d}`}}_hashSharedRenderPipeline(e){const t=e.vs?this._getHash(e.vs.source):0,n=e.fs?this._getHash(e.fs.source):0,s=this._getWebGLVaryingHash(e);return`webgl/S/${t}/${n}V${s}`}_getHash(e){return this._hashes[e]===void 0&&(this._hashes[e]=this._hashCounter++),this._hashes[e]}_getWebGLVaryingHash(e){const{varyings:t=[],bufferMode:n=null}=e;return this._getHash(JSON.stringify({varyings:t,bufferMode:n}))}_getWebGPUAttachmentHash(e){var s;const t=e.colorAttachmentFormats??[this.device.preferredColorFormat],n=e.depthStencilAttachmentFormat??((s=e.parameters)!=null&&s.depthWriteEnabled?this.device.preferredDepthFormat:null);return this._getHash(JSON.stringify({colorAttachmentFormats:t,depthStencilAttachmentFormat:n}))}};h(Pr,"defaultProps",{...ht.defaultProps});let qs=Pr;const Sr=class Sr{constructor(e){h(this,"device");h(this,"_cache",{});this.device=e}static getDefaultShaderFactory(e){const t=e.getModuleData("@luma.gl/core");return t.defaultShaderFactory||(t.defaultShaderFactory=new Sr(e)),t.defaultShaderFactory}get[Symbol.toStringTag](){return"ShaderFactory"}toString(){return`${this[Symbol.toStringTag]}(${this.device.id})`}createShader(e){if(!this.device.props._cacheShaders)return this.device.createShader(e);const t=this._hashShader(e);let n=this._cache[t];if(n)n.useCount++,this.device.props.debugFactories&&M.log(3,`${this}: Reusing shader ${n.resource.id} count=${n.useCount}`)();else{const s=this.device.createShader({...e,id:e.id?`${e.id}-cached`:void 0});this._cache[t]=n={resource:s,useCount:1},this.device.props.debugFactories&&M.log(3,`${this}: Created new shader ${s.id}`)()}return n.resource}release(e){if(!this.device.props._cacheShaders){e.destroy();return}const t=this._hashShader(e),n=this._cache[t];if(n)if(n.useCount--,n.useCount===0)this.device.props._destroyShaders&&(delete this._cache[t],n.resource.destroy(),this.device.props.debugFactories&&M.log(3,`${this}: Releasing shader ${e.id}, destroyed`)());else{if(n.useCount<0)throw new Error(`ShaderFactory: Shader ${e.id} released too many times`);this.device.props.debugFactories&&M.log(3,`${this}: Releasing shader ${e.id} count=${n.useCount}`)()}}_hashShader(e){return`${e.stage}:${e.source}`}};h(Sr,"defaultProps",{...Hs.defaultProps});let Zs=Sr;function Dh(i,e,t){const n=i.bindings.find(s=>s.name===e||`${s.name.toLocaleLowerCase()}uniforms`===e.toLocaleLowerCase());return!n&&!(t!=null&&t.ignoreWarnings)&&M.warn(`Binding ${e} not set: Not found in shader layout.`)(),n||null}function Dc(i,e){if(!e)return{};if(Fv(e))return Object.fromEntries(Object.entries(e).map(([s,r])=>[Number(s),{...r}]));const t={};for(const[n,s]of Object.entries(e)){const r=Dh(i,n),o=(r==null?void 0:r.group)??0;t[o]||(t[o]={}),t[o][n]=s}return t}function Ea(i){const e={};for(const t of Object.values(i))Object.assign(e,t);return e}function Fv(i){const e=Object.keys(i);return e.length>0&&e.every(t=>/^\d+$/.test(t))}const ke=class ke extends q{get[Symbol.toStringTag](){return"RenderPass"}constructor(e,t,n=ke.defaultProps){t=ke.normalizeProps(e,t),super(e,t,n)}static normalizeProps(e,t){return t}};h(ke,"defaultClearColor",[0,0,0,1]),h(ke,"defaultClearDepth",1),h(ke,"defaultClearStencil",0),h(ke,"defaultProps",{...q.defaultProps,framebuffer:null,resolveTargets:void 0,parameters:void 0,clearColor:ke.defaultClearColor,clearColors:void 0,clearDepth:ke.defaultClearDepth,clearStencil:ke.defaultClearStencil,depthReadOnly:!1,stencilReadOnly:!1,discard:!1,occlusionQuerySet:void 0,timestampQuerySet:void 0,beginTimestampIndex:void 0,endTimestampIndex:void 0});let Ca=ke;const Er=class Er extends q{constructor(t,n){super(t,n,Er.defaultProps);h(this,"_timeProfilingQuerySet",null);h(this,"_timeProfilingSlotCount",0);h(this,"_gpuTimeMs");this._timeProfilingQuerySet=n.timeProfilingQuerySet??null,this._timeProfilingSlotCount=0,this._gpuTimeMs=void 0}get[Symbol.toStringTag](){return"CommandEncoder"}async resolveTimeProfilingQuerySet(){if(this._gpuTimeMs=void 0,!this._timeProfilingQuerySet)return;const t=Math.floor(this._timeProfilingSlotCount/2);if(t<=0)return;const n=t*2,s=await this._timeProfilingQuerySet.readResults({firstQuery:0,queryCount:n});let r=0n;for(let o=0;o<n;o+=2)r+=s[o+1]-s[o];this._gpuTimeMs=Number(r)/1e6}getTimeProfilingSlotCount(){return this._timeProfilingSlotCount}getTimeProfilingQuerySet(){return this._timeProfilingQuerySet}_applyTimeProfilingToPassProps(t){const n=t||{};if(!this._supportsTimestampQueries()||!this._timeProfilingQuerySet||n.timestampQuerySet!==void 0||n.beginTimestampIndex!==void 0||n.endTimestampIndex!==void 0)return n;const s=this._timeProfilingSlotCount;return s+1>=this._timeProfilingQuerySet.props.count?n:(this._timeProfilingSlotCount+=2,{...n,timestampQuerySet:this._timeProfilingQuerySet,beginTimestampIndex:s,endTimestampIndex:s+1})}_supportsTimestampQueries(){return this.device.features.has("timestamp-query")}};h(Er,"defaultProps",{...q.defaultProps,measureExecutionTime:void 0,timeProfilingQuerySet:void 0});let La=Er;const Cr=class Cr extends q{get[Symbol.toStringTag](){return"CommandBuffer"}constructor(e,t){super(e,t,Cr.defaultProps)}};h(Cr,"defaultProps",{...q.defaultProps});let Ta=Cr;const Lr=class Lr extends q{constructor(t,n){super(t,n,Lr.defaultProps);h(this,"maxVertexAttributes");h(this,"indexBuffer",null);h(this,"attributes");this.maxVertexAttributes=t.limits.maxVertexAttributes,this.attributes=new Array(this.maxVertexAttributes).fill(null)}get[Symbol.toStringTag](){return"VertexArray"}getBufferSlot(t){return null}getDrawValidationError(){return null}setConstantWebGL(t,n){this.device.reportError(new Error("constant attributes not supported"),this)()}};h(Lr,"defaultProps",{...q.defaultProps,shaderLayout:void 0,bufferLayout:[]});let Aa=Lr;const Tr=class Tr extends q{get[Symbol.toStringTag](){return"TransformFeedback"}constructor(e,t){super(e,t,Tr.defaultProps)}};h(Tr,"defaultProps",{...q.defaultProps,layout:void 0,buffers:{}});let Ma=Tr;const Ar=class Ar extends q{get[Symbol.toStringTag](){return"QuerySet"}constructor(e,t){super(e,t,Ar.defaultProps)}};h(Ar,"defaultProps",{...q.defaultProps,type:void 0,count:void 0});let Ia=Ar;const Mr=class Mr extends q{get[Symbol.toStringTag](){return"Fence"}constructor(e,t={}){super(e,t,Mr.defaultProps)}};h(Mr,"defaultProps",{...q.defaultProps});let Ra=Mr;function Fc(i){const e=zc(i),t=jv[e];if(!t)throw new Error(`Unsupported variable shader type: ${i}`);return t}function zv(i){const e=Fh(i),t=Gv[e];if(!t)throw new Error(`Unsupported attribute shader type: ${i}`);const[n,s]=t,r=n==="i32"||n==="u32",o=n!=="u32",a=$v[n]*s;return{primitiveType:n,components:s,byteLength:a,integer:r,signed:o}}class Nv{getVariableShaderTypeInfo(e){return Fc(e)}getAttributeShaderTypeInfo(e){return zv(e)}makeShaderAttributeType(e,t){return Uv(e,t)}resolveAttributeShaderTypeAlias(e){return Fh(e)}resolveVariableShaderTypeAlias(e){return zc(e)}}function Uv(i,e){return e===1?i:`vec${e}<${i}>`}function Fh(i){return Vv[i]||i}function zc(i){return Wv[i]||i}const Li=new Nv,$v={f32:4,f16:2,i32:4,u32:4},Gv={f32:["f32",1],"vec2<f32>":["f32",2],"vec3<f32>":["f32",3],"vec4<f32>":["f32",4],f16:["f16",1],"vec2<f16>":["f16",2],"vec3<f16>":["f16",3],"vec4<f16>":["f16",4],i32:["i32",1],"vec2<i32>":["i32",2],"vec3<i32>":["i32",3],"vec4<i32>":["i32",4],u32:["u32",1],"vec2<u32>":["u32",2],"vec3<u32>":["u32",3],"vec4<u32>":["u32",4]},jv={f32:{type:"f32",components:1},f16:{type:"f16",components:1},i32:{type:"i32",components:1},u32:{type:"u32",components:1},"vec2<f32>":{type:"f32",components:2},"vec3<f32>":{type:"f32",components:3},"vec4<f32>":{type:"f32",components:4},"vec2<f16>":{type:"f16",components:2},"vec3<f16>":{type:"f16",components:3},"vec4<f16>":{type:"f16",components:4},"vec2<i32>":{type:"i32",components:2},"vec3<i32>":{type:"i32",components:3},"vec4<i32>":{type:"i32",components:4},"vec2<u32>":{type:"u32",components:2},"vec3<u32>":{type:"u32",components:3},"vec4<u32>":{type:"u32",components:4},"mat2x2<f32>":{type:"f32",components:4},"mat2x3<f32>":{type:"f32",components:6},"mat2x4<f32>":{type:"f32",components:8},"mat3x2<f32>":{type:"f32",components:6},"mat3x3<f32>":{type:"f32",components:9},"mat3x4<f32>":{type:"f32",components:12},"mat4x2<f32>":{type:"f32",components:8},"mat4x3<f32>":{type:"f32",components:12},"mat4x4<f32>":{type:"f32",components:16},"mat2x2<f16>":{type:"f16",components:4},"mat2x3<f16>":{type:"f16",components:6},"mat2x4<f16>":{type:"f16",components:8},"mat3x2<f16>":{type:"f16",components:6},"mat3x3<f16>":{type:"f16",components:9},"mat3x4<f16>":{type:"f16",components:12},"mat4x2<f16>":{type:"f16",components:8},"mat4x3<f16>":{type:"f16",components:12},"mat4x4<f16>":{type:"f16",components:16},"mat2x2<i32>":{type:"i32",components:4},"mat2x3<i32>":{type:"i32",components:6},"mat2x4<i32>":{type:"i32",components:8},"mat3x2<i32>":{type:"i32",components:6},"mat3x3<i32>":{type:"i32",components:9},"mat3x4<i32>":{type:"i32",components:12},"mat4x2<i32>":{type:"i32",components:8},"mat4x3<i32>":{type:"i32",components:12},"mat4x4<i32>":{type:"i32",components:16},"mat2x2<u32>":{type:"u32",components:4},"mat2x3<u32>":{type:"u32",components:6},"mat2x4<u32>":{type:"u32",components:8},"mat3x2<u32>":{type:"u32",components:6},"mat3x3<u32>":{type:"u32",components:9},"mat3x4<u32>":{type:"u32",components:12},"mat4x2<u32>":{type:"u32",components:8},"mat4x3<u32>":{type:"u32",components:12},"mat4x4<u32>":{type:"u32",components:16}},Vv={vec2i:"vec2<i32>",vec3i:"vec3<i32>",vec4i:"vec4<i32>",vec2u:"vec2<u32>",vec3u:"vec3<u32>",vec4u:"vec4<u32>",vec2f:"vec2<f32>",vec3f:"vec3<f32>",vec4f:"vec4<f32>",vec2h:"vec2<f16>",vec3h:"vec3<f16>",vec4h:"vec4<f16>"},Wv={vec2i:"vec2<i32>",vec3i:"vec3<i32>",vec4i:"vec4<i32>",vec2u:"vec2<u32>",vec3u:"vec3<u32>",vec4u:"vec4<u32>",vec2f:"vec2<f32>",vec3f:"vec3<f32>",vec4f:"vec4<f32>",vec2h:"vec2<f16>",vec3h:"vec3<f16>",vec4h:"vec4<f16>",mat2x2f:"mat2x2<f32>",mat2x3f:"mat2x3<f32>",mat2x4f:"mat2x4<f32>",mat3x2f:"mat3x2<f32>",mat3x3f:"mat3x3<f32>",mat3x4f:"mat3x4<f32>",mat4x2f:"mat4x2<f32>",mat4x3f:"mat4x3<f32>",mat4x4f:"mat4x4<f32>",mat2x2i:"mat2x2<i32>",mat2x3i:"mat2x3<i32>",mat2x4i:"mat2x4<i32>",mat3x2i:"mat3x2<i32>",mat3x3i:"mat3x3<i32>",mat3x4i:"mat3x4<i32>",mat4x2i:"mat4x2<i32>",mat4x3i:"mat4x3<i32>",mat4x4i:"mat4x4<i32>",mat2x2u:"mat2x2<u32>",mat2x3u:"mat2x3<u32>",mat2x4u:"mat2x4<u32>",mat3x2u:"mat3x2<u32>",mat3x3u:"mat3x3<u32>",mat3x4u:"mat3x4<u32>",mat4x2u:"mat4x2<u32>",mat4x3u:"mat4x3<u32>",mat4x4u:"mat4x4<u32>",mat2x2h:"mat2x2<f16>",mat2x3h:"mat2x3<f16>",mat2x4h:"mat2x4<f16>",mat3x2h:"mat3x2<f16>",mat3x3h:"mat3x3<f16>",mat3x4h:"mat3x4<f16>",mat4x2h:"mat4x2<f16>",mat4x3h:"mat4x3<f16>",mat4x4h:"mat4x4<f16>"};function Nc(i,e={}){const t={...i},n=e.layout??"std140",s={};let r=0;for(const[o,a]of Object.entries(t))r=Oa(s,o,a,r,n);return r=Xe(r,bt(t,n)),{layout:n,byteLength:r*4,uniformTypes:t,fields:s}}function Nr(i,e){const t=zc(i),n=Fc(t),s=/^mat(\d)x(\d)<.+>$/.exec(t);if(s){const o=Number(s[1]),a=Number(s[2]),c=ou(a,t,n.type),l=Yv(c.size,c.alignment,e);return{alignment:c.alignment,size:o*l,components:o*a,columns:o,rows:a,columnStride:l,shaderType:t,type:n.type}}const r=/^vec(\d)<.+>$/.exec(t);return r?ou(Number(r[1]),t,n.type):{alignment:1,size:1,components:1,columns:1,rows:1,columnStride:1,shaderType:t,type:n.type}}function zh(i){return!!i&&typeof i=="object"&&!Array.isArray(i)}function Oa(i,e,t,n,s){if(typeof t=="string"){const r=Nr(t,s),o=Xe(n,r.alignment);return i[e]={offset:o,...r},o+r.size}if(Array.isArray(t)){if(Array.isArray(t[0]))throw new Error(`Nested arrays are not supported for ${e}`);const r=t[0],o=t[1],a=Uh(r,s),c=Xe(n,bt(t,s));for(let l=0;l<o;l++)Oa(i,`${e}[${l}]`,r,c+l*a,s);return c+a*o}if(zh(t)){const r=bt(t,s);let o=Xe(n,r);for(const[a,c]of Object.entries(t))o=Oa(i,`${e}.${a}`,c,o,s);return Xe(o,r)}throw new Error(`Unsupported CompositeShaderType for ${e}`)}function Nh(i,e){if(typeof i=="string")return Nr(i,e).size;if(Array.isArray(i)){const n=i[0],s=i[1];if(Array.isArray(n))throw new Error("Nested arrays are not supported");return Uh(n,e)*s}let t=0;for(const n of Object.values(i)){const s=n;t=Xe(t,bt(s,e)),t+=Nh(s,e)}return Xe(t,bt(i,e))}function bt(i,e){if(typeof i=="string")return Nr(i,e).alignment;if(Array.isArray(i)){const n=i[0],s=bt(n,e);return $h(e)?Math.max(s,4):s}let t=1;for(const n of Object.values(i)){const s=bt(n,e);t=Math.max(t,s)}return qv(e)?Math.max(t,4):t}function ou(i,e,t,n){return{alignment:i===2?2:4,size:i===3?3:i,components:i,columns:1,rows:i,columnStride:i===3?3:i,shaderType:e,type:t}}function Uh(i,e){const t=Nh(i,e),n=bt(i,e);return Hv(t,n,e)}function Hv(i,e,t){return Xe(i,$h(t)?4:e)}function Yv(i,e,t){return t==="std140"?4:Xe(i,e)}function $h(i){return i==="std140"||i==="wgsl-uniform"}function qv(i){return i==="std140"||i==="wgsl-uniform"}let Xn;function Gh(i){return(!Xn||Xn.byteLength<i)&&(Xn=new ArrayBuffer(i)),Xn}function Zv(i,e){const t=Gh(i.BYTES_PER_ELEMENT*e);return new i(t,0,e)}function Xv(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function Xs(i){return Array.isArray(i)?i.length===0||typeof i[0]=="number":Xv(i)}class Kv{constructor(e){h(this,"layout");this.layout=e}has(e){return!!this.layout.fields[e]}get(e){const t=this.layout.fields[e];return t?{offset:t.offset,size:t.size}:void 0}getFlatUniformValues(e){const t={};for(const[n,s]of Object.entries(e)){const r=this.layout.uniformTypes[n];r?this._flattenCompositeValue(t,n,r,s):this.layout.fields[n]&&(t[n]=s)}return t}getData(e){const t=Gh(this.layout.byteLength);new Uint8Array(t,0,this.layout.byteLength).fill(0);const n={i32:new Int32Array(t),u32:new Uint32Array(t),f32:new Float32Array(t),f16:new Uint16Array(t)},s=this.getFlatUniformValues(e);for(const[r,o]of Object.entries(s))this._writeLeafValue(n,r,o);return new Uint8Array(t,0,this.layout.byteLength)}_flattenCompositeValue(e,t,n,s){if(s!==void 0){if(typeof n=="string"||this.layout.fields[t]){e[t]=s;return}if(Array.isArray(n)){const r=n[0],o=n[1];if(Array.isArray(r))throw new Error(`Nested arrays are not supported for ${t}`);if(typeof r=="string"&&Xs(s)){this._flattenPackedArray(e,t,r,o,s);return}if(!Array.isArray(s)){M.warn(`Unsupported uniform array value for ${t}:`,s)();return}for(let a=0;a<Math.min(s.length,o);a++){const c=s[a];c!==void 0&&this._flattenCompositeValue(e,`${t}[${a}]`,r,c)}return}if(zh(n)&&Qv(s)){for(const[r,o]of Object.entries(s)){if(o===void 0)continue;const a=`${t}.${r}`;this._flattenCompositeValue(e,a,n[r],o)}return}M.warn(`Unsupported uniform value for ${t}:`,s)()}}_flattenPackedArray(e,t,n,s,r){const o=r,c=Nr(n,this.layout.layout).components;for(let l=0;l<s;l++){const u=l*c;if(u>=o.length)break;c===1?e[`${t}[${l}]`]=Number(o[u]):e[`${t}[${l}]`]=Jv(r,u,u+c)}}_writeLeafValue(e,t,n){const s=this.layout.fields[t];if(!s){M.warn(`Uniform ${t} not found in layout`)();return}const{type:r,components:o,columns:a,rows:c,offset:l,columnStride:u}=s,f=e[r];if(o===1){f[l]=Number(n);return}const d=n;if(a===1){for(let p=0;p<o;p++)f[l+p]=Number(d[p]??0);return}let g=0;for(let p=0;p<a;p++){const m=l+p*u;for(let _=0;_<c;_++)f[m+_]=Number(d[g++]??0)}}}function Qv(i){return!!i&&typeof i=="object"&&!Array.isArray(i)&&!ArrayBuffer.isView(i)}function Jv(i,e,t){return Array.prototype.slice.call(i,e,t)}const e0=128;function t0(i,e,t=16){if(i===e)return!0;const n=i,s=e;if(!Xs(n)||!Xs(s)||n.length!==s.length)return!1;const r=Math.min(t,e0);if(n.length>r)return!1;for(let o=0;o<n.length;++o)if(s[o]!==n[o])return!1;return!0}function i0(i){return Xs(i)?i.slice():i}class n0{constructor(e){h(this,"name");h(this,"uniforms",{});h(this,"modifiedUniforms",{});h(this,"modified",!0);h(this,"bindingLayout",{});h(this,"needsRedraw","initialized");var t;if(this.name=(e==null?void 0:e.name)||"unnamed",e!=null&&e.name&&(e!=null&&e.shaderLayout)){const n=(t=e==null?void 0:e.shaderLayout.bindings)==null?void 0:t.find(r=>r.type==="uniform"&&r.name===(e==null?void 0:e.name));if(!n)throw new Error(e==null?void 0:e.name);const s=n;for(const r of s.uniforms||[])this.bindingLayout[r.name]=r}}setUniforms(e){for(const[t,n]of Object.entries(e))this._setUniform(t,n)&&!this.needsRedraw&&this.setNeedsRedraw(`${this.name}.${t}=${n}`)}setNeedsRedraw(e){this.needsRedraw=this.needsRedraw||e}getAllUniforms(){return this.modifiedUniforms={},this.needsRedraw=!1,this.uniforms||{}}_setUniform(e,t){return t0(this.uniforms[e],t)?!1:(this.uniforms[e]=i0(t),this.modifiedUniforms[e]=!0,this.modified=!0,!0)}}const s0=1024;class jh{constructor(e,t){h(this,"device");h(this,"uniformBlocks",new Map);h(this,"shaderBlockLayouts",new Map);h(this,"shaderBlockWriters",new Map);h(this,"uniformBuffers",new Map);this.device=e;for(const[n,s]of Object.entries(t)){const r=n,o=Nc(s.uniformTypes??{},{layout:s.layout??r0(e)}),a=new Kv(o);this.shaderBlockLayouts.set(r,o),this.shaderBlockWriters.set(r,a);const c=new n0({name:n});c.setUniforms(a.getFlatUniformValues(s.defaultUniforms||{})),this.uniformBlocks.set(r,c)}}destroy(){for(const e of this.uniformBuffers.values())e.destroy()}setUniforms(e,t){var n;for(const[s,r]of Object.entries(e)){const o=s,a=this.shaderBlockWriters.get(o),c=a==null?void 0:a.getFlatUniformValues(r||{});(n=this.uniformBlocks.get(o))==null||n.setUniforms(c||{})}this.updateUniformBuffers(t)}getUniformBufferByteLength(e){var n;const t=((n=this.shaderBlockLayouts.get(e))==null?void 0:n.byteLength)||0;return Math.max(t,s0)}getUniformBufferData(e){var s;const t=((s=this.uniformBlocks.get(e))==null?void 0:s.getAllUniforms())||{},n=this.shaderBlockWriters.get(e);return(n==null?void 0:n.getData(t))||new Uint8Array(0)}createUniformBuffer(e,t){t&&this.setUniforms(t);const n=this.getUniformBufferByteLength(e),s=this.device.createBuffer({usage:W.UNIFORM|W.COPY_DST,byteLength:n}),r=this.getUniformBufferData(e);return s.write(r),s}getManagedUniformBuffer(e){if(!this.uniformBuffers.get(e)){const t=this.getUniformBufferByteLength(e),n=this.device.createBuffer({usage:W.UNIFORM|W.COPY_DST,byteLength:t});this.uniformBuffers.set(e,n)}return this.uniformBuffers.get(e)}updateUniformBuffers(e){let t=!1;for(const n of this.uniformBlocks.keys()){const s=this.updateUniformBuffer(n,e);t||(t=s)}return t&&M.log(3,`UniformStore.updateUniformBuffers(): ${t}`)(),t}updateUniformBuffer(e,t){var o;const n=this.uniformBlocks.get(e);let s=this.uniformBuffers.get(e),r=!1;if(s&&(n!=null&&n.needsRedraw)){r||(r=n.needsRedraw);const a=this.getUniformBufferData(e);if(s=this.uniformBuffers.get(e),s&&(t?this.device.writeBufferViaCommandEncoder(t,s,a):s.write(a)),M.level>=4){const c=(o=this.uniformBlocks.get(e))==null?void 0:o.getAllUniforms();M.log(4,`Writing to uniform buffer ${String(e)}`,a,c)()}}return r}}function r0(i){return i.type==="webgpu"?"wgsl-uniform":"std140"}function Ba(i){return i.attributes?i.attributes.map(e=>e.attribute):[i.name]}function o0(i){return Object.fromEntries(i.attributes.map(e=>[e.name,e.location]))}function au(i){let e=1/0;for(const t of i)t!==void 0&&(e=Math.min(e,t));return e}function a0(i,e,t){c0(e);const n=new Map;for(const s of e){const r=l0(s);if(s.attributes)for(const o of s.attributes)n.has(o.attribute)||n.set(o.attribute,{bufferName:s.name,stepMode:s.stepMode,vertexFormat:o.format,byteOffset:o.byteOffset,byteStride:r});else s.format&&!n.has(s.name)&&n.set(s.name,{bufferName:s.name,stepMode:s.stepMode,vertexFormat:s.format,byteOffset:0,byteStride:r})}return i.attributes.map(s=>{const r=n.get(s.name);!r&&(t!=null&&t.warnOnMissingBufferLayout)&&M.warn(`layout for attribute "${s.name}" not present in buffer layout`)();const o=Li.getAttributeShaderTypeInfo(s.type),a=(r==null?void 0:r.vertexFormat)||be.getCompatibleVertexFormat(o);return{attributeName:s.name,bufferName:(r==null?void 0:r.bufferName)||s.name,location:s.location,vertexFormat:a,byteOffset:(r==null?void 0:r.byteOffset)??0,byteStride:(r==null?void 0:r.byteStride)??be.getVertexFormatInfo(a).byteLength,stepMode:(r==null?void 0:r.stepMode)||s.stepMode||(s.name.startsWith("instance")?"instance":"vertex")}}).sort((s,r)=>s.location-r.location)}function c0(i){for(const e of i)(e.attributes&&e.format||!e.attributes&&!e.format)&&M.warn(`BufferLayout ${e.name} must have either 'attributes' or 'format' field`)()}function l0(i){if(typeof i.byteStride=="number")return i.byteStride;if(i.attributes){let e=0;for(const t of i.attributes)e+=be.getVertexFormatInfo(t.format).byteLength;return e}return be.getVertexFormatInfo(i.format).byteLength}function Vh(i,e){const t={},n=a0(i,e,{warnOnMissingBufferLayout:!0});for(const s of n){const r=u0(i,s);t[s.attributeName]=r}return t}function u0(i,e){const t=f0(i,e.attributeName),n=Li.getAttributeShaderTypeInfo(t.type),s=e.vertexFormat,r=be.getVertexFormatInfo(s);return{attributeName:e.attributeName,bufferName:e.bufferName,location:t.location,shaderType:t.type,primitiveType:n.primitiveType,shaderComponents:n.components,vertexFormat:s,bufferDataType:r.type,bufferComponents:r.components,normalized:r.normalized,integer:n.integer,stepMode:e.stepMode,byteOffset:e.byteOffset,byteStride:e.byteStride}}function f0(i,e){const t=i.attributes.find(n=>n.name===e);return t||M.warn(`shader layout attribute "${e}" not present in shader`)(),t||null}const d0=/^(vs|fs):(?:#(?:decl|main-start|main-end)|[A-Za-z_][\w-]*)$/;function Wh(i=[],e){const t=[],n={},s={},r={},o={};for(const a of i)cu({modules:t,defines:n,injections:s,vertexInputs:r,varyings:o},a),cu({modules:t,defines:n,injections:s,vertexInputs:r,varyings:o},a[e]);for(const a of Object.keys(o))if(r[a])throw new Error(`ShaderPlugin name "${a}" cannot be both a vertex input and a varying`);return{modules:t,defines:n,injections:s,vertexInputs:r,varyings:o}}function Hh(i=[],e=[]){const t=[...i],n=new Set(t.map(s=>s.name));for(const s of e)n.has(s.name)||(t.push(s),n.add(s.name));return t}function cu(i,e){var t;if(e){(t=e.modules)!=null&&t.length&&i.modules.push(...e.modules),e.defines&&Object.assign(i.defines,e.defines);for(const[n,s]of Object.entries(e.vertexInputs||{})){lu(n,"vertex input");const r=i.vertexInputs[n];if(r&&r!==s)throw new Error(`ShaderPlugin vertex input "${n}" has conflicting types "${r}" and "${s}"`);i.vertexInputs[n]=s}for(const[n,s]of Object.entries(e.varyings||{})){lu(n,"varying");const r=h0(n,s),o=i.varyings[n];if(o&&(o.type!==r.type||o.interpolation!==r.interpolation))throw new Error(`ShaderPlugin varying "${n}" has conflicting declarations "${o.type}/${o.interpolation}" and "${r.type}/${r.interpolation}"`);i.varyings[n]=r}for(const n of e.injections||[])g0(n.target),i.injections[n.target]||(i.injections[n.target]=[]),i.injections[n.target].push({injection:n.injection,order:n.order??0})}}function lu(i,e){if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(i)||i.startsWith("_luma_"))throw new Error(`ShaderPlugin ${e} "${i}" must be a valid non-reserved identifier`)}function h0(i,e){const{primitiveType:t}=Li.getAttributeShaderTypeInfo(e.type),n=t==="i32"||t==="u32",s=e.interpolation||(n?"flat":"smooth");if(n&&s==="smooth")throw new Error(`ShaderPlugin integer varying "${i}" must use flat interpolation`);return{type:e.type,interpolation:s}}function g0(i){if(!d0.test(i))throw new Error(`ShaderPlugin injection target "${i}" must be a named shader anchor or hook`)}const p0=/^(?:uniform\s+)?(?:(?:lowp|mediump|highp)\s+)?[A-Za-z0-9_]+(?:<[^>]+>)?\s+([A-Za-z0-9_]+)(?:\s*\[[^\]]+\])?\s*;/,m0=/((?:layout\s*\([^)]*\)\s*)*)uniform\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{([\s\S]*?)\}\s*([A-Za-z_][A-Za-z0-9_]*)?\s*;/g;function Uc(i){return`${i.name}Uniforms`}function _0(i,e){const t=e==="wgsl"?i.source:e==="vertex"?i.vs:i.fs;if(!t)return null;const n=Uc(i);return w0(t,e==="wgsl"?"wgsl":"glsl",n)}function y0(i,e){const t=Object.keys(i.uniformTypes||{});if(!t.length)return null;const n=_0(i,e);return n?{moduleName:i.name,uniformBlockName:Uc(i),stage:e,expectedUniformNames:t,actualUniformNames:n,matches:S0(t,n)}:null}function b0(i,e,t={}){var r,o;const n=y0(i,e);if(!n||n.matches)return n;const s=E0(n);return(o=(r=t.log)==null?void 0:r.error)==null||o.call(r,s,n)(),t.throwOnError!==!1&&Ei(!1,s),n}function $c(i){var n;const e=[],t=C0(i);for(const s of t.matchAll(m0)){const r=((n=s[1])==null?void 0:n.trim())||null;e.push({blockName:s[2],body:s[3],instanceName:s[4]||null,layoutQualifier:r,hasLayoutQualifier:!!r,isStd140:!!(r&&/\blayout\s*\([^)]*\bstd140\b[^)]*\)/.exec(r))})}return e}function v0(i,e,t,n){var o;const s=$c(i).filter(a=>!a.isStd140),r=new Set;for(const a of s){if(r.has(a.blockName))continue;r.add(a.blockName);const c="",l=a.hasLayoutQualifier?`declares ${L0(a.layoutQualifier)} instead of layout(std140)`:"does not declare layout(std140)",u=`${c}${e} shader uniform block ${a.blockName} ${l}. luma.gl host-side shader block packing assumes explicit layout(std140) for GLSL uniform blocks. Add \`layout(std140)\` to the block declaration.`;(o=t==null?void 0:t.warn)==null||o.call(t,u,a)()}return s}function w0(i,e,t){const n=e==="wgsl"?x0(i,t):P0(i,t);if(!n)return null;const s=[];for(const r of n.split(`
`)){const o=r.replace(/\/\/.*$/,"").trim();if(!o||o.startsWith("#"))continue;const a=e==="wgsl"?o.match(/^([A-Za-z0-9_]+)\s*:/):o.match(p0);a&&s.push(a[1])}return s}function x0(i,e){const t=new RegExp(`\\bstruct\\s+${e}\\b`,"m").exec(i);if(!t)return null;const n=i.indexOf("{",t.index);if(n<0)return null;let s=0;for(let r=n;r<i.length;r++){const o=i[r];if(o==="{"){s++;continue}if(o==="}"&&(s--,s===0))return i.slice(n+1,r)}return null}function P0(i,e){const t=$c(i).find(n=>n.blockName===e);return(t==null?void 0:t.body)||null}function S0(i,e){if(i.length!==e.length)return!1;for(let t=0;t<i.length;t++)if(i[t]!==e[t])return!1;return!0}function E0(i){const{expectedUniformNames:e,actualUniformNames:t}=i,n=e.filter(a=>!t.includes(a)),s=t.filter(a=>!e.includes(a)),r=[`Expected ${e.length} fields, found ${t.length}.`],o=T0(e,t);return o&&r.push(o),n.length&&r.push(`Missing from shader block (${n.length}): ${uu(n)}.`),s.length&&r.push(`Unexpected in shader block (${s.length}): ${uu(s)}.`),e.length<=12&&t.length<=12&&(n.length||s.length)&&(r.push(`Expected: ${e.join(", ")}.`),r.push(`Actual: ${t.join(", ")}.`)),`${i.moduleName}: ${i.stage} shader uniform block ${i.uniformBlockName} does not match module.uniformTypes. ${r.join(" ")}`}function C0(i){return i.replace(/\/\*[\s\S]*?\*\//g,"").replace(/\/\/.*$/gm,"")}function L0(i){return i.replace(/\s+/g," ").trim()}function T0(i,e){const t=Math.min(i.length,e.length);for(let n=0;n<t;n++)if(i[n]!==e[n])return`First mismatch at field ${n+1}: expected ${i[n]}, found ${e[n]}.`;return i.length>e.length?`Shader block ends after field ${e.length}; expected next field ${i[e.length]}.`:e.length>i.length?`Shader block has extra field ${e.length}: ${e[i.length]}.`:null}function uu(i,e=8){if(i.length<=e)return i.join(", ");const t=i.length-e;return`${i.slice(0,e).join(", ")}, ... (${t} more)`}function A0(i){switch(i==null?void 0:i.gpu.toLowerCase()){case"apple":return`#define APPLE_GPU
// Apple optimizes away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
#define LUMA_FP32_TAN_PRECISION_WORKAROUND 1
// Intel GPU doesn't have full 32 bits precision in same cases, causes overflow
#define LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND 1
`;case"nvidia":return`#define NVIDIA_GPU
// Nvidia optimizes away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
`;case"intel":return`#define INTEL_GPU
// Intel optimizes away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
// Intel's built-in 'tan' function doesn't have acceptable precision
#define LUMA_FP32_TAN_PRECISION_WORKAROUND 1
// Intel GPU doesn't have full 32 bits precision in same cases, causes overflow
#define LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND 1
`;case"amd":return`#define AMD_GPU
`;default:return`#define DEFAULT_GPU
// Prevent driver from optimizing away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
// Headless Chrome's software shader 'tan' function doesn't have acceptable precision
#define LUMA_FP32_TAN_PRECISION_WORKAROUND 1
// If the GPU doesn't have full 32 bits precision, will causes overflow
#define LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND 1
`}}function M0(i,e){var n;if(Number(((n=i.match(/^#version[ \t]+(\d+)/m))==null?void 0:n[1])||100)!==300)throw new Error("luma.gl v9 only supports GLSL 3.00 shader sources");switch(e){case"vertex":return i=fu(i,I0),i;case"fragment":return i=fu(i,R0),i;default:throw new Error(e)}}const Yh=[[/^(#version[ \t]+(100|300[ \t]+es))?[ \t]*\n/,`#version 300 es
`],[/\btexture(2D|2DProj|Cube)Lod(EXT)?\(/g,"textureLod("],[/\btexture(2D|2DProj|Cube)(EXT)?\(/g,"texture("]],I0=[...Yh,[ka("attribute"),"in $1"],[ka("varying"),"out $1"]],R0=[...Yh,[ka("varying"),"in $1"]];function fu(i,e){for(const[t,n]of e)i=i.replace(t,n);return i}function ka(i){return new RegExp(`\\b${i}[ \\t]+(\\w+[ \\t]+\\w+(\\[\\w+\\])?;)`,"g")}function Da(i,e,t="glsl"){let n="";for(const s in i){const r=i[s];if(n+=`${t==="wgsl"?"fn":"void"} ${r.signature} {
`,r.header&&(n+=`  ${r.header}`),e[s]){const a=e[s];a.sort((c,l)=>c.order-l.order);for(const c of a)n+=`  ${c.injection}
`}r.footer&&(n+=`  ${r.footer}`),n+=`}
`}return n}function qh(i){const e={vertex:{},fragment:{}};for(const t of i){let n,s;typeof t!="string"?(n=t,s=n.hook):(n={},s=t),s=s.trim();const r=s.indexOf(":"),o=s.slice(0,r),a=s.slice(r+1),c=s.replace(/\(.+/,""),l=Object.assign(n,{signature:a});switch(o){case"vs":e.vertex[c]=l;break;case"fs":e.fragment[c]=l;break;default:throw new Error(o)}}return e}function O0(i,e){return{name:B0(i,e),language:"glsl",version:k0(i)}}function B0(i,e="unnamed"){const n=/#define[^\S\r\n]*SHADER_NAME[^\S\r\n]*([A-Za-z0-9_-]+)\s*/.exec(i);return n?n[1]:e}function k0(i){let e=100;const t=i.match(/[^\s]+/g);if(t&&t.length>=2&&t[0]==="#version"){const n=parseInt(t[1],10);Number.isFinite(n)&&(e=n)}if(e!==100&&e!==300)throw new Error(`Invalid GLSL version ${e}`);return e}const du=[new RegExp(`@binding\\(\\s*(\\d+)\\s*\\)\\s*@group\\(\\s*(\\d+)\\s*\\)\\s*${Re}\\s*:\\s*([^;]+);`,"g"),new RegExp(`@group\\(\\s*(\\d+)\\s*\\)\\s*@binding\\(\\s*(\\d+)\\s*\\)\\s*${Re}\\s*:\\s*([^;]+);`,"g")];function Zh(i,e=[]){var r;const t=Dr(i),n=new Map;for(const o of e)n.set(hu(o.name,o.group,o.location),o.moduleName);const s=[];for(const o of du){o.lastIndex=0;let a;for(a=o.exec(t);a;){const c=o===du[0],l=Number(a[c?1:2]),u=Number(a[c?2:1]),f=(r=a[3])==null?void 0:r.trim(),d=a[4],g=a[5].trim(),p=n.get(hu(d,u,l));s.push(D0({name:d,group:u,binding:l,owner:p?"module":"application",moduleName:p,accessDeclaration:f,resourceType:g})),a=o.exec(t)}}return s.sort((o,a)=>o.group!==a.group?o.group-a.group:o.binding!==a.binding?o.binding-a.binding:o.name.localeCompare(a.name))}function D0(i){const e={name:i.name,group:i.group,binding:i.binding,owner:i.owner,kind:"unknown",moduleName:i.moduleName,resourceType:i.resourceType};if(i.accessDeclaration){const t=i.accessDeclaration.split(",").map(n=>n.trim());if(t[0]==="uniform")return{...e,kind:"uniform",access:"uniform"};if(t[0]==="storage"){const n=t[1]||"read_write";return{...e,kind:n==="read"?"read-only-storage":"storage",access:n}}}return i.resourceType==="sampler"||i.resourceType==="sampler_comparison"?{...e,kind:"sampler",samplerKind:i.resourceType==="sampler_comparison"?"comparison":"filtering"}:i.resourceType.startsWith("texture_storage_")?{...e,kind:"storage-texture",access:z0(i.resourceType),viewDimension:gu(i.resourceType)}:i.resourceType.startsWith("texture_")?{...e,kind:"texture",viewDimension:gu(i.resourceType),sampleType:F0(i.resourceType),multisampled:i.resourceType.startsWith("texture_multisampled_")}:e}function hu(i,e,t){return`${e}:${t}:${i}`}function gu(i){if(i.includes("cube_array"))return"cube-array";if(i.includes("2d_array"))return"2d-array";if(i.includes("cube"))return"cube";if(i.includes("3d"))return"3d";if(i.includes("2d"))return"2d";if(i.includes("1d"))return"1d"}function F0(i){if(i.startsWith("texture_depth_"))return"depth";if(i.includes("<i32>"))return"sint";if(i.includes("<u32>"))return"uint";if(i.includes("<f32>"))return"float"}function z0(i){const e=/,\s*([A-Za-z_][A-Za-z0-9_]*)\s*>$/.exec(i);return e==null?void 0:e[1]}const Mt="([a-zA-Z_][a-zA-Z0-9_]*)",N0=/^\s*\#\s*if\s+(.+?)\s*(?:\/\/.*)?$/,U0=new RegExp(`^\\s*\\#\\s*ifdef\\s*${Mt}\\s*$`),$0=new RegExp(`^\\s*\\#\\s*ifndef\\s*${Mt}\\s*(?:\\/\\/.*)?$`),G0=/^\s*\#\s*else\s*(?:\/\/.*)?$/,j0=/^\s*\#\s*endif\s*$/,V0=new RegExp(`^\\s*\\#\\s*ifdef\\s*${Mt}\\s*(?:\\/\\/.*)?$`),W0=/^\s*\#\s*endif\s*(?:\/\/.*)?$/;function bn(i,e){var o,a;const t=i.split(`
`),n=[],s=[];let r=!0;for(const c of t){const l=c.match(N0),u=c.match(V0)||c.match(U0),f=c.match($0),d=c.match(G0),g=c.match(W0)||c.match(j0);if(l){const p=H0(l[1],(e==null?void 0:e.defines)||{}),m=r&&p;s.push({parentActive:r,branchTaken:p,active:m}),r=m}else if(u||f){const p=(o=u||f)==null?void 0:o[1],m=!!((a=e==null?void 0:e.defines)!=null&&a[p]),_=u?m:!m,v=r&&_;s.push({parentActive:r,branchTaken:_,active:v}),r=v}else if(d){const p=s[s.length-1];if(!p)throw new Error("Encountered #else without matching #if, #ifdef or #ifndef");p.active=p.parentActive&&!p.branchTaken,p.branchTaken=!0,r=p.active}else g?(s.pop(),r=s.length?s[s.length-1].active:!0):r&&n.push(c)}if(s.length>0)throw new Error("Unterminated conditional block in shader source");return n.join(`
`)}function H0(i,e){const t=i.trim();if(/^[+-]?\d+(?:\.\d+)?$/.test(t))return Number(t)!==0;if(t==="true")return!0;if(t==="false")return!1;const n=t.match(new RegExp(`^!\\s*${Mt}$`));if(n)return!e[n[1]];const s=t.match(new RegExp(`^${Mt}$`));if(s)return!!e[s[1]];const r=t.match(new RegExp(`^defined\\s*\\(\\s*${Mt}\\s*\\)$`));if(r)return e[r[1]]!==void 0;const o=t.match(new RegExp(`^!\\s*defined\\s*\\(\\s*${Mt}\\s*\\)$`));if(o)return e[o[1]]===void 0;throw new Error(`Unsupported #if expression "${i}"`)}function Y0(i,e){const t=[];for(const[n,s]of Object.entries(e))Z0(i,n),t.push(`in ${Gc(s)} ${n};`);return t.join(`
`)}function q0(i,e,t){const n=Object.entries(t);if(n.length===0)return{source:i,declarations:"",initialization:""};const s=X0(i,e),r=i.slice(s.openParenthesis+1,s.closeParenthesis),o=K0(i,r),a=new Set(o.locations),c=[],l=[],u=[];for(const[m,_]of n){if(o.names.has(m)||ew(i,m))throw new Error(`ShaderPlugin vertex input "${m}" conflicts with an existing WGSL shader input or variable`);const v=tw(a);a.add(v);const w=`_luma_${m}`;c.push(`@location(${v}) ${w}: ${_}`),l.push(`var<private> ${m}: ${_};`),u.push(`${m} = ${w};`)}const f=r.trim()?`,
  `:`
  `,d=r.trim()?"":`
`,g=`${r}${f}${c.join(`,
  `)}${d}`;return{source:i.slice(0,s.openParenthesis+1)+g+i.slice(s.closeParenthesis),declarations:l.join(`
`),initialization:u.join(`
`)}}function Gc(i){const{primitiveType:e,components:t}=Li.getAttributeShaderTypeInfo(i),n=e==="i32"?"int":e==="u32"?"uint":"float";return t===1?n:`${n==="int"?"i":n==="uint"?"u":""}vec${t}`}function Z0(i,e){const t=Ur(e);if(new RegExp(`\\b(?:in|attribute)\\s+(?:(?:lowp|mediump|highp)\\s+)?[A-Za-z_][A-Za-z0-9_]*\\s+${t}\\s*(?:\\[|;)`).test(i))throw new Error(`ShaderPlugin vertex input "${e}" conflicts with an existing GLSL input`)}function X0(i,e){const n=new RegExp(`\\bfn\\s+${Ur(e)}\\s*\\(`,"g").exec(i);if(!n)throw new Error(`ShaderPlugin vertex inputs require WGSL vertex entry point "${e}"`);const s=i.indexOf("(",n.index),r=Xh(i,s,"(",")");if(r<0)throw new Error(`Unable to parse WGSL vertex entry point "${e}" parameters`);return{openParenthesis:s,closeParenthesis:r}}function K0(i,e){const t=pu(e),n=new Set(mu(e)),s=Q0(e);for(const r of s){const o=J0(i,r);if(o!==null){t.push(...pu(o));for(const a of mu(o))n.add(a)}}return{locations:t,names:n}}function pu(i){const e=[],t=/@location\s*\(\s*(\d+)\s*\)/g;let n=t.exec(i);for(;n;)e.push(Number(n[1])),n=t.exec(i);return e}function mu(i){const e=[],t=/(?:^|,)\s*(?:@[A-Za-z_][\w]*(?:\([^)]*\))?\s*)*([A-Za-z_][\w]*)\s*:/gm;let n=t.exec(i);for(;n;)e.push(n[1]),n=t.exec(i);return e}function Q0(i){const e=[],t=/:\s*([A-Za-z_][\w]*)\b/g;let n=t.exec(i);for(;n;)e.push(n[1]),n=t.exec(i);return e}function J0(i,e){const n=new RegExp(`\\bstruct\\s+${Ur(e)}\\s*\\{`,"g").exec(i);if(!n)return null;const s=i.indexOf("{",n.index),r=Xh(i,s,"{","}");return r<0?null:i.slice(s+1,r)}function ew(i,e){const t=Ur(e),n=new RegExp(`\\b(?:var(?:<[^>]+>)?|let|const)\\s+${t}\\b`,"g");let s=n.exec(i);for(;s;){if(iw(i,s.index)===0)return!0;s=n.exec(i)}return!1}function tw(i){let e=0;for(;i.has(e);)e++;return e}function Xh(i,e,t,n){let s=0,r=0,o=!1;for(let a=e;a<i.length;a++){const c=i[a],l=i[a+1];if(o){c===`
`&&(o=!1);continue}if(r>0){c==="/"&&l==="*"?(r++,a++):c==="*"&&l==="/"&&(r--,a++);continue}if(c==="/"&&l==="/"){o=!0,a++;continue}if(c==="/"&&l==="*"){r=1,a++;continue}if(c===t&&s++,c===n&&--s===0)return a}return-1}function iw(i,e){let t=0,n=0,s=!1;for(let r=0;r<e;r++){const o=i[r],a=i[r+1];if(s){o===`
`&&(s=!1);continue}if(n>0){o==="/"&&a==="*"?(n++,r++):o==="*"&&a==="/"&&(n--,r++);continue}o==="/"&&a==="/"?(s=!0,r++):o==="/"&&a==="*"?(n=1,r++):o==="{"?t++:o==="}"&&t--}return t}function Ur(i){return i.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function nw(i,e,t){const n=[],s=[];for(const[r,o]of Object.entries(t)){_w(i,r);const a=o.interpolation==="flat"?"flat ":"",c=e==="vertex"?"out":"in";n.push(`${a}${c} ${Gc(o.type)} ${r};`),e==="vertex"&&s.push(`${r} = ${pw(o.type)};`)}return{declarations:n.join(`
`),initialization:s.join(`
`)}}function sw(i,e,t,n){const s=Object.entries(n);if(s.length===0)return{source:i,declarations:"",vertexInitialization:"",fragmentInitialization:""};let r=i,o=Kn(r,e,"vertex");const a=rw(r,o);let c=Kn(r,t,"fragment");const l=ow(r,c),u=mo(r,a),f=mo(r,l.type),d=new Set([...Qn(o.parameters),...Qn(u.body),...Qn(c.parameters),...Qn(f.body)]),g=new Set([..._u(u.body),..._u(f.body)]),p=[],m=[],_=[],v=[];for(const[S,C]of s){if(d.has(S)||hw(r,S))throw new Error(`ShaderPlugin varying "${S}" conflicts with existing WGSL stage I/O or a module variable`);const O=gw(g);g.add(O);const B=C.interpolation==="flat"?" @interpolate(flat)":"";p.push(`  @location(${O})${B} ${S}: ${C.type},`),m.push(`var<private> ${S}: ${C.type};`),_.push(`${S} = ${mw(C.type)};`),v.push(`${S} = ${l.name}.${S};`)}aw(r,a,o.openBrace,o.closeBrace),r=cw(r,a,o,s.map(([S])=>S)),o=Kn(r,e,"vertex"),r=lw(r,o,s.map(([S])=>S));const y=(a===l.type?[a]:[a,l.type]).map(S=>mo(r,S).closeBrace).sort((S,C)=>C-S);for(const S of y)r=r.slice(0,S)+`${p.join(`
`)}
`+r.slice(S);if(c=Kn(r,t,"fragment"),!new RegExp(`\\b${Ht(l.name)}\\s*:`).test(c.parameters))throw new Error(`Unable to preserve WGSL fragment input "${l.name}"`);return{source:r,declarations:m.join(`
`),vertexInitialization:_.join(`
`),fragmentInitialization:v.join(`
`)}}function Kn(i,e,t){const s=new RegExp(`\\bfn\\s+${Ht(e)}\\s*\\(`,"g").exec(i);if(!s)throw new Error(`ShaderPlugin varyings require WGSL ${t} entry point "${e}"`);const r=i.indexOf("(",s.index),o=Ks(i,r,"(",")"),a=i.indexOf("{",o),c=Ks(i,a,"{","}");if(o<0||a<0||c<0)throw new Error(`Unable to parse WGSL ${t} entry point "${e}"`);return{openParenthesis:r,closeParenthesis:o,openBrace:a,closeBrace:c,parameters:i.slice(r+1,o)}}function rw(i,e){const t=i.slice(e.closeParenthesis+1,e.openBrace),n=/->\s*([A-Za-z_][\w]*)\s*$/.exec(t.trim());if(!n||jc(i,n[1])===null)throw new Error("ShaderPlugin varyings require the WGSL vertex entry point to return a named struct");return n[1]}function ow(i,e){const t=[];for(const n of dw(e.parameters,",")){const s=/(?:@[A-Za-z_][\w]*(?:\([^)]*\))?\s*)*([A-Za-z_][\w]*)\s*:\s*([A-Za-z_][\w]*)\s*$/.exec(n.trim());s&&jc(i,s[2])&&t.push({name:s[1],type:s[2]})}if(t.length!==1)throw new Error(`ShaderPlugin varyings require exactly one named WGSL fragment input struct; found ${t.length}`);return t[0]}function mo(i,e){const t=jc(i,e);if(!t)throw new Error(`Unable to find WGSL stage I/O struct "${e}"`);return t}function jc(i,e){const n=new RegExp(`\\bstruct\\s+${Ht(e)}\\s*\\{`,"g").exec(i);if(!n)return null;const s=i.indexOf("{",n.index),r=Ks(i,s,"{","}");return r<0?null:{openBrace:s,closeBrace:r,body:i.slice(s+1,r)}}function aw(i,e,t,n){const s=new RegExp(`\\b${Ht(e)}\\s*\\(`,"g");let r=s.exec(i);for(;r;){if(r.index<t||r.index>n)throw new Error(`ShaderPlugin varying output struct "${e}" is constructed outside the selected vertex entry point`);r=s.exec(i)}}function cw(i,e,t,n){const s=new RegExp(`\\b${Ht(e)}\\s*\\(`,"g"),r=[];let o=s.exec(i);for(;o;){if(o.index>t.openBrace&&o.index<t.closeBrace){const a=i.indexOf("(",o.index),c=Ks(i,a,"(",")");if(c<0||c>t.closeBrace)throw new Error(`Unable to parse WGSL output constructor "${e}"`);r.push({openParenthesis:a,closeParenthesis:c})}o=s.exec(i)}for(const a of r.sort((c,l)=>l.closeParenthesis-c.closeParenthesis)){const l=i.slice(a.openParenthesis+1,a.closeParenthesis).trim()?", ":"";i=i.slice(0,a.closeParenthesis)+l+n.join(", ")+i.slice(a.closeParenthesis)}return i}function lw(i,e,t){const n=uw(i,e.openBrace+1,e.closeBrace);for(let s=n.length-1;s>=0;s--){const r=n[s],o=i.slice(r.expressionStart,r.semicolon).trim();if(!o)throw new Error("ShaderPlugin varying vertex entry point cannot use an empty return");const a=`_luma_vertexOutput${s}`,c=t.map(u=>`${a}.${u} = ${u};`).join(`
`),l=`{
var ${a} = ${o};
${c}
return ${a};
}`;i=i.slice(0,r.start)+l+i.slice(r.semicolon+1)}return i}function uw(i,e,t){const n=[];let s=e;for(;s<t;)if(s=Vc(i,s,t),i.slice(s,s+6)==="return"&&!/[A-Za-z0-9_]/.test(i[s+6]||"")){const r=s+6,o=fw(i,r,t);if(o<0)throw new Error("Unable to parse WGSL return statement in selected vertex entry point");n.push({start:s,expressionStart:r,semicolon:o}),s=o+1}else s++;return n}function fw(i,e,t){let n=0,s=0;for(let r=e;r<t;r++){const o=Vc(i,r,t);if(o!==r){r=o-1;continue}const a=i[r];if(a==="("&&n++,a===")"&&n--,a==="["&&s++,a==="]"&&s--,a===";"&&n===0&&s===0)return r}return-1}function Vc(i,e,t){let n=e;if(i[n]==="/"&&i[n+1]==="/"){const s=i.indexOf(`
`,n+2);return s<0||s>t?t:s+1}if(i[n]==="/"&&i[n+1]==="*"){let s=1;for(n+=2;n<t&&s>0;)i[n]==="/"&&i[n+1]==="*"?(s++,n+=2):i[n]==="*"&&i[n+1]==="/"?(s--,n+=2):n++}return n}function dw(i,e){const t=[];let n=0,s=0,r=0;for(let o=0;o<i.length;o++){const a=i[o];a==="("&&s++,a===")"&&s--,a==="<"&&r++,a===">"&&r--,a===e&&s===0&&r===0&&(t.push(i.slice(n,o)),n=o+1)}return t.push(i.slice(n)),t}function _u(i){const e=[],t=/@location\s*\(\s*(\d+)\s*\)/g;let n=t.exec(i);for(;n;)e.push(Number(n[1])),n=t.exec(i);return e}function Qn(i){const e=[],t=/(?:^|,)\s*(?:@[A-Za-z_][\w]*(?:\([^)]*\))?\s*)*([A-Za-z_][\w]*)\s*:/gm;let n=t.exec(i);for(;n;)e.push(n[1]),n=t.exec(i);return e}function hw(i,e){const t=new RegExp(`\\b(?:var(?:<[^>]+>)?|let|const)\\s+${Ht(e)}\\b`,"g");let n=t.exec(i);for(;n;){if(yw(i,n.index)===0)return!0;n=t.exec(i)}return!1}function gw(i){let e=0;for(;i.has(e);)e++;return e}function pw(i){const{primitiveType:e,components:t}=Li.getAttributeShaderTypeInfo(i),n=e==="u32"?"0u":e==="i32"?"0":"0.0";return t===1?n:`${Gc(i)}(${n})`}function mw(i){const{primitiveType:e,components:t}=Li.getAttributeShaderTypeInfo(i),n=`${e}(0)`;return t===1?n:`${i}(${n})`}function _w(i,e){if(new RegExp(`\\b(?:flat\\s+|smooth\\s+)?(?:in|out|varying)\\s+(?:(?:lowp|mediump|highp)\\s+)?[A-Za-z_][A-Za-z0-9_]*\\s+${Ht(e)}\\s*(?:\\[|;)`).test(i))throw new Error(`ShaderPlugin varying "${e}" conflicts with existing GLSL stage I/O`)}function Ks(i,e,t,n){let s=0,r=0,o=!1;for(let a=e;a<i.length;a++){const c=i[a],l=i[a+1];if(o){c===`
`&&(o=!1);continue}if(r>0){c==="/"&&l==="*"?(r++,a++):c==="*"&&l==="/"&&(r--,a++);continue}if(c==="/"&&l==="/"){o=!0,a++;continue}if(c==="/"&&l==="*"){r=1,a++;continue}if(c===t&&s++,c===n&&--s===0)return a}return-1}function yw(i,e){let t=0;for(let n=0;n<e;n++){const s=Vc(i,n,e);if(s!==n){n=s-1;continue}i[n]==="{"&&t++,i[n]==="}"&&t--}return t}function Ht(i){return i.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const Wc=`

${ys}
`,vn=100,bw=`precision highp float;
`;function vw(i){const e=Gs(i.modules||[]),{source:t,bindingAssignments:n}=xw(i.platformInfo,{...i,source:i.source,stage:"vertex",modules:e});return{source:t,getUniforms:Kh(e),bindingAssignments:n,bindingTable:Zh(t,n),shaderLayout:vh(t,{vertexEntryPoint:i.vertexEntryPoint,scanVertexAttributes:i.scanVertexAttributes})}}function ww(i){const{vs:e,fs:t}=i,n=Gs(i.modules||[]);return{vs:yu(i.platformInfo,{...i,source:e,stage:"vertex",modules:n}),fs:yu(i.platformInfo,{...i,source:t,stage:"fragment",modules:n}),getUniforms:Kh(n)}}function xw(i,e){const{source:t,stage:n,modules:s,defines:r={},hookFunctions:o=[],inject:a={},pluginInjections:c={},pluginVertexInputs:l={},pluginVaryings:u={},vertexEntryPoint:f="vertexMain",fragmentEntryPoint:d="fragmentMain",log:g}=e;Ei(typeof t=="string","shader source must be a string");const p=bn(t,{defines:r}),m=q0(p,f,l),_=sw(m.source,f,d,u),v=_.source;let w="";const y=qh(o),x={},S={},C={};Qh(c,x,S,C);for(const F in a){const z=typeof a[F]=="string"?{injection:a[F],order:0}:a[F],L=/^(v|f)s:(#)?([\w-]+)$/.exec(F);if(L){const G=L[2],b=L[3];G?b==="decl"?S[F]=[z]:C[F]=[z]:x[F]=[z]}else C[F]=[z]}Pw(m.declarations,m.initialization,S,C),Sw(_,S,C);const O=s,B=Mw(v),D=Aw(B.source),k=Bw(O,e._bindingRegistry,D,r),N=[];for(const F of O){g&&Ch(F,v,g);const z=bn(Jh(F,"wgsl",g),{defines:r}),L=Iw(z,F,{usedBindingsByGroup:D,bindingRegistry:e._bindingRegistry,reservedBindingKeysByGroup:k});N.push(...L.bindingAssignments);const G=L.source;w+=G;const b=Ew(F);for(const P in b){const E=/^(v|f)s:#([\w-]+)$/.exec(P);if(E){const T=E[2]==="decl"?S:C;T[P]=T[P]||[],T[P].push(b[P])}else x[P]=x[P]||[],x[P].push(b[P])}}return w+=Wc,w=Us(w,n,Cw(S),!1,"wgsl",{vertex:f,fragment:d}),w+=Lw(y,x),w+=Uw(N),w+=B.source,w=Us(w,n,C,!1,"wgsl",{vertex:f,fragment:d}),Nw(w),{source:w,bindingAssignments:N}}function yu(i,e){var k;const{source:t,stage:n,language:s="glsl",modules:r,defines:o={},hookFunctions:a=[],inject:c={},pluginInjections:l={},pluginVertexInputs:u={},pluginVaryings:f={},prologue:d=!0,log:g}=e;Ei(typeof t=="string","shader source must be a string");const p=s==="glsl"?O0(t).version:-1,m=i.shaderLanguageVersion,_=p===100?"#version 100":"#version 300 es",w=t.split(`
`).slice(1).join(`
`),y={};r.forEach(N=>{Object.assign(y,N.defines)}),Object.assign(y,o);let x="";switch(s){case"wgsl":break;case"glsl":x=d?`${_}

// ----- PROLOGUE -------------------------
${`#define SHADER_TYPE_${n.toUpperCase()}`}

${A0(i)}
${n==="fragment"?bw:""}

// ----- APPLICATION DEFINES -------------------------

${Tw(y)}

`:`${_}
`;break}const S=qh(a),C={},O={},B={};Qh(l,C,O,B);for(const N in c){const F=typeof c[N]=="string"?{injection:c[N],order:0}:c[N],z=/^(v|f)s:(#)?([\w-]+)$/.exec(N);if(z){const L=z[2],G=z[3];L?G==="decl"?O[N]=[F]:B[N]=[F]:C[N]=[F]}else B[N]=[F]}if(n==="vertex"){const N=Y0(w,u);N&&(O["vs:#decl"]=O["vs:#decl"]||[],O["vs:#decl"].push({injection:N,order:Number.MIN_SAFE_INTEGER}))}const D=nw(w,n,f);if(D.declarations){const N=n==="vertex"?"vs:#decl":"fs:#decl";O[N]=O[N]||[],O[N].push({injection:D.declarations,order:Number.MIN_SAFE_INTEGER})}D.initialization&&(B["vs:#main-start"]=B["vs:#main-start"]||[],B["vs:#main-start"].push({injection:D.initialization,order:Number.MIN_SAFE_INTEGER}));for(const N of r){g&&Ch(N,w,g);const F=Jh(N,n,g);x+=F;const z=((k=N.instance)==null?void 0:k.normalizedInjections[n])||{};for(const L in z){const G=/^(v|f)s:#([\w-]+)$/.exec(L);if(G){const P=G[2]==="decl"?O:B;P[L]=P[L]||[],P[L].push(z[L])}else C[L]=C[L]||[],C[L].push(z[L])}}return x+="// ----- MAIN SHADER SOURCE -------------------------",x+=Wc,x=Us(x,n,O),x+=Da(S[n],C),x+=w,x=Us(x,n,B),s==="glsl"&&p!==m&&(x=M0(x,n)),s==="glsl"&&v0(x,n,g),x.trim()}function Kh(i){return function(t){var s;const n={};for(const r of i){const o=(s=r.getUniforms)==null?void 0:s.call(r,t,n);Object.assign(n,o)}return n}}function Qh(i,e,t,n){for(const s in i){const r=/^(v|f)s:(#)?([\w-]+)$/.exec(s);if(r){const o=r[2],a=r[3],c=o?a==="decl"?t:n:e;c[s]=c[s]||[],c[s].push(...i[s])}else n[s]=n[s]||[],n[s].push(...i[s])}}function Pw(i,e,t,n){i&&(t["vs:#decl"]=t["vs:#decl"]||[],t["vs:#decl"].push({injection:i,order:Number.MIN_SAFE_INTEGER})),e&&(n["vs:#main-start"]=n["vs:#main-start"]||[],n["vs:#main-start"].push({injection:e,order:Number.MIN_SAFE_INTEGER}))}function Sw(i,e,t){i.declarations&&(e["vs:#decl"]=e["vs:#decl"]||[],e["vs:#decl"].push({injection:i.declarations,order:Number.MIN_SAFE_INTEGER})),i.vertexInitialization&&(t["vs:#main-start"]=t["vs:#main-start"]||[],t["vs:#main-start"].push({injection:i.vertexInitialization,order:Number.MIN_SAFE_INTEGER})),i.fragmentInitialization&&(t["fs:#main-start"]=t["fs:#main-start"]||[],t["fs:#main-start"].push({injection:i.fragmentInitialization,order:Number.MIN_SAFE_INTEGER}))}function Ew(i){var e,t;return{...((e=i.instance)==null?void 0:e.normalizedInjections.vertex)||{},...((t=i.instance)==null?void 0:t.normalizedInjections.fragment)||{}}}function Cw(i){const e=[...i["vs:#decl"]||[],...i["fs:#decl"]||[]];return e.length?{"vs:#decl":e}:{}}function Lw(i,e){return Da(i.vertex,e,"wgsl")+Da(i.fragment,e,"wgsl")}function Tw(i={}){let e="";for(const t in i){const n=i[t];(n||Number.isFinite(n))&&(e+=`#define ${t.toUpperCase()} ${i[t]}
`)}return e}function Jh(i,e,t){let n;switch(e){case"vertex":n=i.vs||"";break;case"fragment":n=i.fs||"";break;case"wgsl":n=i.source||"";break;default:Ei(!1)}if(!i.name)throw new Error("Shader module must have a name");b0(i,e,{log:t});const s=i.name.toUpperCase().replace(/[^0-9a-z]/gi,"_");let r=`// ----- MODULE ${i.name} ---------------

`;return e!=="wgsl"&&(r+=`#define MODULE_${s}
`),r+=`${n}
`,r}function Aw(i){const e=new Map;for(const t of Si(i,jy)){const n=Number(t.bindingToken),s=Number(t.groupToken);Hc(s,n,t.name),mi(e,s,n,`application binding "${t.name}"`)}return e}function Mw(i){const e=Si(i,ma),t=new Map;for(const r of e){if(r.bindingToken==="auto")continue;const o=Number(r.bindingToken),a=Number(r.groupToken);Hc(a,o,r.name),mi(t,a,o,`application binding "${r.name}"`)}const n={sawSupportedBindingDeclaration:e.length>0},s=yh(i,ma,r=>Ow(r,t,n));if(bh(i)&&!n.sawSupportedBindingDeclaration)throw new Error('Unsupported @binding(auto) declaration form in application WGSL. Use adjacent "@group(N)" and "@binding(auto)" decorators followed by a bindable "var" declaration.');return{source:s}}function Iw(i,e,t){const n=[],r={sawSupportedBindingDeclaration:Si(i,mn).length>0,nextHintedBindingLocation:typeof e.firstBindingSlot=="number"?e.firstBindingSlot:null},o=yh(i,mn,a=>Rw(a,{module:e,context:t,bindingAssignments:n,relocationState:r}));if(bh(i)&&!r.sawSupportedBindingDeclaration)throw new Error(`Unsupported @binding(auto) declaration form in module "${e.name}". Use adjacent "@group(N)" and "@binding(auto)" decorators followed by a bindable "var" declaration.`);return{source:o,bindingAssignments:n}}function Rw(i,e){var d,g;const{module:t,context:n,bindingAssignments:s,relocationState:r}=e,{match:o,bindingToken:a,groupToken:c,name:l}=i,u=Number(c);if(a==="auto"){const p=eg(u,t.name,l),m=(d=n.bindingRegistry)==null?void 0:d.get(p),_=m!==void 0?m:Fw(u,n.usedBindingsByGroup,t.name,r.nextHintedBindingLocation??void 0,n.bindingRegistry);return bu(t.name,u,_,l),m!==void 0&&kw(n.reservedBindingKeysByGroup,u,_,p)?(s.push({moduleName:t.name,name:l,group:u,location:_}),o.replace(/@binding\(\s*auto\s*\)/,`@binding(${_})`)):(mi(n.usedBindingsByGroup,u,_,`module "${t.name}" binding "${l}"`),(g=n.bindingRegistry)==null||g.set(p,_),s.push({moduleName:t.name,name:l,group:u,location:_}),r.nextHintedBindingLocation!==null&&m===void 0&&(r.nextHintedBindingLocation=_+1),o.replace(/@binding\(\s*auto\s*\)/,`@binding(${_})`))}const f=Number(a);return bu(t.name,u,f,l),mi(n.usedBindingsByGroup,u,f,`module "${t.name}" binding "${l}"`),s.push({moduleName:t.name,name:l,group:u,location:f}),o}function Ow(i,e,t){const{match:n,bindingToken:s,groupToken:r,name:o}=i,a=Number(r);if(s==="auto"){const c=zw(a,e);return Hc(a,c,o),mi(e,a,c,`application binding "${o}"`),n.replace(/@binding\(\s*auto\s*\)/,`@binding(${c})`)}return t.sawSupportedBindingDeclaration=!0,n}function Bw(i,e,t,n){const s=new Map;if(!e)return s;for(const r of i)for(const o of Dw(r,n)){const a=eg(o.group,r.name,o.name),c=e.get(a);if(c!==void 0){const l=s.get(o.group)||new Map,u=l.get(c);if(u&&u!==a)throw new Error(`Duplicate WGSL binding reservation for modules "${u}" and "${a}": group ${o.group}, binding ${c}.`);mi(t,o.group,c,`registered module binding "${a}"`),l.set(c,a),s.set(o.group,l)}}return s}function kw(i,e,t,n){const s=i.get(e);if(!s)return!1;const r=s.get(t);if(!r)return!1;if(r!==n)throw new Error(`Registered module binding "${n}" collided with "${r}": group ${e}, binding ${t}.`);return!0}function Dw(i,e){const t=[],n=bn(i.source||"",{defines:e});for(const s of Si(n,mn))t.push({name:s.name,group:Number(s.groupToken)});return t}function Hc(i,e,t){if(i===0&&e>=vn)throw new Error(`Application binding "${t}" in group 0 uses reserved binding ${e}. Application-owned explicit group-0 bindings must stay below ${vn}.`)}function bu(i,e,t,n){if(e===0&&t<vn)throw new Error(`Module "${i}" binding "${n}" in group 0 uses reserved application binding ${t}. Module-owned explicit group-0 bindings must be ${vn} or higher.`)}function mi(i,e,t,n){const s=i.get(e)||new Set;if(s.has(t))throw new Error(`Duplicate WGSL binding assignment for ${n}: group ${e}, binding ${t}.`);s.add(t),i.set(e,s)}function Fw(i,e,t,n,s){const r=e.get(i)||new Set,o=new Set,a=`${i}:`,c=`${a}${t}:`;for(const[u,f]of s||[])u.startsWith(c)&&o.add(f);let l=n??(i===0?vn:r.size>0?Math.max(...r)+1:0);for(;r.has(l)||o.has(l);)l++;for(const[u,f]of s||[])f===l&&u.startsWith(a)&&(s==null||s.delete(u));return l}function zw(i,e){const t=e.get(i)||new Set;let n=0;for(;t.has(n);)n++;return n}function Nw(i){const e=Wy(i,mn);if(!e)return;const t=$w(i,e.index);throw t?new Error(`Unresolved @binding(auto) for module "${t}" binding "${e.name}" remained in assembled WGSL source.`):Gw(i,e.index)?new Error(`Unresolved @binding(auto) for application binding "${e.name}" remained in assembled WGSL source.`):new Error(`Unresolved @binding(auto) remained in assembled WGSL source near "${jw(e.match)}".`)}function Uw(i){if(i.length===0)return"";let e=`// ----- MODULE WGSL BINDING ASSIGNMENTS ---------------
`;for(const t of i)e+=`// ${t.moduleName}.${t.name} -> @group(${t.group}) @binding(${t.location})
`;return e+=`
`,e}function eg(i,e,t){return`${i}:${e}:${t}`}function $w(i,e){const t=/^\/\/ ----- MODULE ([^\n]+) ---------------$/gm;let n,s;for(s=t.exec(i);s&&s.index<=e;)n=s[1],s=t.exec(i);return n}function Gw(i,e){const t=i.indexOf(Wc);return t>=0?e>t:!0}function jw(i){return i.replace(/\s+/g," ").trim()}const rt=class rt{constructor(){h(this,"_hookFunctions",[]);h(this,"_defaultModules",[])}static getDefaultShaderAssembler(e){return Ei(e==="glsl"||e==="wgsl"),e==="wgsl"?(rt.defaultShaderAssemblers.wgsl=rt.defaultShaderAssemblers.wgsl||new _i,rt.defaultShaderAssemblers.wgsl):(rt.defaultShaderAssemblers.glsl=rt.defaultShaderAssemblers.glsl||new Vw,rt.defaultShaderAssemblers.glsl)}addDefaultModule(e){this._defaultModules.find(t=>t.name===(typeof e=="string"?e:e.name))||this._defaultModules.push(e)}removeDefaultModule(e){const t=typeof e=="string"?e:e.name;this._defaultModules=this._defaultModules.filter(n=>n.name!==t)}addShaderHook(e,t){t&&(e=Object.assign(t,{hook:e})),this._hookFunctions.push(e)}_getModuleList(e=[]){const t=new Array(this._defaultModules.length+e.length),n={};let s=0;for(let r=0,o=this._defaultModules.length;r<o;++r){const a=this._defaultModules[r],c=a.name;t[s++]=a,n[c]=!0}for(let r=0,o=e.length;r<o;++r){const a=e[r],c=a.name;n[c]||(t[s++]=a,n[c]=!0)}return t.length=s,$s(t),t}};h(rt,"defaultShaderAssemblers",{});let vt=rt;class Vw extends vt{constructor(){super(...arguments);h(this,"shaderLanguage","glsl")}assembleGLSLShaderPair(t){const n=this._getModuleList(t.modules),s=this._hookFunctions;return{...ww({...t,vs:t.vs,fs:t.fs,modules:n,hookFunctions:s}),modules:n}}}class _i extends vt{constructor(){super(...arguments);h(this,"shaderLanguage","wgsl");h(this,"_wgslBindingRegistry",new Map)}assembleWGSLShader(t){const n=this._getModuleList(t.modules),s=this._hookFunctions,r=_i.getShaderPreprocessorDefines(t,n),o=t.platformInfo.shaderLanguage==="wgsl"&&t.source?bn(t.source,{defines:r}):t.source,{source:a,getUniforms:c,bindingAssignments:l}=vw({...t,source:o,defines:r,_bindingRegistry:this._wgslBindingRegistry,modules:n,hookFunctions:s}),u=t.platformInfo.shaderLanguage==="wgsl"?bn(a,{defines:r}):a;return{source:u,getUniforms:c,modules:n,bindingAssignments:l,bindingTable:Zh(u,l),shaderLayout:vh(u,{vertexEntryPoint:t.vertexEntryPoint,scanVertexAttributes:t.scanVertexAttributes})}}static getShaderPreprocessorDefines(t,n){return{..._i.getPlatformPreprocessorDefines(t.platformInfo),...n.reduce((s,r)=>(Object.assign(s,r.defines),s),{}),...t.defines}}static getPlatformPreprocessorDefines(t){const n=t.limits||{};return{LUMA_SUPPORTS_VERTEX_STORAGE_BUFFERS:t.type==="webgpu"&&(n.maxStorageBuffersInVertexStage||0)>0,LUMA_FP32_TAN_PRECISION_WORKAROUND:t.type==="webgpu"&&t.gpu.toLowerCase()!=="nvidia"&&t.gpu.toLowerCase()!=="amd",LUMA_FP64_INTEGER_ARITHMETIC:t.type==="webgpu"&&t.gpu.toLowerCase()==="apple"}}}const Ww=`out vec4 transform_output;
void main() {
  transform_output = vec4(0);
}`,Hw=`#version 300 es
${Ww}`;function Yw(i){const{input:e,inputChannels:t,output:n}={};if(!e)return Hw;if(!t)throw new Error("inputChannels");const s=qw(t),r=Zw(e,t);return`#version 300 es
in ${s} ${e};
out vec4 ${n};
void main() {
  ${n} = ${r};
}`}function qw(i){switch(i){case 1:return"float";case 2:return"vec2";case 3:return"vec3";case 4:return"vec4";default:throw new Error(`invalid channels: ${i}`)}}function Zw(i,e){switch(e){case 1:return`vec4(${i}, 0.0, 0.0, 1.0)`;case 2:return`vec4(${i}, 0.0, 1.0)`;case 3:return`vec4(${i}, 1.0)`;case 4:return i;default:throw new Error(`invalid channels: ${e}`)}}const Xw={EPSILON:1e-12,debug:!1,precision:4,printTypes:!1,printDegrees:!1,printRowMajor:!0,_cartographicRadians:!1};globalThis.mathgl=globalThis.mathgl||{config:{...Xw}};const Se=globalThis.mathgl.config;function Kw(i,{precision:e=Se.precision}={}){return i=Qw(i),`${parseFloat(i.toPrecision(e))}`}function Nt(i){return Array.isArray(i)||ArrayBuffer.isView(i)&&!(i instanceof DataView)}function ae(i,e,t){return ex(i,n=>Math.max(e,Math.min(t,n)))}function Qs(i,e,t){return Nt(i)?i.map((n,s)=>Qs(n,e[s],t)):t*e+(1-t)*i}function ci(i,e,t){const n=Se.EPSILON;try{if(i===e)return!0;if(Nt(i)&&Nt(e)){if(i.length!==e.length)return!1;for(let s=0;s<i.length;++s)if(!ci(i[s],e[s]))return!1;return!0}return i&&i.equals?i.equals(e):e&&e.equals?e.equals(i):typeof i=="number"&&typeof e=="number"?Math.abs(i-e)<=Se.EPSILON*Math.max(1,Math.abs(i),Math.abs(e)):!1}finally{Se.EPSILON=n}}function Qw(i){return Math.round(i/Se.EPSILON)*Se.EPSILON}function Jw(i){return i.clone?i.clone():new Array(i.length)}function ex(i,e,t){if(Nt(i)){const n=i;t=t||Jw(n);for(let s=0;s<t.length&&s<n.length;++s){const r=typeof i=="number"?i:i[s];t[s]=e(r,s,t)}return t}return e(i)}class Yc extends Array{clone(){return new this.constructor().copy(this)}fromArray(e,t=0){for(let n=0;n<this.ELEMENTS;++n)this[n]=e[n+t];return this.check()}toArray(e=[],t=0){for(let n=0;n<this.ELEMENTS;++n)e[t+n]=this[n];return e}toObject(e){return e}from(e){return Array.isArray(e)?this.copy(e):this.fromObject(e)}to(e){return e===this?this:Nt(e)?this.toArray(e):this.toObject(e)}toTarget(e){return e?this.to(e):this}toFloat32Array(){return new Float32Array(this)}toString(){return this.formatString(Se)}formatString(e){let t="";for(let n=0;n<this.ELEMENTS;++n)t+=(n>0?", ":"")+Kw(this[n],e);return`${e.printTypes?this.constructor.name:""}[${t}]`}equals(e){if(!e||this.length!==e.length)return!1;for(let t=0;t<this.ELEMENTS;++t)if(!ci(this[t],e[t]))return!1;return!0}exactEquals(e){if(!e||this.length!==e.length)return!1;for(let t=0;t<this.ELEMENTS;++t)if(this[t]!==e[t])return!1;return!0}negate(){for(let e=0;e<this.ELEMENTS;++e)this[e]=-this[e];return this.check()}lerp(e,t,n){if(n===void 0)return this.lerp(this,e,t);for(let s=0;s<this.ELEMENTS;++s){const r=e[s],o=typeof t=="number"?t:t[s];this[s]=r+n*(o-r)}return this.check()}min(e){for(let t=0;t<this.ELEMENTS;++t)this[t]=Math.min(e[t],this[t]);return this.check()}max(e){for(let t=0;t<this.ELEMENTS;++t)this[t]=Math.max(e[t],this[t]);return this.check()}clamp(e,t){for(let n=0;n<this.ELEMENTS;++n)this[n]=Math.min(Math.max(this[n],e[n]),t[n]);return this.check()}add(...e){for(const t of e)for(let n=0;n<this.ELEMENTS;++n)this[n]+=t[n];return this.check()}subtract(...e){for(const t of e)for(let n=0;n<this.ELEMENTS;++n)this[n]-=t[n];return this.check()}scale(e){if(typeof e=="number")for(let t=0;t<this.ELEMENTS;++t)this[t]*=e;else for(let t=0;t<this.ELEMENTS&&t<e.length;++t)this[t]*=e[t];return this.check()}multiplyByScalar(e){for(let t=0;t<this.ELEMENTS;++t)this[t]*=e;return this.check()}check(){if(Se.debug&&!this.validate())throw new Error(`math.gl: ${this.constructor.name} some fields set to invalid numbers'`);return this}validate(){let e=this.length===this.ELEMENTS;for(let t=0;t<this.ELEMENTS;++t)e=e&&Number.isFinite(this[t]);return e}sub(e){return this.subtract(e)}setScalar(e){for(let t=0;t<this.ELEMENTS;++t)this[t]=e;return this.check()}addScalar(e){for(let t=0;t<this.ELEMENTS;++t)this[t]+=e;return this.check()}subScalar(e){return this.addScalar(-e)}multiplyScalar(e){for(let t=0;t<this.ELEMENTS;++t)this[t]*=e;return this.check()}divideScalar(e){return this.multiplyByScalar(1/e)}clampScalar(e,t){for(let n=0;n<this.ELEMENTS;++n)this[n]=Math.min(Math.max(this[n],e),t);return this.check()}get elements(){return this}}function tx(i,e){if(i.length!==e)return!1;for(let t=0;t<i.length;++t)if(!Number.isFinite(i[t]))return!1;return!0}function te(i){if(!Number.isFinite(i))throw new Error(`Invalid number ${JSON.stringify(i)}`);return i}function bs(i,e,t=""){if(Se.debug&&!tx(i,e))throw new Error(`math.gl: ${t} some fields set to invalid numbers'`);return i}function vu(i,e){if(!i)throw new Error(`math.gl assertion ${e}`)}class tg extends Yc{get x(){return this[0]}set x(e){this[0]=te(e)}get y(){return this[1]}set y(e){this[1]=te(e)}len(){return Math.sqrt(this.lengthSquared())}magnitude(){return this.len()}lengthSquared(){let e=0;for(let t=0;t<this.ELEMENTS;++t)e+=this[t]*this[t];return e}magnitudeSquared(){return this.lengthSquared()}distance(e){return Math.sqrt(this.distanceSquared(e))}distanceSquared(e){let t=0;for(let n=0;n<this.ELEMENTS;++n){const s=this[n]-e[n];t+=s*s}return te(t)}dot(e){let t=0;for(let n=0;n<this.ELEMENTS;++n)t+=this[n]*e[n];return te(t)}normalize(){const e=this.magnitude();if(e!==0)for(let t=0;t<this.ELEMENTS;++t)this[t]/=e;return this.check()}multiply(...e){for(const t of e)for(let n=0;n<this.ELEMENTS;++n)this[n]*=t[n];return this.check()}divide(...e){for(const t of e)for(let n=0;n<this.ELEMENTS;++n)this[n]/=t[n];return this.check()}lengthSq(){return this.lengthSquared()}distanceTo(e){return this.distance(e)}distanceToSquared(e){return this.distanceSquared(e)}getComponent(e){return vu(e>=0&&e<this.ELEMENTS,"index is out of range"),te(this[e])}setComponent(e,t){return vu(e>=0&&e<this.ELEMENTS,"index is out of range"),this[e]=t,this.check()}addVectors(e,t){return this.copy(e).add(t)}subVectors(e,t){return this.copy(e).subtract(t)}multiplyVectors(e,t){return this.copy(e).multiply(t)}addScaledVector(e,t){return this.add(new this.constructor(e).multiplyScalar(t))}}const Ji=1e-6;let $e=typeof Float32Array<"u"?Float32Array:Array;function ix(){const i=new $e(2);return $e!=Float32Array&&(i[0]=0,i[1]=0),i}function wu(i,e,t){return i[0]=e[0]+t[0],i[1]=e[1]+t[1],i}function nx(i,e,t){return i[0]=e[0]-t[0],i[1]=e[1]-t[1],i}function sx(i,e){return i[0]=-e[0],i[1]=-e[1],i}function ig(i,e,t,n){const s=e[0],r=e[1];return i[0]=s+n*(t[0]-s),i[1]=r+n*(t[1]-r),i}function rx(i,e,t){const n=e[0],s=e[1];return i[0]=t[0]*n+t[4]*s+t[12],i[1]=t[1]*n+t[5]*s+t[13],i}const ox=nx;(function(){const i=ix();return function(e,t,n,s,r,o){let a,c;for(t||(t=2),n||(n=0),s?c=Math.min(s*t+n,e.length):c=e.length,a=n;a<c;a+=t)i[0]=e[a],i[1]=e[a+1],r(i,i,o),e[a]=i[0],e[a+1]=i[1];return e}})();function ax(i,e,t){const n=e[0],s=e[1],r=t[3]*n+t[7]*s||1;return i[0]=(t[0]*n+t[4]*s)/r,i[1]=(t[1]*n+t[5]*s)/r,i}function ng(i,e,t){const n=e[0],s=e[1],r=e[2],o=t[3]*n+t[7]*s+t[11]*r||1;return i[0]=(t[0]*n+t[4]*s+t[8]*r)/o,i[1]=(t[1]*n+t[5]*s+t[9]*r)/o,i[2]=(t[2]*n+t[6]*s+t[10]*r)/o,i}function cx(i,e,t){const n=e[0],s=e[1];return i[0]=t[0]*n+t[2]*s,i[1]=t[1]*n+t[3]*s,i[2]=e[2],i}function lx(i,e,t){const n=e[0],s=e[1];return i[0]=t[0]*n+t[2]*s,i[1]=t[1]*n+t[3]*s,i[2]=e[2],i[3]=e[3],i}function ux(i,e,t){const n=e[0],s=e[1],r=e[2];return i[0]=t[0]*n+t[3]*s+t[6]*r,i[1]=t[1]*n+t[4]*s+t[7]*r,i[2]=t[2]*n+t[5]*s+t[8]*r,i[3]=e[3],i}function sg(){const i=new $e(3);return $e!=Float32Array&&(i[0]=0,i[1]=0,i[2]=0),i}function fx(i){const e=i[0],t=i[1],n=i[2];return Math.sqrt(e*e+t*t+n*n)}function xu(i,e,t){const n=new $e(3);return n[0]=i,n[1]=e,n[2]=t,n}function dx(i,e,t){return i[0]=e[0]-t[0],i[1]=e[1]-t[1],i[2]=e[2]-t[2],i}function hx(i){const e=i[0],t=i[1],n=i[2];return e*e+t*t+n*n}function gx(i,e){return i[0]=-e[0],i[1]=-e[1],i[2]=-e[2],i}function rg(i,e){const t=e[0],n=e[1],s=e[2];let r=t*t+n*n+s*s;return r>0&&(r=1/Math.sqrt(r)),i[0]=e[0]*r,i[1]=e[1]*r,i[2]=e[2]*r,i}function en(i,e){return i[0]*e[0]+i[1]*e[1]+i[2]*e[2]}function Rt(i,e,t){const n=e[0],s=e[1],r=e[2],o=t[0],a=t[1],c=t[2];return i[0]=s*c-r*a,i[1]=r*o-n*c,i[2]=n*a-s*o,i}function px(i,e,t,n){const s=e[0],r=e[1],o=e[2];return i[0]=s+n*(t[0]-s),i[1]=r+n*(t[1]-r),i[2]=o+n*(t[2]-o),i}function qc(i,e,t){const n=e[0],s=e[1],r=e[2];let o=t[3]*n+t[7]*s+t[11]*r+t[15];return o=o||1,i[0]=(t[0]*n+t[4]*s+t[8]*r+t[12])/o,i[1]=(t[1]*n+t[5]*s+t[9]*r+t[13])/o,i[2]=(t[2]*n+t[6]*s+t[10]*r+t[14])/o,i}function mx(i,e,t){const n=e[0],s=e[1],r=e[2];return i[0]=n*t[0]+s*t[3]+r*t[6],i[1]=n*t[1]+s*t[4]+r*t[7],i[2]=n*t[2]+s*t[5]+r*t[8],i}function Zc(i,e,t){const n=t[0],s=t[1],r=t[2],o=t[3],a=e[0],c=e[1],l=e[2];let u=s*l-r*c,f=r*a-n*l,d=n*c-s*a,g=s*d-r*f,p=r*u-n*d,m=n*f-s*u;const _=o*2;return u*=_,f*=_,d*=_,g*=2,p*=2,m*=2,i[0]=a+u+g,i[1]=c+f+p,i[2]=l+d+m,i}function _x(i,e,t,n){const s=[],r=[];return s[0]=e[0]-t[0],s[1]=e[1]-t[1],s[2]=e[2]-t[2],r[0]=s[0],r[1]=s[1]*Math.cos(n)-s[2]*Math.sin(n),r[2]=s[1]*Math.sin(n)+s[2]*Math.cos(n),i[0]=r[0]+t[0],i[1]=r[1]+t[1],i[2]=r[2]+t[2],i}function yx(i,e,t,n){const s=[],r=[];return s[0]=e[0]-t[0],s[1]=e[1]-t[1],s[2]=e[2]-t[2],r[0]=s[2]*Math.sin(n)+s[0]*Math.cos(n),r[1]=s[1],r[2]=s[2]*Math.cos(n)-s[0]*Math.sin(n),i[0]=r[0]+t[0],i[1]=r[1]+t[1],i[2]=r[2]+t[2],i}function bx(i,e,t,n){const s=[],r=[];return s[0]=e[0]-t[0],s[1]=e[1]-t[1],s[2]=e[2]-t[2],r[0]=s[0]*Math.cos(n)-s[1]*Math.sin(n),r[1]=s[0]*Math.sin(n)+s[1]*Math.cos(n),r[2]=s[2],i[0]=r[0]+t[0],i[1]=r[1]+t[1],i[2]=r[2]+t[2],i}function vx(i,e){const t=i[0],n=i[1],s=i[2],r=e[0],o=e[1],a=e[2],c=Math.sqrt((t*t+n*n+s*s)*(r*r+o*o+a*a)),l=c&&en(i,e)/c;return Math.acos(Math.min(Math.max(l,-1),1))}const og=dx,ag=fx,_o=hx;(function(){const i=sg();return function(e,t,n,s,r,o){let a,c;for(t||(t=3),n||(n=0),s?c=Math.min(s*t+n,e.length):c=e.length,a=n;a<c;a+=t)i[0]=e[a],i[1]=e[a+1],i[2]=e[a+2],r(i,i,o),e[a]=i[0],e[a+1]=i[1],e[a+2]=i[2];return e}})();const yo=[0,0,0];let Jn;class tt extends tg{static get ZERO(){return Jn||(Jn=new tt(0,0,0),Object.freeze(Jn)),Jn}constructor(e=0,t=0,n=0){super(-0,-0,-0),arguments.length===1&&Nt(e)?this.copy(e):(Se.debug&&(te(e),te(t),te(n)),this[0]=e,this[1]=t,this[2]=n)}set(e,t,n){return this[0]=e,this[1]=t,this[2]=n,this.check()}copy(e){return this[0]=e[0],this[1]=e[1],this[2]=e[2],this.check()}fromObject(e){return Se.debug&&(te(e.x),te(e.y),te(e.z)),this[0]=e.x,this[1]=e.y,this[2]=e.z,this.check()}toObject(e){return e.x=this[0],e.y=this[1],e.z=this[2],e}get ELEMENTS(){return 3}get z(){return this[2]}set z(e){this[2]=te(e)}angle(e){return vx(this,e)}cross(e){return Rt(this,this,e),this.check()}rotateX({radians:e,origin:t=yo}){return _x(this,this,t,e),this.check()}rotateY({radians:e,origin:t=yo}){return yx(this,this,t,e),this.check()}rotateZ({radians:e,origin:t=yo}){return bx(this,this,t,e),this.check()}transform(e){return this.transformAsPoint(e)}transformAsPoint(e){return qc(this,this,e),this.check()}transformAsVector(e){return ng(this,this,e),this.check()}transformByMatrix3(e){return mx(this,this,e),this.check()}transformByMatrix2(e){return cx(this,this,e),this.check()}transformByQuaternion(e){return Zc(this,this,e),this.check()}}let es;class Xc extends tg{static get ZERO(){return es||(es=new Xc(0,0,0,0),Object.freeze(es)),es}constructor(e=0,t=0,n=0,s=0){super(-0,-0,-0,-0),Nt(e)&&arguments.length===1?this.copy(e):(Se.debug&&(te(e),te(t),te(n),te(s)),this[0]=e,this[1]=t,this[2]=n,this[3]=s)}set(e,t,n,s){return this[0]=e,this[1]=t,this[2]=n,this[3]=s,this.check()}copy(e){return this[0]=e[0],this[1]=e[1],this[2]=e[2],this[3]=e[3],this.check()}fromObject(e){return Se.debug&&(te(e.x),te(e.y),te(e.z),te(e.w)),this[0]=e.x,this[1]=e.y,this[2]=e.z,this[3]=e.w,this}toObject(e){return e.x=this[0],e.y=this[1],e.z=this[2],e.w=this[3],e}get ELEMENTS(){return 4}get z(){return this[2]}set z(e){this[2]=te(e)}get w(){return this[3]}set w(e){this[3]=te(e)}transform(e){return qc(this,this,e),this.check()}transformByMatrix3(e){return ux(this,this,e),this.check()}transformByMatrix2(e){return lx(this,this,e),this.check()}transformByQuaternion(e){return Zc(this,this,e),this.check()}applyMatrix4(e){return e.transform(this,this),this}}class wx extends Yc{toString(){let e="[";if(Se.printRowMajor){e+="row-major:";for(let t=0;t<this.RANK;++t)for(let n=0;n<this.RANK;++n)e+=` ${this[n*this.RANK+t]}`}else{e+="column-major:";for(let t=0;t<this.ELEMENTS;++t)e+=` ${this[t]}`}return e+="]",e}getElementIndex(e,t){return t*this.RANK+e}getElement(e,t){return this[t*this.RANK+e]}setElement(e,t,n){return this[t*this.RANK+e]=te(n),this}getColumn(e,t=new Array(this.RANK).fill(-0)){const n=e*this.RANK;for(let s=0;s<this.RANK;++s)t[s]=this[n+s];return t}setColumn(e,t){const n=e*this.RANK;for(let s=0;s<this.RANK;++s)this[n+s]=t[s];return this}}function xx(){const i=new $e(9);return $e!=Float32Array&&(i[1]=0,i[2]=0,i[3]=0,i[5]=0,i[6]=0,i[7]=0),i[0]=1,i[4]=1,i[8]=1,i}function Px(i){return i[0]=1,i[1]=0,i[2]=0,i[3]=0,i[4]=0,i[5]=1,i[6]=0,i[7]=0,i[8]=0,i[9]=0,i[10]=1,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,i}function Sx(i,e){if(i===e){const t=e[1],n=e[2],s=e[3],r=e[6],o=e[7],a=e[11];i[1]=e[4],i[2]=e[8],i[3]=e[12],i[4]=t,i[6]=e[9],i[7]=e[13],i[8]=n,i[9]=r,i[11]=e[14],i[12]=s,i[13]=o,i[14]=a}else i[0]=e[0],i[1]=e[4],i[2]=e[8],i[3]=e[12],i[4]=e[1],i[5]=e[5],i[6]=e[9],i[7]=e[13],i[8]=e[2],i[9]=e[6],i[10]=e[10],i[11]=e[14],i[12]=e[3],i[13]=e[7],i[14]=e[11],i[15]=e[15];return i}function Fa(i,e){const t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],f=e[9],d=e[10],g=e[11],p=e[12],m=e[13],_=e[14],v=e[15],w=t*a-n*o,y=t*c-s*o,x=t*l-r*o,S=n*c-s*a,C=n*l-r*a,O=s*l-r*c,B=u*m-f*p,D=u*_-d*p,k=u*v-g*p,N=f*_-d*m,F=f*v-g*m,z=d*v-g*_;let L=w*z-y*F+x*N+S*k-C*D+O*B;return L?(L=1/L,i[0]=(a*z-c*F+l*N)*L,i[1]=(s*F-n*z-r*N)*L,i[2]=(m*O-_*C+v*S)*L,i[3]=(d*C-f*O-g*S)*L,i[4]=(c*k-o*z-l*D)*L,i[5]=(t*z-s*k+r*D)*L,i[6]=(_*x-p*O-v*y)*L,i[7]=(u*O-d*x+g*y)*L,i[8]=(o*F-a*k+l*B)*L,i[9]=(n*k-t*F-r*B)*L,i[10]=(p*C-m*x+v*w)*L,i[11]=(f*x-u*C-g*w)*L,i[12]=(a*D-o*N-c*B)*L,i[13]=(t*N-n*D+s*B)*L,i[14]=(m*y-p*S-_*w)*L,i[15]=(u*S-f*y+d*w)*L,i):null}function Ex(i){const e=i[0],t=i[1],n=i[2],s=i[3],r=i[4],o=i[5],a=i[6],c=i[7],l=i[8],u=i[9],f=i[10],d=i[11],g=i[12],p=i[13],m=i[14],_=i[15],v=e*o-t*r,w=e*a-n*r,y=t*a-n*o,x=l*p-u*g,S=l*m-f*g,C=u*m-f*p,O=e*C-t*S+n*x,B=r*C-o*S+a*x,D=l*y-u*w+f*v,k=g*y-p*w+m*v;return c*O-s*B+_*D-d*k}function Ot(i,e,t){const n=e[0],s=e[1],r=e[2],o=e[3],a=e[4],c=e[5],l=e[6],u=e[7],f=e[8],d=e[9],g=e[10],p=e[11],m=e[12],_=e[13],v=e[14],w=e[15];let y=t[0],x=t[1],S=t[2],C=t[3];return i[0]=y*n+x*a+S*f+C*m,i[1]=y*s+x*c+S*d+C*_,i[2]=y*r+x*l+S*g+C*v,i[3]=y*o+x*u+S*p+C*w,y=t[4],x=t[5],S=t[6],C=t[7],i[4]=y*n+x*a+S*f+C*m,i[5]=y*s+x*c+S*d+C*_,i[6]=y*r+x*l+S*g+C*v,i[7]=y*o+x*u+S*p+C*w,y=t[8],x=t[9],S=t[10],C=t[11],i[8]=y*n+x*a+S*f+C*m,i[9]=y*s+x*c+S*d+C*_,i[10]=y*r+x*l+S*g+C*v,i[11]=y*o+x*u+S*p+C*w,y=t[12],x=t[13],S=t[14],C=t[15],i[12]=y*n+x*a+S*f+C*m,i[13]=y*s+x*c+S*d+C*_,i[14]=y*r+x*l+S*g+C*v,i[15]=y*o+x*u+S*p+C*w,i}function Js(i,e,t){const n=t[0],s=t[1],r=t[2];let o,a,c,l,u,f,d,g,p,m,_,v;return e===i?(i[12]=e[0]*n+e[4]*s+e[8]*r+e[12],i[13]=e[1]*n+e[5]*s+e[9]*r+e[13],i[14]=e[2]*n+e[6]*s+e[10]*r+e[14],i[15]=e[3]*n+e[7]*s+e[11]*r+e[15]):(o=e[0],a=e[1],c=e[2],l=e[3],u=e[4],f=e[5],d=e[6],g=e[7],p=e[8],m=e[9],_=e[10],v=e[11],i[0]=o,i[1]=a,i[2]=c,i[3]=l,i[4]=u,i[5]=f,i[6]=d,i[7]=g,i[8]=p,i[9]=m,i[10]=_,i[11]=v,i[12]=o*n+u*s+p*r+e[12],i[13]=a*n+f*s+m*r+e[13],i[14]=c*n+d*s+_*r+e[14],i[15]=l*n+g*s+v*r+e[15]),i}function Kc(i,e,t){const n=t[0],s=t[1],r=t[2];return i[0]=e[0]*n,i[1]=e[1]*n,i[2]=e[2]*n,i[3]=e[3]*n,i[4]=e[4]*s,i[5]=e[5]*s,i[6]=e[6]*s,i[7]=e[7]*s,i[8]=e[8]*r,i[9]=e[9]*r,i[10]=e[10]*r,i[11]=e[11]*r,i[12]=e[12],i[13]=e[13],i[14]=e[14],i[15]=e[15],i}function Cx(i,e,t,n){let s=n[0],r=n[1],o=n[2],a=Math.sqrt(s*s+r*r+o*o),c,l,u,f,d,g,p,m,_,v,w,y,x,S,C,O,B,D,k,N,F,z,L,G;return a<Ji?null:(a=1/a,s*=a,r*=a,o*=a,l=Math.sin(t),c=Math.cos(t),u=1-c,f=e[0],d=e[1],g=e[2],p=e[3],m=e[4],_=e[5],v=e[6],w=e[7],y=e[8],x=e[9],S=e[10],C=e[11],O=s*s*u+c,B=r*s*u+o*l,D=o*s*u-r*l,k=s*r*u-o*l,N=r*r*u+c,F=o*r*u+s*l,z=s*o*u+r*l,L=r*o*u-s*l,G=o*o*u+c,i[0]=f*O+m*B+y*D,i[1]=d*O+_*B+x*D,i[2]=g*O+v*B+S*D,i[3]=p*O+w*B+C*D,i[4]=f*k+m*N+y*F,i[5]=d*k+_*N+x*F,i[6]=g*k+v*N+S*F,i[7]=p*k+w*N+C*F,i[8]=f*z+m*L+y*G,i[9]=d*z+_*L+x*G,i[10]=g*z+v*L+S*G,i[11]=p*z+w*L+C*G,e!==i&&(i[12]=e[12],i[13]=e[13],i[14]=e[14],i[15]=e[15]),i)}function cg(i,e,t){const n=Math.sin(t),s=Math.cos(t),r=e[4],o=e[5],a=e[6],c=e[7],l=e[8],u=e[9],f=e[10],d=e[11];return e!==i&&(i[0]=e[0],i[1]=e[1],i[2]=e[2],i[3]=e[3],i[12]=e[12],i[13]=e[13],i[14]=e[14],i[15]=e[15]),i[4]=r*s+l*n,i[5]=o*s+u*n,i[6]=a*s+f*n,i[7]=c*s+d*n,i[8]=l*s-r*n,i[9]=u*s-o*n,i[10]=f*s-a*n,i[11]=d*s-c*n,i}function Lx(i,e,t){const n=Math.sin(t),s=Math.cos(t),r=e[0],o=e[1],a=e[2],c=e[3],l=e[8],u=e[9],f=e[10],d=e[11];return e!==i&&(i[4]=e[4],i[5]=e[5],i[6]=e[6],i[7]=e[7],i[12]=e[12],i[13]=e[13],i[14]=e[14],i[15]=e[15]),i[0]=r*s-l*n,i[1]=o*s-u*n,i[2]=a*s-f*n,i[3]=c*s-d*n,i[8]=r*n+l*s,i[9]=o*n+u*s,i[10]=a*n+f*s,i[11]=c*n+d*s,i}function lg(i,e,t){const n=Math.sin(t),s=Math.cos(t),r=e[0],o=e[1],a=e[2],c=e[3],l=e[4],u=e[5],f=e[6],d=e[7];return e!==i&&(i[8]=e[8],i[9]=e[9],i[10]=e[10],i[11]=e[11],i[12]=e[12],i[13]=e[13],i[14]=e[14],i[15]=e[15]),i[0]=r*s+l*n,i[1]=o*s+u*n,i[2]=a*s+f*n,i[3]=c*s+d*n,i[4]=l*s-r*n,i[5]=u*s-o*n,i[6]=f*s-a*n,i[7]=d*s-c*n,i}function Tx(i,e){const t=e[0],n=e[1],s=e[2],r=e[3],o=t+t,a=n+n,c=s+s,l=t*o,u=n*o,f=n*a,d=s*o,g=s*a,p=s*c,m=r*o,_=r*a,v=r*c;return i[0]=1-f-p,i[1]=u+v,i[2]=d-_,i[3]=0,i[4]=u-v,i[5]=1-l-p,i[6]=g+m,i[7]=0,i[8]=d+_,i[9]=g-m,i[10]=1-l-f,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,i}function Ax(i,e,t,n,s,r,o){const a=1/(t-e),c=1/(s-n),l=1/(r-o);return i[0]=r*2*a,i[1]=0,i[2]=0,i[3]=0,i[4]=0,i[5]=r*2*c,i[6]=0,i[7]=0,i[8]=(t+e)*a,i[9]=(s+n)*c,i[10]=(o+r)*l,i[11]=-1,i[12]=0,i[13]=0,i[14]=o*r*2*l,i[15]=0,i}function Mx(i,e,t,n,s){const r=1/Math.tan(e/2);if(i[0]=r/t,i[1]=0,i[2]=0,i[3]=0,i[4]=0,i[5]=r,i[6]=0,i[7]=0,i[8]=0,i[9]=0,i[11]=-1,i[12]=0,i[13]=0,i[15]=0,s!=null&&s!==1/0){const o=1/(n-s);i[10]=(s+n)*o,i[14]=2*s*n*o}else i[10]=-1,i[14]=-2*n;return i}const Ix=Mx;function Rx(i,e,t,n,s,r,o){const a=1/(e-t),c=1/(n-s),l=1/(r-o);return i[0]=-2*a,i[1]=0,i[2]=0,i[3]=0,i[4]=0,i[5]=-2*c,i[6]=0,i[7]=0,i[8]=0,i[9]=0,i[10]=2*l,i[11]=0,i[12]=(e+t)*a,i[13]=(s+n)*c,i[14]=(o+r)*l,i[15]=1,i}const Ox=Rx;function Bx(i,e,t,n){let s,r,o,a,c,l,u,f,d,g;const p=e[0],m=e[1],_=e[2],v=n[0],w=n[1],y=n[2],x=t[0],S=t[1],C=t[2];return Math.abs(p-x)<Ji&&Math.abs(m-S)<Ji&&Math.abs(_-C)<Ji?Px(i):(f=p-x,d=m-S,g=_-C,s=1/Math.sqrt(f*f+d*d+g*g),f*=s,d*=s,g*=s,r=w*g-y*d,o=y*f-v*g,a=v*d-w*f,s=Math.sqrt(r*r+o*o+a*a),s?(s=1/s,r*=s,o*=s,a*=s):(r=0,o=0,a=0),c=d*a-g*o,l=g*r-f*a,u=f*o-d*r,s=Math.sqrt(c*c+l*l+u*u),s?(s=1/s,c*=s,l*=s,u*=s):(c=0,l=0,u=0),i[0]=r,i[1]=c,i[2]=f,i[3]=0,i[4]=o,i[5]=l,i[6]=d,i[7]=0,i[8]=a,i[9]=u,i[10]=g,i[11]=0,i[12]=-(r*p+o*m+a*_),i[13]=-(c*p+l*m+u*_),i[14]=-(f*p+d*m+g*_),i[15]=1,i)}function kx(){const i=new $e(4);return $e!=Float32Array&&(i[0]=0,i[1]=0,i[2]=0,i[3]=0),i}function Dx(i,e,t){return i[0]=e[0]+t[0],i[1]=e[1]+t[1],i[2]=e[2]+t[2],i[3]=e[3]+t[3],i}function Qc(i,e,t){return i[0]=e[0]*t,i[1]=e[1]*t,i[2]=e[2]*t,i[3]=e[3]*t,i}function Fx(i){const e=i[0],t=i[1],n=i[2],s=i[3];return Math.sqrt(e*e+t*t+n*n+s*s)}function zx(i){const e=i[0],t=i[1],n=i[2],s=i[3];return e*e+t*t+n*n+s*s}function Nx(i,e){const t=e[0],n=e[1],s=e[2],r=e[3];let o=t*t+n*n+s*s+r*r;return o>0&&(o=1/Math.sqrt(o)),i[0]=t*o,i[1]=n*o,i[2]=s*o,i[3]=r*o,i}function Ux(i,e){return i[0]*e[0]+i[1]*e[1]+i[2]*e[2]+i[3]*e[3]}function $x(i,e,t,n){const s=e[0],r=e[1],o=e[2],a=e[3];return i[0]=s+n*(t[0]-s),i[1]=r+n*(t[1]-r),i[2]=o+n*(t[2]-o),i[3]=a+n*(t[3]-a),i}function Ti(i,e,t){const n=e[0],s=e[1],r=e[2],o=e[3];return i[0]=t[0]*n+t[4]*s+t[8]*r+t[12]*o,i[1]=t[1]*n+t[5]*s+t[9]*r+t[13]*o,i[2]=t[2]*n+t[6]*s+t[10]*r+t[14]*o,i[3]=t[3]*n+t[7]*s+t[11]*r+t[15]*o,i}function Gx(i,e,t){const n=e[0],s=e[1],r=e[2],o=t[0],a=t[1],c=t[2],l=t[3],u=l*n+a*r-c*s,f=l*s+c*n-o*r,d=l*r+o*s-a*n,g=-o*n-a*s-c*r;return i[0]=u*l+g*-o+f*-c-d*-a,i[1]=f*l+g*-a+d*-o-u*-c,i[2]=d*l+g*-c+u*-a-f*-o,i[3]=e[3],i}(function(){const i=kx();return function(e,t,n,s,r,o){let a,c;for(t||(t=4),n||(n=0),s?c=Math.min(s*t+n,e.length):c=e.length,a=n;a<c;a+=t)i[0]=e[a],i[1]=e[a+1],i[2]=e[a+2],i[3]=e[a+3],r(i,i,o),e[a]=i[0],e[a+1]=i[1],e[a+2]=i[2],e[a+3]=i[3];return e}})();var za;(function(i){i[i.COL0ROW0=0]="COL0ROW0",i[i.COL0ROW1=1]="COL0ROW1",i[i.COL0ROW2=2]="COL0ROW2",i[i.COL0ROW3=3]="COL0ROW3",i[i.COL1ROW0=4]="COL1ROW0",i[i.COL1ROW1=5]="COL1ROW1",i[i.COL1ROW2=6]="COL1ROW2",i[i.COL1ROW3=7]="COL1ROW3",i[i.COL2ROW0=8]="COL2ROW0",i[i.COL2ROW1=9]="COL2ROW1",i[i.COL2ROW2=10]="COL2ROW2",i[i.COL2ROW3=11]="COL2ROW3",i[i.COL3ROW0=12]="COL3ROW0",i[i.COL3ROW1=13]="COL3ROW1",i[i.COL3ROW2=14]="COL3ROW2",i[i.COL3ROW3=15]="COL3ROW3"})(za||(za={}));const jx=45*Math.PI/180,Vx=1,bo=.1,vo=500,Wx=Object.freeze([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);class Ge extends wx{static get IDENTITY(){return Yx()}static get ZERO(){return Hx()}get ELEMENTS(){return 16}get RANK(){return 4}get INDICES(){return za}constructor(e){super(-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0),arguments.length===1&&Array.isArray(e)?this.copy(e):this.identity()}copy(e){return this[0]=e[0],this[1]=e[1],this[2]=e[2],this[3]=e[3],this[4]=e[4],this[5]=e[5],this[6]=e[6],this[7]=e[7],this[8]=e[8],this[9]=e[9],this[10]=e[10],this[11]=e[11],this[12]=e[12],this[13]=e[13],this[14]=e[14],this[15]=e[15],this.check()}set(e,t,n,s,r,o,a,c,l,u,f,d,g,p,m,_){return this[0]=e,this[1]=t,this[2]=n,this[3]=s,this[4]=r,this[5]=o,this[6]=a,this[7]=c,this[8]=l,this[9]=u,this[10]=f,this[11]=d,this[12]=g,this[13]=p,this[14]=m,this[15]=_,this.check()}setRowMajor(e,t,n,s,r,o,a,c,l,u,f,d,g,p,m,_){return this[0]=e,this[1]=r,this[2]=l,this[3]=g,this[4]=t,this[5]=o,this[6]=u,this[7]=p,this[8]=n,this[9]=a,this[10]=f,this[11]=m,this[12]=s,this[13]=c,this[14]=d,this[15]=_,this.check()}toRowMajor(e){return e[0]=this[0],e[1]=this[4],e[2]=this[8],e[3]=this[12],e[4]=this[1],e[5]=this[5],e[6]=this[9],e[7]=this[13],e[8]=this[2],e[9]=this[6],e[10]=this[10],e[11]=this[14],e[12]=this[3],e[13]=this[7],e[14]=this[11],e[15]=this[15],e}identity(){return this.copy(Wx)}fromObject(e){return this.check()}fromQuaternion(e){return Tx(this,e),this.check()}frustum(e){const{left:t,right:n,bottom:s,top:r,near:o=bo,far:a=vo}=e;return a===1/0?qx(this,t,n,s,r,o):Ax(this,t,n,s,r,o,a),this.check()}lookAt(e){const{eye:t,center:n=[0,0,0],up:s=[0,1,0]}=e;return Bx(this,t,n,s),this.check()}ortho(e){const{left:t,right:n,bottom:s,top:r,near:o=bo,far:a=vo}=e;return Ox(this,t,n,s,r,o,a),this.check()}orthographic(e){const{fovy:t=jx,aspect:n=Vx,focalDistance:s=1,near:r=bo,far:o=vo}=e;Pu(t);const a=t/2,c=s*Math.tan(a),l=c*n;return this.ortho({left:-l,right:l,bottom:-c,top:c,near:r,far:o})}perspective(e){const{fovy:t=45*Math.PI/180,aspect:n=1,near:s=.1,far:r=500}=e;return Pu(t),Ix(this,t,n,s,r),this.check()}determinant(){return Ex(this)}getScale(e=[-0,-0,-0]){return e[0]=Math.sqrt(this[0]*this[0]+this[1]*this[1]+this[2]*this[2]),e[1]=Math.sqrt(this[4]*this[4]+this[5]*this[5]+this[6]*this[6]),e[2]=Math.sqrt(this[8]*this[8]+this[9]*this[9]+this[10]*this[10]),e}getTranslation(e=[-0,-0,-0]){return e[0]=this[12],e[1]=this[13],e[2]=this[14],e}getRotation(e,t){e=e||[-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0,-0],t=t||[-0,-0,-0];const n=this.getScale(t),s=1/n[0],r=1/n[1],o=1/n[2];return e[0]=this[0]*s,e[1]=this[1]*r,e[2]=this[2]*o,e[3]=0,e[4]=this[4]*s,e[5]=this[5]*r,e[6]=this[6]*o,e[7]=0,e[8]=this[8]*s,e[9]=this[9]*r,e[10]=this[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,e}getRotationMatrix3(e,t){e=e||[-0,-0,-0,-0,-0,-0,-0,-0,-0],t=t||[-0,-0,-0];const n=this.getScale(t),s=1/n[0],r=1/n[1],o=1/n[2];return e[0]=this[0]*s,e[1]=this[1]*r,e[2]=this[2]*o,e[3]=this[4]*s,e[4]=this[5]*r,e[5]=this[6]*o,e[6]=this[8]*s,e[7]=this[9]*r,e[8]=this[10]*o,e}transpose(){return Sx(this,this),this.check()}invert(){return Fa(this,this),this.check()}multiplyLeft(e){return Ot(this,e,this),this.check()}multiplyRight(e){return Ot(this,this,e),this.check()}rotateX(e){return cg(this,this,e),this.check()}rotateY(e){return Lx(this,this,e),this.check()}rotateZ(e){return lg(this,this,e),this.check()}rotateXYZ(e){return this.rotateX(e[0]).rotateY(e[1]).rotateZ(e[2])}rotateAxis(e,t){return Cx(this,this,e,t),this.check()}scale(e){return Kc(this,this,Array.isArray(e)?e:[e,e,e]),this.check()}translate(e){return Js(this,this,e),this.check()}transform(e,t){return e.length===4?(t=Ti(t||[-0,-0,-0,-0],e,this),bs(t,4),t):this.transformAsPoint(e,t)}transformAsPoint(e,t){const{length:n}=e;let s;switch(n){case 2:s=rx(t||[-0,-0],e,this);break;case 3:s=qc(t||[-0,-0,-0],e,this);break;default:throw new Error("Illegal vector")}return bs(s,e.length),s}transformAsVector(e,t){let n;switch(e.length){case 2:n=ax(t||[-0,-0],e,this);break;case 3:n=ng(t||[-0,-0,-0],e,this);break;default:throw new Error("Illegal vector")}return bs(n,e.length),n}transformPoint(e,t){return this.transformAsPoint(e,t)}transformVector(e,t){return this.transformAsPoint(e,t)}transformDirection(e,t){return this.transformAsVector(e,t)}makeRotationX(e){return this.identity().rotateX(e)}makeTranslation(e,t,n){return this.identity().translate([e,t,n])}}let ts,is;function Hx(){return ts||(ts=new Ge([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),Object.freeze(ts)),ts}function Yx(){return is||(is=new Ge,Object.freeze(is)),is}function Pu(i){if(i>Math.PI*2)throw Error("expected radians")}function qx(i,e,t,n,s,r){const o=2*r/(t-e),a=2*r/(s-n),c=(t+e)/(t-e),l=(s+n)/(s-n),u=-1,f=-1,d=-2*r;return i[0]=o,i[1]=0,i[2]=0,i[3]=0,i[4]=0,i[5]=a,i[6]=0,i[7]=0,i[8]=c,i[9]=l,i[10]=u,i[11]=f,i[12]=0,i[13]=0,i[14]=d,i[15]=0,i}function Su(){const i=new $e(4);return $e!=Float32Array&&(i[0]=0,i[1]=0,i[2]=0),i[3]=1,i}function Zx(i){return i[0]=0,i[1]=0,i[2]=0,i[3]=1,i}function ug(i,e,t){t=t*.5;const n=Math.sin(t);return i[0]=n*e[0],i[1]=n*e[1],i[2]=n*e[2],i[3]=Math.cos(t),i}function Eu(i,e,t){const n=e[0],s=e[1],r=e[2],o=e[3],a=t[0],c=t[1],l=t[2],u=t[3];return i[0]=n*u+o*a+s*l-r*c,i[1]=s*u+o*c+r*a-n*l,i[2]=r*u+o*l+n*c-s*a,i[3]=o*u-n*a-s*c-r*l,i}function Xx(i,e,t){t*=.5;const n=e[0],s=e[1],r=e[2],o=e[3],a=Math.sin(t),c=Math.cos(t);return i[0]=n*c+o*a,i[1]=s*c+r*a,i[2]=r*c-s*a,i[3]=o*c-n*a,i}function Kx(i,e,t){t*=.5;const n=e[0],s=e[1],r=e[2],o=e[3],a=Math.sin(t),c=Math.cos(t);return i[0]=n*c-r*a,i[1]=s*c+o*a,i[2]=r*c+n*a,i[3]=o*c-s*a,i}function Qx(i,e,t){t*=.5;const n=e[0],s=e[1],r=e[2],o=e[3],a=Math.sin(t),c=Math.cos(t);return i[0]=n*c+s*a,i[1]=s*c-n*a,i[2]=r*c+o*a,i[3]=o*c-r*a,i}function Jx(i,e){const t=e[0],n=e[1],s=e[2];return i[0]=t,i[1]=n,i[2]=s,i[3]=Math.sqrt(Math.abs(1-t*t-n*n-s*s)),i}function vs(i,e,t,n){const s=e[0],r=e[1],o=e[2],a=e[3];let c=t[0],l=t[1],u=t[2],f=t[3],d,g,p,m,_;return d=s*c+r*l+o*u+a*f,d<0&&(d=-d,c=-c,l=-l,u=-u,f=-f),1-d>Ji?(g=Math.acos(d),_=Math.sin(g),p=Math.sin((1-n)*g)/_,m=Math.sin(n*g)/_):(p=1-n,m=n),i[0]=p*s+m*c,i[1]=p*r+m*l,i[2]=p*o+m*u,i[3]=p*a+m*f,i}function eP(i,e){const t=e[0],n=e[1],s=e[2],r=e[3],o=t*t+n*n+s*s+r*r,a=o?1/o:0;return i[0]=-t*a,i[1]=-n*a,i[2]=-s*a,i[3]=r*a,i}function tP(i,e){return i[0]=-e[0],i[1]=-e[1],i[2]=-e[2],i[3]=e[3],i}function fg(i,e){const t=e[0]+e[4]+e[8];let n;if(t>0)n=Math.sqrt(t+1),i[3]=.5*n,n=.5/n,i[0]=(e[5]-e[7])*n,i[1]=(e[6]-e[2])*n,i[2]=(e[1]-e[3])*n;else{let s=0;e[4]>e[0]&&(s=1),e[8]>e[s*3+s]&&(s=2);const r=(s+1)%3,o=(s+2)%3;n=Math.sqrt(e[s*3+s]-e[r*3+r]-e[o*3+o]+1),i[s]=.5*n,n=.5/n,i[3]=(e[r*3+o]-e[o*3+r])*n,i[r]=(e[r*3+s]+e[s*3+r])*n,i[o]=(e[o*3+s]+e[s*3+o])*n}return i}const iP=Dx,nP=Qc,sP=Ux,rP=$x,oP=Fx,aP=zx,dg=Nx,cP=(function(){const i=sg(),e=xu(1,0,0),t=xu(0,1,0);return function(n,s,r){const o=en(s,r);return o<-.999999?(Rt(i,e,s),ag(i)<1e-6&&Rt(i,t,s),rg(i,i),ug(n,i,Math.PI),n):o>.999999?(n[0]=0,n[1]=0,n[2]=0,n[3]=1,n):(Rt(i,s,r),n[0]=i[0],n[1]=i[1],n[2]=i[2],n[3]=1+o,dg(n,n))}})();(function(){const i=Su(),e=Su();return function(t,n,s,r,o,a){return vs(i,n,o,a),vs(e,s,r,a),vs(t,i,e,2*a*(1-a)),t}})();(function(){const i=xx();return function(e,t,n,s){return i[0]=n[0],i[3]=n[1],i[6]=n[2],i[1]=s[0],i[4]=s[1],i[7]=s[2],i[2]=-t[0],i[5]=-t[1],i[8]=-t[2],dg(e,fg(e,i))}})();const lP=[0,0,0,1];class uP extends Yc{constructor(e=0,t=0,n=0,s=1){super(-0,-0,-0,-0),Array.isArray(e)&&arguments.length===1?this.copy(e):this.set(e,t,n,s)}copy(e){return this[0]=e[0],this[1]=e[1],this[2]=e[2],this[3]=e[3],this.check()}set(e,t,n,s){return this[0]=e,this[1]=t,this[2]=n,this[3]=s,this.check()}fromObject(e){return this[0]=e.x,this[1]=e.y,this[2]=e.z,this[3]=e.w,this.check()}fromMatrix3(e){return fg(this,e),this.check()}fromAxisRotation(e,t){return ug(this,e,t),this.check()}identity(){return Zx(this),this.check()}setAxisAngle(e,t){return this.fromAxisRotation(e,t)}get ELEMENTS(){return 4}get x(){return this[0]}set x(e){this[0]=te(e)}get y(){return this[1]}set y(e){this[1]=te(e)}get z(){return this[2]}set z(e){this[2]=te(e)}get w(){return this[3]}set w(e){this[3]=te(e)}len(){return oP(this)}lengthSquared(){return aP(this)}dot(e){return sP(this,e)}rotationTo(e,t){return cP(this,e,t),this.check()}add(e){return iP(this,this,e),this.check()}calculateW(){return Jx(this,this),this.check()}conjugate(){return tP(this,this),this.check()}invert(){return eP(this,this),this.check()}lerp(e,t,n){return n===void 0?this.lerp(this,e,t):(rP(this,e,t,n),this.check())}multiplyRight(e){return Eu(this,this,e),this.check()}multiplyLeft(e){return Eu(this,e,this),this.check()}normalize(){const e=this.len(),t=e>0?1/e:0;return this[0]=this[0]*t,this[1]=this[1]*t,this[2]=this[2]*t,this[3]=this[3]*t,e===0&&(this[3]=1),this.check()}rotateX(e){return Xx(this,this,e),this.check()}rotateY(e){return Kx(this,this,e),this.check()}rotateZ(e){return Qx(this,this,e),this.check()}scale(e){return nP(this,this,e),this.check()}slerp(e,t,n){let s,r,o;switch(arguments.length){case 1:({start:s=lP,target:r,ratio:o}=e);break;case 2:s=this,r=e,o=t;break;default:s=e,r=t,o=n}return vs(this,s,r,o),this.check()}transformVector4(e,t=new Xc){return Gx(t,e,this),bs(t,4)}lengthSq(){return this.lengthSquared()}setFromAxisAngle(e,t){return this.setAxisAngle(e,t)}premultiply(e){return this.multiplyLeft(e)}multiply(e){return this.multiplyRight(e)}}function hg(i,e=[],t=0){const n=Math.fround(i),s=i-n;return e[t]=n,e[t+1]=s,e}function fP(i){return i-Math.fround(i)}function dP(i){const e=new Float32Array(32);for(let t=0;t<4;++t)for(let n=0;n<4;++n){const s=t*4+n;hg(i[n*4+t],e,s*2)}return e}function gg(i,e=!0){return i??e}function pg(i=[0,0,0],e=!0){return e?i.map(t=>t/255):[...i]}function hP(i,e=!0){const t=pg(i.slice(0,3),e),n=Number.isFinite(i[3]),s=n?i[3]:1;return[t[0],t[1],t[2],e&&n?s/255:s]}const gP=`#ifdef LUMA_FP32_TAN_PRECISION_WORKAROUND

// All these functions are for substituting tan() function from Intel GPU only
const float TWO_PI = 6.2831854820251465;
const float PI_2 = 1.5707963705062866;
const float PI_16 = 0.1963495463132858;

const float SIN_TABLE_0 = 0.19509032368659973;
const float SIN_TABLE_1 = 0.3826834261417389;
const float SIN_TABLE_2 = 0.5555702447891235;
const float SIN_TABLE_3 = 0.7071067690849304;

const float COS_TABLE_0 = 0.9807852506637573;
const float COS_TABLE_1 = 0.9238795042037964;
const float COS_TABLE_2 = 0.8314695954322815;
const float COS_TABLE_3 = 0.7071067690849304;

const float INVERSE_FACTORIAL_3 = 1.666666716337204e-01; // 1/3!
const float INVERSE_FACTORIAL_5 = 8.333333767950535e-03; // 1/5!
const float INVERSE_FACTORIAL_7 = 1.9841270113829523e-04; // 1/7!
const float INVERSE_FACTORIAL_9 = 2.75573188446287533e-06; // 1/9!

float sin_taylor_fp32(float a) {
  float r, s, t, x;

  if (a == 0.0) {
    return 0.0;
  }

  x = -a * a;
  s = a;
  r = a;

  r = r * x;
  t = r * INVERSE_FACTORIAL_3;
  s = s + t;

  r = r * x;
  t = r * INVERSE_FACTORIAL_5;
  s = s + t;

  r = r * x;
  t = r * INVERSE_FACTORIAL_7;
  s = s + t;

  r = r * x;
  t = r * INVERSE_FACTORIAL_9;
  s = s + t;

  return s;
}

void sincos_taylor_fp32(float a, out float sin_t, out float cos_t) {
  if (a == 0.0) {
    sin_t = 0.0;
    cos_t = 1.0;
  }
  sin_t = sin_taylor_fp32(a);
  cos_t = sqrt(1.0 - sin_t * sin_t);
}

float tan_taylor_fp32(float a) {
    float sin_a;
    float cos_a;

    if (a == 0.0) {
        return 0.0;
    }

    // 2pi range reduction
    float z = floor(a / TWO_PI);
    float r = a - TWO_PI * z;

    float t;
    float q = floor(r / PI_2 + 0.5);
    int j = int(q);

    if (j < -2 || j > 2) {
        return 1.0 / 0.0;
    }

    t = r - PI_2 * q;

    q = floor(t / PI_16 + 0.5);
    int k = int(q);
    int abs_k = int(abs(float(k)));

    if (abs_k > 4) {
        return 1.0 / 0.0;
    } else {
        t = t - PI_16 * q;
    }

    float u = 0.0;
    float v = 0.0;

    float sin_t, cos_t;
    float s, c;
    sincos_taylor_fp32(t, sin_t, cos_t);

    if (k == 0) {
        s = sin_t;
        c = cos_t;
    } else {
        if (abs(float(abs_k) - 1.0) < 0.5) {
            u = COS_TABLE_0;
            v = SIN_TABLE_0;
        } else if (abs(float(abs_k) - 2.0) < 0.5) {
            u = COS_TABLE_1;
            v = SIN_TABLE_1;
        } else if (abs(float(abs_k) - 3.0) < 0.5) {
            u = COS_TABLE_2;
            v = SIN_TABLE_2;
        } else if (abs(float(abs_k) - 4.0) < 0.5) {
            u = COS_TABLE_3;
            v = SIN_TABLE_3;
        }
        if (k > 0) {
            s = u * sin_t + v * cos_t;
            c = u * cos_t - v * sin_t;
        } else {
            s = u * sin_t - v * cos_t;
            c = u * cos_t + v * sin_t;
        }
    }

    if (j == 0) {
        sin_a = s;
        cos_a = c;
    } else if (j == 1) {
        sin_a = c;
        cos_a = -s;
    } else if (j == -1) {
        sin_a = -c;
        cos_a = s;
    } else {
        sin_a = -s;
        cos_a = -c;
    }
    return sin_a / cos_a;
}
#endif

float tan_fp32(float a) {
#ifdef LUMA_FP32_TAN_PRECISION_WORKAROUND
  return tan_taylor_fp32(a);
#else
  return tan(a);
#endif
}
`,pP=`#ifdef LUMA_FP32_TAN_PRECISION_WORKAROUND
const FP32_TWO_PI: f32 = 6.2831854820251465;
const FP32_PI_2: f32 = 1.5707963705062866;
const FP32_PI_16: f32 = 0.1963495463132858;

const FP32_SIN_TABLE_0: f32 = 0.19509032368659973;
const FP32_SIN_TABLE_1: f32 = 0.3826834261417389;
const FP32_SIN_TABLE_2: f32 = 0.5555702447891235;
const FP32_SIN_TABLE_3: f32 = 0.7071067690849304;

const FP32_COS_TABLE_0: f32 = 0.9807852506637573;
const FP32_COS_TABLE_1: f32 = 0.9238795042037964;
const FP32_COS_TABLE_2: f32 = 0.8314695954322815;
const FP32_COS_TABLE_3: f32 = 0.7071067690849304;

const FP32_INVERSE_FACTORIAL_3: f32 = 1.666666716337204e-01;
const FP32_INVERSE_FACTORIAL_5: f32 = 8.333333767950535e-03;
const FP32_INVERSE_FACTORIAL_7: f32 = 1.9841270113829523e-04;
const FP32_INVERSE_FACTORIAL_9: f32 = 2.75573188446287533e-06;
const FP32_OVERFLOW: f32 = 3.402823466e+38;

fn sin_taylor_fp32(a: f32) -> f32 {
  if (a == 0.0) {
    return 0.0;
  }

  let x = -a * a;
  var sum = a;
  var term = a;

  term = term * x;
  sum = sum + term * FP32_INVERSE_FACTORIAL_3;
  term = term * x;
  sum = sum + term * FP32_INVERSE_FACTORIAL_5;
  term = term * x;
  sum = sum + term * FP32_INVERSE_FACTORIAL_7;
  term = term * x;
  sum = sum + term * FP32_INVERSE_FACTORIAL_9;

  return sum;
}

fn tan_taylor_fp32(a: f32) -> f32 {
  if (a == 0.0) {
    return 0.0;
  }

  let z = floor(a / FP32_TWO_PI);
  let reduced = a - FP32_TWO_PI * z;

  var quadrantValue = floor(reduced / FP32_PI_2 + 0.5);
  let quadrant = i32(quadrantValue);
  if (quadrant < -2 || quadrant > 2) {
    return FP32_OVERFLOW;
  }

  var angle = reduced - FP32_PI_2 * quadrantValue;
  quadrantValue = floor(angle / FP32_PI_16 + 0.5);
  let tableIndex = i32(quadrantValue);
  let absoluteTableIndex = abs(tableIndex);
  if (absoluteTableIndex > 4) {
    return FP32_OVERFLOW;
  }

  angle = angle - FP32_PI_16 * quadrantValue;
  let sinAngle = sin_taylor_fp32(angle);
  let cosAngle = sqrt(1.0 - sinAngle * sinAngle);

  var tableCos = 0.0;
  var tableSin = 0.0;
  if (absoluteTableIndex == 1) {
    tableCos = FP32_COS_TABLE_0;
    tableSin = FP32_SIN_TABLE_0;
  } else if (absoluteTableIndex == 2) {
    tableCos = FP32_COS_TABLE_1;
    tableSin = FP32_SIN_TABLE_1;
  } else if (absoluteTableIndex == 3) {
    tableCos = FP32_COS_TABLE_2;
    tableSin = FP32_SIN_TABLE_2;
  } else if (absoluteTableIndex == 4) {
    tableCos = FP32_COS_TABLE_3;
    tableSin = FP32_SIN_TABLE_3;
  }

  var sinReduced = sinAngle;
  var cosReduced = cosAngle;
  if (tableIndex > 0) {
    sinReduced = tableCos * sinAngle + tableSin * cosAngle;
    cosReduced = tableCos * cosAngle - tableSin * sinAngle;
  } else if (tableIndex < 0) {
    sinReduced = tableCos * sinAngle - tableSin * cosAngle;
    cosReduced = tableCos * cosAngle + tableSin * sinAngle;
  }

  var sinValue = 0.0;
  var cosValue = 0.0;
  if (quadrant == 0) {
    sinValue = sinReduced;
    cosValue = cosReduced;
  } else if (quadrant == 1) {
    sinValue = cosReduced;
    cosValue = -sinReduced;
  } else if (quadrant == -1) {
    sinValue = -cosReduced;
    cosValue = sinReduced;
  } else {
    sinValue = -sinReduced;
    cosValue = -cosReduced;
  }

  return sinValue / cosValue;
}

fn tan_fp32(a: f32) -> f32 {
  return tan_taylor_fp32(a);
}
#else
fn tan_fp32(a: f32) -> f32 {
  return tan(a);
}
#endif
`,mP={name:"fp32",source:pP,vs:gP},Cu=`
layout(std140) uniform fp64arithmeticUniforms {
  uniform float ONE;
  uniform float SPLIT;
} fp64;

/*
About LUMA_FP64_CODE_ELIMINATION_WORKAROUND

The purpose of this workaround is to prevent shader compilers from
optimizing away necessary arithmetic operations by swapping their sequences
or transform the equation to some 'equivalent' form.

These helpers implement Dekker/Veltkamp-style error tracking. If the compiler
folds constants or reassociates the arithmetic, the high/low split can stop
tracking the rounding error correctly. That failure mode tends to look fine in
simple coordinate setup, but then breaks down inside iterative arithmetic such
as fp64 Mandelbrot loops.

The method is to multiply an artifical variable, ONE, which will be known to
the compiler to be 1 only at runtime. The whole expression is then represented
as a polynomial with respective to ONE. In the coefficients of all terms, only one a
and one b should appear

err = (a + b) * ONE^6 - a * ONE^5 - (a + b) * ONE^4 + a * ONE^3 - b - (a + b) * ONE^2 + a * ONE
*/

float prevent_fp64_optimization(float value) {
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  return value + fp64.ONE * 0.0;
#else
  return value;
#endif
}

// Divide float number to high and low floats to extend fraction bits
vec2 split(float a) {
  // Keep SPLIT as a runtime uniform so the compiler cannot fold the Dekker
  // split into a constant expression and reassociate the recovery steps.
  float split = prevent_fp64_optimization(fp64.SPLIT);
  float t = prevent_fp64_optimization(a * split);
  float temp = t - a;
  float a_hi = t - temp;
  float a_lo = a - a_hi;
  return vec2(a_hi, a_lo);
}

// Divide float number again when high float uses too many fraction bits
vec2 split2(vec2 a) {
  vec2 b = split(a.x);
  b.y += a.y;
  return b;
}

// Special sum operation when a > b
vec2 quickTwoSum(float a, float b) {
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  float sum = (a + b) * fp64.ONE;
  float err = b - (sum - a) * fp64.ONE;
#else
  float sum = a + b;
  float err = b - (sum - a);
#endif
  return vec2(sum, err);
}

// General sum operation
vec2 twoSum(float a, float b) {
  float s = (a + b);
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  float v = (s * fp64.ONE - a) * fp64.ONE;
  float err = (a - (s - v) * fp64.ONE) * fp64.ONE * fp64.ONE * fp64.ONE + (b - v);
#else
  float v = s - a;
  float err = (a - (s - v)) + (b - v);
#endif
  return vec2(s, err);
}

vec2 twoSub(float a, float b) {
  float s = (a - b);
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  float v = (s * fp64.ONE - a) * fp64.ONE;
  float err = (a - (s - v) * fp64.ONE) * fp64.ONE * fp64.ONE * fp64.ONE - (b + v);
#else
  float v = s - a;
  float err = (a - (s - v)) - (b + v);
#endif
  return vec2(s, err);
}

vec2 twoSqr(float a) {
  float prod = a * a;
  vec2 a_fp64 = split(a);
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  float err = ((a_fp64.x * a_fp64.x - prod) * fp64.ONE + 2.0 * a_fp64.x *
    a_fp64.y * fp64.ONE * fp64.ONE) + a_fp64.y * a_fp64.y * fp64.ONE * fp64.ONE * fp64.ONE;
#else
  float err = ((a_fp64.x * a_fp64.x - prod) + 2.0 * a_fp64.x * a_fp64.y) + a_fp64.y * a_fp64.y;
#endif
  return vec2(prod, err);
}

vec2 twoProd(float a, float b) {
  float prod = a * b;
  vec2 a_fp64 = split(a);
  vec2 b_fp64 = split(b);
  // twoProd is especially sensitive because mul_fp64 and div_fp64 both depend
  // on the split terms and cross terms staying in the original evaluation
  // order. If the compiler folds or reassociates them, the low part tends to
  // collapse to zero or NaN on some drivers.
  float highProduct = prevent_fp64_optimization(a_fp64.x * b_fp64.x);
  float crossProduct1 = prevent_fp64_optimization(a_fp64.x * b_fp64.y);
  float crossProduct2 = prevent_fp64_optimization(a_fp64.y * b_fp64.x);
  float lowProduct = prevent_fp64_optimization(a_fp64.y * b_fp64.y);
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  float err1 = (highProduct - prod) * fp64.ONE;
  float err2 = crossProduct1 * fp64.ONE * fp64.ONE;
  float err3 = crossProduct2 * fp64.ONE * fp64.ONE * fp64.ONE;
  float err4 = lowProduct * fp64.ONE * fp64.ONE * fp64.ONE * fp64.ONE;
#else
  float err1 = highProduct - prod;
  float err2 = crossProduct1;
  float err3 = crossProduct2;
  float err4 = lowProduct;
#endif
  float err = ((err1 + err2) + err3) + err4;
  return vec2(prod, err);
}

vec2 sum_fp64(vec2 a, vec2 b) {
  vec2 s, t;
  s = twoSum(a.x, b.x);
  t = twoSum(a.y, b.y);
  s.y += t.x;
  s = quickTwoSum(s.x, s.y);
  s.y += t.y;
  s = quickTwoSum(s.x, s.y);
  return s;
}

vec2 sub_fp64(vec2 a, vec2 b) {
  vec2 s, t;
  s = twoSub(a.x, b.x);
  t = twoSub(a.y, b.y);
  s.y += t.x;
  s = quickTwoSum(s.x, s.y);
  s.y += t.y;
  s = quickTwoSum(s.x, s.y);
  return s;
}

vec2 mul_fp64(vec2 a, vec2 b) {
  vec2 prod = twoProd(a.x, b.x);
  // y component is for the error
  prod.y += a.x * b.y;
#if defined(LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND)
  prod = split2(prod);
#endif
  prod = quickTwoSum(prod.x, prod.y);
  prod.y += a.y * b.x;
#if defined(LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND)
  prod = split2(prod);
#endif
  prod = quickTwoSum(prod.x, prod.y);
  return prod;
}

vec2 div_fp64(vec2 a, vec2 b) {
  float xn = 1.0 / b.x;
#if defined(LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND)
  vec2 yn = mul_fp64(a, vec2(xn, 0));
#else
  vec2 yn = a * xn;
#endif
  float diff = (sub_fp64(a, mul_fp64(b, yn))).x;
  vec2 prod = twoProd(xn, diff);
  return sum_fp64(yn, prod);
}

vec2 sqrt_fp64(vec2 a) {
  if (a.x == 0.0 && a.y == 0.0) return vec2(0.0, 0.0);
  if (a.x < 0.0) return vec2(0.0 / 0.0, 0.0 / 0.0);

  float x = 1.0 / sqrt(a.x);
  float yn = a.x * x;
#if defined(LUMA_FP64_CODE_ELIMINATION_WORKAROUND)
  vec2 yn_sqr = twoSqr(yn) * fp64.ONE;
#else
  vec2 yn_sqr = twoSqr(yn);
#endif
  float diff = sub_fp64(a, yn_sqr).x;
  vec2 prod = twoProd(x * 0.5, diff);
#if defined(LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND)
  return sum_fp64(split(yn), prod);
#else
  return sum_fp64(vec2(yn, 0.0), prod);
#endif
}
`,_P=`struct Fp64F32Bits {
  sign: u32,
  baseExponent: i32,
  significand: u32,
  isZero: bool,
  isInf: bool,
  isNan: bool,
};

// Decode an f32 as (-1)^sign * significand * 2^baseExponent.
fn fp64_decode_f32_bits(bits: u32) -> Fp64F32Bits {
  let sign = bits >> 31u;
  let exponentBits = (bits >> 23u) & 0xffu;
  let fraction = bits & 0x7fffffu;

  if (exponentBits == 0xffu) {
    return Fp64F32Bits(sign, 0, 0u, false, fraction == 0u, fraction != 0u);
  }
  if (exponentBits == 0u) {
    return Fp64F32Bits(sign, -149, fraction, fraction == 0u, false, false);
  }
  return Fp64F32Bits(sign, i32(exponentBits) - 150, 0x800000u | fraction, false, false, false);
}

fn fp64_f32_magnitude_compare(aBits: u32, bBits: u32) -> i32 {
  let aMagnitude = aBits & 0x7fffffffu;
  let bMagnitude = bBits & 0x7fffffffu;
  if (aMagnitude == bMagnitude) {
    return 0;
  }
  return select(-1, 1, aMagnitude > bMagnitude);
}

fn fp64_make_residual_f32_bits(
  exactSign: u32,
  exactMagnitude: vec2u,
  exactBaseExponent: i32,
  highBits: u32
) -> u32 {
  if (fp64_u64_is_zero(exactMagnitude)) {
    return 0u;
  }

  let high = fp64_decode_f32_bits(highBits);
  if (high.isInf || high.isNan) {
    return exactSign << 31u;
  }
  if (high.isZero) {
    return fp64_make_f32_bits_from_u64(exactSign, exactMagnitude, exactBaseExponent);
  }

  let commonBaseExponent = min(exactBaseExponent, high.baseExponent);
  let exactShift = exactBaseExponent - commonBaseExponent;
  let highShift = high.baseExponent - commonBaseExponent;

  // A normal two-sum/two-product residual never needs a shift this large.
  // This guard gives deterministic underflow behavior outside that contract.
  if (exactShift >= 64 || highShift >= 64) {
    return exactSign << 31u;
  }

  let exactAligned = fp64_u64_shift_left(exactMagnitude, u32(exactShift));
  let highAligned = fp64_u64_shift_left(vec2u(0u, high.significand), u32(highShift));
  let comparison = fp64_u64_compare(exactAligned, highAligned);
  if (comparison == 0) {
    return 0u;
  }

  var residualSign = exactSign;
  var residualMagnitude: vec2u;
  if (comparison > 0) {
    residualMagnitude = fp64_u64_sub(exactAligned, highAligned);
  } else {
    residualSign = exactSign ^ 1u;
    residualMagnitude = fp64_u64_sub(highAligned, exactAligned);
  }
  return fp64_make_f32_bits_from_u64(
    residualSign,
    residualMagnitude,
    commonBaseExponent
  );
}

fn fp64_split_accumulator_bits(
  sign: u32,
  magnitude: vec2u,
  baseExponent: i32
) -> vec2u {
  let highBits = fp64_make_f32_bits_from_u64(sign, magnitude, baseExponent);
  let lowBits = fp64_make_residual_f32_bits(sign, magnitude, baseExponent, highBits);
  return vec2u(highBits, lowBits);
}

fn fp64_two_sum_integer_bits(aBits: u32, bBits: u32) -> vec2u {
  let a = fp64_decode_f32_bits(aBits);
  let b = fp64_decode_f32_bits(bBits);

  if (a.isNan || b.isNan) {
    return vec2u(0x7fc00000u, 0u);
  }
  if (a.isInf || b.isInf) {
    if (a.isInf && b.isInf && a.sign != b.sign) {
      return vec2u(0x7fc00000u, 0u);
    }
    return select(vec2u(bBits, 0u), vec2u(aBits, 0u), a.isInf);
  }
  if (a.isZero && b.isZero) {
    return vec2u((a.sign & b.sign) << 31u, 0u);
  }
  if (a.isZero) {
    return vec2u(bBits, 0u);
  }
  if (b.isZero) {
    return vec2u(aBits, 0u);
  }

  let exponentDifference = select(
    b.baseExponent - a.baseExponent,
    a.baseExponent - b.baseExponent,
    a.baseExponent >= b.baseExponent
  );

  // Beyond half an ulp, rounding cannot change the larger operand. Returning
  // the smaller operand intact also avoids an unbounded integer alignment.
  // At a power-of-two boundary the spacing below the larger operand is half
  // the spacing above it, so an opposite-sign gap-25 operand can still change
  // the rounded high limb. Gap 26 is the first universally safe early-out.
  if (exponentDifference > 25) {
    if (fp64_f32_magnitude_compare(aBits, bBits) >= 0) {
      return vec2u(aBits, bBits);
    }
    return vec2u(bBits, aBits);
  }

  let commonBaseExponent = min(a.baseExponent, b.baseExponent);
  let aMagnitude = fp64_u64_shift_left(
    vec2u(0u, a.significand),
    u32(a.baseExponent - commonBaseExponent)
  );
  let bMagnitude = fp64_u64_shift_left(
    vec2u(0u, b.significand),
    u32(b.baseExponent - commonBaseExponent)
  );

  var resultSign = a.sign;
  var resultMagnitude: vec2u;
  if (a.sign == b.sign) {
    resultMagnitude = fp64_u64_add(aMagnitude, bMagnitude);
  } else {
    let comparison = fp64_u64_compare(aMagnitude, bMagnitude);
    if (comparison == 0) {
      return vec2u(0u, 0u);
    }
    if (comparison > 0) {
      resultMagnitude = fp64_u64_sub(aMagnitude, bMagnitude);
    } else {
      resultSign = b.sign;
      resultMagnitude = fp64_u64_sub(bMagnitude, aMagnitude);
    }
  }

  return fp64_split_accumulator_bits(resultSign, resultMagnitude, commonBaseExponent);
}

fn fp64_two_sum_integer(a: f32, b: f32) -> vec2f {
  let resultBits = fp64_two_sum_integer_bits(bitcast<u32>(a), bitcast<u32>(b));
  return vec2f(bitcast<f32>(resultBits.x), bitcast<f32>(resultBits.y));
}

fn fp64_multiply_significands(a: u32, b: u32) -> vec2u {
  let aLow = a & 0xffffu;
  let aHigh = a >> 16u;
  let bLow = b & 0xffffu;
  let bHigh = b >> 16u;
  let lowProduct = aLow * bLow;
  let crossProduct = aLow * bHigh + aHigh * bLow;
  let highProduct = aHigh * bHigh;

  var result = vec2u(0u, lowProduct);
  result = fp64_u64_add(
    result,
    fp64_u64_shift_left(vec2u(0u, crossProduct), 16u)
  );
  result = fp64_u64_add(result, vec2u(highProduct, 0u));
  return result;
}

fn fp64_two_prod_integer_bits(aBits: u32, bBits: u32) -> vec2u {
  let a = fp64_decode_f32_bits(aBits);
  let b = fp64_decode_f32_bits(bBits);
  let resultSign = a.sign ^ b.sign;

  if (a.isNan || b.isNan || ((a.isZero || b.isZero) && (a.isInf || b.isInf))) {
    return vec2u(0x7fc00000u, 0u);
  }
  if (a.isInf || b.isInf) {
    return vec2u((resultSign << 31u) | 0x7f800000u, resultSign << 31u);
  }
  if (a.isZero || b.isZero) {
    return vec2u(resultSign << 31u, resultSign << 31u);
  }

  let magnitude = fp64_multiply_significands(a.significand, b.significand);
  return fp64_split_accumulator_bits(
    resultSign,
    magnitude,
    a.baseExponent + b.baseExponent
  );
}

fn fp64_two_prod_integer(a: f32, b: f32) -> vec2f {
  let resultBits = fp64_two_prod_integer_bits(bitcast<u32>(a), bitcast<u32>(b));
  return vec2f(bitcast<f32>(resultBits.x), bitcast<f32>(resultBits.y));
}

fn fp64_round_add_integer(a: f32, b: f32) -> f32 {
  return fp64_two_sum_integer(a, b).x;
}

fn fp64_round_mul_integer(a: f32, b: f32) -> f32 {
  return fp64_two_prod_integer(a, b).x;
}

#ifndef LUMA_FP64_PREDICATE_ONLY
fn fp64_f32_finite_exponent(value: Fp64F32Bits) -> i32 {
  let mostSignificantBit = 31u - countLeadingZeros(value.significand);
  return value.baseExponent + i32(mostSignificantBit);
}

fn fp64_scale_f32_integer(value: f32, exponent: i32) -> f32 {
  let decoded = fp64_decode_f32_bits(bitcast<u32>(value));
  if (decoded.isZero || decoded.isInf || decoded.isNan) {
    return value;
  }
  let resultBits = fp64_make_f32_bits_from_u64(
    decoded.sign,
    vec2u(0u, decoded.significand),
    decoded.baseExponent + exponent
  );
  return bitcast<f32>(resultBits);
}

// Divide normalized significands so the hardware operation cannot overflow,
// underflow, or flush a subnormal result. Reapply the exponent with integer
// packing, which also produces subnormal correction limbs without relying on
// floating-point arithmetic to preserve them.
fn fp64_divide_f32_integer(aValue: f32, bValue: f32) -> f32 {
  let a = fp64_decode_f32_bits(bitcast<u32>(aValue));
  let b = fp64_decode_f32_bits(bitcast<u32>(bValue));
  if (a.isZero || b.isZero || a.isInf || b.isInf || a.isNan || b.isNan) {
    return aValue / bValue;
  }

  let aMostSignificantBit = 31u - countLeadingZeros(a.significand);
  let bMostSignificantBit = 31u - countLeadingZeros(b.significand);
  let normalizedABits = fp64_make_f32_bits_from_u64(
    a.sign,
    vec2u(0u, a.significand),
    -i32(aMostSignificantBit)
  );
  let normalizedBBits = fp64_make_f32_bits_from_u64(
    b.sign,
    vec2u(0u, b.significand),
    -i32(bMostSignificantBit)
  );
  let normalizedQuotient = bitcast<f32>(normalizedABits) / bitcast<f32>(normalizedBBits);
  let quotient = fp64_decode_f32_bits(bitcast<u32>(normalizedQuotient));
  let exponentShift =
    a.baseExponent + i32(aMostSignificantBit) -
    b.baseExponent - i32(bMostSignificantBit);
  let quotientBits = fp64_make_f32_bits_from_u64(
    quotient.sign,
    vec2u(0u, quotient.significand),
    quotient.baseExponent + exponentShift
  );
  return bitcast<f32>(quotientBits);
}
#endif

#ifndef LUMA_FP64_PREDICATE_ONLY
fn split(a: f32) -> vec2f {
  let aBits = bitcast<u32>(a);
  let decoded = fp64_decode_f32_bits(aBits);
  if (decoded.isZero || decoded.isInf || decoded.isNan) {
    return vec2f(a, 0.0);
  }

  var roundedHigh = decoded.significand >> 12u;
  let remainder = decoded.significand & 0xfffu;
  if (remainder > 0x800u || (remainder == 0x800u && (roundedHigh & 1u) == 1u)) {
    roundedHigh = roundedHigh + 1u;
  }
  var highMagnitude = vec2u(0u, roundedHigh << 12u);
  var highBits = fp64_make_f32_bits_from_u64(
    decoded.sign,
    highMagnitude,
    decoded.baseExponent
  );
  // Rounding the high limb of a maximum-exponent value can overflow even
  // though the original value is finite. Truncate only in that boundary case
  // so split remains an exact finite decomposition.
  if (fp64_decode_f32_bits(highBits).isInf) {
    roundedHigh = decoded.significand >> 12u;
    highMagnitude = vec2u(0u, roundedHigh << 12u);
    highBits = fp64_make_f32_bits_from_u64(
      decoded.sign,
      highMagnitude,
      decoded.baseExponent
    );
  }
  let lowBits = fp64_make_residual_f32_bits(
    decoded.sign,
    vec2u(0u, decoded.significand),
    decoded.baseExponent,
    highBits
  );
  return vec2f(bitcast<f32>(highBits), bitcast<f32>(lowBits));
}

fn split2(a: vec2f) -> vec2f {
  var result = split(a.x);
  result.y = fp64_round_add_integer(result.y, a.y);
  return result;
}
#endif

#ifndef LUMA_FP64_PREDICATE_ONLY
fn quickTwoSum(a: f32, b: f32) -> vec2f {
  return fp64_two_sum_integer(a, b);
}
#endif

fn twoSum(a: f32, b: f32) -> vec2f {
  return fp64_two_sum_integer(a, b);
}

fn twoSub(a: f32, b: f32) -> vec2f {
  let bBits = bitcast<u32>(b) ^ 0x80000000u;
  let resultBits = fp64_two_sum_integer_bits(bitcast<u32>(a), bBits);
  return vec2f(bitcast<f32>(resultBits.x), bitcast<f32>(resultBits.y));
}

#ifndef LUMA_FP64_PREDICATE_ONLY
fn twoSqr(a: f32) -> vec2f {
  return fp64_two_prod_integer(a, a);
}

fn twoProd(a: f32, b: f32) -> vec2f {
  return fp64_two_prod_integer(a, b);
}
#endif

fn sum_fp64(a: vec2f, b: vec2f) -> vec2f {
  var sum = fp64_two_sum_integer(a.x, b.x);
  let lowSum = fp64_two_sum_integer(a.y, b.y);
  sum.y = fp64_round_add_integer(sum.y, lowSum.x);
  sum = fp64_two_sum_integer(sum.x, sum.y);
  sum.y = fp64_round_add_integer(sum.y, lowSum.y);
  return fp64_two_sum_integer(sum.x, sum.y);
}

fn sub_fp64(a: vec2f, b: vec2f) -> vec2f {
  let negatedB = vec2f(
    bitcast<f32>(bitcast<u32>(b.x) ^ 0x80000000u),
    bitcast<f32>(bitcast<u32>(b.y) ^ 0x80000000u)
  );
  return sum_fp64(a, negatedB);
}

fn mul_fp64(a: vec2f, b: vec2f) -> vec2f {
  var product = fp64_two_prod_integer(a.x, b.x);
  let crossProduct1 = fp64_round_mul_integer(a.x, b.y);
  product.y = fp64_round_add_integer(product.y, crossProduct1);
  product = fp64_two_sum_integer(product.x, product.y);
  let crossProduct2 = fp64_round_mul_integer(a.y, b.x);
  product.y = fp64_round_add_integer(product.y, crossProduct2);
  return fp64_two_sum_integer(product.x, product.y);
}

#ifndef LUMA_FP64_PREDICATE_ONLY
fn fp64_scale_fp64_integer(value: vec2f, exponent: i32) -> vec2f {
  let high = fp64_scale_f32_integer(value.x, exponent);
  let low = fp64_scale_f32_integer(value.y, exponent);
  return sum_fp64(vec2f(high, 0.0), vec2f(low, 0.0));
}

fn fp64_div_fp64_normalized(a: vec2f, b: vec2f) -> vec2f {
  let quotientHigh = fp64_divide_f32_integer(a.x, b.x);
  var quotient = vec2f(quotientHigh, 0.0);

  let remainder = sub_fp64(a, mul_fp64(b, quotient));
  let quotientLow = fp64_divide_f32_integer(remainder.x, b.x);
  quotient = sum_fp64(quotient, vec2f(quotientLow, 0.0));

  let secondRemainder = sub_fp64(a, mul_fp64(b, quotient));
  let correction = fp64_divide_f32_integer(secondRemainder.x, b.x);
  return sum_fp64(quotient, vec2f(correction, 0.0));
}

fn div_fp64(a: vec2f, b: vec2f) -> vec2f {
  let decodedA = fp64_decode_f32_bits(bitcast<u32>(a.x));
  let decodedB = fp64_decode_f32_bits(bitcast<u32>(b.x));
  if (
    decodedA.isZero || decodedB.isZero ||
    decodedA.isInf || decodedB.isInf ||
    decodedA.isNan || decodedB.isNan
  ) {
    return fp64_div_fp64_normalized(a, b);
  }

  let exponentA = fp64_f32_finite_exponent(decodedA);
  let exponentB = fp64_f32_finite_exponent(decodedB);
  // Correct the quotient near unity so b * q and the remainder stay clear of
  // both f32 underflow and overflow. The exponent difference is applied once.
  let normalizedA = fp64_scale_fp64_integer(a, -exponentA);
  let normalizedB = fp64_scale_fp64_integer(b, -exponentB);
  let normalizedQuotient = fp64_div_fp64_normalized(normalizedA, normalizedB);
  return fp64_scale_fp64_integer(normalizedQuotient, exponentA - exponentB);
}

fn fp64_sqrt_fp64_normalized(a: vec2f) -> vec2f {
  let estimate = sqrt(a.x);
  let difference = sub_fp64(a, fp64_two_prod_integer(estimate, estimate)).x;
  let denominator = fp64_round_add_integer(estimate, estimate);
  let correction = fp64_divide_f32_integer(difference, denominator);
  return sum_fp64(vec2f(estimate, 0.0), vec2f(correction, 0.0));
}

fn sqrt_fp64(a: vec2f) -> vec2f {
  let decoded = fp64_decode_f32_bits(bitcast<u32>(a.x));
  let decodedLow = fp64_decode_f32_bits(bitcast<u32>(a.y));
  if (decoded.isZero && decodedLow.isZero) {
    return vec2f(0.0, 0.0);
  }
  if (decoded.sign == 1u) {
    let nanValue = fp64_nan(a.x);
    return vec2f(nanValue, nanValue);
  }

  if (decoded.isInf || decoded.isNan) {
    return fp64_sqrt_fp64_normalized(a);
  }
  let exponent = fp64_f32_finite_exponent(decoded);
  // An even scale lets the final square-root rescale use an integer exponent.
  let evenExponent = exponent - (exponent & 1);
  let normalizedA = fp64_scale_fp64_integer(a, -evenExponent);
  let normalizedRoot = fp64_sqrt_fp64_normalized(normalizedA);
  return fp64_scale_fp64_integer(normalizedRoot, evenExponent / 2);
}
#endif
`,yP=`struct Fp64ArithmeticUniforms {
  ONE: f32,
  SPLIT: f32,
};

@group(0) @binding(auto) var<uniform> fp64arithmetic : Fp64ArithmeticUniforms;

#ifndef LUMA_FP64_F32_INPUT_ONLY
struct Fp64Bits {
  sign: u32,
  exponent: i32,
  significand: vec2u,
  isZero: bool,
  isInf: bool,
  isNan: bool,
};
#endif

#ifndef LUMA_FP64_PREDICATE_ONLY
fn fp64_nan(seed: f32) -> f32 {
  let nanBits = 0x7fc00000u | select(0u, 1u, seed < 0.0);
  return bitcast<f32>(nanBits);
}
#endif

fn fp64_u64_is_zero(value: vec2u) -> bool {
  return value.x == 0u && value.y == 0u;
}

fn fp64_u64_compare(a: vec2u, b: vec2u) -> i32 {
  if (a.x != b.x) {
    return select(-1, 1, a.x > b.x);
  }
  if (a.y != b.y) {
    return select(-1, 1, a.y > b.y);
  }
  return 0;
}

fn fp64_u64_add(a: vec2u, b: vec2u) -> vec2u {
  let low = a.y + b.y;
  let carry = select(0u, 1u, low < a.y);
  return vec2u(a.x + b.x + carry, low);
}

fn fp64_u64_sub(a: vec2u, b: vec2u) -> vec2u {
  let borrow = select(0u, 1u, a.y < b.y);
  return vec2u(a.x - b.x - borrow, a.y - b.y);
}

fn fp64_u64_shift_left(value: vec2u, shift: u32) -> vec2u {
  if (shift == 0u) {
    return value;
  }
  if (shift < 32u) {
    return vec2u((value.x << shift) | (value.y >> (32u - shift)), value.y << shift);
  }
  if (shift == 32u) {
    return vec2u(value.y, 0u);
  }
  if (shift < 64u) {
    return vec2u(value.y << (shift - 32u), 0u);
  }
  return vec2u(0u);
}

fn fp64_u64_shift_right(value: vec2u, shift: u32) -> vec2u {
  if (shift == 0u) {
    return value;
  }
  if (shift < 32u) {
    return vec2u(value.x >> shift, (value.y >> shift) | (value.x << (32u - shift)));
  }
  if (shift == 32u) {
    return vec2u(0u, value.x);
  }
  if (shift < 64u) {
    return vec2u(0u, value.x >> (shift - 32u));
  }
  return vec2u(0u);
}

fn fp64_u64_get_bit(value: vec2u, bitIndex: u32) -> bool {
  if (bitIndex >= 64u) {
    return false;
  }
  if (bitIndex >= 32u) {
    return ((value.x >> (bitIndex - 32u)) & 1u) != 0u;
  }
  return ((value.y >> bitIndex) & 1u) != 0u;
}

fn fp64_u64_has_bits_below(value: vec2u, bitCount: u32) -> bool {
  if (bitCount == 0u) {
    return false;
  }
  if (bitCount >= 64u) {
    return !fp64_u64_is_zero(value);
  }
  if (bitCount > 32u) {
    let highBitCount = bitCount - 32u;
    let highMask = (1u << highBitCount) - 1u;
    return value.y != 0u || (value.x & highMask) != 0u;
  }
  if (bitCount == 32u) {
    return value.y != 0u;
  }
  let lowMask = (1u << bitCount) - 1u;
  return (value.y & lowMask) != 0u;
}

#ifndef LUMA_FP64_F32_INPUT_ONLY
fn fp64_u64_shift_right_sticky(value: vec2u, shift: u32) -> vec2u {
  var shifted = fp64_u64_shift_right(value, shift);
  if (fp64_u64_has_bits_below(value, shift)) {
    shifted.y = shifted.y | 1u;
  }
  return shifted;
}
#endif

fn fp64_u64_count_leading_zeros(value: vec2u) -> u32 {
  if (value.x != 0u) {
    return countLeadingZeros(value.x);
  }
  return 32u + countLeadingZeros(value.y);
}

fn fp64_round_shift_right_to_u32(value: vec2u, shift: u32) -> u32 {
  if (shift == 0u) {
    return value.y;
  }

  let truncated = fp64_u64_shift_right(value, shift);
  var rounded = truncated.y;
  let guard = fp64_u64_get_bit(value, shift - 1u);
  let hasTrailingBits = fp64_u64_has_bits_below(value, shift - 1u);
  if (guard && (hasTrailingBits || (rounded & 1u) == 1u)) {
    rounded = rounded + 1u;
  }
  return rounded;
}

#ifndef LUMA_FP64_F32_INPUT_ONLY
fn fp64_round_shift_right(value: vec2u, shift: u32) -> vec2u {
  if (shift == 0u) {
    return value;
  }

  var rounded = fp64_u64_shift_right(value, shift);
  let guard = fp64_u64_get_bit(value, shift - 1u);
  let hasTrailingBits = fp64_u64_has_bits_below(value, shift - 1u);
  if (guard && (hasTrailingBits || (rounded.y & 1u) == 1u)) {
    rounded = fp64_u64_add(rounded, vec2u(0u, 1u));
  }
  return rounded;
}
#endif

fn fp64_make_f32_bits_from_u64(sign: u32, significand: vec2u, baseExponent: i32) -> u32 {
  if (fp64_u64_is_zero(significand)) {
    return sign << 31u;
  }

  let leadingZeros = fp64_u64_count_leading_zeros(significand);
  let mostSignificantBit = 63u - leadingZeros;
  var exponent = baseExponent + i32(mostSignificantBit);

  if (exponent > 127) {
    return (sign << 31u) | 0x7f800000u;
  }

  if (exponent >= -126) {
    let shift = i32(mostSignificantBit) - 23;
    var significand24: u32;
    if (shift > 0) {
      significand24 = fp64_round_shift_right_to_u32(significand, u32(shift));
    } else {
      significand24 = fp64_u64_shift_left(significand, u32(-shift)).y;
    }

    if (significand24 >= 0x1000000u) {
      significand24 = significand24 >> 1u;
      exponent = exponent + 1;
      if (exponent > 127) {
        return (sign << 31u) | 0x7f800000u;
      }
    }

    return (sign << 31u) | (u32(exponent + 127) << 23u) | (significand24 & 0x7fffffu);
  }

  let scaleExponent = baseExponent + 149;
  var mantissa: u32;
  if (scaleExponent >= 0) {
    mantissa = fp64_u64_shift_left(significand, u32(scaleExponent)).y;
  } else {
    mantissa = fp64_round_shift_right_to_u32(significand, u32(-scaleExponent));
  }

  if (mantissa >= 0x800000u) {
    return (sign << 31u) | 0x00800000u;
  }
  return (sign << 31u) | mantissa;
}

#ifndef LUMA_FP64_F32_INPUT_ONLY
fn fp64_decode_bits(bits: vec2u) -> Fp64Bits {
  let sign = bits.x >> 31u;
  let exponentBits = (bits.x >> 20u) & 0x7ffu;
  let fractionHigh = bits.x & 0xfffffu;
  let fractionLow = bits.y;
  let fraction = vec2u(fractionHigh, fractionLow);

  if (exponentBits == 0x7ffu) {
    let isInf = fp64_u64_is_zero(fraction);
    return Fp64Bits(sign, 0, vec2u(0u), false, isInf, !isInf);
  }

  if (exponentBits == 0u) {
    let isZero = fp64_u64_is_zero(fraction);
    return Fp64Bits(sign, -1022, fraction, isZero, false, false);
  }

  return Fp64Bits(sign, i32(exponentBits) - 1023, vec2u((1u << 20u) | fractionHigh, fractionLow), false, false, false);
}

fn fp64_finite_magnitude_compare(a: Fp64Bits, b: Fp64Bits) -> i32 {
  if (a.exponent != b.exponent) {
    return select(-1, 1, a.exponent > b.exponent);
  }
  return fp64_u64_compare(a.significand, b.significand);
}
#endif

#ifndef LUMA_FP64_F32_INPUT_ONLY
struct Fp64RawF32Bits {
  sign: u32,
  baseExponent: i32,
  significand: u32,
  isZero: bool,
  isInf: bool,
  isNan: bool,
};

// Decode an f32 as (-1)^sign * significand * 2^baseExponent. This shared
// integer representation lets normalization remain independent of the
// selected double-single arithmetic implementation.
fn fp64_decode_raw_f32_bits(bits: u32) -> Fp64RawF32Bits {
  let sign = bits >> 31u;
  let exponentBits = (bits >> 23u) & 0xffu;
  let fraction = bits & 0x7fffffu;

  if (exponentBits == 0xffu) {
    return Fp64RawF32Bits(sign, 0, 0u, false, fraction == 0u, fraction != 0u);
  }
  if (exponentBits == 0u) {
    return Fp64RawF32Bits(sign, -149, fraction, fraction == 0u, false, false);
  }
  return Fp64RawF32Bits(
    sign,
    i32(exponentBits) - 150,
    0x800000u | fraction,
    false,
    false,
    false
  );
}

fn fp64_raw_f32_magnitude_compare(aBits: u32, bBits: u32) -> i32 {
  let aMagnitude = aBits & 0x7fffffffu;
  let bMagnitude = bBits & 0x7fffffffu;
  if (aMagnitude == bMagnitude) {
    return 0;
  }
  return select(-1, 1, aMagnitude > bMagnitude);
}

fn fp64_make_raw_residual_f32_bits(
  exactSign: u32,
  exactMagnitude: vec2u,
  exactBaseExponent: i32,
  highBits: u32
) -> u32 {
  if (fp64_u64_is_zero(exactMagnitude)) {
    return 0u;
  }

  let high = fp64_decode_raw_f32_bits(highBits);
  if (high.isInf || high.isNan) {
    return 0u;
  }
  if (high.isZero) {
    return fp64_make_f32_bits_from_u64(exactSign, exactMagnitude, exactBaseExponent);
  }

  let commonBaseExponent = min(exactBaseExponent, high.baseExponent);
  let exactShift = exactBaseExponent - commonBaseExponent;
  let highShift = high.baseExponent - commonBaseExponent;
  if (exactShift >= 64 || highShift >= 64) {
    return 0u;
  }

  let exactAligned = fp64_u64_shift_left(exactMagnitude, u32(exactShift));
  let highAligned = fp64_u64_shift_left(vec2u(0u, high.significand), u32(highShift));
  let comparison = fp64_u64_compare(exactAligned, highAligned);
  if (comparison == 0) {
    return 0u;
  }

  var residualSign = exactSign;
  var residualMagnitude: vec2u;
  if (comparison > 0) {
    residualMagnitude = fp64_u64_sub(exactAligned, highAligned);
  } else {
    residualSign = exactSign ^ 1u;
    residualMagnitude = fp64_u64_sub(highAligned, exactAligned);
  }
  return fp64_make_f32_bits_from_u64(
    residualSign,
    residualMagnitude,
    commonBaseExponent
  );
}

fn fp64_split_raw_accumulator_bits(
  sign: u32,
  magnitude: vec2u,
  baseExponent: i32
) -> vec2u {
  if (fp64_u64_is_zero(magnitude)) {
    return vec2u(0u);
  }
  let highBits = fp64_make_f32_bits_from_u64(sign, magnitude, baseExponent);
  let rawLowBits = fp64_make_raw_residual_f32_bits(sign, magnitude, baseExponent, highBits);
  let lowBits = select(rawLowBits, 0u, (rawLowBits & 0x7fffffffu) == 0u);
  if ((highBits & 0x7fffffffu) == 0u && (lowBits & 0x7fffffffu) == 0u) {
    return vec2u(0u);
  }
  return vec2u(highBits, lowBits);
}
#endif

#ifndef LUMA_FP64_F32_INPUT_ONLY
// Round an arithmetic accumulator to binary64 before splitting it. The
// aligned add/subtract paths retain three guard bits plus a sticky bit, which
// is sufficient for round-to-nearest-even at the binary64 boundary.
fn fp64_split_binary64_accumulator_bits(
  sign: u32,
  magnitude: vec2u,
  baseExponent: i32
) -> vec2u {
  if (fp64_u64_is_zero(magnitude)) {
    return vec2u(0u);
  }

  let mostSignificantBit = 63u - fp64_u64_count_leading_zeros(magnitude);
  let exponent = baseExponent + i32(mostSignificantBit);
  if (exponent > 1023) {
    return vec2u((sign << 31u) | 0x7f800000u, 0u);
  }

  var roundedMagnitude = magnitude;
  var roundedBaseExponent = baseExponent;
  if (exponent >= -1022) {
    if (mostSignificantBit > 52u) {
      let shift = mostSignificantBit - 52u;
      roundedMagnitude = fp64_round_shift_right(magnitude, shift);
      roundedBaseExponent = baseExponent + i32(shift);
    }
  } else {
    let shift = -1074 - baseExponent;
    if (shift > 0) {
      roundedMagnitude = fp64_round_shift_right(magnitude, u32(shift));
      roundedBaseExponent = -1074;
    }
  }

  if (fp64_u64_is_zero(roundedMagnitude)) {
    return vec2u(0u);
  }
  return fp64_split_raw_accumulator_bits(sign, roundedMagnitude, roundedBaseExponent);
}
#endif

#ifndef LUMA_FP64_PREDICATE_ONLY
fn fp64_add_raw_f32_bits(aBits: u32, bBits: u32) -> vec2u {
  let a = fp64_decode_raw_f32_bits(aBits);
  let b = fp64_decode_raw_f32_bits(bBits);

  if (a.isNan || b.isNan) {
    return vec2u(0x7fc00000u, 0u);
  }
  if (a.isInf || b.isInf) {
    if (a.isInf && b.isInf && a.sign != b.sign) {
      return vec2u(0x7fc00000u, 0u);
    }
    return select(vec2u(bBits, 0u), vec2u(aBits, 0u), a.isInf);
  }
  if (a.isZero && b.isZero) {
    return vec2u(0u);
  }
  if (a.isZero) {
    return vec2u(bBits, 0u);
  }
  if (b.isZero) {
    return vec2u(aBits, 0u);
  }

  let exponentDifference = abs(a.baseExponent - b.baseExponent);
  if (exponentDifference > 25) {
    if (fp64_raw_f32_magnitude_compare(aBits, bBits) >= 0) {
      return vec2u(aBits, bBits);
    }
    return vec2u(bBits, aBits);
  }

  let commonBaseExponent = min(a.baseExponent, b.baseExponent);
  let aMagnitude = fp64_u64_shift_left(
    vec2u(0u, a.significand),
    u32(a.baseExponent - commonBaseExponent)
  );
  let bMagnitude = fp64_u64_shift_left(
    vec2u(0u, b.significand),
    u32(b.baseExponent - commonBaseExponent)
  );

  var resultSign = a.sign;
  var resultMagnitude: vec2u;
  if (a.sign == b.sign) {
    resultMagnitude = fp64_u64_add(aMagnitude, bMagnitude);
  } else {
    let comparison = fp64_u64_compare(aMagnitude, bMagnitude);
    if (comparison == 0) {
      return vec2u(0u);
    }
    if (comparison > 0) {
      resultMagnitude = fp64_u64_sub(aMagnitude, bMagnitude);
    } else {
      resultSign = b.sign;
      resultMagnitude = fp64_u64_sub(bMagnitude, aMagnitude);
    }
  }

  return fp64_split_raw_accumulator_bits(
    resultSign,
    resultMagnitude,
    commonBaseExponent
  );
}
#endif

#ifndef LUMA_FP64_F32_INPUT_ONLY
fn fp64_add_aligned_magnitudes_to_fp64_bits(
  sign: u32,
  larger: Fp64Bits,
  smaller: Fp64Bits
) -> vec2u {
  let largeSignificand = fp64_u64_shift_left(larger.significand, 3u);
  let smallSignificand = fp64_u64_shift_right_sticky(
    fp64_u64_shift_left(smaller.significand, 3u),
    u32(larger.exponent - smaller.exponent)
  );
  let resultSignificand = fp64_u64_add(largeSignificand, smallSignificand);
  return fp64_split_binary64_accumulator_bits(
    sign,
    resultSignificand,
    larger.exponent - 55
  );
}

fn fp64_sub_aligned_magnitudes_to_fp64_bits(
  sign: u32,
  larger: Fp64Bits,
  smaller: Fp64Bits
) -> vec2u {
  let largeSignificand = fp64_u64_shift_left(larger.significand, 3u);
  let smallSignificand = fp64_u64_shift_right_sticky(
    fp64_u64_shift_left(smaller.significand, 3u),
    u32(larger.exponent - smaller.exponent)
  );
  let resultSignificand = fp64_u64_sub(largeSignificand, smallSignificand);
  return fp64_split_binary64_accumulator_bits(
    sign,
    resultSignificand,
    larger.exponent - 55
  );
}

fn fp64_add_aligned_magnitudes_to_f32_bits(sign: u32, larger: Fp64Bits, smaller: Fp64Bits) -> u32 {
  let largeSignificand = fp64_u64_shift_left(larger.significand, 3u);
  let smallSignificand = fp64_u64_shift_right_sticky(
    fp64_u64_shift_left(smaller.significand, 3u),
    u32(larger.exponent - smaller.exponent)
  );
  let resultSignificand = fp64_u64_add(largeSignificand, smallSignificand);
  return fp64_make_f32_bits_from_u64(sign, resultSignificand, larger.exponent - 55);
}

fn fp64_sub_aligned_magnitudes_to_f32_bits(sign: u32, larger: Fp64Bits, smaller: Fp64Bits) -> u32 {
  let largeSignificand = fp64_u64_shift_left(larger.significand, 3u);
  let smallSignificand = fp64_u64_shift_right_sticky(
    fp64_u64_shift_left(smaller.significand, 3u),
    u32(larger.exponent - smaller.exponent)
  );
  let resultSignificand = fp64_u64_sub(largeSignificand, smallSignificand);
  return fp64_make_f32_bits_from_u64(sign, resultSignificand, larger.exponent - 55);
}

// Subtract two raw binary64 values and round the exact result once to f32.
// The input words are canonical high/low words: .x contains sign/exponent/high
// fraction bits, and .y contains the low 32 fraction bits.
fn sub_fp64u32_to_f32_bits(aBits: vec2u, bBits: vec2u) -> u32 {
  let a = fp64_decode_bits(aBits);
  let b = fp64_decode_bits(bBits);
  let bSubtractionSign = b.sign ^ 1u;

  if (a.isNan || b.isNan) {
    return 0x7fc00000u;
  }
  if (a.isInf && b.isInf) {
    if (a.sign == bSubtractionSign) {
      return (a.sign << 31u) | 0x7f800000u;
    }
    return 0x7fc00000u;
  }
  if (a.isInf) {
    return (a.sign << 31u) | 0x7f800000u;
  }
  if (b.isInf) {
    return (bSubtractionSign << 31u) | 0x7f800000u;
  }
  if (a.isZero && b.isZero) {
    return select(0u, 0x80000000u, a.sign == 1u && b.sign == 0u);
  }

  let magnitudeComparison = fp64_finite_magnitude_compare(a, b);
  if (a.sign == bSubtractionSign) {
    if (magnitudeComparison >= 0) {
      return fp64_add_aligned_magnitudes_to_f32_bits(a.sign, a, b);
    }
    return fp64_add_aligned_magnitudes_to_f32_bits(a.sign, b, a);
  }

  if (magnitudeComparison == 0) {
    return 0u;
  }
  if (magnitudeComparison > 0) {
    return fp64_sub_aligned_magnitudes_to_f32_bits(a.sign, a, b);
  }
  return fp64_sub_aligned_magnitudes_to_f32_bits(bSubtractionSign, b, a);
}

fn sub_fp64u32_to_f32(aBits: vec2u, bBits: vec2u) -> f32 {
  return bitcast<f32>(sub_fp64u32_to_f32_bits(aBits, bBits));
}

// Subtract two raw binary64 values, round once to binary64, then split the
// result into normalized f32 limbs. Finite results must fit within the f32
// exponent range; larger magnitudes map to infinity and smaller magnitudes
// map to zero. The input words use canonical high/low word order.
fn sub_fp64u32_to_fp64_bits(aBits: vec2u, bBits: vec2u) -> vec2u {
  let a = fp64_decode_bits(aBits);
  let b = fp64_decode_bits(bBits);
  let bSubtractionSign = b.sign ^ 1u;

  if (a.isNan || b.isNan) {
    return vec2u(0x7fc00000u, 0u);
  }
  if (a.isInf && b.isInf) {
    if (a.sign == bSubtractionSign) {
      return vec2u((a.sign << 31u) | 0x7f800000u, 0u);
    }
    return vec2u(0x7fc00000u, 0u);
  }
  if (a.isInf) {
    return vec2u((a.sign << 31u) | 0x7f800000u, 0u);
  }
  if (b.isInf) {
    return vec2u((bSubtractionSign << 31u) | 0x7f800000u, 0u);
  }
  if (a.isZero && b.isZero) {
    return vec2u(0u);
  }

  let magnitudeComparison = fp64_finite_magnitude_compare(a, b);
  if (a.sign == bSubtractionSign) {
    if (magnitudeComparison >= 0) {
      return fp64_add_aligned_magnitudes_to_fp64_bits(a.sign, a, b);
    }
    return fp64_add_aligned_magnitudes_to_fp64_bits(a.sign, b, a);
  }

  if (magnitudeComparison == 0) {
    return vec2u(0u);
  }
  if (magnitudeComparison > 0) {
    return fp64_sub_aligned_magnitudes_to_fp64_bits(a.sign, a, b);
  }
  return fp64_sub_aligned_magnitudes_to_fp64_bits(bSubtractionSign, b, a);
}

fn sub_fp64u32_to_fp64(aBits: vec2u, bBits: vec2u) -> vec2f {
  let resultBits = sub_fp64u32_to_fp64_bits(aBits, bBits);
  return vec2f(bitcast<f32>(resultBits.x), bitcast<f32>(resultBits.y));
}
#endif

#ifndef LUMA_FP64_PREDICATE_ONLY
fn fp64_runtime_zero() -> f32 {
  return fp64arithmetic.ONE * 0.0;
}

fn prevent_fp64_optimization(value: f32) -> f32 {
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  return value + fp64_runtime_zero();
#else
  return value;
#endif
}
#endif

#ifdef LUMA_FP64_INTEGER_ARITHMETIC
${_P}
#else
fn split(a: f32) -> vec2f {
  let splitValue = prevent_fp64_optimization(fp64arithmetic.SPLIT + fp64_runtime_zero());
  let t = prevent_fp64_optimization(a * splitValue);
  let temp = prevent_fp64_optimization(t - a);
  let aHi = prevent_fp64_optimization(t - temp);
  let aLo = prevent_fp64_optimization(a - aHi);
  return vec2f(aHi, aLo);
}

fn split2(a: vec2f) -> vec2f {
  var b = split(a.x);
  b.y = b.y + a.y;
  return b;
}

fn quickTwoSum(a: f32, b: f32) -> vec2f {
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  let sum = prevent_fp64_optimization((a + b) * fp64arithmetic.ONE);
  let err = prevent_fp64_optimization(b - (sum - a) * fp64arithmetic.ONE);
#else
  let sum = prevent_fp64_optimization(a + b);
  let err = prevent_fp64_optimization(b - (sum - a));
#endif
  return vec2f(sum, err);
}

fn twoSum(a: f32, b: f32) -> vec2f {
  let s = prevent_fp64_optimization(a + b);
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  let v = prevent_fp64_optimization((s * fp64arithmetic.ONE - a) * fp64arithmetic.ONE);
  let err =
    prevent_fp64_optimization((a - (s - v) * fp64arithmetic.ONE) *
      fp64arithmetic.ONE *
      fp64arithmetic.ONE *
      fp64arithmetic.ONE) +
    prevent_fp64_optimization(b - v);
#else
  let v = prevent_fp64_optimization(s - a);
  let err = prevent_fp64_optimization(a - (s - v)) + prevent_fp64_optimization(b - v);
#endif
  return vec2f(s, err);
}

fn twoSub(a: f32, b: f32) -> vec2f {
  let s = prevent_fp64_optimization(a - b);
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  let v = prevent_fp64_optimization((s * fp64arithmetic.ONE - a) * fp64arithmetic.ONE);
  let err =
    prevent_fp64_optimization((a - (s - v) * fp64arithmetic.ONE) *
      fp64arithmetic.ONE *
      fp64arithmetic.ONE *
      fp64arithmetic.ONE) -
    prevent_fp64_optimization(b + v);
#else
  let v = prevent_fp64_optimization(s - a);
  let err = prevent_fp64_optimization(a - (s - v)) - prevent_fp64_optimization(b + v);
#endif
  return vec2f(s, err);
}

fn twoSqr(a: f32) -> vec2f {
  let prod = prevent_fp64_optimization(a * a);
  let aFp64 = split(a);
  let highProduct = prevent_fp64_optimization(aFp64.x * aFp64.x);
  let crossProduct = prevent_fp64_optimization(2.0 * aFp64.x * aFp64.y);
  let lowProduct = prevent_fp64_optimization(aFp64.y * aFp64.y);
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  let err =
    (prevent_fp64_optimization(highProduct - prod) * fp64arithmetic.ONE +
      crossProduct * fp64arithmetic.ONE * fp64arithmetic.ONE) +
    lowProduct * fp64arithmetic.ONE * fp64arithmetic.ONE * fp64arithmetic.ONE;
#else
  let err = ((prevent_fp64_optimization(highProduct - prod) + crossProduct) + lowProduct);
#endif
  return vec2f(prod, err);
}

fn twoProd(a: f32, b: f32) -> vec2f {
  let prod = prevent_fp64_optimization(a * b);
  let aFp64 = split(a);
  let bFp64 = split(b);
  let highProduct = prevent_fp64_optimization(aFp64.x * bFp64.x);
  let crossProduct1 = prevent_fp64_optimization(aFp64.x * bFp64.y);
  let crossProduct2 = prevent_fp64_optimization(aFp64.y * bFp64.x);
  let lowProduct = prevent_fp64_optimization(aFp64.y * bFp64.y);
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  let err1 = (highProduct - prod) * fp64arithmetic.ONE;
  let err2 = crossProduct1 * fp64arithmetic.ONE * fp64arithmetic.ONE;
  let err3 = crossProduct2 * fp64arithmetic.ONE * fp64arithmetic.ONE * fp64arithmetic.ONE;
  let err4 =
    lowProduct *
    fp64arithmetic.ONE *
    fp64arithmetic.ONE *
    fp64arithmetic.ONE *
    fp64arithmetic.ONE;
#else
  let err1 = highProduct - prod;
  let err2 = crossProduct1;
  let err3 = crossProduct2;
  let err4 = lowProduct;
#endif
  let err12InputA = prevent_fp64_optimization(err1);
  let err12InputB = prevent_fp64_optimization(err2);
  let err12 = prevent_fp64_optimization(err12InputA + err12InputB);
  let err123InputA = prevent_fp64_optimization(err12);
  let err123InputB = prevent_fp64_optimization(err3);
  let err123 = prevent_fp64_optimization(err123InputA + err123InputB);
  let err1234InputA = prevent_fp64_optimization(err123);
  let err1234InputB = prevent_fp64_optimization(err4);
  let err = prevent_fp64_optimization(err1234InputA + err1234InputB);
  return vec2f(prod, err);
}

fn sum_fp64(a: vec2f, b: vec2f) -> vec2f {
  var s = twoSum(a.x, b.x);
  let t = twoSum(a.y, b.y);
  s.y = prevent_fp64_optimization(s.y + t.x);
  s = quickTwoSum(s.x, s.y);
  s.y = prevent_fp64_optimization(s.y + t.y);
  s = quickTwoSum(s.x, s.y);
  return s;
}

fn sub_fp64(a: vec2f, b: vec2f) -> vec2f {
  var s = twoSub(a.x, b.x);
  let t = twoSub(a.y, b.y);
  s.y = prevent_fp64_optimization(s.y + t.x);
  s = quickTwoSum(s.x, s.y);
  s.y = prevent_fp64_optimization(s.y + t.y);
  s = quickTwoSum(s.x, s.y);
  return s;
}

fn mul_fp64(a: vec2f, b: vec2f) -> vec2f {
  var prod = twoProd(a.x, b.x);
  let crossProduct1 = prevent_fp64_optimization(a.x * b.y);
  prod.y = prevent_fp64_optimization(prod.y + crossProduct1);
#ifdef LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND
  prod = split2(prod);
#endif
  prod = quickTwoSum(prod.x, prod.y);
  let crossProduct2 = prevent_fp64_optimization(a.y * b.x);
  prod.y = prevent_fp64_optimization(prod.y + crossProduct2);
#ifdef LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND
  prod = split2(prod);
#endif
  prod = quickTwoSum(prod.x, prod.y);
  return prod;
}

#ifndef LUMA_FP64_PREDICATE_ONLY
fn div_fp64(a: vec2f, b: vec2f) -> vec2f {
  let xn = prevent_fp64_optimization(1.0 / b.x);
  let yn = mul_fp64(a, vec2f(xn, fp64_runtime_zero()));
  let diff = prevent_fp64_optimization(sub_fp64(a, mul_fp64(b, yn)).x);
  let prod = twoProd(xn, diff);
  return sum_fp64(yn, prod);
}

fn sqrt_fp64(a: vec2f) -> vec2f {
  if (a.x == 0.0 && a.y == 0.0) {
    return vec2f(0.0, 0.0);
  }
  if (a.x < 0.0) {
    let nanValue = fp64_nan(a.x);
    return vec2f(nanValue, nanValue);
  }

  let x = prevent_fp64_optimization(1.0 / sqrt(a.x));
  let yn = prevent_fp64_optimization(a.x * x);
#ifdef LUMA_FP64_CODE_ELIMINATION_WORKAROUND
  let ynSqr = twoSqr(yn) * fp64arithmetic.ONE;
#else
  let ynSqr = twoSqr(yn);
#endif
  let diff = prevent_fp64_optimization(sub_fp64(a, ynSqr).x);
  let prod = twoProd(prevent_fp64_optimization(x * 0.5), diff);
#ifdef LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND
  return sum_fp64(split(yn), prod);
#else
  return sum_fp64(vec2f(yn, 0.0), prod);
#endif
}
#endif
#endif

#ifndef LUMA_FP64_PREDICATE_ONLY
fn fp64_f32_bits_is_nan(bits: u32) -> bool {
  return (bits & 0x7fffffffu) > 0x7f800000u;
}

fn fp64_f32_bits_is_inf(bits: u32) -> bool {
  return (bits & 0x7fffffffu) == 0x7f800000u;
}

fn fp64_compare_f32_bits(aBits: u32, bBits: u32) -> i32 {
  let aMagnitude = aBits & 0x7fffffffu;
  let bMagnitude = bBits & 0x7fffffffu;
  if (aMagnitude == 0u && bMagnitude == 0u) {
    return 0;
  }
  let aSign = aBits >> 31u;
  let bSign = bBits >> 31u;
  if (aSign != bSign) {
    return select(1, -1, aSign == 1u);
  }
  if (aMagnitude == bMagnitude) {
    return 0;
  }
  let magnitudeComparison = select(-1, 1, aMagnitude > bMagnitude);
  return select(magnitudeComparison, -magnitudeComparison, aSign == 1u);
}

// Normalize an arbitrary pair of finite f32 limbs with integer accumulation.
// This is independent of LUMA_FP64_INTEGER_ARITHMETIC and canonicalizes every
// representation of zero to vec2f(+0.0, +0.0).
fn normalize_fp64(value: vec2f) -> vec2f {
  let resultBits = fp64_add_raw_f32_bits(bitcast<u32>(value.x), bitcast<u32>(value.y));
  return vec2f(bitcast<f32>(resultBits.x), bitcast<f32>(resultBits.y));
}

fn is_nan_fp64(value: vec2f) -> bool {
  let normalized = normalize_fp64(value);
  return fp64_f32_bits_is_nan(bitcast<u32>(normalized.x)) ||
    fp64_f32_bits_is_nan(bitcast<u32>(normalized.y));
}

fn is_finite_fp64(value: vec2f) -> bool {
  let normalized = normalize_fp64(value);
  let highBits = bitcast<u32>(normalized.x);
  let lowBits = bitcast<u32>(normalized.y);
  return !fp64_f32_bits_is_nan(highBits) && !fp64_f32_bits_is_nan(lowBits) &&
    !fp64_f32_bits_is_inf(highBits) && !fp64_f32_bits_is_inf(lowBits);
}

// Returns -1, 0, or 1. NaN is unordered and returns 0; call is_nan_fp64 or
// is_finite_fp64 first when 0 must mean a finite zero.
fn sign_fp64(value: vec2f) -> i32 {
  let normalized = normalize_fp64(value);
  let highBits = bitcast<u32>(normalized.x);
  let lowBits = bitcast<u32>(normalized.y);
  if (fp64_f32_bits_is_nan(highBits) || fp64_f32_bits_is_nan(lowBits)) {
    return 0;
  }
  if ((highBits & 0x7fffffffu) != 0u) {
    return select(1, -1, (highBits >> 31u) == 1u);
  }
  if ((lowBits & 0x7fffffffu) != 0u) {
    return select(1, -1, (lowBits >> 31u) == 1u);
  }
  return 0;
}

// Compares double-single values and returns -1, 0, or 1. NaN is unordered
// and returns 0; callers that require equality semantics must first check
// is_nan_fp64 or is_finite_fp64.
fn compare_fp64(a: vec2f, b: vec2f) -> i32 {
  let normalizedA = normalize_fp64(a);
  let normalizedB = normalize_fp64(b);
  let aHighBits = bitcast<u32>(normalizedA.x);
  let aLowBits = bitcast<u32>(normalizedA.y);
  let bHighBits = bitcast<u32>(normalizedB.x);
  let bLowBits = bitcast<u32>(normalizedB.y);
  if (fp64_f32_bits_is_nan(aHighBits) || fp64_f32_bits_is_nan(aLowBits) ||
      fp64_f32_bits_is_nan(bHighBits) || fp64_f32_bits_is_nan(bLowBits)) {
    return 0;
  }
  let highComparison = fp64_compare_f32_bits(aHighBits, bHighBits);
  if (highComparison != 0) {
    return highComparison;
  }
  return fp64_compare_f32_bits(aLowBits, bLowBits);
}
#endif
`,bP={ONE:1,SPLIT:4097},vP={name:"fp64arithmetic",source:yP,fs:Cu,vs:Cu,defaultUniforms:bP,uniformTypes:{ONE:"f32",SPLIT:"f32"},fp64ify:hg,fp64LowPart:fP,fp64ifyMatrix4:dP},wP={useByteColors:"f32"},xP={useByteColors:!0},Lu=SP("floatColors"),PP=EP("floatColors");function SP(i){return`layout(std140) uniform ${i}Uniforms {
  float useByteColors;
} ${i};

vec3 ${i}_normalize(vec3 inputColor) {
  return ${i}.useByteColors > 0.5 ? inputColor / 255.0 : inputColor;
}

vec4 ${i}_normalize(vec4 inputColor) {
  return ${i}.useByteColors > 0.5 ? inputColor / 255.0 : inputColor;
}

vec4 ${i}_premultiplyAlpha(vec4 inputColor) {
  return vec4(inputColor.rgb * inputColor.a, inputColor.a);
}

vec4 ${i}_unpremultiplyAlpha(vec4 inputColor) {
  return inputColor.a > 0.0 ? vec4(inputColor.rgb / inputColor.a, inputColor.a) : vec4(0.0);
}

vec4 ${i}_premultiply_alpha(vec4 inputColor) {
  return ${i}_premultiplyAlpha(inputColor);
}

vec4 ${i}_unpremultiply_alpha(vec4 inputColor) {
  return ${i}_unpremultiplyAlpha(inputColor);
}
`}function EP(i){return`struct ${i}Uniforms {
  useByteColors: f32
};

@group(0) @binding(auto) var<uniform> ${i} : ${i}Uniforms;

fn ${i}_normalize(inputColor: vec3<f32>) -> vec3<f32> {
  return select(inputColor, inputColor / 255.0, ${i}.useByteColors > 0.5);
}

fn ${i}_normalize4(inputColor: vec4<f32>) -> vec4<f32> {
  return select(inputColor, inputColor / 255.0, ${i}.useByteColors > 0.5);
}

fn ${i}_premultiplyAlpha(inputColor: vec4<f32>) -> vec4<f32> {
  return vec4<f32>(inputColor.rgb * inputColor.a, inputColor.a);
}

fn ${i}_unpremultiplyAlpha(inputColor: vec4<f32>) -> vec4<f32> {
  return select(
    vec4<f32>(0.0),
    vec4<f32>(inputColor.rgb / inputColor.a, inputColor.a),
    inputColor.a > 0.0
  );
}

fn ${i}_premultiply_alpha(inputColor: vec4<f32>) -> vec4<f32> {
  return ${i}_premultiplyAlpha(inputColor);
}

fn ${i}_unpremultiply_alpha(inputColor: vec4<f32>) -> vec4<f32> {
  return ${i}_unpremultiplyAlpha(inputColor);
}
`}const CP={name:"floatColors",props:{},uniforms:{},vs:Lu,fs:Lu,source:PP,uniformTypes:wP,defaultUniforms:xP},LP=[0,1,1,1],TP=`layout(std140) uniform pickingUniforms {
  float isActive;
  float isAttribute;
  float isHighlightActive;
  float useByteColors;
  vec3 highlightedObjectColor;
  vec4 highlightColor;
} picking;

out vec4 picking_vRGBcolor_Avalid;

// Normalize unsigned byte color to 0-1 range
vec3 picking_normalizeColor(vec3 color) {
  return picking.useByteColors > 0.5 ? color / 255.0 : color;
}

// Normalize unsigned byte color to 0-1 range
vec4 picking_normalizeColor(vec4 color) {
  return picking.useByteColors > 0.5 ? color / 255.0 : color;
}

bool picking_isColorZero(vec3 color) {
  return dot(color, vec3(1.0)) < 0.00001;
}

bool picking_isColorValid(vec3 color) {
  return dot(color, vec3(1.0)) > 0.00001;
}

// Check if this vertex is highlighted 
bool isVertexHighlighted(vec3 vertexColor) {
  vec3 highlightedObjectColor = picking_normalizeColor(picking.highlightedObjectColor);
  return
    bool(picking.isHighlightActive) && picking_isColorZero(abs(vertexColor - highlightedObjectColor));
}

// Set the current picking color
void picking_setPickingColor(vec3 pickingColor) {
  pickingColor = picking_normalizeColor(pickingColor);

  if (bool(picking.isActive)) {
    // Use alpha as the validity flag. If pickingColor is [0, 0, 0] fragment is non-pickable
    picking_vRGBcolor_Avalid.a = float(picking_isColorValid(pickingColor));

    if (!bool(picking.isAttribute)) {
      // Stores the picking color so that the fragment shader can render it during picking
      picking_vRGBcolor_Avalid.rgb = pickingColor;
    }
  } else {
    // Do the comparison with selected item color in vertex shader as it should mean fewer compares
    picking_vRGBcolor_Avalid.a = float(isVertexHighlighted(pickingColor));
  }
}

void picking_setPickingAttribute(float value) {
  if (bool(picking.isAttribute)) {
    picking_vRGBcolor_Avalid.r = value;
  }
}

void picking_setPickingAttribute(vec2 value) {
  if (bool(picking.isAttribute)) {
    picking_vRGBcolor_Avalid.rg = value;
  }
}

void picking_setPickingAttribute(vec3 value) {
  if (bool(picking.isAttribute)) {
    picking_vRGBcolor_Avalid.rgb = value;
  }
}
`,AP=`layout(std140) uniform pickingUniforms {
  float isActive;
  float isAttribute;
  float isHighlightActive;
  float useByteColors;
  vec3 highlightedObjectColor;
  vec4 highlightColor;
} picking;

in vec4 picking_vRGBcolor_Avalid;

/*
 * Returns highlight color if this item is selected.
 */
vec4 picking_filterHighlightColor(vec4 color) {
  // If we are still picking, we don't highlight
  if (picking.isActive > 0.5) {
    return color;
  }

  bool selected = bool(picking_vRGBcolor_Avalid.a);

  if (selected) {
    // Blend in highlight color based on its alpha value
    float highLightAlpha = picking.highlightColor.a;
    float blendedAlpha = highLightAlpha + color.a * (1.0 - highLightAlpha);
    float highLightRatio = highLightAlpha / blendedAlpha;

    vec3 blendedRGB = mix(color.rgb, picking.highlightColor.rgb, highLightRatio);
    return vec4(blendedRGB, blendedAlpha);
  } else {
    return color;
  }
}

/*
 * Returns picking color if picking enabled else unmodified argument.
 */
vec4 picking_filterPickingColor(vec4 color) {
  if (bool(picking.isActive)) {
    if (picking_vRGBcolor_Avalid.a == 0.0) {
      discard;
    }
    return picking_vRGBcolor_Avalid;
  }
  return color;
}

/*
 * Returns picking color if picking is enabled if not
 * highlight color if this item is selected, otherwise unmodified argument.
 */
vec4 picking_filterColor(vec4 color) {
  vec4 highlightColor = picking_filterHighlightColor(color);
  return picking_filterPickingColor(highlightColor);
}
`,Xt={props:{},uniforms:{},name:"picking",uniformTypes:{isActive:"f32",isAttribute:"f32",isHighlightActive:"f32",useByteColors:"f32",highlightedObjectColor:"vec3<f32>",highlightColor:"vec4<f32>"},defaultUniforms:{isActive:!1,isAttribute:!1,isHighlightActive:!1,useByteColors:!0,highlightedObjectColor:[0,0,0],highlightColor:LP},vs:TP,fs:AP,getUniforms:MP};function MP(i={},e){const t={},n=gg(i.useByteColors,!0);if(i.highlightedObjectColor!==void 0)if(i.highlightedObjectColor===null)t.isHighlightActive=!1;else{t.isHighlightActive=!0;const s=i.highlightedObjectColor.slice(0,3);t.highlightedObjectColor=s}return i.highlightColor&&(t.highlightColor=hP(i.highlightColor,n)),i.isActive!==void 0&&(t.isActive=!!i.isActive,t.isAttribute=!!i.isAttribute),i.useByteColors!==void 0&&(t.useByteColors=!!i.useByteColors),t}const Tu=`precision highp int;

// #if (defined(SHADER_TYPE_FRAGMENT) && defined(LIGHTING_FRAGMENT)) || (defined(SHADER_TYPE_VERTEX) && defined(LIGHTING_VERTEX))
struct AmbientLight {
  vec3 color;
};

struct PointLight {
  vec3 color;
  vec3 position;
  vec3 attenuation; // 2nd order x:Constant-y:Linear-z:Exponential
};

struct SpotLight {
  vec3 color;
  vec3 position;
  vec3 direction;
  vec3 attenuation;
  vec2 coneCos;
};

struct DirectionalLight {
  vec3 color;
  vec3 direction;
};

struct UniformLight {
  vec3 color;
  vec3 position;
  vec3 direction;
  vec3 attenuation;
  vec2 coneCos;
};

layout(std140) uniform lightingUniforms {
  int enabled;
  int directionalLightCount;
  int pointLightCount;
  int spotLightCount;
  vec3 ambientColor;
  UniformLight lights[5];
} lighting;

PointLight lighting_getPointLight(int index) {
  UniformLight light = lighting.lights[index];
  return PointLight(light.color, light.position, light.attenuation);
}

SpotLight lighting_getSpotLight(int index) {
  UniformLight light = lighting.lights[lighting.pointLightCount + index];
  return SpotLight(light.color, light.position, light.direction, light.attenuation, light.coneCos);
}

DirectionalLight lighting_getDirectionalLight(int index) {
  UniformLight light =
    lighting.lights[lighting.pointLightCount + lighting.spotLightCount + index];
  return DirectionalLight(light.color, light.direction);
}

float getPointLightAttenuation(PointLight pointLight, float distance) {
  return pointLight.attenuation.x
       + pointLight.attenuation.y * distance
       + pointLight.attenuation.z * distance * distance;
}

float getSpotLightAttenuation(SpotLight spotLight, vec3 positionWorldspace) {
  vec3 light_direction = normalize(positionWorldspace - spotLight.position);
  float coneFactor = smoothstep(
    spotLight.coneCos.y,
    spotLight.coneCos.x,
    dot(normalize(spotLight.direction), light_direction)
  );
  float distanceAttenuation = getPointLightAttenuation(
    PointLight(spotLight.color, spotLight.position, spotLight.attenuation),
    distance(spotLight.position, positionWorldspace)
  );
  return distanceAttenuation / max(coneFactor, 0.0001);
}

// #endif
`,IP=`// #if (defined(SHADER_TYPE_FRAGMENT) && defined(LIGHTING_FRAGMENT)) || (defined(SHADER_TYPE_VERTEX) && defined(LIGHTING_VERTEX))
const MAX_LIGHTS: i32 = 5;

struct AmbientLight {
  color: vec3<f32>,
};

struct PointLight {
  color: vec3<f32>,
  position: vec3<f32>,
  attenuation: vec3<f32>, // 2nd order x:Constant-y:Linear-z:Exponential
};

struct SpotLight {
  color: vec3<f32>,
  position: vec3<f32>,
  direction: vec3<f32>,
  attenuation: vec3<f32>,
  coneCos: vec2<f32>,
};

struct DirectionalLight {
  color: vec3<f32>,
  direction: vec3<f32>,
};

struct UniformLight {
  color: vec3<f32>,
  position: vec3<f32>,
  direction: vec3<f32>,
  attenuation: vec3<f32>,
  coneCos: vec2<f32>,
};

struct lightingUniforms {
  enabled: i32,
  directionalLightCount: i32,
  pointLightCount: i32,
  spotLightCount: i32,
  ambientColor: vec3<f32>,
  lights: array<UniformLight, 5>,
};

@group(2) @binding(auto) var<uniform> lighting : lightingUniforms;

fn lighting_getPointLight(index: i32) -> PointLight {
  let light = lighting.lights[index];
  return PointLight(light.color, light.position, light.attenuation);
}

fn lighting_getSpotLight(index: i32) -> SpotLight {
  let light = lighting.lights[lighting.pointLightCount + index];
  return SpotLight(light.color, light.position, light.direction, light.attenuation, light.coneCos);
}

fn lighting_getDirectionalLight(index: i32) -> DirectionalLight {
  let light = lighting.lights[lighting.pointLightCount + lighting.spotLightCount + index];
  return DirectionalLight(light.color, light.direction);
}

fn getPointLightAttenuation(pointLight: PointLight, distance: f32) -> f32 {
  return pointLight.attenuation.x
       + pointLight.attenuation.y * distance
       + pointLight.attenuation.z * distance * distance;
}

fn getSpotLightAttenuation(spotLight: SpotLight, positionWorldspace: vec3<f32>) -> f32 {
  let lightDirection = normalize(positionWorldspace - spotLight.position);
  let coneFactor = smoothstep(
    spotLight.coneCos.y,
    spotLight.coneCos.x,
    dot(normalize(spotLight.direction), lightDirection)
  );
  let distanceAttenuation = getPointLightAttenuation(
    PointLight(spotLight.color, spotLight.position, spotLight.attenuation),
    distance(spotLight.position, positionWorldspace)
  );
  return distanceAttenuation / max(coneFactor, 0.0001);
}
`,Tt=5,RP={color:"vec3<f32>",position:"vec3<f32>",direction:"vec3<f32>",attenuation:"vec3<f32>",coneCos:"vec2<f32>"},OP={props:{},uniforms:{},name:"lighting",defines:{},uniformTypes:{enabled:"i32",directionalLightCount:"i32",pointLightCount:"i32",spotLightCount:"i32",ambientColor:"vec3<f32>",lights:[RP,Tt]},defaultUniforms:ws(),bindingLayout:[{name:"lighting",group:2}],firstBindingSlot:0,source:IP,vs:Tu,fs:Tu,getUniforms:BP};function BP(i,e={}){if(i=i&&{...i},!i)return ws();i.lights&&(i={...i,...DP(i.lights),lights:void 0});const{useByteColors:t,ambientLight:n,pointLights:s,spotLights:r,directionalLights:o}=i||{};if(!(n||s&&s.length>0||r&&r.length>0||o&&o.length>0))return{...ws(),enabled:0};const c={...ws(),...kP({useByteColors:t,ambientLight:n,pointLights:s,spotLights:r,directionalLights:o})};return i.enabled!==void 0&&(c.enabled=i.enabled?1:0),c}function kP({useByteColors:i,ambientLight:e,pointLights:t=[],spotLights:n=[],directionalLights:s=[]}){const r=mg();let o=0,a=0,c=0,l=0;for(const u of t){if(o>=Tt)break;r[o]={...r[o],color:ns(u,i),position:u.position,attenuation:u.attenuation||[1,0,0]},o++,a++}for(const u of n){if(o>=Tt)break;r[o]={...r[o],color:ns(u,i),position:u.position,direction:u.direction,attenuation:u.attenuation||[1,0,0],coneCos:zP(u)},o++,c++}for(const u of s){if(o>=Tt)break;r[o]={...r[o],color:ns(u,i),direction:u.direction},o++,l++}return t.length+n.length+s.length>Tt&&M.warn(`MAX_LIGHTS exceeded, truncating to ${Tt}`)(),{ambientColor:ns(e,i),directionalLightCount:l,pointLightCount:a,spotLightCount:c,lights:r}}function DP(i){var t,n,s;const e={pointLights:[],spotLights:[],directionalLights:[]};for(const r of i||[])switch(r.type){case"ambient":e.ambientLight=r;break;case"directional":(t=e.directionalLights)==null||t.push(r);break;case"point":(n=e.pointLights)==null||n.push(r);break;case"spot":(s=e.spotLights)==null||s.push(r);break}return e}function ns(i={},e){const{color:t=[0,0,0],intensity:n=1}=i;return pg(t,gg(e,!0)).map(r=>r*n)}function ws(){return{enabled:1,directionalLightCount:0,pointLightCount:0,spotLightCount:0,ambientColor:[.1,.1,.1],lights:mg()}}function mg(){return Array.from({length:Tt},()=>FP())}function FP(){return{color:[1,1,1],position:[1,1,2],direction:[1,1,1],attenuation:[1,0,0],coneCos:[1,0]}}function zP(i){const e=i.innerConeAngle??0,t=i.outerConeAngle??Math.PI/4;return[Math.cos(e),Math.cos(t)]}const NP=`layout(std140) uniform phongMaterialUniforms {
  uniform bool unlit;
  uniform float ambient;
  uniform float diffuse;
  uniform float shininess;
  uniform vec3  specularColor;
} material;
`,UP=`layout(std140) uniform phongMaterialUniforms {
  uniform bool unlit;
  uniform float ambient;
  uniform float diffuse;
  uniform float shininess;
  uniform vec3  specularColor;
} material;

vec3 lighting_getLightColor(vec3 surfaceColor, vec3 light_direction, vec3 view_direction, vec3 normal_worldspace, vec3 color) {
  vec3 halfway_direction = normalize(light_direction + view_direction);
  float lambertian = dot(light_direction, normal_worldspace);
  float specular = 0.0;
  if (lambertian > 0.0) {
    float specular_angle = max(dot(normal_worldspace, halfway_direction), 0.0);
    specular = pow(specular_angle, material.shininess);
  }
  lambertian = max(lambertian, 0.0);
  return (lambertian * material.diffuse * surfaceColor + specular * floatColors_normalize(material.specularColor)) * color;
}

vec3 lighting_getLightColor(vec3 surfaceColor, vec3 cameraPosition, vec3 position_worldspace, vec3 normal_worldspace) {
  vec3 lightColor = surfaceColor;

  if (material.unlit) {
    return surfaceColor;
  }

  if (lighting.enabled == 0) {
    return lightColor;
  }

  vec3 view_direction = normalize(cameraPosition - position_worldspace);
  lightColor = material.ambient * surfaceColor * lighting.ambientColor;

  for (int i = 0; i < lighting.pointLightCount; i++) {
    PointLight pointLight = lighting_getPointLight(i);
    vec3 light_position_worldspace = pointLight.position;
    vec3 light_direction = normalize(light_position_worldspace - position_worldspace);
    float light_attenuation = getPointLightAttenuation(pointLight, distance(light_position_worldspace, position_worldspace));
    lightColor += lighting_getLightColor(surfaceColor, light_direction, view_direction, normal_worldspace, pointLight.color / light_attenuation);
  }

  for (int i = 0; i < lighting.spotLightCount; i++) {
    SpotLight spotLight = lighting_getSpotLight(i);
    vec3 light_position_worldspace = spotLight.position;
    vec3 light_direction = normalize(light_position_worldspace - position_worldspace);
    float light_attenuation = getSpotLightAttenuation(spotLight, position_worldspace);
    lightColor += lighting_getLightColor(surfaceColor, light_direction, view_direction, normal_worldspace, spotLight.color / light_attenuation);
  }

  for (int i = 0; i < lighting.directionalLightCount; i++) {
    DirectionalLight directionalLight = lighting_getDirectionalLight(i);
    lightColor += lighting_getLightColor(surfaceColor, -directionalLight.direction, view_direction, normal_worldspace, directionalLight.color);
  }
  
  return lightColor;
}
`,$P=`struct phongMaterialUniforms {
  unlit: u32,
  ambient: f32,
  diffuse: f32,
  shininess: f32,
  specularColor: vec3<f32>,
};

@group(3) @binding(auto) var<uniform> phongMaterial : phongMaterialUniforms;

fn lighting_getLightColor(surfaceColor: vec3<f32>, light_direction: vec3<f32>, view_direction: vec3<f32>, normal_worldspace: vec3<f32>, color: vec3<f32>) -> vec3<f32> {
  let halfway_direction: vec3<f32> = normalize(light_direction + view_direction);
  var lambertian: f32 = dot(light_direction, normal_worldspace);
  var specular: f32 = 0.0;
  if (lambertian > 0.0) {
    let specular_angle = max(dot(normal_worldspace, halfway_direction), 0.0);
    specular = pow(specular_angle, phongMaterial.shininess);
  }
  lambertian = max(lambertian, 0.0);
  return (
    lambertian * phongMaterial.diffuse * surfaceColor +
    specular * floatColors_normalize(phongMaterial.specularColor)
  ) * color;
}

fn lighting_getLightColor2(surfaceColor: vec3<f32>, cameraPosition: vec3<f32>, position_worldspace: vec3<f32>, normal_worldspace: vec3<f32>) -> vec3<f32> {
  var lightColor: vec3<f32> = surfaceColor;

  if (phongMaterial.unlit != 0u) {
    return surfaceColor;
  }

  if (lighting.enabled == 0) {
    return lightColor;
  }

  let view_direction: vec3<f32> = normalize(cameraPosition - position_worldspace);
  lightColor = phongMaterial.ambient * surfaceColor * lighting.ambientColor;

  for (var i: i32 = 0; i < lighting.pointLightCount; i++) {
    let pointLight: PointLight = lighting_getPointLight(i);
    let light_position_worldspace: vec3<f32> = pointLight.position;
    let light_direction: vec3<f32> = normalize(light_position_worldspace - position_worldspace);
    let light_attenuation = getPointLightAttenuation(
      pointLight,
      distance(light_position_worldspace, position_worldspace)
    );
    lightColor += lighting_getLightColor(
      surfaceColor,
      light_direction,
      view_direction,
      normal_worldspace,
      pointLight.color / light_attenuation
    );
  }

  for (var i: i32 = 0; i < lighting.spotLightCount; i++) {
    let spotLight: SpotLight = lighting_getSpotLight(i);
    let light_position_worldspace: vec3<f32> = spotLight.position;
    let light_direction: vec3<f32> = normalize(light_position_worldspace - position_worldspace);
    let light_attenuation = getSpotLightAttenuation(spotLight, position_worldspace);
    lightColor += lighting_getLightColor(
      surfaceColor,
      light_direction,
      view_direction,
      normal_worldspace,
      spotLight.color / light_attenuation
    );
  }

  for (var i: i32 = 0; i < lighting.directionalLightCount; i++) {
    let directionalLight: DirectionalLight = lighting_getDirectionalLight(i);
    lightColor += lighting_getLightColor(surfaceColor, -directionalLight.direction, view_direction, normal_worldspace, directionalLight.color);
  }  
  
  return lightColor;
}

fn lighting_getSpecularLightColor(cameraPosition: vec3<f32>, position_worldspace: vec3<f32>, normal_worldspace: vec3<f32>) -> vec3<f32>{
  var lightColor = vec3<f32>(0, 0, 0);
  let surfaceColor = vec3<f32>(0, 0, 0);

  if (lighting.enabled != 0) {
    let view_direction = normalize(cameraPosition - position_worldspace);

    for (var i: i32 = 0; i < lighting.pointLightCount; i++) {
      let pointLight: PointLight = lighting_getPointLight(i);
      let light_position_worldspace: vec3<f32> = pointLight.position;
      let light_direction: vec3<f32> = normalize(light_position_worldspace - position_worldspace);
      let light_attenuation = getPointLightAttenuation(
        pointLight,
        distance(light_position_worldspace, position_worldspace)
      );
      lightColor += lighting_getLightColor(
        surfaceColor,
        light_direction,
        view_direction,
        normal_worldspace,
        pointLight.color / light_attenuation
      );
    }

    for (var i: i32 = 0; i < lighting.spotLightCount; i++) {
      let spotLight: SpotLight = lighting_getSpotLight(i);
      let light_position_worldspace: vec3<f32> = spotLight.position;
      let light_direction: vec3<f32> = normalize(light_position_worldspace - position_worldspace);
      let light_attenuation = getSpotLightAttenuation(spotLight, position_worldspace);
      lightColor += lighting_getLightColor(
        surfaceColor,
        light_direction,
        view_direction,
        normal_worldspace,
        spotLight.color / light_attenuation
      );
    }

    for (var i: i32 = 0; i < lighting.directionalLightCount; i++) {
        let directionalLight: DirectionalLight = lighting_getDirectionalLight(i);
        lightColor += lighting_getLightColor(surfaceColor, -directionalLight.direction, view_direction, normal_worldspace, directionalLight.color);
    }
  }
  return lightColor;
}
`,GP=[38.25,38.25,38.25],_g={props:{},name:"gouraudMaterial",bindingLayout:[{name:"gouraudMaterial",group:3}],vs:UP.replace("phongMaterial","gouraudMaterial"),fs:NP.replace("phongMaterial","gouraudMaterial"),source:$P.replaceAll("phongMaterial","gouraudMaterial"),defines:{LIGHTING_VERTEX:!0},dependencies:[OP,CP],uniformTypes:{unlit:"i32",ambient:"f32",diffuse:"f32",shininess:"f32",specularColor:"vec3<f32>"},defaultUniforms:{unlit:!1,ambient:.35,diffuse:.6,shininess:32,specularColor:GP},getUniforms(i){return{..._g.defaultUniforms,...i}}},jP=`struct LayerUniforms {
  opacity: f32,
};

@group(0) @binding(auto)
var<uniform> layer: LayerUniforms;
`,Au=`layout(std140) uniform layerUniforms {
  uniform float opacity;
} layer;
`,VP={name:"layer",source:jP,vs:Au,fs:Au,getUniforms:i=>({opacity:Math.pow(i.opacity,1/2.2)}),uniformTypes:{opacity:"f32"}},WP=`

@must_use
fn deckgl_premultiplied_alpha(fragColor: vec4<f32>) -> vec4<f32> {
    return vec4(fragColor.rgb * fragColor.a, fragColor.a); 
};
`,Bn={name:"color",dependencies:[],source:WP,getUniforms:i=>({})},HP=`const SMOOTH_EDGE_RADIUS: f32 = 0.5;

struct VertexGeometry {
  position: vec4<f32>,
  worldPosition: vec3<f32>,
  worldPositionAlt: vec3<f32>,
  normal: vec3<f32>,
  uv: vec2<f32>,
  pickingColor: vec3<f32>,
};

var<private> geometry_: VertexGeometry = VertexGeometry(
  vec4<f32>(0.0, 0.0, 1.0, 0.0),
  vec3<f32>(0.0, 0.0, 0.0),
  vec3<f32>(0.0, 0.0, 0.0),
  vec3<f32>(0.0, 0.0, 0.0),
  vec2<f32>(0.0, 0.0),
  vec3<f32>(0.0, 0.0, 0.0)
);

struct FragmentGeometry {
  uv: vec2<f32>,
};

var<private> fragmentGeometry: FragmentGeometry;

fn smoothedge(edge: f32, x: f32) -> f32 {
  return smoothstep(edge - SMOOTH_EDGE_RADIUS, edge + SMOOTH_EDGE_RADIUS, x);
}
`,yg="#define SMOOTH_EDGE_RADIUS 0.5",YP=`${yg}

struct VertexGeometry {
  vec4 position;
  vec3 worldPosition;
  vec3 worldPositionAlt;
  vec3 normal;
  vec2 uv;
  vec3 pickingColor;
} geometry = VertexGeometry(
  vec4(0.0, 0.0, 1.0, 0.0),
  vec3(0.0),
  vec3(0.0),
  vec3(0.0),
  vec2(0.0),
  vec3(0.0)
);
`,qP=`${yg}

struct FragmentGeometry {
  vec2 uv;
};
FragmentGeometry geometry;

float smoothedge(float edge, float x) {
  return smoothstep(edge - SMOOTH_EDGE_RADIUS, edge + SMOOTH_EDGE_RADIUS, x);
}
`,bg={name:"geometry",source:HP,vs:YP,fs:qP},ZP=25;var H;(function(i){i[i.Start=1]="Start",i[i.Move=2]="Move",i[i.End=4]="End",i[i.Cancel=8]="Cancel"})(H||(H={}));var de;(function(i){i[i.None=0]="None",i[i.Left=1]="Left",i[i.Right=2]="Right",i[i.Up=4]="Up",i[i.Down=8]="Down",i[i.Horizontal=3]="Horizontal",i[i.Vertical=12]="Vertical",i[i.All=15]="All"})(de||(de={}));var $;(function(i){i[i.Possible=1]="Possible",i[i.Began=2]="Began",i[i.Changed=4]="Changed",i[i.Ended=8]="Ended",i[i.Recognized=8]="Recognized",i[i.Cancelled=16]="Cancelled",i[i.Failed=32]="Failed"})($||($={}));const XP="compute",KP="auto",er="manipulation",xs="none",Na="pan-x",Ua="pan-y";function QP(i){if(i.includes(xs))return xs;const e=i.includes(Na),t=i.includes(Ua);return e&&t?xs:e||t?e?Na:Ua:i.includes(er)?er:KP}class JP{constructor(e,t){this.actions="",this.manager=e,this.set(t)}set(e){e===XP&&(e=this.compute()),this.manager.element&&(this.manager.element.style.touchAction=e,this.actions=e)}update(){this.set(this.manager.options.touchAction)}compute(){let e=[];for(const t of this.manager.recognizers)t.options.enable&&(e=e.concat(t.getTouchAction()));return QP(e.join(" "))}}function tr(i){return i.trim().split(/\s+/g)}function wo(i,e,t){if(i)for(const n of tr(e))i.addEventListener(n,t,!1)}function xo(i,e,t){if(i)for(const n of tr(e))i.removeEventListener(n,t,!1)}function Mu(i){return(i.ownerDocument||i).defaultView}function e2(i,e){let t=i;for(;t;){if(t===e)return!0;t=t.parentNode}return!1}function vg(i){const e=i.length;if(e===1)return{x:Math.round(i[0].clientX),y:Math.round(i[0].clientY)};let t=0,n=0,s=0;for(;s<e;)t+=i[s].clientX,n+=i[s].clientY,s++;return{x:Math.round(t/e),y:Math.round(n/e)}}function Iu(i){const e=[];let t=0;for(;t<i.pointers.length;)e[t]={clientX:Math.round(i.pointers[t].clientX),clientY:Math.round(i.pointers[t].clientY)},t++;return{timeStamp:Date.now(),pointers:e,center:vg(e),deltaX:i.deltaX,deltaY:i.deltaY}}function Jc(i,e){const t=e.x-i.x,n=e.y-i.y;return Math.sqrt(t*t+n*n)}function $a(i,e){const t=e.clientX-i.clientX,n=e.clientY-i.clientY;return Math.sqrt(t*t+n*n)}function t2(i,e){const t=e.x-i.x,n=e.y-i.y;return Math.atan2(n,t)*180/Math.PI}function Ru(i,e){const t=e.clientX-i.clientX,n=e.clientY-i.clientY;return Math.atan2(n,t)*180/Math.PI}function el(i,e){return i===e?de.None:Math.abs(i)>=Math.abs(e)?i<0?de.Left:de.Right:e<0?de.Up:de.Down}function i2(i,e){const t=e.center;let n=i.offsetDelta,s=i.prevDelta;const r=i.prevInput;return(e.eventType===H.Start||(r==null?void 0:r.eventType)===H.End)&&(s=i.prevDelta={x:(r==null?void 0:r.deltaX)||0,y:(r==null?void 0:r.deltaY)||0},n=i.offsetDelta={x:t.x,y:t.y}),{deltaX:s.x+(t.x-n.x),deltaY:s.y+(t.y-n.y)}}function wg(i,e,t){return{x:e/i||0,y:t/i||0}}function n2(i,e){return $a(e[0],e[1])/$a(i[0],i[1])}function s2(i,e){return Ru(e[1],e[0])-Ru(i[1],i[0])}function r2(i,e){const t=i.lastInterval||e,n=e.timeStamp-t.timeStamp;let s,r,o,a;if(e.eventType!==H.Cancel&&(n>ZP||t.velocity===void 0)){const c=e.deltaX-t.deltaX,l=e.deltaY-t.deltaY,u=wg(n,c,l);r=u.x,o=u.y,s=Math.abs(u.x)>Math.abs(u.y)?u.x:u.y,a=el(c,l),i.lastInterval=e}else s=t.velocity,r=t.velocityX,o=t.velocityY,a=t.direction;e.velocity=s,e.velocityX=r,e.velocityY=o,e.direction=a}function Ga(i,e){return"pointerId"in i?i.pointerId:e}function Ou(i,e){i.movementOrigin=new Map(e.map((t,n)=>[Ga(t,n),{clientX:t.clientX,clientY:t.clientY}])),i.firstMovementTime=void 0}function o2(i,e){var s;const t=e.pointers.map(Ga);if(((s=i.movementOrigin)==null?void 0:s.size)===t.length&&t.every(r=>i.movementOrigin.has(r))||Ou(i,e.pointers),e.distancePerPointer=e.pointers.map((r,o)=>$a(i.movementOrigin.get(t[o]),r)),e.eventType&H.Move&&e.distancePerPointer.some(r=>r>0)&&(i.firstMovementTime??(i.firstMovementTime=e.timeStamp)),e.movementDeltaTime=i.firstMovementTime===void 0?0:e.timeStamp-i.firstMovementTime,e.eventType&(H.End|H.Cancel)){const r=e.changedPointers.map(o=>Ga(o,e.pointers.indexOf(o)));Ou(i,e.pointers.filter((o,a)=>!r.includes(t[a])))}}function a2(i,e){const{session:t}=i,{pointers:n}=e,{length:s}=n;t.firstInput||(t.firstInput=Iu(e)),s>1&&!t.firstMultiple?t.firstMultiple=Iu(e):s===1&&(t.firstMultiple=!1);const{firstInput:r,firstMultiple:o}=t,a=o?o.center:r.center,c=e.center=vg(n);e.timeStamp=Date.now(),e.deltaTime=e.timeStamp-r.timeStamp,o2(t,e),e.angle=t2(a,c),e.distance=Jc(a,c);const{deltaX:l,deltaY:u}=i2(t,e);e.deltaX=l,e.deltaY=u,e.offsetDirection=el(e.deltaX,e.deltaY);const f=wg(e.deltaTime,e.deltaX,e.deltaY);e.overallVelocityX=f.x,e.overallVelocityY=f.y,e.overallVelocity=Math.abs(f.x)>Math.abs(f.y)?f.x:f.y,e.scale=o?n2(o.pointers,n):1,e.rotation=o?s2(o.pointers,n):0,e.maxPointers=t.prevInput?e.pointers.length>t.prevInput.maxPointers?e.pointers.length:t.prevInput.maxPointers:e.pointers.length;let d=i.element;return e2(e.srcEvent.target,d)&&(d=e.srcEvent.target),e.target=d,r2(t,e),e}function c2(i,e,t){const n=t.pointers.length,s=t.changedPointers.length,r=e&H.Start&&n-s===0,o=e&(H.End|H.Cancel)&&n-s===0;t.isFirst=!!r,t.isFinal=!!o,r&&(i.session={}),t.eventType=e;const a=a2(i,t);i.emit("hammer.input",a),i.recognize(a),i.session.prevInput=a}let l2=class{constructor(e){this.evEl="",this.evWin="",this.evTarget="",this.domHandler=t=>{this.manager.options.enable&&this.handler(t)},this.manager=e,this.element=e.element,this.target=e.options.inputTarget||e.element}callback(e,t){c2(this.manager,e,t)}init(){wo(this.element,this.evEl,this.domHandler),wo(this.target,this.evTarget,this.domHandler),wo(Mu(this.element),this.evWin,this.domHandler)}destroy(){xo(this.element,this.evEl,this.domHandler),xo(this.target,this.evTarget,this.domHandler),xo(Mu(this.element),this.evWin,this.domHandler)}};const u2={pointerdown:H.Start,pointermove:H.Move,pointerup:H.End,pointercancel:H.Cancel,pointerout:H.Cancel},f2="pointerdown",d2="pointermove pointerup pointercancel";class h2 extends l2{constructor(e){super(e),this.evEl=f2,this.evWin=d2,this.store=this.manager.session.pointerEvents=[],this.init()}handler(e){const{store:t}=this;let n=!1;const s=u2[e.type],r=e.pointerType,o=r==="touch";let a=t.findIndex(c=>c.pointerId===e.pointerId);s&H.Start&&(e.buttons||o)?a<0&&(t.push(e),a=t.length-1):s&(H.End|H.Cancel)&&(n=!0),!(a<0)&&(t[a]=e,this.callback(s,{pointers:t,changedPointers:[e],eventType:s,pointerType:r,srcEvent:e}),n&&t.splice(a,1))}}const g2=["","webkit","Moz","MS","ms","o"];function p2(i,e){const t=e[0].toUpperCase()+e.slice(1);for(const n of g2){const s=n?n+t:e;if(s in i)return s}}const m2=1,Bu=2,ku={touchAction:"compute",enable:!0,inputTarget:null,cssProps:{userSelect:"none",userDrag:"none",touchCallout:"none",tapHighlightColor:"rgba(0,0,0,0)"}};class _2{constructor(e,t){this.options={...ku,...t,cssProps:{...ku.cssProps,...t.cssProps},inputTarget:t.inputTarget||e},this.handlers={},this.session={},this.recognizers=[],this.oldCssProps={},this.element=e,this.input=new h2(this),this.touchAction=new JP(this,this.options.touchAction),this.toggleCssProps(!0)}set(e){return Object.assign(this.options,e),e.touchAction&&this.touchAction.update(),e.inputTarget&&(this.input.destroy(),this.input.target=e.inputTarget,this.input.init()),this}stop(e){this.session.stopped=e?Bu:m2}recognize(e){const{session:t}=this;if(t.stopped)return;this.session.prevented&&e.srcEvent.preventDefault();let n;const{recognizers:s}=this;let{curRecognizer:r}=t;(!r||r&&r.state&$.Recognized)&&(r=t.curRecognizer=null);let o=0;for(;o<s.length;)n=s[o],t.stopped!==Bu&&(!r||n===r||n.canRecognizeWith(r))?n.recognize(e):n.reset(),!r&&n.state&($.Began|$.Changed|$.Ended)&&(r=t.curRecognizer=n),o++}get(e){const{recognizers:t}=this;for(let n=0;n<t.length;n++)if(t[n].options.event===e)return t[n];return null}add(e){if(Array.isArray(e)){for(const n of e)this.add(n);return this}const t=this.get(e.options.event);return t&&this.remove(t),this.recognizers.push(e),e.manager=this,this.touchAction.update(),e}remove(e){if(Array.isArray(e)){for(const n of e)this.remove(n);return this}const t=typeof e=="string"?this.get(e):e;if(t){const{recognizers:n}=this,s=n.indexOf(t);s!==-1&&(n.splice(s,1),this.touchAction.update())}return this}on(e,t){if(!e||!t)return;const{handlers:n}=this;for(const s of tr(e))n[s]=n[s]||[],n[s].push(t)}off(e,t){if(!e)return;const{handlers:n}=this;for(const s of tr(e))t?n[s]&&n[s].splice(n[s].indexOf(t),1):delete n[s]}emit(e,t){const n=this.handlers[e]&&this.handlers[e].slice();if(!n||!n.length)return;const s=t;s.type=e,s.preventDefault=function(){t.srcEvent.preventDefault()};let r=0;for(;r<n.length;)n[r](s),r++}destroy(){this.toggleCssProps(!1),this.handlers={},this.session={},this.input.destroy(),this.element=null}toggleCssProps(e){const{element:t}=this;if(t){for(const[n,s]of Object.entries(this.options.cssProps)){const r=p2(t.style,n);e?(this.oldCssProps[r]=t.style[r],t.style[r]=s):t.style[r]=this.oldCssProps[r]||""}e||(this.oldCssProps={})}}}let y2=1;function b2(){return y2++}function Du(i){return i&$.Cancelled?"cancel":i&$.Ended?"end":i&$.Changed?"move":i&$.Began?"start":""}class tl{constructor(e){this.options=e,this.id=b2(),this.state=$.Possible,this.simultaneous={},this.requireFail=[]}set(e){return Object.assign(this.options,e),this.manager.touchAction.update(),this}recognizeWith(e){if(Array.isArray(e)){for(const s of e)this.recognizeWith(s);return this}let t;if(typeof e=="string"){if(t=this.manager.get(e),!t)throw new Error(`Cannot find recognizer ${e}`)}else t=e;const{simultaneous:n}=this;return n[t.id]||(n[t.id]=t,t.recognizeWith(this)),this}dropRecognizeWith(e){if(Array.isArray(e)){for(const n of e)this.dropRecognizeWith(n);return this}let t;return typeof e=="string"?t=this.manager.get(e):t=e,t&&delete this.simultaneous[t.id],this}requireFailure(e){if(Array.isArray(e)){for(const s of e)this.requireFailure(s);return this}let t;if(typeof e=="string"){if(t=this.manager.get(e),!t)throw new Error(`Cannot find recognizer ${e}`)}else t=e;const{requireFail:n}=this;return n.indexOf(t)===-1&&(n.push(t),t.requireFailure(this)),this}dropRequireFailure(e){if(Array.isArray(e)){for(const n of e)this.dropRequireFailure(n);return this}let t;if(typeof e=="string"?t=this.manager.get(e):t=e,t){const n=this.requireFail.indexOf(t);n>-1&&this.requireFail.splice(n,1)}return this}hasRequireFailures(){return!!this.requireFail.find(e=>e.options.enable)}canRecognizeWith(e){return!!this.simultaneous[e.id]}emit(e){if(!e)return;const{state:t}=this;t<$.Ended&&this.manager.emit(this.options.event+Du(t),e),this.manager.emit(this.options.event,e),e.additionalEvent&&this.manager.emit(e.additionalEvent,e),t>=$.Ended&&this.manager.emit(this.options.event+Du(t),e)}tryEmit(e){this.canEmit()?this.emit(e):this.state=$.Failed}canEmit(){let e=0;for(;e<this.requireFail.length;){if(!(this.requireFail[e].state&($.Failed|$.Possible)))return!1;e++}return!0}recognize(e){const t={...e};if(!this.options.enable){this.reset(),this.state=$.Failed;return}this.state&($.Recognized|$.Cancelled|$.Failed)&&(this.state=$.Possible),this.state=this.process(t),this.state&($.Began|$.Changed|$.Ended|$.Cancelled)&&this.tryEmit(t)}getEventNames(){return[this.options.event]}reset(){}}function v2(i){return Math.abs(((i+180)%360+360)%360-180)}function w2(i,e){return(e.distance===void 0||i.distance>=e.distance)&&(e.distancePerPointer===void 0||i.distancePerPointer.length>0&&i.distancePerPointer.every(t=>t>=e.distancePerPointer))&&(e.movementDeltaTime===void 0||i.movementDeltaTime>=e.movementDeltaTime)&&(e.rotation===void 0||v2(i.rotation)>=e.rotation)&&(e.scale===void 0||Math.abs(i.scale-1)>=e.scale)}class x2 extends tl{attrTest(e){const t=this.options.pointers;return t===0||e.pointers.length===t}coherentTest(e){const t=this.options.coherent;return!(t!=null&&t.length)||t.some(n=>w2(e,n))}process(e){const{state:t}=this,{eventType:n}=e,s=t&($.Began|$.Changed),r=this.attrTest(e);return s&&(n&H.Cancel||!r)?t|$.Cancelled:s||r?n&H.End?t|$.Ended:t&$.Began?t|$.Changed:$.Began:$.Failed}}const P2=["","start","move","end","cancel"];class S2 extends tl{constructor(e={}){super({enable:!0,event:"doubleclickdrag",pointers:1,interval:500,time:350,threshold:28,dragThreshold:1,pixelsPerScale:120,...e}),this._tapStart=null,this._lastTap=null,this._drag=null,this._emittedStart=!1}getTouchAction(){return[er]}getEventNames(){return P2.map(e=>this.options.event+e)}process(e){const{options:t}=this;return e.pointers.length===t.pointers?e.eventType&H.Start?this._handleStart(e):e.eventType&H.Move?this._handleMove(e):e.eventType&H.Cancel?this._handleEnd(e,!0):e.eventType&H.End?this._handleEnd(e,!1):$.Failed:(this.reset(),$.Failed)}reset(){this._tapStart=null,this._lastTap=null,this._drag=null,this._emittedStart=!1}emit(e){var t;if(e){if(this.state===$.Began){if(!((t=this._drag)!=null&&t.active)||this._emittedStart)return;this._emittedStart=!0,this.manager.emit(`${this.options.event}start`,e),this.manager.emit(this.options.event,e);return}if(this.state===$.Changed){if(!this._emittedStart)return;this.manager.emit(`${this.options.event}move`,e),this.manager.emit(this.options.event,e);return}if(this.state===$.Ended){if(!this._emittedStart)return;this.manager.emit(this.options.event,e),this.manager.emit(`${this.options.event}end`,e),this._emittedStart=!1;return}if(this.state===$.Cancelled){if(!this._emittedStart)return;this.manager.emit(this.options.event,e),this.manager.emit(`${this.options.event}cancel`,e),this._emittedStart=!1}}}_handleStart(e){const t=this._getPointerId(e);return this._lastTap&&this._isTapMatch(e,this._lastTap)?(this._tapStart=null,this._lastTap=null,this._drag={startCenter:e.center,pointerId:t,active:!1},this._emittedStart=!1,$.Began):(this._tapStart={center:e.center,timeStamp:e.timeStamp,pointerId:t},this._lastTap=null,this._drag=null,this._emittedStart=!1,$.Failed)}_handleMove(e){if(!this._drag||!this._isSamePointer(e,this._drag.pointerId))return $.Failed;const t=this._drag.startCenter.y-e.center.y;return!this._drag.active&&Math.abs(t)<this.options.dragThreshold?$.Began:(this._drag.active=!0,e.scale=Math.pow(2,t/this.options.pixelsPerScale),this._emittedStart?$.Changed:$.Began)}_handleEnd(e,t){if(this._drag&&this._isSamePointer(e,this._drag.pointerId)){const{active:n,startCenter:s}=this._drag;if(this._drag=null,this._tapStart=null,this._lastTap=null,!n)return this._emittedStart=!1,$.Failed;const r=s.y-e.center.y;return e.scale=Math.pow(2,r/this.options.pixelsPerScale),t?$.Cancelled:$.Ended}return!this._tapStart||!this._isSamePointer(e,this._tapStart.pointerId)?(t&&this.reset(),$.Failed):(this._isValidTap(e)?this._lastTap={center:e.center,timeStamp:e.timeStamp,pointerId:this._tapStart.pointerId}:this._lastTap=null,this._tapStart=null,$.Failed)}_isTapMatch(e,t){return e.timeStamp-t.timeStamp<=this.options.interval&&Jc(e.center,t.center)<=this.options.threshold}_isValidTap(e){return e.deltaTime<=this.options.time&&e.distance<=this.options.threshold}_getPointerId(e){return"pointerId"in e.srcEvent?e.srcEvent.pointerId:null}_isSamePointer(e,t){return t===null||this._getPointerId(e)===t}}class Fu extends tl{constructor(e={}){super({enable:!0,event:"tap",pointers:1,taps:1,interval:300,time:250,threshold:9,posThreshold:10,...e}),this.pTime=null,this.pCenter=null,this._timer=null,this._input=null,this.count=0}getTouchAction(){return[er]}process(e){const{options:t}=this,n=e.pointers.length===t.pointers,s=e.distance<t.threshold,r=e.deltaTime<t.time;if(this.reset(),e.eventType&H.Start&&this.count===0)return this.failTimeout();if(s&&r&&n){if(e.eventType!==H.End)return this.failTimeout();const o=this.pTime?e.timeStamp-this.pTime<t.interval:!0,a=!this.pCenter||Jc(this.pCenter,e.center)<t.posThreshold;if(this.pTime=e.timeStamp,this.pCenter=e.center,!a||!o?this.count=1:this.count+=1,this._input=e,this.count%t.taps===0)return this.hasRequireFailures()?(this._timer=setTimeout(()=>{this.state=$.Recognized,this.tryEmit(this._input)},t.interval),$.Began):$.Recognized}return $.Failed}failTimeout(){return this._timer=setTimeout(()=>{this.state=$.Failed},this.options.interval),$.Failed}reset(){clearTimeout(this._timer)}emit(e){this.state===$.Recognized&&(e.tapCount=this.count,this.manager.emit(this.options.event,e))}}class xg extends x2{constructor(){super(...arguments),this.wheelSession=null,this.wheelSessionUnsubscribe=null,this.handleWheelSessionEvent=e=>{e.device==="trackpad"&&this.handleTrackpadEvent(e)}}set(e){var s;const{wheelSession:t,...n}=e;return t&&t!==this.wheelSession&&((s=this.wheelSessionUnsubscribe)==null||s.call(this),this.wheelSessionUnsubscribe=null,this.wheelSession=t),super.set(n),this.updateWheelSessionSubscription(),this}getTrackpadInput(e,t={}){const{srcEvent:n}=e,s=t.deltaX??e.deltaX,r=t.deltaY??e.deltaY,o=el(s,r),a=Math.sqrt(e.deltaX*e.deltaX+e.deltaY*e.deltaY),c=n;return{pointers:[c,c],changedPointers:[c,c],pointerType:"trackpad",srcEvent:c,eventType:e.eventType,timeStamp:e.timeStamp,deltaTime:e.deltaTime,center:e.center,deltaX:s,deltaY:r,angle:Math.atan2(r,s)*180/Math.PI,distance:Math.sqrt(s*s+r*r),distancePerPointer:[a,a],movementDeltaTime:e.deltaTime,scale:1,rotation:0,direction:o,offsetDirection:o,velocity:e.velocity,velocityX:e.velocityX,velocityY:e.velocityY,overallVelocity:e.overallVelocity,overallVelocityX:e.overallVelocityX,overallVelocityY:e.overallVelocityY,maxPointers:2,target:n.target||this.manager.element,additionalEvent:"",...t}}updateWheelSessionSubscription(){const e=!!(this.wheelSession&&this.options.enable&&this.options.trackpad&&this.options.pointers===2);e&&!this.wheelSessionUnsubscribe?this.wheelSessionUnsubscribe=this.wheelSession.on(this.handleWheelSessionEvent):!e&&this.wheelSessionUnsubscribe&&(this.wheelSessionUnsubscribe(),this.wheelSessionUnsubscribe=null)}}const E2=["","start","move","end","cancel","up","down","left","right"];class zu extends xg{constructor(e={}){super({enable:!0,pointers:1,event:"pan",threshold:10,direction:de.All,trackpad:!1,coherent:[],...e}),this.trackpadGesture=!1,this.pX=null,this.pY=null}getTouchAction(){const{options:{direction:e}}=this,t=[];return e&de.Horizontal&&t.push(Ua),e&de.Vertical&&t.push(Na),t}getEventNames(){return E2.map(e=>this.options.event+e)}directionTest(e){const{options:t}=this;let n=!0,{distance:s}=e,{direction:r}=e;const o=e.deltaX,a=e.deltaY;return r&t.direction||(t.direction&de.Horizontal?(r=o===0?de.None:o<0?de.Left:de.Right,n=o!==this.pX,s=Math.abs(e.deltaX)):(r=a===0?de.None:a<0?de.Up:de.Down,n=a!==this.pY,s=Math.abs(e.deltaY))),e.direction=r,n&&s>t.threshold&&!!(r&t.direction)}attrTest(e){var s;const t=!!(this.state&$.Began),n=!((s=this.options.coherent)!=null&&s.length&&e.eventType&(H.End|H.Cancel));return super.attrTest(e)&&(t||n&&this.coherentTest(e)&&this.directionTest(e))}emit(e){this.pX=e.deltaX,this.pY=e.deltaY;const t=de[e.direction].toLowerCase();t&&(e.additionalEvent=this.options.event+t),super.emit(e)}handleTrackpadEvent(e){e.isFirst&&(this.trackpadGesture=!e.srcEvent.ctrlKey,!this.trackpadGesture&&this.state&($.Recognized|$.Cancelled|$.Failed)&&(this.state=$.Possible)),this.trackpadGesture&&(this.recognize(this.getTrackpadInput(e,{deltaX:-e.deltaX,deltaY:-e.deltaY,velocity:-e.velocity,velocityX:-e.velocityX,velocityY:-e.velocityY,overallVelocity:-e.overallVelocity,overallVelocityX:-e.overallVelocityX,overallVelocityY:-e.overallVelocityY})),e.isFinal&&(this.trackpadGesture=!1))}}const C2=["","start","move","end","cancel","in","out"];class L2 extends xg{constructor(e={}){super({enable:!0,event:"pinch",threshold:0,pointers:2,trackpad:!1,coherent:[],...e}),this.trackpadGesture=!1}getTouchAction(){return[xs]}getEventNames(){return C2.map(e=>this.options.event+e)}attrTest(e){var r;const t=!!((r=this.options.coherent)!=null&&r.length),n=!!(this.state&$.Began),s=!(t&&e.eventType&(H.End|H.Cancel));return super.attrTest(e)&&(n||s&&(t?this.coherentTest(e):Math.abs(e.scale-1)>this.options.threshold))}emit(e){if(e.scale!==1){const t=e.scale<1?"in":"out";e.additionalEvent=this.options.event+t}super.emit(e)}handleTrackpadEvent(e){e.isFirst&&(this.trackpadGesture=e.srcEvent.ctrlKey,!this.trackpadGesture&&this.state&($.Recognized|$.Cancelled|$.Failed)&&(this.state=$.Possible)),this.trackpadGesture&&(this.recognize(this.getTrackpadInput(e,{deltaX:0,deltaY:0,velocity:0,velocityX:0,velocityY:0,overallVelocity:0,overallVelocityX:0,overallVelocityY:0,scale:Math.exp(-e.deltaY/100)})),e.isFinal&&(this.trackpadGesture=!1))}}class $r{constructor(e,t,n){this.element=e,this.callback=t,this.options=n}listen(e,t){t?this.element.addEventListener(e,this.handleEvent,{passive:!1}):this.element.removeEventListener(e,this.handleEvent)}}const T2=typeof navigator<"u"&&navigator.userAgent?navigator.userAgent.toLowerCase():"",A2=T2.indexOf("firefox")!==-1,M2=40,I2=.25;class R2 extends $r{constructor(e,t,n){var s;n.enable=n.enable??!1,super(e,t,n),this.handleEvent=r=>{var a;if(!this.options.enable)return;let o=r.deltaY;globalThis.WheelEvent&&(A2&&r.deltaMode===globalThis.WheelEvent.DOM_DELTA_PIXEL&&(o/=globalThis.devicePixelRatio),r.deltaMode===globalThis.WheelEvent.DOM_DELTA_LINE&&(o*=M2)),r.shiftKey&&o&&(o=o*I2),this.callback({type:"wheel",center:{x:r.clientX,y:r.clientY},delta:-o,device:((a=this.options.wheelSession)==null?void 0:a.device)??"unknown",srcEvent:r,pointerType:"mouse",target:r.target})},n.enable&&(this.wheelSessionUnsubscribe=(s=this.options.wheelSession)==null?void 0:s.on(()=>{}),this.listen("wheel",!0))}destroy(){var e;this.listen("wheel",!1),(e=this.wheelSessionUnsubscribe)==null||e.call(this),this.wheelSessionUnsubscribe=void 0}enableEventType(e,t){var n,s;e==="wheel"&&this.options.enable!==t&&(this.options.enable=t,t&&!this.wheelSessionUnsubscribe&&(this.wheelSessionUnsubscribe=(n=this.options.wheelSession)==null?void 0:n.on(()=>{})),this.listen("wheel",t),t||((s=this.wheelSessionUnsubscribe)==null||s.call(this),this.wheelSessionUnsubscribe=void 0))}}const O2=4.000244140625,Nu=40,B2=0,k2=1,D2=40,Uu=40,F2=120,z2={classificationDelay:32,endDelay:80};class N2{constructor(e,t={}){var n;this.subscriptions=new Map,this.session=null,this.classificationTimer=null,this.endTimer=null,this.pressedControlKeys=new Set,this.listeningForControlKeys=!1,this.handleEvent=s=>{if(!this.hasSubscribers)return"unknown";const r=$2(s,this.pressedControlKeys.size>0);let o=this.session;if(o&&r.timeStamp-o.lastTimeStamp>=this.options.endDelay){if(this.end(),!this.hasSubscribers)return"unknown";o=null}o?(this.scheduleEnd(),this.addSample(o,r)):(o=this.startPendingSession(r),this.scheduleEnd());let{device:a}=o;return a==="unknown"&&(a=Po(o.samples,!1),a!=="unknown"&&this.begin(o,a)),a},this.finishClassification=()=>{if(this.classificationTimer=null,!this.session||this.session.device!=="unknown")return;const s=this.session,r=Po(s.samples,!0);this.begin(s,r==="unknown"?"mouse":r)},this.end=()=>{if(!this.session)return;if(this.session.device==="unknown"){const r=this.session,o=Po(r.samples,!0);this.begin(r,o==="unknown"?"mouse":o)}if(!this.session)return;const s=this.session;this.emit(H.End,s.lastEvent),this.reset()},this.handleKeyDown=s=>{s.key==="Control"&&this.pressedControlKeys.add(s.code||s.key)},this.handleKeyUp=s=>{s.key==="Control"&&(s.code?this.pressedControlKeys.delete(s.code):this.pressedControlKeys.clear())},this.handleWindowBlur=()=>{this.pressedControlKeys.clear()},this.element=e,this.options={...z2,...t},(n=this.element)==null||n.addEventListener("wheel",this.handleEvent,{passive:!0})}get hasSubscribers(){return this.subscriptions.size>0}get device(){var e;return((e=this.session)==null?void 0:e.device)??"unknown"}on(e){const t={listener:e};return this.subscriptions.set(e,t),this.updateControlKeyEventListeners(),()=>{this.subscriptions.get(e)===t&&this.off(e)}}off(e){this.subscriptions.delete(e),this.updateControlKeyEventListeners(),this.hasSubscribers||this.reset()}cancel(){const e=this.session;e&&e.device!=="unknown"&&this.emit(H.Cancel,e.lastEvent),this.reset()}destroy(){var e;this.cancel(),this.subscriptions.clear(),this.updateControlKeyEventListeners(),(e=this.element)==null||e.removeEventListener("wheel",this.handleEvent)}startPendingSession(e){const t={samples:[e],device:"unknown",firstTimeStamp:e.timeStamp,lastTimeStamp:e.timeStamp,totalDeltaX:e.deltaX,totalDeltaY:e.deltaY,velocityX:0,velocityY:0,lastEvent:e.event};return this.session=t,this.classificationTimer=globalThis.setTimeout(this.finishClassification,this.options.classificationDelay),t}addSample(e,t){if(e.samples.push(t),e.lastTimeStamp=t.timeStamp,e.lastEvent=t.event,e.totalDeltaX+=t.deltaX,e.totalDeltaY+=t.deltaY,e.device!=="unknown"){const n=e.samples[e.samples.length-2],s=t.timeStamp-n.timeStamp;e.velocityX=s>0?t.deltaX/s:0,e.velocityY=s>0?t.deltaY/s:0,this.emit(H.Move,t.event,{velocityX:e.velocityX,velocityY:e.velocityY})}}begin(e,t){e.device=t,this.clearClassificationTimer(),this.emit(H.Start,e.samples[0].event);const n=e.lastTimeStamp-e.firstTimeStamp;e.velocityX=n>0?e.totalDeltaX/n:0,e.velocityY=n>0?e.totalDeltaY/n:0,this.emit(H.Move,e.lastEvent,{velocityX:e.velocityX,velocityY:e.velocityY})}scheduleEnd(){this.clearEndTimer(),this.endTimer=globalThis.setTimeout(this.end,this.options.endDelay)}emit(e,t,n){const s=this.session;if(!s||s.device==="unknown")return;const r=e===H.Start,o=e===H.End||e===H.Cancel,a=r?s.firstTimeStamp:s.lastTimeStamp,c=r?0:Math.max(0,a-s.firstTimeStamp),l=r?0:s.totalDeltaX,u=r?0:s.totalDeltaY,f=c>0?l/c:0,d=c>0?u/c:0,g=r?0:(n==null?void 0:n.velocityX)??s.velocityX,p=r?0:(n==null?void 0:n.velocityY)??s.velocityY,m={eventType:e,device:s.device,srcEvent:t,timeStamp:a,center:{x:t.clientX,y:t.clientY},deltaX:l,deltaY:u,deltaTime:c,velocity:Math.abs(g)>Math.abs(p)?g:p,velocityX:g,velocityY:p,overallVelocity:Math.abs(f)>Math.abs(d)?f:d,overallVelocityX:f,overallVelocityY:d,isFirst:r,isFinal:o};for(const{listener:_}of[...this.subscriptions.values()])_(m)}reset(){this.clearClassificationTimer(),this.clearEndTimer(),this.session=null}clearClassificationTimer(){this.classificationTimer!==null&&(globalThis.clearTimeout(this.classificationTimer),this.classificationTimer=null)}clearEndTimer(){this.endTimer!==null&&(globalThis.clearTimeout(this.endTimer),this.endTimer=null)}updateControlKeyEventListeners(){const e=this.hasSubscribers,t=U2();!t||e===this.listeningForControlKeys||(this.listeningForControlKeys=e,e?(t.addEventListener("keydown",this.handleKeyDown,!0),t.addEventListener("keyup",this.handleKeyUp,!0),t.addEventListener("blur",this.handleWindowBlur)):(t.removeEventListener("keydown",this.handleKeyDown,!0),t.removeEventListener("keyup",this.handleKeyUp,!0),t.removeEventListener("blur",this.handleWindowBlur),this.pressedControlKeys.clear()))}}function U2(){var i;return typeof window<"u"?window:(i=globalThis.document)==null?void 0:i.defaultView}function $2(i,e){let t=i.deltaX,n=i.deltaY;return i.deltaMode===k2&&(t*=Nu,n*=Nu),{event:i,timeStamp:i.timeStamp,deltaX:t,deltaY:n,isControlKeyDown:e}}function Po(i,e){return i.some(({event:t,isControlKeyDown:n})=>t.ctrlKey&&!n)?"trackpad":i.some(({event:t})=>t.deltaMode!==B2)||i.some(G2)||i.every(({event:t})=>{const n=t.wheelDelta;return n!==void 0&&Math.abs(n)%40===0})?"mouse":i.some(({deltaX:t})=>t!==0)||i.length>1&&j2(i)?"trackpad":e?"mouse":"unknown"}function G2({event:i,deltaX:e,deltaY:t}){if(e!==0||t===0)return!1;const n=Math.abs(t/O2);if(Number.isInteger(n))return!0;const s=i.wheelDelta;return typeof s=="number"&&s!==0&&s%F2===0}function j2(i){for(let e=0;e<i.length;e++){const t=i[e];if(Math.abs(t.deltaX)>Uu||Math.abs(t.deltaY)>Uu||e>0&&t.timeStamp-i[e-1].timeStamp>D2)return!1}return!0}const $u=["mousedown","mousemove","mouseup","mouseover","mouseout","mouseenter","mouseleave"];class V2 extends $r{constructor(e,t,n){super(e,t,{enable:!0,...n}),this.handleEvent=r=>{this.handleOverEvent(r),this.handleOutEvent(r),this.handleEnterEvent(r),this.handleLeaveEvent(r),this.handleMoveEvent(r)},this.pressed=!1;const{enable:s=!1}=this.options;this.enableMoveEvent=s,this.enableLeaveEvent=s,this.enableEnterEvent=s,this.enableOutEvent=s,this.enableOverEvent=s,s&&$u.forEach(r=>this.listen(r,!0))}destroy(){$u.forEach(e=>this.listen(e,!1))}enableEventType(e,t){switch(e){case"pointermove":this.enableMoveEvent!==t&&(this.enableMoveEvent=t,this.listen("mousedown",t),this.listen("mousemove",t),this.listen("mouseup",t));break;case"pointerover":this.enableOverEvent!==t&&(this.enableOverEvent=t,this.listen("mouseover",t));break;case"pointerout":this.enableOutEvent!==t&&(this.enableOutEvent=t,this.listen("mouseout",t));break;case"pointerenter":this.enableEnterEvent!==t&&(this.enableEnterEvent=t,this.listen("mouseenter",t));break;case"pointerleave":this.enableLeaveEvent!==t&&(this.enableLeaveEvent=t,this.listen("mouseleave",t));break}}handleOverEvent(e){this.enableOverEvent&&e.type==="mouseover"&&this._emit("pointerover",e)}handleOutEvent(e){this.enableOutEvent&&e.type==="mouseout"&&this._emit("pointerout",e)}handleEnterEvent(e){this.enableEnterEvent&&e.type==="mouseenter"&&this._emit("pointerenter",e)}handleLeaveEvent(e){this.enableLeaveEvent&&e.type==="mouseleave"&&this._emit("pointerleave",e)}handleMoveEvent(e){if(this.enableMoveEvent)switch(e.type){case"mousedown":e.button>=0&&(this.pressed=!0);break;case"mousemove":e.buttons===0&&(this.pressed=!1),this.pressed||this._emit("pointermove",e);break;case"mouseup":this.pressed=!1;break}}_emit(e,t){this.callback({type:e,center:{x:t.clientX,y:t.clientY},srcEvent:t,pointerType:"mouse",target:t.target})}}const Gu=["keydown","keyup"];class W2 extends $r{constructor(e,t,n){super(e,t,{enable:!0,tabIndex:0,...n}),this.handleEvent=r=>{const o=r.target||r.srcElement;o.tagName==="INPUT"&&o.type==="text"||o.tagName==="TEXTAREA"||(this.enableDownEvent&&r.type==="keydown"&&this.callback({type:"keydown",srcEvent:r,key:r.key,target:r.target}),this.enableUpEvent&&r.type==="keyup"&&this.callback({type:"keyup",srcEvent:r,key:r.key,target:r.target}))};const{enable:s=!1}=this.options;this.enableDownEvent=s,this.enableUpEvent=s,e.tabIndex=this.options.tabIndex,e.style.outline="none",s&&Gu.forEach(r=>this.listen(r,!0))}destroy(){Gu.forEach(e=>this.listen(e,!1))}enableEventType(e,t){e==="keydown"&&this.enableDownEvent!==t&&(this.enableDownEvent=t,this.listen(e,t)),e==="keyup"&&this.enableUpEvent!==t&&(this.enableUpEvent=t,this.listen(e,t))}}class H2 extends $r{constructor(e,t,n){n.enable=n.enable??!1,super(e,t,n),this.handleEvent=s=>{this.options.enable&&this.callback({type:"contextmenu",center:{x:s.clientX,y:s.clientY},srcEvent:s,pointerType:"mouse",target:s.target})},n.enable&&this.listen("contextmenu",!0)}destroy(){this.listen("contextmenu",!1)}enableEventType(e,t){e==="contextmenu"&&this.options.enable!==t&&(this.options.enable=t,this.listen("contextmenu",t))}}const ju=1,ja=2,Vu=4,Y2={pointerdown:ju,pointermove:ja,pointerup:Vu,mousedown:ju,mousemove:ja,mouseup:Vu},q2=0,Z2=1,X2=2,K2=1,Q2=2,J2=4;function eS(i){const e=Y2[i.srcEvent.type];if(!e)return null;const{buttons:t,button:n}=i.srcEvent;let s=!1,r=!1,o=!1;return e===ja?(s=!!(t&K2),r=!!(t&J2),o=!!(t&Q2)):(s=n===q2,r=n===Z2,o=n===X2),{leftButton:s,middleButton:r,rightButton:o}}function tS(i,e){const t=i.center;if(!t)return null;const n=e.getBoundingClientRect(),s=n.width/e.offsetWidth||1,r=n.height/e.offsetHeight||1,o={x:(t.x-n.left-e.clientLeft)/s,y:(t.y-n.top-e.clientTop)/r};return{center:t,offsetCenter:o}}const iS={srcElement:"root",priority:0};class nS{constructor(e,t){this.handleEvent=n=>{if(this.isEmpty())return;const s=this._normalizeEvent(n);let r=n.srcEvent.target;for(;r&&r!==s.rootElement;){if(this._emit(s,r),s.handled)return;r=r.parentNode}this._emit(s,"root")},this.eventManager=e,this.recognizerName=t,this.handlers=[],this.handlersByElement=new Map,this._active=!1}isEmpty(){return!this._active}add(e,t,n,s=!1,r=!1){const{handlers:o,handlersByElement:a}=this,c={...iS,...n};let l=a.get(c.srcElement);l||(l=[],a.set(c.srcElement,l));const u={type:e,handler:t,srcElement:c.srcElement,priority:c.priority};s&&(u.once=!0),r&&(u.passive=!0),o.push(u),this._active=this._active||!u.passive;let f=l.length-1;for(;f>=0&&!(l[f].priority>=u.priority);)f--;l.splice(f+1,0,u)}remove(e,t){const{handlers:n,handlersByElement:s}=this;for(let r=n.length-1;r>=0;r--){const o=n[r];if(o.type===e&&o.handler===t){n.splice(r,1);const a=s.get(o.srcElement);a.splice(a.indexOf(o),1),a.length===0&&s.delete(o.srcElement)}}this._active=n.some(r=>!r.passive)}_emit(e,t){const n=this.handlersByElement.get(t);if(n){let s=!1;const r=()=>{e.handled=!0},o=()=>{e.handled=!0,s=!0},a=[];for(let c=0;c<n.length;c++){const{type:l,handler:u,once:f}=n[c];if(u({...e,type:l,stopPropagation:r,stopImmediatePropagation:o}),f&&a.push(n[c]),s)break}for(let c=0;c<a.length;c++){const{type:l,handler:u}=a[c];this.remove(l,u)}}}_normalizeEvent(e){const t=this.eventManager.getElement();return{...e,...eS(e),...tS(e,t),preventDefault:()=>{e.srcEvent.preventDefault()},stopImmediatePropagation:null,stopPropagation:null,handled:!1,rootElement:t}}}function sS(i){if("recognizer"in i)return i;let e;const t=Array.isArray(i)?[...i]:[i];if(typeof t[0]=="function"){const n=t.shift(),s=t.shift()||{};e=new n(s)}else e=t.shift();return{recognizer:e,recognizeWith:typeof t[0]=="string"?[t[0]]:t[0],requireFailure:typeof t[1]=="string"?[t[1]]:t[1]}}class rS{constructor(e=null,t={}){if(this._onBasicInput=n=>{this.manager.emit(n.srcEvent.type,n)},this._onOtherEvent=n=>{this.manager.emit(n.type,n)},this.options={recognizers:[],events:{},touchAction:"compute",tabIndex:0,cssProps:{},...t},this.events=new Map,this.element=e,this.wheelSession=new N2(e),!!e){this.manager=new _2(e,this.options);for(const n of this.options.recognizers){const{recognizer:s,recognizeWith:r,requireFailure:o}=sS(n);this.manager.add(s),r&&s.recognizeWith(r),o&&s.requireFailure(o)}this.manager.on("hammer.input",this._onBasicInput),this.wheelInput=new R2(e,this._onOtherEvent,{enable:!1,wheelSession:this.wheelSession}),this.moveInput=new V2(e,this._onOtherEvent,{enable:!1}),this.keyInput=new W2(e,this._onOtherEvent,{enable:!1,tabIndex:t.tabIndex}),this.contextmenuInput=new H2(e,this._onOtherEvent,{enable:!1}),this.on(this.options.events)}}getElement(){return this.element}destroy(){if(!this.element){this.wheelSession.destroy();return}this.wheelInput.destroy(),this.wheelSession.destroy(),this.moveInput.destroy(),this.keyInput.destroy(),this.contextmenuInput.destroy(),this.manager.destroy()}on(e,t,n){this._addEventHandler(e,t,n,!1)}once(e,t,n){this._addEventHandler(e,t,n,!0)}watch(e,t,n){this._addEventHandler(e,t,n,!1,!0)}off(e,t){this._removeEventHandler(e,t)}emit(e){var t;(t=this.manager)==null||t.emit(e.type,e)}_toggleRecognizer(e,t){var r,o,a,c;const{manager:n}=this;if(!n)return;const s=n.get(e);s&&(s.set({enable:t,wheelSession:this.wheelSession}),n.touchAction.update()),(r=this.wheelInput)==null||r.enableEventType(e,t),(o=this.moveInput)==null||o.enableEventType(e,t),(a=this.keyInput)==null||a.enableEventType(e,t),(c=this.contextmenuInput)==null||c.enableEventType(e,t)}_addEventHandler(e,t,n,s,r){if(typeof e!="string"){n=t;for(const[l,u]of Object.entries(e))this._addEventHandler(l,u,n,s,r);return}const{manager:o,events:a}=this;if(!o)return;let c=a.get(e);if(!c){const l=this._getRecognizerName(e)||e;c=new nS(this,l),a.set(e,c),o&&o.on(e,c.handleEvent)}c.add(e,t,n,s,r),c.isEmpty()||this._toggleRecognizer(c.recognizerName,!0)}_removeEventHandler(e,t){if(typeof e!="string"){for(const[r,o]of Object.entries(e))this._removeEventHandler(r,o);return}const{events:n}=this,s=n.get(e);if(s&&(s.remove(e,t),s.isEmpty())){const{recognizerName:r}=s;let o=!1;for(const a of n.values())if(a.recognizerName===r&&!a.isEmpty()){o=!0;break}o||this._toggleRecognizer(r,!1)}}_getRecognizerName(e){var t;return(t=this.manager.recognizers.find(n=>n.getEventNames().includes(e)))==null?void 0:t.options.event}}const xe={WEB_MERCATOR:1,GLOBE:2,WEB_MERCATOR_AUTO_OFFSET:4,IDENTITY:0},at={common:0,meters:1,pixels:2},Ps={click:"onClick",dblclick:"onClick",panstart:"onDragStart",panmove:"onDrag",panend:"onDragEnd"},Wu={multipan:[zu,{threshold:10,pointers:2,trackpad:!0}],pinch:[L2,{trackpad:!0},null,["multipan"]],pan:[zu,{threshold:1},["pinch"],["multipan"]],dblclick:[Fu,{event:"dblclick",taps:2,enable:!1}],dblclickdrag:[S2,{event:"dblclickdrag",enable:!1},["dblclick"],null],click:[Fu,{event:"click"},["dblclickdrag"],["dblclick","dblclickdrag"]]};function oS(i,e){if(i===e)return!0;if(Array.isArray(i)){const t=i.length;if(!e||e.length!==t)return!1;for(let n=0;n<t;n++)if(i[n]!==e[n])return!1;return!0}return!1}function kn(i){let e={},t;return n=>{for(const s in n)if(!oS(n[s],e[s])){t=i(n),e=n;break}return t}}const Hu=[0,0,0,0],aS=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0],Pg=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],cS=[0,0,0],Sg=[0,0,0],lS={default:-1,cartesian:0,lnglat:1,"meter-offsets":2,"lnglat-offsets":3};function Gr(i){const e=lS[i];if(e===void 0)throw new Error(`Invalid coordinateSystem: ${i}`);return e}const uS=kn(hS);function Eg(i,e,t=Sg){t.length<3&&(t=[t[0],t[1],0]);let n=t,s,r=!0;switch(e==="lnglat-offsets"||e==="meter-offsets"?s=t:s=i.isGeospatial?[Math.fround(i.longitude),Math.fround(i.latitude),0]:null,i.projectionMode){case xe.WEB_MERCATOR:e==="lnglat"?(s=[0,0,0],r=!1):e==="cartesian"&&(r=!1,s=i.unprojectPosition([Math.fround(i.center[0]),Math.fround(i.center[1]),0]));break;case xe.WEB_MERCATOR_AUTO_OFFSET:e==="lnglat"?n=s:e==="cartesian"&&(n=[Math.fround(i.center[0]),Math.fround(i.center[1]),0],s=i.unprojectPosition(n),n[0]-=t[0],n[1]-=t[1],n[2]-=t[2]);break;case xe.IDENTITY:n=i.position.map(Math.fround),n[2]=n[2]||0;break;case xe.GLOBE:r=!1,s=null;break;default:r=!1}return{geospatialOrigin:s,shaderCoordinateOrigin:n,offsetMode:r}}function fS(i,e,t){const{viewMatrixUncentered:n,projectionMatrix:s}=i;let{viewMatrix:r,viewProjectionMatrix:o}=i,a=Hu,c=Hu,l=i.cameraPosition;const{geospatialOrigin:u,shaderCoordinateOrigin:f,offsetMode:d}=Eg(i,e,t);return d&&(c=i.projectPosition(u||f),l=[l[0]-c[0],l[1]-c[1],l[2]-c[2]],c[3]=1,a=Ti([],c,o),r=n||r,o=Ot([],s,r),o=Ot([],o,aS)),{viewMatrix:r,viewProjectionMatrix:o,projectionCenter:a,originCommon:c,cameraPosCommon:l,shaderCoordinateOrigin:f,geospatialOrigin:u}}function dS({viewport:i,devicePixelRatio:e=1,modelMatrix:t=null,coordinateSystem:n="default",coordinateOrigin:s=Sg,autoWrapLongitude:r=!1}){n==="default"&&(n=i.isGeospatial?"lnglat":"cartesian");const o=uS({viewport:i,devicePixelRatio:e,coordinateSystem:n,coordinateOrigin:s});return o.wrapLongitude=r,o.modelMatrix=t||Pg,o}function hS({viewport:i,devicePixelRatio:e,coordinateSystem:t,coordinateOrigin:n}){const{projectionCenter:s,viewProjectionMatrix:r,originCommon:o,cameraPosCommon:a,shaderCoordinateOrigin:c,geospatialOrigin:l}=fS(i,t,n),u=i.getDistanceScales(),f=[i.width*e,i.height*e],d=Ti([],[0,0,-i.focalDistance,1],i.projectionMatrix)[3]||1,g={coordinateSystem:Gr(t),projectionMode:i.projectionMode,coordinateOrigin:c,commonOrigin:o.slice(0,3),center:s,pseudoMeters:!!i._pseudoMeters,viewportSize:f,devicePixelRatio:e,focalDistance:d,commonUnitsPerMeter:u.unitsPerMeter,commonUnitsPerWorldUnit:u.unitsPerMeter,commonUnitsPerWorldUnit2:cS,scale:i.scale,wrapLongitude:!1,viewProjectionMatrix:r,modelMatrix:Pg,cameraPosition:a};if(l){const p=i.getDistanceScales(l);switch(t){case"meter-offsets":g.commonUnitsPerWorldUnit=p.unitsPerMeter,g.commonUnitsPerWorldUnit2=p.unitsPerMeter2;break;case"lnglat":case"lnglat-offsets":i._pseudoMeters||(g.commonUnitsPerMeter=p.unitsPerMeter),g.commonUnitsPerWorldUnit=p.unitsPerDegree,g.commonUnitsPerWorldUnit2=p.unitsPerDegree2;break;case"cartesian":g.commonUnitsPerWorldUnit=[1,1,p.unitsPerMeter[2]],g.commonUnitsPerWorldUnit2=[0,0,p.unitsPerMeter2[2]];break}}if(i.projectionMode===xe.GLOBE&&t==="meter-offsets"){const _=n[0]*Math.PI/180,v=n[1]*Math.PI/180,w=Math.cos(v),y=((n[2]||0)/6370972+1)*256;g.commonOrigin=[Math.sin(_)*w*y,-Math.cos(_)*w*y,Math.sin(v)*y]}return g}const gS=["default","lnglat","meter-offsets","lnglat-offsets","cartesian"],pS=gS.map(i=>`const COORDINATE_SYSTEM_${i.toUpperCase().replaceAll("-","_")}: i32 = ${Gr(i)};`).join(""),mS=Object.keys(xe).map(i=>`const PROJECTION_MODE_${i}: i32 = ${xe[i]};`).join(""),_S=Object.keys(at).map(i=>`const UNIT_${i.toUpperCase()}: i32 = ${at[i]};`).join(""),yS=`${pS}
${mS}
${_S}

const TILE_SIZE: f32 = 512.0;
const PI: f32 = 3.1415926536;
const WORLD_SCALE: f32 = TILE_SIZE / (PI * 2.0);
const ZERO_64_LOW: vec3<f32> = vec3<f32>(0.0, 0.0, 0.0);
const EARTH_RADIUS: f32 = 6370972.0; // meters
const GLOBE_RADIUS: f32 = 256.0;

// -----------------------------------------------------------------------------
// Uniform block (converted from GLSL uniform block)
// -----------------------------------------------------------------------------
struct ProjectUniforms {
  wrapLongitude: i32,
  coordinateSystem: i32,
  commonUnitsPerMeter: vec3<f32>,
  projectionMode: i32,
  scale: f32,
  commonUnitsPerWorldUnit: vec3<f32>,
  commonUnitsPerWorldUnit2: vec3<f32>,
  center: vec4<f32>,
  modelMatrix: mat4x4<f32>,
  viewProjectionMatrix: mat4x4<f32>,
  viewportSize: vec2<f32>,
  devicePixelRatio: f32,
  focalDistance: f32,
  cameraPosition: vec3<f32>,
  coordinateOrigin: vec3<f32>,
  commonOrigin: vec3<f32>,
  pseudoMeters: i32,
};

@group(0) @binding(auto)
var<uniform> project: ProjectUniforms;

// -----------------------------------------------------------------------------
// Geometry data shared across the project helpers.
// The active layer shader is responsible for populating this private module
// state before calling the project functions below.
// -----------------------------------------------------------------------------

// Structure to carry additional geometry data used by deck.gl filters.
struct Geometry {
  worldPosition: vec3<f32>,
  worldPositionAlt: vec3<f32>,
  position: vec4<f32>,
  normal: vec3<f32>,
  uv: vec2<f32>,
  pickingColor: vec3<f32>,
};

var<private> geometry: Geometry;
`,bS=`${yS}

// -----------------------------------------------------------------------------
// Functions
// -----------------------------------------------------------------------------

// Returns an adjustment factor for commonUnitsPerMeter
fn _project_size_at_latitude(lat: f32) -> f32 {
  let y = clamp(lat, -89.9, 89.9);
  return 1.0 / cos(radians(y));
}

// Overloaded version: scales a value in meters at a given latitude.
fn _project_size_at_latitude_m(meters: f32, lat: f32) -> f32 {
  return meters * project.commonUnitsPerMeter.z * _project_size_at_latitude(lat);
}

// Computes a non-linear scale factor based on geometry.
// (Note: This function relies on "geometry" being provided.)
fn project_size() -> f32 {
  if (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR &&
      project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT &&
      project.pseudoMeters == 0) {
    if (geometry.position.w == 0.0) {
      return _project_size_at_latitude(geometry.worldPosition.y);
    }
    let y: f32 = geometry.position.y / TILE_SIZE * 2.0 - 1.0;
    let y2 = y * y;
    let y4 = y2 * y2;
    let y6 = y4 * y2;
    return 1.0 + 4.9348 * y2 + 4.0587 * y4 + 1.5642 * y6;
  }
  return 1.0;
}

// Overloads to scale offsets (meters to world units)
fn project_size_float(meters: f32) -> f32 {
  return meters * project.commonUnitsPerMeter.z * project_size();
}

fn project_size_vec2(meters: vec2<f32>) -> vec2<f32> {
  return meters * project.commonUnitsPerMeter.xy * project_size();
}

fn project_size_vec3(meters: vec3<f32>) -> vec3<f32> {
  return meters * project.commonUnitsPerMeter * project_size();
}

fn project_size_vec4(meters: vec4<f32>) -> vec4<f32> {
  return vec4<f32>(meters.xyz * project.commonUnitsPerMeter, meters.w);
}

// Returns a rotation matrix aligning the z‑axis with the given up vector.
fn project_get_orientation_matrix(up: vec3<f32>) -> mat3x3<f32> {
  let uz = normalize(up);
  let ux = select(
    vec3<f32>(1.0, 0.0, 0.0),
    normalize(vec3<f32>(uz.y, -uz.x, 0.0)),
    abs(uz.z) == 1.0
  );
  let uy = cross(uz, ux);
  return mat3x3<f32>(ux, uy, uz);
}

// Since WGSL does not support "out" parameters, we return a struct.
struct RotationResult {
  needsRotation: bool,
  transform: mat3x3<f32>,
};

fn project_needs_rotation(commonPosition: vec3<f32>) -> RotationResult {
  if (project.projectionMode == PROJECTION_MODE_GLOBE) {
    return RotationResult(true, project_get_orientation_matrix(commonPosition));
  } else {
    return RotationResult(false, mat3x3<f32>());  // identity alternative if needed
  };
}

// Projects a normal vector from the current coordinate system to world space.
fn project_normal(vector: vec3<f32>) -> vec3<f32> {
  let normal_modelspace = project.modelMatrix * vec4<f32>(vector, 0.0);
  var n = normalize(normal_modelspace.xyz * project.commonUnitsPerMeter);
  let rotResult = project_needs_rotation(geometry.position.xyz);
  if (rotResult.needsRotation) {
    n = rotResult.transform * n;
  }
  return n;
}

// Applies a scale offset based on y-offset (dy)
fn project_offset_(offset: vec4<f32>) -> vec4<f32> {
  let dy: f32 = offset.y;
  let commonUnitsPerWorldUnit = project.commonUnitsPerWorldUnit + project.commonUnitsPerWorldUnit2 * dy;
  return vec4<f32>(offset.xyz * commonUnitsPerWorldUnit, offset.w);
}

// Projects lng/lat coordinates to a unit tile [0,1]
fn project_mercator_(lnglat: vec2<f32>) -> vec2<f32> {
  var x = lnglat.x;
  if (project.wrapLongitude != 0) {
    x = ((x + 180.0) % 360.0) - 180.0;
  }
  let y = clamp(lnglat.y, -89.9, 89.9);
  return vec2<f32>(
    radians(x) + PI,
    PI + log(tan_fp32(PI * 0.25 + radians(y) * 0.5))
  ) * WORLD_SCALE;
}

// Projects lng/lat/z coordinates for a globe projection.
fn project_globe_(lnglatz: vec3<f32>) -> vec3<f32> {
  let lambda = radians(lnglatz.x);
  let phi = radians(lnglatz.y);
  let cosPhi = cos(phi);
  let D = (lnglatz.z / EARTH_RADIUS + 1.0) * GLOBE_RADIUS;
  return vec3<f32>(
    sin(lambda) * cosPhi,
    -cos(lambda) * cosPhi,
    sin(phi)
  ) * D;
}

// Mercator y of project_mercator_'s latitude clamp: log(tan(PI / 4 + radians(89.9) / 2))
const MAX_MERCATOR_Y: f32 = 7.0439589847;

// Inverse of project_globe_ followed by project_mercator_, without forming lat/lng:
// Mercator y = atanh(sin(lat)) = log((D + |z|) / |xy|), which stays accurate near the poles
fn project_globe_to_mercator_(spherePos: vec3<f32>) -> vec2<f32> {
  let D = length(spherePos);
  let h = max(length(spherePos.xy), 1e-20);
  let y = sign(spherePos.z) * min(log((D + abs(spherePos.z)) / h), MAX_MERCATOR_Y);
  let x = atan2(spherePos.x, -spherePos.y);
  return (vec2<f32>(x, y) + PI) * WORLD_SCALE;
}

// Flat common space (Mercator or cartesian) of a common position; identity except under GLOBE.
// WGSL has no function overloading: pass position.xyz for a vec4. See project.glsl.ts.
fn project_common_position_to_flat(commonPosition: vec3<f32>) -> vec2<f32> {
  if (project.projectionMode == PROJECTION_MODE_GLOBE) {
    return project_globe_to_mercator_(commonPosition);
  }
  return commonPosition.xy;
}

// World copy of a flat x nearest to referenceX
fn project_wrap_flat_x_(x: f32, referenceX: f32) -> f32 {
  return x - TILE_SIZE * floor((x - referenceX) / TILE_SIZE + 0.5);
}

// Flat position in the world copy nearest to referenceX (e.g. a bounds centre); geospatial only
fn project_common_position_to_flat_wrapped(commonPosition: vec3<f32>, referenceX: f32) -> vec2<f32> {
  var flatPosition = project_common_position_to_flat(commonPosition);
  if (project.projectionMode != PROJECTION_MODE_IDENTITY) {
    flatPosition.x = project_wrap_flat_x_(flatPosition.x, referenceX);
  }
  return flatPosition;
}

// Flat position continuous across the antimeridian under GLOBE (seam moved opposite referenceX,
// e.g. the camera); identity for flat modes. For periodic patterns.
fn project_common_position_to_flat_continuous(commonPosition: vec3<f32>, referenceX: f32) -> vec2<f32> {
  var flatPosition = project_common_position_to_flat(commonPosition);
  if (project.projectionMode == PROJECTION_MODE_GLOBE) {
    flatPosition.x = project_wrap_flat_x_(flatPosition.x, referenceX);
  }
  return flatPosition;
}

// Projects positions (with an optional 64-bit low part) from the input
// coordinate system to the common space.
fn project_position_vec4_f64(position: vec4<f32>, position64Low: vec3<f32>) -> vec4<f32> {
  var position_world = project.modelMatrix * position;

  // Work around for a Mac+NVIDIA bug:
  if (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR) {
    if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT) {
      return vec4<f32>(
        project_mercator_(position_world.xy),
        _project_size_at_latitude_m(position_world.z, position_world.y),
        position_world.w
      );
    }
    if (project.coordinateSystem == COORDINATE_SYSTEM_CARTESIAN) {
      position_world = vec4f(position_world.xyz + project.coordinateOrigin, position_world.w);
    }
  }
  if (project.projectionMode == PROJECTION_MODE_GLOBE) {
    if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT) {
      return vec4<f32>(
        project_globe_(position_world.xyz),
        position_world.w
      );
    }
    if (project.coordinateSystem == COORDINATE_SYSTEM_METER_OFFSETS) {
      let enuMatrix = project_get_orientation_matrix(project.commonOrigin);
      let metersToCommon = GLOBE_RADIUS / EARTH_RADIUS;
      let offsetCommon = (enuMatrix * vec3<f32>(-position_world.x, -position_world.y, position_world.z)) * metersToCommon;
      return vec4<f32>(project.commonOrigin + offsetCommon, position_world.w);
    }
  }
  if (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR_AUTO_OFFSET) {
    if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT) {
      if (abs(position_world.y - project.coordinateOrigin.y) > 0.25) {
        return vec4<f32>(
          project_mercator_(position_world.xy) - project.commonOrigin.xy,
          project_size_float(position_world.z),
          position_world.w
        );
      }
    }
  }
  if (project.projectionMode == PROJECTION_MODE_IDENTITY ||
      (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR_AUTO_OFFSET &&
       (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT ||
        project.coordinateSystem == COORDINATE_SYSTEM_CARTESIAN))) {
    position_world = vec4f(position_world.xyz - project.coordinateOrigin, position_world.w);
  }

  return project_offset_(position_world) +
         project_offset_(project.modelMatrix * vec4<f32>(position64Low, 0.0));
}

// Overloaded versions for different input types.
fn project_position_vec4_f32(position: vec4<f32>) -> vec4<f32> {
  return project_position_vec4_f64(position, ZERO_64_LOW);
}

fn project_position_vec3_f64(position: vec3<f32>, position64Low: vec3<f32>) -> vec3<f32> {
  let projected_position = project_position_vec4_f64(vec4<f32>(position, 1.0), position64Low);
  return projected_position.xyz;
}

fn project_position_vec3_f32(position: vec3<f32>) -> vec3<f32> {
  let projected_position = project_position_vec4_f64(vec4<f32>(position, 1.0), ZERO_64_LOW);
  return projected_position.xyz;
}

fn project_position_vec2_f32(position: vec2<f32>) -> vec2<f32> {
  let projected_position = project_position_vec4_f64(vec4<f32>(position, 0.0, 1.0), ZERO_64_LOW);
  return projected_position.xy;
}

// Transforms a common space position to clip space.
fn project_common_position_to_clipspace_with_projection(position: vec4<f32>, viewProjectionMatrix: mat4x4<f32>, center: vec4<f32>) -> vec4<f32> {
  var clipPosition = viewProjectionMatrix * position + center;
  // deck.gl projection matrices use WebGL's [-w, w] depth range; WebGPU clips z to [0, w].
  clipPosition.z = (clipPosition.z + clipPosition.w) * 0.5;
  return clipPosition;
}

// Uses the project viewProjectionMatrix and center.
fn project_common_position_to_clipspace(position: vec4<f32>) -> vec4<f32> {
  return project_common_position_to_clipspace_with_projection(position, project.viewProjectionMatrix, project.center);
}

// Returns a clip space offset corresponding to a given number of screen pixels.
fn project_pixel_size_to_clipspace(pixels: vec2<f32>) -> vec2<f32> {
  let offset = pixels / project.viewportSize * project.devicePixelRatio * 2.0;
  return offset * project.focalDistance;
}

fn project_meter_size_to_pixel(meters: f32) -> f32 {
  return project_size_float(meters) * project.scale;
}

fn project_unit_size_to_pixel(size: f32, unit: i32) -> f32 {
  if (unit == UNIT_METERS) {
    return project_meter_size_to_pixel(size);
  } else if (unit == UNIT_COMMON) {
    return size * project.scale;
  }
  // UNIT_PIXELS: no scaling applied.
  return size;
}

fn project_pixel_size_float(pixels: f32) -> f32 {
  return pixels / project.scale;
}

fn project_pixel_size_vec2(pixels: vec2<f32>) -> vec2<f32> {
  return pixels / project.scale;
}
`,vS=["default","lnglat","meter-offsets","lnglat-offsets","cartesian"],wS=vS.map(i=>`const int COORDINATE_SYSTEM_${i.toUpperCase().replaceAll("-","_")} = ${Gr(i)};`).join(""),xS=Object.keys(xe).map(i=>`const int PROJECTION_MODE_${i} = ${xe[i]};`).join(""),PS=Object.keys(at).map(i=>`const int UNIT_${i.toUpperCase()} = ${at[i]};`).join(""),SS=`${wS}
${xS}
${PS}
layout(std140) uniform projectUniforms {
bool wrapLongitude;
int coordinateSystem;
vec3 commonUnitsPerMeter;
int projectionMode;
float scale;
vec3 commonUnitsPerWorldUnit;
vec3 commonUnitsPerWorldUnit2;
vec4 center;
mat4 modelMatrix;
mat4 viewProjectionMatrix;
vec2 viewportSize;
float devicePixelRatio;
float focalDistance;
vec3 cameraPosition;
vec3 coordinateOrigin;
vec3 commonOrigin;
bool pseudoMeters;
} project;
const float TILE_SIZE = 512.0;
const float PI = 3.1415926536;
const float WORLD_SCALE = TILE_SIZE / (PI * 2.0);
const vec3 ZERO_64_LOW = vec3(0.0);
const float EARTH_RADIUS = 6370972.0;
const float GLOBE_RADIUS = 256.0;
float project_size_at_latitude(float lat) {
float y = clamp(lat, -89.9, 89.9);
return 1.0 / cos(radians(y));
}
float project_size() {
if (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR &&
project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT &&
project.pseudoMeters == false) {
if (geometry.position.w == 0.0) {
return project_size_at_latitude(geometry.worldPosition.y);
}
float y = geometry.position.y / TILE_SIZE * 2.0 - 1.0;
float y2 = y * y;
float y4 = y2 * y2;
float y6 = y4 * y2;
return 1.0 + 4.9348 * y2 + 4.0587 * y4 + 1.5642 * y6;
}
return 1.0;
}
float project_size_at_latitude(float meters, float lat) {
return meters * project.commonUnitsPerMeter.z * project_size_at_latitude(lat);
}
float project_size(float meters) {
return meters * project.commonUnitsPerMeter.z * project_size();
}
vec2 project_size(vec2 meters) {
return meters * project.commonUnitsPerMeter.xy * project_size();
}
vec3 project_size(vec3 meters) {
return meters * project.commonUnitsPerMeter * project_size();
}
vec4 project_size(vec4 meters) {
return vec4(meters.xyz * project.commonUnitsPerMeter, meters.w);
}
mat3 project_get_orientation_matrix(vec3 up) {
vec3 uz = normalize(up);
vec3 ux = abs(uz.z) == 1.0 ? vec3(1.0, 0.0, 0.0) : normalize(vec3(uz.y, -uz.x, 0));
vec3 uy = cross(uz, ux);
return mat3(ux, uy, uz);
}
bool project_needs_rotation(vec3 commonPosition, out mat3 transform) {
if (project.projectionMode == PROJECTION_MODE_GLOBE) {
transform = project_get_orientation_matrix(commonPosition);
return true;
}
return false;
}
vec3 project_normal(vec3 vector) {
vec4 normal_modelspace = project.modelMatrix * vec4(vector, 0.0);
vec3 n = normalize(normal_modelspace.xyz * project.commonUnitsPerMeter);
mat3 rotation;
if (project_needs_rotation(geometry.position.xyz, rotation)) {
n = rotation * n;
}
return n;
}
vec4 project_offset_(vec4 offset) {
float dy = offset.y;
vec3 commonUnitsPerWorldUnit = project.commonUnitsPerWorldUnit + project.commonUnitsPerWorldUnit2 * dy;
return vec4(offset.xyz * commonUnitsPerWorldUnit, offset.w);
}
vec2 project_mercator_(vec2 lnglat) {
float x = lnglat.x;
if (project.wrapLongitude) {
x = mod(x + 180., 360.0) - 180.;
}
float y = clamp(lnglat.y, -89.9, 89.9);
return vec2(
radians(x) + PI,
PI + log(tan_fp32(PI * 0.25 + radians(y) * 0.5))
) * WORLD_SCALE;
}
vec3 project_globe_(vec3 lnglatz) {
float lambda = radians(lnglatz.x);
float phi = radians(lnglatz.y);
float cosPhi = cos(phi);
float D = (lnglatz.z / EARTH_RADIUS + 1.0) * GLOBE_RADIUS;
return vec3(
sin(lambda) * cosPhi,
-cos(lambda) * cosPhi,
sin(phi)
) * D;
}
const float MAX_MERCATOR_Y = 7.0439589847;
vec2 project_globe_to_mercator_(vec3 spherePos) {
float D = length(spherePos);
float h = max(length(spherePos.xy), 1e-20);
float y = sign(spherePos.z) * min(log((D + abs(spherePos.z)) / h), MAX_MERCATOR_Y);
float x = atan(spherePos.x, -spherePos.y);
return (vec2(x, y) + PI) * WORLD_SCALE;
}
vec2 project_common_position_to_flat(vec3 commonPosition) {
if (project.projectionMode == PROJECTION_MODE_GLOBE) {
return project_globe_to_mercator_(commonPosition);
}
return commonPosition.xy;
}
vec2 project_common_position_to_flat(vec4 commonPosition) {
return project_common_position_to_flat(commonPosition.xyz);
}
float project_wrap_flat_x_(float x, float referenceX) {
return x - TILE_SIZE * floor((x - referenceX) / TILE_SIZE + 0.5);
}
vec2 project_common_position_to_flat_wrapped(vec3 commonPosition, float referenceX) {
vec2 flatPosition = project_common_position_to_flat(commonPosition);
if (project.projectionMode != PROJECTION_MODE_IDENTITY) {
flatPosition.x = project_wrap_flat_x_(flatPosition.x, referenceX);
}
return flatPosition;
}
vec2 project_common_position_to_flat_wrapped(vec4 commonPosition, float referenceX) {
return project_common_position_to_flat_wrapped(commonPosition.xyz, referenceX);
}
vec2 project_common_position_to_flat_continuous(vec3 commonPosition, float referenceX) {
vec2 flatPosition = project_common_position_to_flat(commonPosition);
if (project.projectionMode == PROJECTION_MODE_GLOBE) {
flatPosition.x = project_wrap_flat_x_(flatPosition.x, referenceX);
}
return flatPosition;
}
vec2 project_common_position_to_flat_continuous(vec4 commonPosition, float referenceX) {
return project_common_position_to_flat_continuous(commonPosition.xyz, referenceX);
}
vec4 project_position(vec4 position, vec3 position64Low) {
vec4 position_world = project.modelMatrix * position;
if (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR) {
if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT) {
return vec4(
project_mercator_(position_world.xy),
project_size_at_latitude(position_world.z, position_world.y),
position_world.w
);
}
if (project.coordinateSystem == COORDINATE_SYSTEM_CARTESIAN) {
position_world.xyz += project.coordinateOrigin;
}
}
if (project.projectionMode == PROJECTION_MODE_GLOBE) {
if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT) {
return vec4(
project_globe_(position_world.xyz),
position_world.w
);
}
if (project.coordinateSystem == COORDINATE_SYSTEM_METER_OFFSETS) {
mat3 enuMatrix = project_get_orientation_matrix(project.commonOrigin);
float metersToCommon = GLOBE_RADIUS / EARTH_RADIUS;
vec3 offsetCommon = (enuMatrix * vec3(-position_world.xy, position_world.z)) * metersToCommon;
return vec4(project.commonOrigin + offsetCommon, position_world.w);
}
}
if (project.projectionMode == PROJECTION_MODE_WEB_MERCATOR_AUTO_OFFSET) {
if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT) {
if (abs(position_world.y - project.coordinateOrigin.y) > 0.25) {
return vec4(
project_mercator_(position_world.xy) - project.commonOrigin.xy,
project_size(position_world.z),
position_world.w
);
}
}
}
if (project.projectionMode == PROJECTION_MODE_IDENTITY ||
(project.projectionMode == PROJECTION_MODE_WEB_MERCATOR_AUTO_OFFSET &&
(project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT ||
project.coordinateSystem == COORDINATE_SYSTEM_CARTESIAN))) {
position_world.xyz -= project.coordinateOrigin;
}
return project_offset_(position_world) + project_offset_(project.modelMatrix * vec4(position64Low, 0.0));
}
vec4 project_position(vec4 position) {
return project_position(position, ZERO_64_LOW);
}
vec3 project_position(vec3 position, vec3 position64Low) {
vec4 projected_position = project_position(vec4(position, 1.0), position64Low);
return projected_position.xyz;
}
vec3 project_position(vec3 position) {
vec4 projected_position = project_position(vec4(position, 1.0), ZERO_64_LOW);
return projected_position.xyz;
}
vec2 project_position(vec2 position) {
vec4 projected_position = project_position(vec4(position, 0.0, 1.0), ZERO_64_LOW);
return projected_position.xy;
}
vec4 project_common_position_to_clipspace(vec4 position, mat4 viewProjectionMatrix, vec4 center) {
return viewProjectionMatrix * position + center;
}
vec4 project_common_position_to_clipspace(vec4 position) {
return project_common_position_to_clipspace(position, project.viewProjectionMatrix, project.center);
}
vec2 project_pixel_size_to_clipspace(vec2 pixels) {
vec2 offset = pixels / project.viewportSize * project.devicePixelRatio * 2.0;
return offset * project.focalDistance;
}
float project_size_to_pixel(float meters) {
return project_size(meters) * project.scale;
}
vec2 project_size_to_pixel(vec2 meters) {
return project_size(meters) * project.scale;
}
float project_size_to_pixel(float size, int unit) {
if (unit == UNIT_METERS) return project_size_to_pixel(size);
if (unit == UNIT_COMMON) return size * project.scale;
return size;
}
float project_pixel_size(float pixels) {
return pixels / project.scale;
}
vec2 project_pixel_size(vec2 pixels) {
return pixels / project.scale;
}
`,ES={};function CS(i=ES){return"viewport"in i?dS(i):{}}const jr={name:"project",dependencies:[mP,bg],source:bS,vs:SS,getUniforms:CS,uniformTypes:{wrapLongitude:"f32",coordinateSystem:"i32",commonUnitsPerMeter:"vec3<f32>",projectionMode:"i32",scale:"f32",commonUnitsPerWorldUnit:"vec3<f32>",commonUnitsPerWorldUnit2:"vec3<f32>",center:"vec4<f32>",modelMatrix:"mat4x4<f32>",viewProjectionMatrix:"mat4x4<f32>",viewportSize:"vec2<f32>",devicePixelRatio:"f32",focalDistance:"f32",cameraPosition:"vec3<f32>",coordinateOrigin:"vec3<f32>",commonOrigin:"vec3<f32>",pseudoMeters:"f32"}},LS=`// Define a structure to hold both the clip-space position and the common position.
struct ProjectResult {
  clipPosition: vec4<f32>,
  commonPosition: vec4<f32>,
};

// This function mimics the GLSL version with the 'out' parameter by returning both values.
fn project_position_to_clipspace_and_commonspace(
    position: vec3<f32>,
    position64Low: vec3<f32>,
    offset: vec3<f32>
) -> ProjectResult {
  // Compute the projected position.
  let projectedPosition: vec3<f32> = project_position_vec3_f64(position, position64Low);

  // Start with the provided offset.
  var finalOffset: vec3<f32> = offset;

  // Get whether a rotation is needed and the rotation matrix.
  let rotationResult = project_needs_rotation(projectedPosition);

  // If rotation is needed, update the offset.
  if (rotationResult.needsRotation) {
    finalOffset = rotationResult.transform * offset;
  }

  // Compute the common position.
  let commonPosition: vec4<f32> = vec4<f32>(projectedPosition + finalOffset, 1.0);

  // Convert to clip-space.
  let clipPosition: vec4<f32> = project_common_position_to_clipspace(commonPosition);

  return ProjectResult(clipPosition, commonPosition);
}

// A convenience overload that returns only the clip-space position.
fn project_position_to_clipspace(
    position: vec3<f32>,
    position64Low: vec3<f32>,
    offset: vec3<f32>
) -> vec4<f32> {
  return project_position_to_clipspace_and_commonspace(position, position64Low, offset).clipPosition;
}
`,TS=`vec4 project_position_to_clipspace(
  vec3 position, vec3 position64Low, vec3 offset, out vec4 commonPosition
) {
  vec3 projectedPosition = project_position(position, position64Low);
  mat3 rotation;
  if (project_needs_rotation(projectedPosition, rotation)) {
    // offset is specified as ENU
    // when in globe projection, rotate offset so that the ground alighs with the surface of the globe
    offset = rotation * offset;
  }
  commonPosition = vec4(projectedPosition + offset, 1.0);
  return project_common_position_to_clipspace(commonPosition);
}

vec4 project_position_to_clipspace(
  vec3 position, vec3 position64Low, vec3 offset
) {
  vec4 commonPosition;
  return project_position_to_clipspace(position, position64Low, offset, commonPosition);
}
`,Dn={name:"project32",dependencies:[jr],source:LS,vs:TS};function AS(){return[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}function li(i,e){const t=Ti([],e,i);return Qc(t,t,1/t[3]),t}function Va(i,e,t){return i<e?e:i>t?t:i}function MS(i){return Math.log(i)*Math.LOG2E}const Cg=Math.log2||MS;function ct(i,e){if(!i)throw new Error(e||"@math.gl/web-mercator: assertion failed.")}const ze=Math.PI,Lg=ze/4,Be=ze/180,Wa=180/ze,yi=512,ir=4003e4,Ke=85.051129,IS=1.5;function RS(i){return Cg(i)}function bi(i){const[e,t]=i;ct(Number.isFinite(e)),ct(Number.isFinite(t)&&t>=-90&&t<=90,"invalid latitude");const n=e*Be,s=t*Be,r=yi*(n+ze)/(2*ze),o=yi*(ze+Math.log(Math.tan(Lg+s*.5)))/(2*ze);return[r,o]}function Fn(i){const[e,t]=i,n=e/yi*(2*ze)-ze,s=2*(Math.atan(Math.exp(t/yi*(2*ze)-ze))-Lg);return[n*Wa,s*Wa]}function OS(i){const{latitude:e}=i;ct(Number.isFinite(e));const t=Math.cos(e*Be);return RS(ir*t)-9}function So(i){const e=Math.cos(i*Be);return yi/ir/e}function Ha(i){const{latitude:e,longitude:t,highPrecision:n=!1}=i;ct(Number.isFinite(e)&&Number.isFinite(t));const s=yi,r=Math.cos(e*Be),o=s/360,a=o/r,c=s/ir/r,l={unitsPerMeter:[c,c,c],metersPerUnit:[1/c,1/c,1/c],unitsPerDegree:[o,a,c],degreesPerUnit:[1/o,1/a,1/c]};if(n){const u=Be*Math.tan(e*Be)/r,f=o*u/2,d=s/ir*u,g=d/a*c;l.unitsPerDegree2=[0,f,d],l.unitsPerMeter2=[g,0,g]}return l}function Tg(i,e){const[t,n,s]=i,[r,o,a]=e,{unitsPerMeter:c,unitsPerMeter2:l}=Ha({longitude:t,latitude:n,highPrecision:!0}),u=bi(i);u[0]+=r*(c[0]+l[0]*o),u[1]+=o*(c[1]+l[1]*o);const f=Fn(u),d=(s||0)+(a||0);return Number.isFinite(s)||Number.isFinite(a)?[f[0],f[1],d]:f}function BS(i){const{height:e,pitch:t,bearing:n,altitude:s,scale:r,center:o}=i,a=AS();Js(a,a,[0,0,-s]),cg(a,a,-t*Be),lg(a,a,n*Be);const c=r/e;return Kc(a,a,[c,c,c]),o&&Js(a,a,gx([],o)),a}function kS(i){const{width:e,height:t,altitude:n,pitch:s=0,offset:r,center:o,scale:a,nearZMultiplier:c=1,farZMultiplier:l=1}=i;let{fovy:u=wn(IS)}=i;n!==void 0&&(u=wn(n));const f=u*Be,d=s*Be,g=il(u);let p=g;o&&(p+=o[2]*a/Math.cos(d)/t);const m=f*(.5+(r?r[1]:0)/t),_=Math.sin(m)*p/Math.sin(Va(Math.PI/2-d-m,.01,Math.PI-.01)),v=Math.sin(d)*_+p,w=p*10,y=Math.min(v*l,w);return{fov:f,aspect:e/t,focalDistance:g,near:c,far:y}}function wn(i){return 2*Math.atan(.5/i)*Wa}function il(i){return .5/Math.tan(.5*i*Be)}function nl(i,e){const[t,n,s=0]=i;return ct(Number.isFinite(t)&&Number.isFinite(n)&&Number.isFinite(s)),li(e,[t,n,s,1])}function nr(i,e,t=0){const[n,s,r]=i;if(ct(Number.isFinite(n)&&Number.isFinite(s),"invalid pixel coordinate"),Number.isFinite(r))return li(e,[n,s,r,1]);const o=li(e,[n,s,0,1]),a=li(e,[n,s,1,1]),c=o[2],l=a[2],u=c===l?0:((t||0)-c)/(l-c);return ig([],o,a,u)}function DS(i){const{width:e,height:t,bounds:n,minExtent:s=0,maxZoom:r=24,offset:o=[0,0]}=i,[[a,c],[l,u]]=n,f=FS(i.padding),d=bi([a,Va(u,-Ke,Ke)]),g=bi([l,Va(c,-Ke,Ke)]),p=[Math.max(Math.abs(g[0]-d[0]),s),Math.max(Math.abs(g[1]-d[1]),s)],m=[e-f.left-f.right-Math.abs(o[0])*2,t-f.top-f.bottom-Math.abs(o[1])*2];ct(m[0]>0&&m[1]>0);const _=m[0]/p[0],v=m[1]/p[1],w=(f.right-f.left)/2/_,y=(f.top-f.bottom)/2/v,x=[(g[0]+d[0])/2+w,(g[1]+d[1])/2+y],S=Fn(x),C=Math.min(r,Cg(Math.abs(Math.min(_,v))));return ct(Number.isFinite(C)),{longitude:S[0],latitude:S[1],zoom:C}}function FS(i=0){return typeof i=="number"?{top:i,bottom:i,left:i,right:i}:(ct(Number.isFinite(i.top)&&Number.isFinite(i.bottom)&&Number.isFinite(i.left)&&Number.isFinite(i.right)),i)}const Yu=Math.PI/180;function zS(i,e=0){const{width:t,height:n,unproject:s}=i,r={targetZ:e},o=s([0,n],r),a=s([t,n],r);let c,l;const u=i.fovy?.5*i.fovy*Yu:Math.atan(.5/i.altitude),f=(90-i.pitch)*Yu;return u>f-.01?(c=qu(i,0,e),l=qu(i,t,e)):(c=s([0,0],r),l=s([t,0],r)),[o,a,l,c]}function qu(i,e,t){const{pixelUnprojectionMatrix:n}=i,s=li(n,[e,0,1,1]),r=li(n,[e,i.height,1,1]),a=(t*i.distanceScales.unitsPerMeter[2]-s[2])/(r[2]-s[2]),c=ig([],s,r,a),l=Fn(c);return l.push(t),l}const Ag=`
layout(std140) uniform shadowUniforms {
  bool drawShadowMap;
  bool useShadowMap;
  vec4 color;
  highp int lightId;
  float lightCount;
  mat4 viewProjectionMatrix0;
  mat4 viewProjectionMatrix1;
  vec4 projectCenter0;
  vec4 projectCenter1;
} shadow;
`,NS=`
const int max_lights = 2;

out vec3 shadow_vPosition[max_lights];

vec4 shadow_setVertexPosition(vec4 position_commonspace) {
  mat4 viewProjectionMatrices[max_lights];
  viewProjectionMatrices[0] = shadow.viewProjectionMatrix0;
  viewProjectionMatrices[1] = shadow.viewProjectionMatrix1;
  vec4 projectCenters[max_lights];
  projectCenters[0] = shadow.projectCenter0;
  projectCenters[1] = shadow.projectCenter1;

  if (shadow.drawShadowMap) {
    return project_common_position_to_clipspace(position_commonspace, viewProjectionMatrices[shadow.lightId], projectCenters[shadow.lightId]);
  }
  if (shadow.useShadowMap) {
    for (int i = 0; i < max_lights; i++) {
      if(i < int(shadow.lightCount)) {
        vec4 shadowMap_position = project_common_position_to_clipspace(position_commonspace, viewProjectionMatrices[i], projectCenters[i]);
        shadow_vPosition[i] = (shadowMap_position.xyz / shadowMap_position.w + 1.0) / 2.0;
      }
    }
  }
  return gl_Position;
}
`,US=`
${Ag}
${NS}
`,$S=`
const int max_lights = 2;
uniform sampler2D shadow_uShadowMap0;
uniform sampler2D shadow_uShadowMap1;

in vec3 shadow_vPosition[max_lights];

const vec4 bitPackShift = vec4(1.0, 255.0, 65025.0, 16581375.0);
const vec4 bitUnpackShift = 1.0 / bitPackShift;
const vec4 bitMask = vec4(1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0,  0.0);

float shadow_getShadowWeight(vec3 position, sampler2D shadowMap) {
  vec4 rgbaDepth = texture(shadowMap, position.xy);

  float z = dot(rgbaDepth, bitUnpackShift);
  return smoothstep(0.001, 0.01, position.z - z);
}

vec4 shadow_filterShadowColor(vec4 color) {
  if (shadow.drawShadowMap) {
    vec4 rgbaDepth = fract(gl_FragCoord.z * bitPackShift);
    rgbaDepth -= rgbaDepth.gbaa * bitMask;
    return rgbaDepth;
  }
  if (shadow.useShadowMap) {
    float shadowAlpha = 0.0;
    shadowAlpha += shadow_getShadowWeight(shadow_vPosition[0], shadow_uShadowMap0);
    if(shadow.lightCount > 1.0) {
      shadowAlpha += shadow_getShadowWeight(shadow_vPosition[1], shadow_uShadowMap1);
    }
    shadowAlpha *= shadow.color.a / shadow.lightCount;
    float blendedAlpha = shadowAlpha + color.a * (1.0 - shadowAlpha);

    return vec4(
      mix(color.rgb, shadow.color.rgb, shadowAlpha / blendedAlpha),
      blendedAlpha
    );
  }
  return color;
}
`,GS=`
${Ag}
${$S}
`,jS=kn(qS),VS=kn(ZS),WS=[0,0,0,1],HS=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0];function YS(i){const{width:e,height:t,pixelUnprojectionMatrix:n}=i,s=[[0,0],[e,0],[e,t],[0,t]],r=s.map(([c,l])=>nr([c,l,-1],n)),o=s.map(([c,l])=>nr([c,l,1],n));if(!i.isGeospatial)return r.concat(o);const a=r.concat(o).filter(c=>c[2]>=0);for(let c=0;c<4;c++){const l=(c+1)%4;for(const[u,f]of[[r[c],o[c]],[r[c],r[l]],[o[c],o[l]]])if(u[2]<0!=f[2]<0){const d=u[2]/(u[2]-f[2]);a.push([u[0]+(f[0]-u[0])*d,u[1]+(f[1]-u[1])*d,0])}}return a.length>0?a:r.concat(o)}function qS({viewport:i,center:e}){return new Ge(i.viewProjectionMatrix).invert().transform(e)}function ZS({viewport:i,shadowMatrices:e}){const t=[],n=YS(i);for(const s of e){const r=s.clone().translate(new tt(i.center).negate()),o=n.map(c=>r.transform(c)),a=new Ge().ortho({left:Math.min(...o.map(c=>c[0])),right:Math.max(...o.map(c=>c[0])),bottom:Math.min(...o.map(c=>c[1])),top:Math.max(...o.map(c=>c[1])),near:Math.min(...o.map(c=>-c[2])),far:Math.max(...o.map(c=>-c[2]))});t.push(a.multiplyRight(s))}return t}function XS(i){const{shadowEnabled:e=!0,project:t}=i;if(!e||!t||!i.shadowMatrices||!i.shadowMatrices.length)return{drawShadowMap:!1,useShadowMap:!1,shadow_uShadowMap0:i.dummyShadowMap,shadow_uShadowMap1:i.dummyShadowMap};const n=jr.getUniforms(t),s=jS({viewport:t.viewport,center:n.center}),r=[],o=VS({shadowMatrices:i.shadowMatrices,viewport:t.viewport}).slice();for(let c=0;c<i.shadowMatrices.length;c++){const l=o[c],u=l.clone().translate(new tt(t.viewport.center).negate());n.coordinateSystem===Gr("lnglat")&&n.projectionMode===xe.WEB_MERCATOR?(o[c]=u,r[c]=s):(o[c]=l.clone().multiplyRight(HS),r[c]=u.transform(s))}const a={drawShadowMap:!!i.drawToShadowMap,useShadowMap:i.shadowMaps?i.shadowMaps.length>0:!1,color:i.shadowColor||WS,lightId:i.shadowLightId||0,lightCount:i.shadowMatrices.length,shadow_uShadowMap0:i.dummyShadowMap,shadow_uShadowMap1:i.dummyShadowMap};for(let c=0;c<o.length;c++)a[`viewProjectionMatrix${c}`]=o[c],a[`projectCenter${c}`]=r[c];for(let c=0;c<2;c++)a[`shadow_uShadowMap${c}`]=i.shadowMaps&&i.shadowMaps[c]||i.dummyShadowMap;return a}const Zu={name:"shadow",dependencies:[jr],vs:US,fs:GS,inject:{"vs:DECKGL_FILTER_GL_POSITION":`
    position = shadow_setVertexPosition(geometry.position);
    `,"fs:DECKGL_FILTER_COLOR":`
    color = shadow_filterShadowColor(color);
    `},getUniforms:XS,uniformTypes:{drawShadowMap:"f32",useShadowMap:"f32",color:"vec4<f32>",lightId:"i32",lightCount:"f32",viewProjectionMatrix0:"mat4x4<f32>",viewProjectionMatrix1:"mat4x4<f32>",projectCenter0:"vec4<f32>",projectCenter1:"vec4<f32>"}},sr=10,rr=16777215;function KS(i,e){i.length===sr?Y.warn(`pickMultipleObjects can only exclude ${sr} previously picked objects for layers without picking buffers`)():i.push(e)}const QS=`  float disabledPickingIndexCount;
  vec4 disabledPickingIndices0;
  vec4 disabledPickingIndices1;
  vec4 disabledPickingIndices2;
`;function Xu(i){return i.replace(`  vec4 highlightColor;
} picking;`,`  vec4 highlightColor;
${QS}} picking;`)}function Eo(i,e){return[i[e]||0,i[e+1]||0,i[e+2]||0,i[e+3]||0]}const JS=`vec3 picking_getPickingColorFromIndex(float objectIndex) {
  if (objectIndex < 0.0 || objectIndex >= ${rr}.0) {
    return vec3(0.0);
  }

  for (int i = 0; i < ${sr}; i++) {
    if (float(i) >= picking.disabledPickingIndexCount) {
      break;
    }
    vec4 disabledIndices = i < 4
      ? picking.disabledPickingIndices0
      : (i < 8 ? picking.disabledPickingIndices1 : picking.disabledPickingIndices2);
    float disabledIndex = disabledIndices[i - (i / 4) * 4];
    if (disabledIndex == objectIndex) {
      return vec3(0.0);
    }
  }

  float encodedIndex = objectIndex + 1.0;
  return vec3(
    mod(encodedIndex, 256.0),
    mod(floor(encodedIndex / 256.0), 256.0),
    mod(floor(encodedIndex / 65536.0), 256.0)
  );
}

vec3 picking_getPickingColorFromIndex(uint objectIndex) {
  return picking_getPickingColorFromIndex(float(objectIndex));
}

vec3 picking_getPickingColorFromInstanceID() {
  return picking_getPickingColorFromIndex(float(gl_InstanceID));
}

void picking_setPickingColorFromInstanceID() {
  picking_setPickingColor(picking_getPickingColorFromInstanceID());
}
`,eE=`struct pickingUniforms {
  isActive: f32,
  isAttribute: f32,
  isHighlightActive: f32,
  useByteColors: f32,
  highlightedObjectColor: vec3<f32>,
  highlightColor: vec4<f32>,
  disabledPickingIndexCount: f32,
  disabledPickingIndices0: vec4<f32>,
  disabledPickingIndices1: vec4<f32>,
  disabledPickingIndices2: vec4<f32>,
};

@group(0) @binding(auto) var<uniform> picking: pickingUniforms;

fn picking_normalizeColor(color: vec3<f32>) -> vec3<f32> {
  return select(color, color / 255.0, picking.useByteColors > 0.5);
}

fn picking_normalizeColor4(color: vec4<f32>) -> vec4<f32> {
  return select(color, color / 255.0, picking.useByteColors > 0.5);
}

fn picking_isColorZero(color: vec3<f32>) -> bool {
  return dot(color, vec3<f32>(1.0)) < 0.00001;
}

fn picking_isColorValid(color: vec3<f32>) -> bool {
  return dot(color, vec3<f32>(1.0)) > 0.00001;
}

fn picking_getPickingColorFromIndex(objectIndex: u32) -> vec3<f32> {
  if (objectIndex >= ${rr}u) {
    return vec3<f32>(0.0);
  }

  for (var i = 0; i < ${sr}; i = i + 1) {
    if (f32(i) >= picking.disabledPickingIndexCount) {
      break;
    }
    let disabledIndices = select(
      picking.disabledPickingIndices2,
      select(picking.disabledPickingIndices1, picking.disabledPickingIndices0, i < 4),
      i < 8
    );
    let disabledIndex = disabledIndices[i % 4];
    if (disabledIndex == f32(objectIndex)) {
      return vec3<f32>(0.0);
    }
  }

  let encodedIndex = objectIndex + 1u;
  return vec3<f32>(
    f32(encodedIndex % 256u),
    f32((encodedIndex / 256u) % 256u),
    f32((encodedIndex / 65536u) % 256u)
  ) / 255.0;
}
`,zn={...Xt,vs:`${Xu(Xt.vs)}
${JS}`,fs:Xu(Xt.fs),source:eE,uniformTypes:{...Xt.uniformTypes,disabledPickingIndexCount:"f32",disabledPickingIndices0:"vec4<f32>",disabledPickingIndices1:"vec4<f32>",disabledPickingIndices2:"vec4<f32>"},defaultUniforms:{...Xt.defaultUniforms,useByteColors:!0,disabledPickingIndexCount:0,disabledPickingIndices0:[0,0,0,0],disabledPickingIndices1:[0,0,0,0],disabledPickingIndices2:[0,0,0,0]},getUniforms(i,e){const t=Xt.getUniforms(i),n=i.disabledPickingIndices||[];return t.disabledPickingIndexCount=n.length,t.disabledPickingIndices0=Eo(n,0),t.disabledPickingIndices1=Eo(n,4),t.disabledPickingIndices2=Eo(n,8),t},inject:{"vs:DECKGL_FILTER_GL_POSITION":`
    // for picking depth values
    picking_setPickingAttribute(position.z / position.w);
  `,"vs:DECKGL_FILTER_COLOR":`
  picking_setPickingColor(geometry.pickingColor);
  `,"fs:DECKGL_FILTER_COLOR":{order:99,injection:`
  // use highlight color if this fragment belongs to the selected object.
  color = picking_filterHighlightColor(color);

  // use picking color if rendering to picking FBO.
  color = picking_filterPickingColor(color);
    `}}},tE=[bg],iE=["vs:DECKGL_FILTER_SIZE(inout vec3 size, VertexGeometry geometry)","vs:DECKGL_FILTER_GL_POSITION(inout vec4 position, VertexGeometry geometry)","vs:DECKGL_FILTER_COLOR(inout vec4 color, VertexGeometry geometry)","fs:DECKGL_FILTER_COLOR(inout vec4 color, FragmentGeometry geometry)"],nE=[];function sE(i){const e=vt.getDefaultShaderAssembler(i);for(const n of tE)e.addDefaultModule(n);e._hookFunctions.length=0;const t=i==="glsl"?iE:nE;for(const n of t)e.addShaderHook(n);return e}const rE=[255,255,255],oE=1;let aE=0;class Mg{constructor(e={}){this.type="ambient";const{color:t=rE}=e,{intensity:n=oE}=e;this.id=e.id||`ambient-${aE++}`,this.color=t,this.intensity=n}}const cE=[255,255,255],lE=1,uE=[0,0,-1];let fE=0;class Ya{constructor(e={}){this.type="directional";const{color:t=cE}=e,{intensity:n=lE}=e,{direction:s=uE}=e,{_shadow:r=!1}=e;this.id=e.id||`directional-${fE++}`,this.color=t,this.intensity=n,this.type="directional",this.direction=new tt(s).normalize().toArray(),this.shadow=r}getProjectedLight(e){return this}}class dE{constructor(e,t={id:"pass"}){const{id:n}=t;this.id=n,this.device=e,this.props={...t}}setProps(e){Object.assign(this.props,e)}render(e){}cleanup(){}}const hE={depthWriteEnabled:!0,depthCompare:"less-equal",blendColorOperation:"add",blendColorSrcFactor:"one",blendColorDstFactor:"one-minus-src-alpha",blendAlphaOperation:"add",blendAlphaSrcFactor:"one",blendAlphaDstFactor:"one-minus-src-alpha"};class sl extends dE{constructor(){super(...arguments),this._lastRenderIndex=-1}render(e){this._render(e)}_render(e){const{canvasContext:t=this.device.canvasContext}=e,n=e.target??t.getCurrentFramebuffer(),[s,r]=t.getDrawingBufferSize(),o=e.clearCanvas??!0;let a=e.clearColor??(o?[0,0,0,0]:!1),c=o?1:!1,l=o?0:!1;const u=e.colorMask??15,f={viewport:[0,0,s,r]};e.colorMask&&(f.colorMask=u),e.scissorRect&&(f.scissorRect=e.scissorRect);const{shaderModuleProps:d,viewports:g,views:p,onViewportActive:m,clearStack:_=!0}=e,v=e.pass||"unknown",w=this.device.type==="webgpu";_&&(this._lastRenderIndex=-1);const y=[];if(!g.length)return this.device.beginRenderPass({framebuffer:n,parameters:f,clearColor:a,clearDepth:c,clearStencil:l}).end(),this.device.submit(),y;try{for(const x of g){m==null||m(x);const S=this._getDrawLayerParams(x,e),C=p&&p[x.id],O=x.subViewports||[x],B=w?O.map(D=>[D]):[O];for(const D of B){const k=this.device.beginRenderPass({framebuffer:n,parameters:f,clearColor:a,clearDepth:c,clearStencil:l});try{for(const N of D){const F=this._drawLayersInViewport(k,{target:n,canvasContext:t,shaderModuleProps:d,viewport:N,view:C,pass:v,layers:e.layers,isPicking:e.isPicking},S);y.push(F)}}finally{k.end(),w&&this.device.submit()}a=!1,c=!1,l=!1}}return y}finally{w||this.device.submit()}}_getDrawLayerParams(e,{layers:t,pass:n,isPicking:s=!1,layerFilter:r,cullRect:o,views:a,effects:c,canvasContext:l=this.device.canvasContext,shaderModuleProps:u},f=!1){var _,v;const d=[],g=Ig(this._lastRenderIndex+1),p={layer:t[0],viewport:e,isPicking:s,renderPass:n,cullRect:o},m={};for(let w=0;w<t.length;w++){const y=t[w],x=this._shouldDrawLayer(y,p,r,m),S={shouldDrawLayer:x};if(x&&!f){S.shouldDrawLayer=!0,S.layerRenderIndex=g(y,x),S.shaderModuleProps=this._getShaderModuleProps(y,c,n,l,u);const C=y.context.device.type==="webgpu"?hE:null;S.layerParameters={...C,...(_=y.context.deck)==null?void 0:_.props.parameters,...(v=a==null?void 0:a[e.id])==null?void 0:v.props.parameters,...this.getLayerParameters(y,w,e)}}d[w]=S}return d}_drawLayersInViewport(e,{layers:t,shaderModuleProps:n,pass:s,target:r,canvasContext:o,viewport:a,view:c,isPicking:l},u){const f=gE(this.device,{canvasContext:o,shaderModuleProps:n,target:r,viewport:a});if(c){const{clear:g,clearColor:p,clearDepth:m,clearStencil:_}=c.props;if(g){let v=[0,0,0,0],w=1,y=0;Array.isArray(p)&&!l?v=[...p.slice(0,3),p[3]||255].map(S=>S/255):p===!1&&(v=!1),m!==void 0&&(w=m),_!==void 0&&(y=_),this.device.beginRenderPass({framebuffer:r,parameters:{viewport:f,scissorRect:f},clearColor:v,clearDepth:w,clearStencil:y}).end()}}const d={totalCount:t.length,visibleCount:0,compositeCount:0,pickableCount:0};e.setParameters({viewport:f});for(let g=0;g<t.length;g++){const p=t[g],m=u[g],{shouldDrawLayer:_}=m;if(_&&p.props.pickable&&d.pickableCount++,p.isComposite&&d.compositeCount++,p.isDrawable&&m.shouldDrawLayer){const{layerRenderIndex:v,shaderModuleProps:w,layerParameters:y}=m;d.visibleCount++,this._lastRenderIndex=Math.max(this._lastRenderIndex,v),w.project&&(w.project.viewport=a),p.context.renderPass=e;try{p._drawLayer({renderPass:e,shaderModuleProps:w,uniforms:{layerIndex:v},parameters:y})}catch(x){p.raiseError(x,`drawing ${p} to ${s}`)}}}return d}shouldDrawLayer(e){return!0}getShaderModuleProps(e,t,n){return null}getLayerParameters(e,t,n){return e.props.parameters}_shouldDrawLayer(e,t,n,s){if(!(e.props.visible&&this.shouldDrawLayer(e)))return!1;t.layer=e;let o=e.parent;for(;o;){if(!o.props.visible||!o.filterSubLayer(t))return!1;t.layer=o,o=o.parent}if(n){const a=t.layer.id;if(a in s||(s[a]=n(t)),!s[a])return!1}return e.activateViewport(t.viewport),!0}_getShaderModuleProps(e,t,n,s,r){var l,u;const o=s.cssToDeviceRatio(),a=((l=e.internalState)==null?void 0:l.propsInTransition)||e.props,c={layer:a,picking:{isActive:!1},project:{viewport:e.context.viewport,devicePixelRatio:o,modelMatrix:a.modelMatrix,coordinateSystem:a.coordinateSystem,coordinateOrigin:a.coordinateOrigin,autoWrapLongitude:e.wrapLongitude}};if(t)for(const f of t)Ku(c,(u=f.getShaderModuleProps)==null?void 0:u.call(f,e,c));for(const f of e.context.defaultShaderModules)f.name in c||(c[f.name]={});return Ku(c,this.getShaderModuleProps(e,t,c),r)}}function Ig(i=0,e={}){const t={},n=(s,r)=>{const o=s.props._offset,a=s.id,c=s.parent&&s.parent.id;let l;if(c&&!(c in e)&&n(s.parent,!1),c in t){const u=t[c]=t[c]||Ig(e[c],e);l=u(s,r),t[a]=u}else Number.isFinite(o)?(l=o+(e[c]||0),t[a]=null):l=i;return r&&l>=i&&(i=l+1),e[a]=l,l};return n}function gE(i,{canvasContext:e=i.canvasContext,shaderModuleProps:t,target:n,viewport:s}){var l;const r=((l=t==null?void 0:t.project)==null?void 0:l.devicePixelRatio)??e.cssToDeviceRatio(),[,o]=e.getDrawingBufferSize(),a=n?n.height:o,c=s;return[c.x*r,a-(c.y+c.height)*r,c.width*r,c.height*r]}function Ku(i,...e){for(const t of e)if(t)for(const n in t)i[n]?Object.assign(i[n],t[n]):i[n]=t[n];return i}class pE extends sl{constructor(e,t){super(e,t);const n=e.createTexture({format:"rgba8unorm",width:1,height:1,sampler:{minFilter:"linear",magFilter:"linear",addressModeU:"clamp-to-edge",addressModeV:"clamp-to-edge"}}),s=e.createTexture({format:"depth16unorm",width:1,height:1});this.fbo=e.createFramebuffer({id:"shadowmap",width:1,height:1,colorAttachments:[n],depthStencilAttachment:s})}delete(){this.fbo&&(this.fbo.destroy(),this.fbo=null)}getShadowMap(){return this.fbo.colorAttachments[0].texture}render(e){const t=this.fbo,n=this.device.canvasContext.cssToDeviceRatio(),s=e.viewports[0],r=s.width*n,o=s.height*n,a=[1,1,1,1];(r!==t.width||o!==t.height)&&t.resize({width:r,height:o}),super.render({...e,clearColor:a,target:t,pass:"shadow"})}getLayerParameters(e,t,n){return{...e.props.parameters,blend:!1,depthWriteEnabled:!0,depthCompare:"less-equal",depthBias:0}}shouldDrawLayer(e){return e.props.shadowEnabled!==!1}getShaderModuleProps(e,t,n){return{shadow:{project:n.project,drawToShadowMap:!0},lighting:{enabled:!1}}}}const mE={color:[255,255,255],intensity:1},Qu=[{color:[255,255,255],intensity:1,direction:[-1,3,-1]},{color:[255,255,255],intensity:.9,direction:[1,-8,-2.5]}],_E=[0,0,0,200/255];class rl{constructor(e={}){this.id="lighting-effect",this.shadowColor=_E,this.shadow=!1,this.directionalLights=[],this.pointLights=[],this.shadowPasses=[],this.dummyShadowMap=null,this.setProps(e)}setup(e){this.context=e;const{device:t,deck:n}=e;this.shadow&&!this.dummyShadowMap&&(this._createShadowPasses(t),n._addDefaultShaderModule(Zu),this.dummyShadowMap=t.createTexture({width:1,height:1}))}setProps(e){this.ambientLight=void 0,this.directionalLights=[],this.pointLights=[];for(const t in e){const n=e[t];switch(n.type){case"ambient":this.ambientLight=n;break;case"directional":this.directionalLights.push(n);break;case"point":this.pointLights.push(n);break}}this._applyDefaultLights(),this.shadow=this.directionalLights.some(t=>t.shadow),this.context&&(this.shadow||this.cleanup(this.context),this.setup(this.context)),this.props=e}preRender({layers:e,layerFilter:t,viewports:n,onViewportActive:s,views:r}){if(this.shadow){this.shadowMatrices=this._calculateMatrices();for(let o=0;o<this.shadowPasses.length;o++)this.shadowPasses[o].render({layers:e,layerFilter:t,viewports:n,onViewportActive:s,views:r,shaderModuleProps:{shadow:{shadowLightId:o,dummyShadowMap:this.dummyShadowMap,shadowMatrices:this.shadowMatrices}}})}}getShaderModuleProps(e,t){const n=this.shadow?{project:t.project,shadowMaps:this.shadowPasses.map(o=>o.getShadowMap()),dummyShadowMap:this.dummyShadowMap,shadowColor:this.shadowColor,shadowMatrices:this.shadowMatrices}:{},s={enabled:!0,lights:this._getLights(e)},r=e.props.material;return{shadow:n,lighting:s,phongMaterial:r,gouraudMaterial:r}}cleanup(e){for(const t of this.shadowPasses)t.delete();this.shadowPasses.length=0,this.dummyShadowMap&&(this.dummyShadowMap.destroy(),this.dummyShadowMap=null,e.deck._removeDefaultShaderModule(Zu))}_calculateMatrices(){const e=[];for(const t of this.directionalLights){const n=new Ge().lookAt({eye:new tt(t.direction).negate()});e.push(n)}return e}_createShadowPasses(e){for(let t=0;t<this.directionalLights.length;t++){const n=new pE(e);this.shadowPasses[t]=n}}_applyDefaultLights(){const{ambientLight:e,pointLights:t,directionalLights:n}=this;!e&&t.length===0&&n.length===0&&(this.ambientLight=new Mg(mE),this.directionalLights.push(new Ya(Qu[0]),new Ya(Qu[1])))}_getLights(e){const t=[];this.ambientLight&&t.push(this.ambientLight);for(const n of this.pointLights)t.push(n.getProjectedLight({layer:e}));for(const n of this.directionalLights)t.push(n.getProjectedLight({layer:e}));return t}}class yE{constructor(e={}){this._pool=[],this.opts={overAlloc:2,poolSize:100},this.setOptions(e)}setOptions(e){Object.assign(this.opts,e)}allocate(e,t,{size:n=1,type:s,padding:r=0,copy:o=!1,initialize:a=!1,maxCount:c}){const l=s||e&&e.constructor||Float32Array,u=t*n+r;if(ArrayBuffer.isView(e)){if(u<=e.length)return e;if(u*e.BYTES_PER_ELEMENT<=e.buffer.byteLength)return new l(e.buffer,0,u)}let f=1/0;c&&(f=c*n+r);const d=this._allocate(l,u,a,f);return e&&o?d.set(e):a||d.fill(0,0,4),this._release(e),d}release(e){this._release(e)}_allocate(e,t,n,s){let r=Math.max(Math.ceil(t*this.opts.overAlloc),1);r>s&&(r=s);const o=this._pool,a=e.BYTES_PER_ELEMENT*r,c=o.findIndex(l=>l.byteLength>=a);if(c>=0){const l=new e(o.splice(c,1)[0],0,r);return n&&l.fill(0),l}return new e(r)}_release(e){if(!ArrayBuffer.isView(e))return;const t=this._pool,{buffer:n}=e,{byteLength:s}=n,r=t.findIndex(o=>o.byteLength>=s);r<0?t.push(n):(r>0||t.length<this.opts.poolSize)&&t.splice(r,0,n),t.length>this.opts.poolSize&&t.shift()}}const vi=new yE;function Yi(){return[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}function xn(i,e){const t=i%e;return t<0?e+t:t}function bE(i){return[i[12],i[13],i[14]]}function vE(i){return{left:Kt(i[3]+i[0],i[7]+i[4],i[11]+i[8],i[15]+i[12]),right:Kt(i[3]-i[0],i[7]-i[4],i[11]-i[8],i[15]-i[12]),bottom:Kt(i[3]+i[1],i[7]+i[5],i[11]+i[9],i[15]+i[13]),top:Kt(i[3]-i[1],i[7]-i[5],i[11]-i[9],i[15]-i[13]),near:Kt(i[3]+i[2],i[7]+i[6],i[11]+i[10],i[15]+i[14]),far:Kt(i[3]-i[2],i[7]-i[6],i[11]-i[10],i[15]-i[14])}}const Ju=new tt;function Kt(i,e,t,n){Ju.set(i,e,t);const s=Ju.len();return{distance:n/s,normal:new tt(-i/s,-e/s,-t/s)}}function wE(i){return i-Math.fround(i)}let Bi;function Ss(i,e){const{size:t=1,startIndex:n=0}=e,s=e.endIndex!==void 0?e.endIndex:i.length,r=(s-n)/t;Bi=vi.allocate(Bi,r,{type:Float32Array,size:t*2});let o=n,a=0;for(;o<s;){for(let c=0;c<t;c++){const l=i[o++];Bi[a+c]=l,Bi[a+c+t]=wE(l)}a+=t*2}return Bi.subarray(0,r*t*2)}function xE(i){let e=null,t=!1;for(const n of i)n&&(e?(t||(e=[[e[0][0],e[0][1]],[e[1][0],e[1][1]]],t=!0),e[0][0]=Math.min(e[0][0],n[0][0]),e[0][1]=Math.min(e[0][1],n[0][1]),e[1][0]=Math.max(e[1][0],n[1][0]),e[1][1]=Math.max(e[1][1],n[1][1])):e=n);return e}const PE=Math.PI/180,SE=Yi(),ef=[0,0,0],EE={unitsPerMeter:[1,1,1],metersPerUnit:[1,1,1]};function CE({width:i,height:e,orthographic:t,fovyRadians:n,focalDistance:s,padding:r,near:o,far:a}){const c=i/e,l=t?new Ge().orthographic({fovy:n,aspect:c,focalDistance:s,near:o,far:a}):new Ge().perspective({fovy:n,aspect:c,near:o,far:a});if(r){const{left:u=0,right:f=0,top:d=0,bottom:g=0}=r,p=ae((u+i-f)/2,0,i)-i/2,m=ae((d+e-g)/2,0,e)-e/2;l[8]-=p*2/i,l[9]+=m*2/e}return l}class Ai{constructor(e={}){this._frustumPlanes={},this.id=e.id||this.constructor.displayName||"viewport",this.x=e.x||0,this.y=e.y||0,this.width=e.width||1,this.height=e.height||1,this.zoom=e.zoom||0,this.padding=e.padding,this.distanceScales=e.distanceScales||EE,this.focalDistance=e.focalDistance||1,this.position=e.position||ef,this.modelMatrix=e.modelMatrix||null;const{longitude:t,latitude:n}=e;this.isGeospatial=Number.isFinite(n)&&Number.isFinite(t),this._initProps(e),this._initMatrices(e),this.equals=this.equals.bind(this),this.project=this.project.bind(this),this.unproject=this.unproject.bind(this),this.projectPosition=this.projectPosition.bind(this),this.unprojectPosition=this.unprojectPosition.bind(this),this.projectFlat=this.projectFlat.bind(this),this.unprojectFlat=this.unprojectFlat.bind(this)}get subViewports(){return null}get metersPerPixel(){return this.distanceScales.metersPerUnit[2]/this.scale}get projectionMode(){return this.isGeospatial?this.zoom<12?xe.WEB_MERCATOR:xe.WEB_MERCATOR_AUTO_OFFSET:xe.IDENTITY}equals(e){return e instanceof Ai?this===e?!0:e.width===this.width&&e.height===this.height&&e.scale===this.scale&&e.projectionMode===this.projectionMode&&e.resolution===this.resolution&&ci(e.distanceScales.unitsPerMeter,this.distanceScales.unitsPerMeter)&&ci(e.projectionMatrix,this.projectionMatrix)&&ci(e.viewMatrix,this.viewMatrix):!1}project(e,{topLeft:t=!0}={}){const n=this.projectPosition(e),s=nl(n,this.pixelProjectionMatrix),[r,o]=s,a=t?o:this.height-o;return e.length===2?[r,a]:[r,a,s[2]]}unproject(e,{topLeft:t=!0,targetZ:n}={}){const[s,r,o]=e,a=t?r:this.height-r,c=n&&n*this.distanceScales.unitsPerMeter[2],l=nr([s,a,o],this.pixelUnprojectionMatrix,c),[u,f,d]=this.unprojectPosition(l);return Number.isFinite(o)?[u,f,d]:Number.isFinite(n)?[u,f,n]:[u,f]}projectPosition(e){const[t,n]=this.projectFlat(e),s=(e[2]||0)*this.distanceScales.unitsPerMeter[2];return[t,n,s]}unprojectPosition(e){const[t,n]=this.unprojectFlat(e),s=(e[2]||0)*this.distanceScales.metersPerUnit[2];return[t,n,s]}projectFlat(e){if(this.isGeospatial){const t=bi(e);return t[1]=ae(t[1],-318,830),t}return e}unprojectFlat(e){return this.isGeospatial?Fn(e):e}getBounds(e={}){const t={targetZ:e.z||0},n=this.unproject([0,0],t),s=this.unproject([this.width,0],t),r=this.unproject([0,this.height],t),o=this.unproject([this.width,this.height],t);return[Math.min(n[0],s[0],r[0],o[0]),Math.min(n[1],s[1],r[1],o[1]),Math.max(n[0],s[0],r[0],o[0]),Math.max(n[1],s[1],r[1],o[1])]}getDistanceScales(e){return e&&this.isGeospatial?Ha({longitude:e[0],latitude:e[1],highPrecision:!0}):this.distanceScales}containsPixel({x:e,y:t,width:n=1,height:s=1}){return e<this.x+this.width&&this.x<e+n&&t<this.y+this.height&&this.y<t+s}getFrustumPlanes(){return this._frustumPlanes.near?this._frustumPlanes:(Object.assign(this._frustumPlanes,vE(this.viewProjectionMatrix)),this._frustumPlanes)}panByPosition(e,t,n){return null}_initProps(e){const t=e.longitude,n=e.latitude;this.isGeospatial&&(Number.isFinite(e.zoom)||(this.zoom=OS({latitude:n})+Math.log2(this.focalDistance)),this.distanceScales=e.distanceScales||Ha({latitude:n,longitude:t}));const s=Math.pow(2,this.zoom);this.scale=s;const{position:r,modelMatrix:o}=e;let a=ef;if(r&&(a=o?new Ge(o).transformAsVector(r,[]):r),this.isGeospatial){const c=this.projectPosition([t,n,0]);this.center=new tt(a).scale(this.distanceScales.unitsPerMeter).add(c)}else this.center=this.projectPosition(a)}_initMatrices(e){const{viewMatrix:t=SE,projectionMatrix:n=null,orthographic:s=!1,fovyRadians:r,fovy:o=75,near:a=.1,far:c=1e3,padding:l=null,focalDistance:u=1}=e;this.viewMatrixUncentered=t,this.viewMatrix=new Ge().multiplyRight(t).translate(new tt(this.center).negate()),this.projectionMatrix=n||CE({width:this.width,height:this.height,orthographic:s,fovyRadians:r||o*PE,focalDistance:u,padding:l,near:a,far:c});const f=Yi();Ot(f,f,this.projectionMatrix),Ot(f,f,this.viewMatrix),this.viewProjectionMatrix=f,this.viewMatrixInverse=Fa([],this.viewMatrix)||this.viewMatrix,this.cameraPosition=bE(this.viewMatrixInverse);const d=Yi(),g=Yi();Kc(d,d,[this.width/2,-this.height/2,1]),Js(d,d,[1,-1,0]),Ot(g,d,this.viewProjectionMatrix),this.pixelProjectionMatrix=g,this.pixelUnprojectionMatrix=Fa(Yi(),this.pixelProjectionMatrix),this.pixelUnprojectionMatrix||Y.warn("Pixel project matrix not invertible")()}}Ai.displayName="Viewport";class ot extends Ai{constructor(e={}){const{latitude:t=0,longitude:n=0,zoom:s=0,pitch:r=0,bearing:o=0,nearZMultiplier:a=.1,farZMultiplier:c=1.01,nearZ:l,farZ:u,orthographic:f=!1,projectionMatrix:d,repeat:g=!1,worldOffset:p=0,position:m,padding:_,legacyMeterSizes:v=!1}=e;let{width:w,height:y,altitude:x=1.5}=e;const S=Math.pow(2,s);w=w||1,y=y||1;let C,O=null;if(d)x=d[5]/2,C=wn(x);else{e.fovy?(C=e.fovy,x=il(C)):C=wn(x);let D;if(_){const{top:k=0,bottom:N=0}=_;D=[0,ae((k+y-N)/2,0,y)-y/2]}O=kS({width:w,height:y,scale:S,center:m&&[0,0,m[2]*So(t)],offset:D,pitch:r,fovy:C,nearZMultiplier:a,farZMultiplier:c}),Number.isFinite(l)&&(O.near=l),Number.isFinite(u)&&(O.far=u)}let B=BS({height:y,pitch:r,bearing:o,scale:S,altitude:x});p&&(B=new Ge().translate([512*p,0,0]).multiplyLeft(B)),super({...e,width:w,height:y,viewMatrix:B,longitude:n,latitude:t,zoom:s,...O,fovy:C,focalDistance:x}),this.latitude=t,this.longitude=n,this.zoom=s,this.pitch=r,this.bearing=o,this.altitude=x,this.fovy=C,this.orthographic=f,this._subViewports=g?[]:null,this._pseudoMeters=v,Object.freeze(this)}get subViewports(){if(this._subViewports&&!this._subViewports.length){const e=this.getBounds(),t=Math.floor((e[0]+180)/360),n=Math.ceil((e[2]-180)/360);for(let s=t;s<=n;s++){const r=s?new ot({...this,worldOffset:s}):this;this._subViewports.push(r)}}return this._subViewports}equals(e){return e instanceof ot&&e._pseudoMeters===this._pseudoMeters&&super.equals(e)}projectPosition(e){if(this._pseudoMeters)return super.projectPosition(e);const[t,n]=this.projectFlat(e),s=(e[2]||0)*So(e[1]);return[t,n,s]}unprojectPosition(e){if(this._pseudoMeters)return super.unprojectPosition(e);const[t,n]=this.unprojectFlat(e),s=(e[2]||0)/So(n);return[t,n,s]}addMetersToLngLat(e,t){return Tg(e,t)}panByPosition(e,t,n){const s=nr(t,this.pixelUnprojectionMatrix),r=this.projectFlat(e),o=wu([],r,sx([],s)),a=wu([],this.center,o),[c,l]=this.unprojectFlat(a);return{longitude:c,latitude:l}}panByPosition3D(e,t){const n=e[2]||0,s=ox([],e,this.unproject(t,{targetZ:n}));return{longitude:this.longitude+s[0],latitude:this.latitude+s[1]}}getBounds(e={}){const t=zS(this,e.z||0);return[Math.min(t[0][0],t[1][0],t[2][0],t[3][0]),Math.min(t[0][1],t[1][1],t[2][1],t[3][1]),Math.max(t[0][0],t[1][0],t[2][0],t[3][0]),Math.max(t[0][1],t[1][1],t[2][1],t[3][1])]}fitBounds(e,t={}){const{width:n,height:s}=this,{longitude:r,latitude:o,zoom:a}=DS({width:n,height:s,bounds:e,...t});return new ot({width:n,height:s,longitude:r,latitude:o,zoom:a})}}ot.displayName="WebMercatorViewport";const tf=[0,0,0];function Co(i,e,t=!1){const n=e.projectPosition(i);if(t&&e instanceof ot){const[s,r,o=0]=i,a=e.getDistanceScales([s,r]);n[2]=o*a.unitsPerMeter[2]}return n}function LE(i){const{viewport:e,modelMatrix:t,coordinateOrigin:n}=i;let{coordinateSystem:s,fromCoordinateSystem:r,fromCoordinateOrigin:o}=i;return s==="default"&&(s=e.isGeospatial?"lnglat":"cartesian"),r===void 0?r=s:r==="default"&&(r=e.isGeospatial?"lnglat":"cartesian"),o===void 0&&(o=n),{viewport:e,coordinateSystem:s,coordinateOrigin:n,modelMatrix:t,fromCoordinateSystem:r,fromCoordinateOrigin:o}}function ol(i,{viewport:e,modelMatrix:t,coordinateSystem:n,coordinateOrigin:s,offsetMode:r}){let[o,a,c=0]=i;switch(t&&([o,a,c]=Ti([],[o,a,c,1],t)),n){case"default":return ol(i,{viewport:e,modelMatrix:t,coordinateSystem:e.isGeospatial?"lnglat":"cartesian",coordinateOrigin:s,offsetMode:r});case"lnglat":return Co([o,a,c],e,r);case"lnglat-offsets":return Co([o+s[0],a+s[1],c+(s[2]||0)],e,r);case"meter-offsets":return Co(Tg(s,[o,a,c]),e,r);case"cartesian":return e.isGeospatial?[o+s[0],a+s[1],c+s[2]]:e.projectPosition([o,a,c]);default:throw new Error(`Invalid coordinateSystem: ${n}`)}}function TE(i,e){const{viewport:t,coordinateSystem:n,coordinateOrigin:s,modelMatrix:r,fromCoordinateSystem:o,fromCoordinateOrigin:a}=LE(e),{autoOffset:c=!0}=e,{geospatialOrigin:l=tf,shaderCoordinateOrigin:u=tf,offsetMode:f=!1}=c?Eg(t,n,s):{},d=ol(i,{viewport:t,modelMatrix:r,coordinateSystem:o,coordinateOrigin:a,offsetMode:f});if(f){const g=t.projectPosition(l||u);og(d,d,g)}return d}const Lo={};function Nn(i="id"){Lo[i]=Lo[i]||1;const e=Lo[i]++;return`${i}-${e}`}class Ut{constructor(e){h(this,"id");h(this,"topology");h(this,"vertexCount");h(this,"indices");h(this,"attributes");h(this,"bufferLayout");h(this,"userData",{});const{attributes:t={},indices:n=null,vertexCount:s=null}=e;this.id=e.id||Nn("geometry"),this.topology=e.topology,n&&(this.indices=ArrayBuffer.isView(n)?{value:n,size:1}:n),this.attributes={};for(const[r,o]of Object.entries(t)){const a=ArrayBuffer.isView(o)?{value:o}:o;if(!ArrayBuffer.isView(a.value))throw new Error(`${this._print(r)}: must be typed array or object with value as typed array`);if((r==="POSITION"||r==="positions")&&!a.size&&(a.size=3),r==="indices"){if(this.indices)throw new Error("Multiple indices detected");this.indices=a}else{const c=Pn(r),l=Object.keys(this.attributes).find(u=>Pn(u)===c);l&&delete this.attributes[l],this.attributes[r]=a}}this.indices&&this.indices.isIndexed!==void 0&&(this.indices=Object.assign({},this.indices),delete this.indices.isIndexed),this.vertexCount=s||this._calculateVertexCount(this.attributes,this.indices),this.bufferLayout=e.bufferLayout||AE(this.attributes)}getVertexCount(){return this.vertexCount}getAttributes(){return this.indices?{indices:this.indices,...this.attributes}:this.attributes}_print(e){return`Geometry ${this.id} attribute ${e}`}_setAttributes(e,t){return this}_calculateVertexCount(e,t){if(t)return t.value.length;let n=1/0;for(const s of Object.values(e)){if(!s)continue;const{value:r,size:o,constant:a}=s;!a&&r&&o!==void 0&&o>=1&&(n=Math.min(n,r.length/o))}return n}}function Pn(i){switch(i){case"POSITION":return"positions";case"NORMAL":return"normals";case"TEXCOORD_0":return"texCoords";case"TEXCOORD_1":return"texCoords1";case"COLOR_0":return"colors";default:return i}}function AE(i){const e=[];for(const[t,n]of Object.entries(i)){if(!n)continue;const{value:s,size:r,normalized:o}=n;if(r===void 0)throw new Error(`Attribute ${t} is missing a size`);e.push({name:Pn(t),format:be.getVertexFormatFromAttribute(s,r,o)})}return e}function ME(i,e={}){const t=e.bufferName||"geometry";if(IE(i,t))return i;const n=e.minAttributeAlignment||4,s=RE(i,e.attributes),r=[];let o=0,a=1/0;for(const[u,f]of s){if(!f)continue;if(f.constant)throw new Error(`Attribute ${u} is constant`);const{value:d,size:g,normalized:p}=f;if(!ArrayBuffer.isView(d))throw new Error(`Attribute ${u} is missing typed array data`);if(g===void 0)throw new Error(`Attribute ${u} is missing a size`);const m=be.getVertexFormatFromAttribute(d,g,p),_=be.getVertexFormatInfo(m);o=nf(o,n),r.push({sourceName:u,attributeName:Pn(u),value:d,size:g,format:m,byteOffset:o,byteLength:_.byteLength}),o+=_.byteLength;const v=d.length/g;if(!Number.isInteger(v))throw new Error(`Attribute ${u} length is not divisible by size`);a=Math.min(a,v)}if(r.length===0||!Number.isFinite(a))throw new Error(`Geometry ${i.id} has no interleavable attributes`);const c=nf(o,n),l=new ArrayBuffer(a*c);for(const u of r)OE(l,a,c,u);return new Ut({id:i.id,topology:i.topology||"triangle-list",vertexCount:i.vertexCount,indices:i.indices,attributes:{[t]:{value:new Uint8Array(l),size:c,byteStride:c}},bufferLayout:[{name:t,stepMode:"vertex",byteStride:c,attributes:r.map(u=>({attribute:u.attributeName,format:u.format,byteOffset:u.byteOffset}))}]})}function IE(i,e){var n;if(i.bufferLayout.length!==1)return!1;const t=i.bufferLayout[0];return t.name===e&&!!((n=t.attributes)!=null&&n.length)&&!!i.attributes[e]}function RE(i,e){return e?e.map(t=>[t,i.attributes[t]]):Object.entries(i.attributes)}function OE(i,e,t,n){const s=n.value.constructor,r=s.BYTES_PER_ELEMENT;if(n.byteOffset%r!==0||t%r!==0)throw new Error(`Attribute ${n.sourceName} is not aligned to its component type`);const o=new s(i),a=n.value,c=n.byteOffset/r,l=t/r;for(let u=0;u<e;u++){const f=u*n.size,d=u*l+c;for(let g=0;g<n.size;g++)o[d+g]=a[f+g]}}function nf(i,e){return Math.ceil(i/e)*e}let BE=1,kE=1;class Rg{constructor(){h(this,"time",0);h(this,"channels",new Map);h(this,"animations",new Map);h(this,"playing",!1);h(this,"lastEngineTime",-1)}addChannel(e){const{delay:t=0,duration:n=Number.POSITIVE_INFINITY,rate:s=1,repeat:r=1}=e,o=BE++,a={time:0,delay:t,duration:n,rate:s,repeat:r};return this._setChannelTime(a,this.time),this.channels.set(o,a),o}removeChannel(e){this.channels.delete(e);for(const[t,n]of this.animations)n.channel===e&&this.detachAnimation(t)}isFinished(e){const t=this.channels.get(e);return t===void 0?!1:this.time>=t.delay+t.duration*t.repeat}getTime(e){if(e===void 0)return this.time;const t=this.channels.get(e);return t===void 0?-1:t.time}setTime(e){this.time=Math.max(0,e);const t=this.channels.values();for(const s of t)this._setChannelTime(s,this.time);const n=this.animations.values();for(const s of n){const{animation:r,channel:o}=s;r.setTime(this.getTime(o))}}play(){this.playing=!0}pause(){this.playing=!1,this.lastEngineTime=-1}reset(){this.setTime(0)}attachAnimation(e,t){const n=kE++;return this.animations.set(n,{animation:e,channel:t}),e.setTime(this.getTime(t)),n}detachAnimation(e){this.animations.delete(e)}update(e){this.playing&&(this.lastEngineTime===-1&&(this.lastEngineTime=e),this.setTime(this.time+(e-this.lastEngineTime)),this.lastEngineTime=e)}_setChannelTime(e,t){const n=t-e.delay,s=e.duration*e.repeat;n>=s?e.time=e.duration*e.rate:(e.time=Math.max(0,n)%e.duration,e.time*=e.rate)}}function DE(i){const e=typeof window<"u"?window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame:null;return e?e.call(window,i):setTimeout(()=>i(typeof performance<"u"?performance.now():Date.now()),1e3/60)}function FE(i){const e=typeof window<"u"?window.cancelAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame:null;if(e){e.call(window,i);return}clearTimeout(i)}let zE=0;const NE="Animation Loop",sf={requestAnimationFrame:i=>DE(i),cancelAnimationFrame:i=>FE(i)},hn=class hn{constructor(e){h(this,"device",null);h(this,"canvas",null);h(this,"props");h(this,"animationProps",null);h(this,"timeline",null);h(this,"stats");h(this,"sharedStats");h(this,"cpuTime");h(this,"gpuTime");h(this,"frameRate");h(this,"display");h(this,"_needsRedraw","initialized");h(this,"_initialized",!1);h(this,"_running",!1);h(this,"_animationFrameId",null);h(this,"_nextFramePromise",null);h(this,"_resolveNextFrame",null);h(this,"_cpuStartTime",0);h(this,"_error",null);h(this,"_lastFrameTime",0);if(this.props={...hn.defaultAnimationLoopProps,...e},e=this.props,!e.device)throw new Error("No device provided");this.stats=e.stats||new Rr({id:`animation-loop-${zE++}`}),this.sharedStats=va.stats.get(NE),this.frameRate=this.stats.get("Frame Rate"),this.frameRate.setSampleSize(1),this.cpuTime=this.stats.get("CPU Time"),this.gpuTime=this.stats.get("GPU Time"),this.setProps({autoResizeViewport:e.autoResizeViewport,animationFrameProvider:e.animationFrameProvider}),this.start=this.start.bind(this),this.stop=this.stop.bind(this),this._onMousemove=this._onMousemove.bind(this),this._onMouseleave=this._onMouseleave.bind(this)}destroy(){var e;this.stop(),this._setDisplay(null),(e=this.device)==null||e._disableDebugGPUTime()}delete(){this.destroy()}reportError(e){this._error=e,this.props.onError(e),this.props.onError===hn.defaultAnimationLoopProps.onError&&typeof window<"u"&&typeof ErrorEvent<"u"&&window.dispatchEvent(new ErrorEvent("error",{error:e,message:e.message}))}setNeedsRedraw(e){return this._needsRedraw=this._needsRedraw||e,this}needsRedraw(){const e=this._needsRedraw;return this._needsRedraw=!1,e}setProps(e){if("autoResizeViewport"in e&&(this.props.autoResizeViewport=e.autoResizeViewport||!1),"animationFrameProvider"in e){const t=e.animationFrameProvider||sf;if(t!==this.props.animationFrameProvider){const n=this._animationFrameId!==null;n&&this._cancelAnimationFrame(),this.props.animationFrameProvider=t,n&&this._requestAnimationFrame()}}return this}async start(){if(this._running)return this;this._running=!0;try{let e;if(!this._initialized){if(this._initialized=!0,await this._initDevice(),this._initialize(),!this._running)return null;await this.props.onInitialize(this._getAnimationProps())}return this._running?(e!==!1&&(this._cancelAnimationFrame(),this._requestAnimationFrame()),this):null}catch(e){const t=e instanceof Error?e:new Error("Unknown error");throw this.props.onError(t),t}}stop(){if(this._running){const e=this.animationProps;this._cancelAnimationFrame(),this._nextFramePromise=null,this._resolveNextFrame=null,this._running=!1,this._lastFrameTime=0,e&&this.props.onFinalize(e)}return this}redraw(e,t=null){var n;return(n=this.device)!=null&&n.isLost||this._error?this:(this._beginFrameTimers(e),this._setupFrame(),this.animationProps&&(this.animationProps.animationFrame=t),this._updateAnimationProps(),this._renderFrame(this._getAnimationProps()),this._clearNeedsRedraw(),this._resolveNextFrame&&(this._resolveNextFrame(this),this._nextFramePromise=null,this._resolveNextFrame=null),this._endFrameTimers(),this)}attachTimeline(e){return this.timeline=e,this.timeline}detachTimeline(){this.timeline=null}waitForRender(){return this.setNeedsRedraw("waitForRender"),this._nextFramePromise||(this._nextFramePromise=new Promise(e=>{this._resolveNextFrame=e})),this._nextFramePromise}async toDataURL(){if(this.setNeedsRedraw("toDataURL"),await this.waitForRender(),this.canvas instanceof HTMLCanvasElement)return this.canvas.toDataURL();throw new Error("OffscreenCanvas")}_initialize(){var e;this._startEventHandling(),this._initializeAnimationProps(),this._updateAnimationProps(),this._resizeViewport(),(e=this.device)==null||e._enableDebugGPUTime()}_setDisplay(e){this.display&&(this.display.destroy(),this.display.animationLoop=null),e&&(e.animationLoop=this),this.display=e}_requestAnimationFrame(){this._running&&(this._animationFrameId=this.props.animationFrameProvider.requestAnimationFrame(this._animationFrame.bind(this)))}_cancelAnimationFrame(){this._animationFrameId!==null&&(this.props.animationFrameProvider.cancelAnimationFrame(this._animationFrameId),this._animationFrameId=null)}_animationFrame(e,t){if(this._running)try{this.redraw(e,t??null),this._requestAnimationFrame()}catch(n){const s=n instanceof Error?n:new Error(String(n));this.reportError(s),this.stop()}}_renderFrame(e){if(this.display){this.display._renderFrame(e);return}const t=this.props.onRender(this._getAnimationProps());this.device&&t!==!1&&this.device.submit()}_clearNeedsRedraw(){this._needsRedraw=!1}_setupFrame(){this._resizeViewport()}_initializeAnimationProps(){var s;const e=(s=this.device)==null?void 0:s.getDefaultCanvasContext();if(!this.device||!e)throw new Error("loop");const t=e==null?void 0:e.canvas,n=e.props.useDevicePixels;this.animationProps={animationLoop:this,device:this.device,canvasContext:e,canvas:t,useDevicePixels:n,timeline:this.timeline,needsRedraw:!1,width:1,height:1,aspect:1,time:0,startTime:Date.now(),engineTime:0,tick:0,tock:0,animationFrame:null,_mousePosition:null}}_getAnimationProps(){if(!this.animationProps)throw new Error("animationProps");return this.animationProps}_updateAnimationProps(){if(!this.animationProps)return;const{width:e,height:t,aspect:n}=this._getSizeAndAspect();(e!==this.animationProps.width||t!==this.animationProps.height)&&this.setNeedsRedraw("drawing buffer resized"),n!==this.animationProps.aspect&&this.setNeedsRedraw("drawing buffer aspect changed"),this.animationProps.width=e,this.animationProps.height=t,this.animationProps.aspect=n,this.animationProps.needsRedraw=this._needsRedraw,this.animationProps.engineTime=Date.now()-this.animationProps.startTime,this.timeline&&this.timeline.update(this.animationProps.engineTime),this.animationProps.tick=Math.floor(this.animationProps.time/1e3*60),this.animationProps.tock++,this.animationProps.time=this.timeline?this.timeline.getTime():this.animationProps.engineTime}async _initDevice(){if(this.device=await this.props.device,!this.device)throw new Error("No device provided");this.canvas=this.device.getDefaultCanvasContext().canvas||null}_createInfoDiv(){if(this.canvas&&this.props.onAddHTML){const e=document.createElement("div");document.body.appendChild(e),e.style.position="relative";const t=document.createElement("div");t.style.position="absolute",t.style.left="10px",t.style.bottom="10px",t.style.width="300px",t.style.background="white",this.canvas instanceof HTMLCanvasElement&&e.appendChild(this.canvas),e.appendChild(t);const n=this.props.onAddHTML(t);n&&(t.innerHTML=n)}}_getSizeAndAspect(){if(!this.device)return{width:1,height:1,aspect:1};const[e,t]=this.device.getDefaultCanvasContext().getDrawingBufferSize(),n=e>0&&t>0?e/t:1;return{width:e,height:t,aspect:n}}_resizeViewport(){this.props.autoResizeViewport&&this.device.gl&&this.device.gl.viewport(0,0,this.device.gl.drawingBufferWidth,this.device.gl.drawingBufferHeight)}_beginFrameTimers(e){var n;const t=e??(typeof performance<"u"?performance.now():Date.now());if(this._lastFrameTime){const s=t-this._lastFrameTime;s>0&&this.frameRate.addTime(s)}this._lastFrameTime=t,(n=this.device)!=null&&n._isDebugGPUTimeEnabled()&&this._consumeEncodedGpuTime(),this.cpuTime.timeStart()}_endFrameTimers(){var e;(e=this.device)!=null&&e._isDebugGPUTimeEnabled()&&this._consumeEncodedGpuTime(),this.cpuTime.timeEnd(),this._updateSharedStats()}_consumeEncodedGpuTime(){if(!this.device)return;const e=this.device.commandEncoder._gpuTimeMs;e!==void 0&&(this.gpuTime.addTime(e),this.device.commandEncoder._gpuTimeMs=void 0)}_updateSharedStats(){if(this.stats!==this.sharedStats){for(const e of Object.keys(this.sharedStats.stats))this.stats.stats[e]||delete this.sharedStats.stats[e];this.stats.forEach(e=>{const t=this.sharedStats.get(e.name,e.type);t.sampleSize=e.sampleSize,t.time=e.time,t.count=e.count,t.samples=e.samples,t.lastTiming=e.lastTiming,t.lastSampleTime=e.lastSampleTime,t.lastSampleCount=e.lastSampleCount,t._count=e._count,t._time=e._time,t._samples=e._samples,t._startTime=e._startTime,t._timerPending=e._timerPending})}}_startEventHandling(){this.canvas&&(this.canvas.addEventListener("mousemove",this._onMousemove.bind(this)),this.canvas.addEventListener("mouseleave",this._onMouseleave.bind(this)))}_onMousemove(e){e instanceof MouseEvent&&(this._getAnimationProps()._mousePosition=[e.offsetX,e.offsetY])}_onMouseleave(e){this._getAnimationProps()._mousePosition=null}};h(hn,"defaultAnimationLoopProps",{device:null,onAddHTML:()=>"",onInitialize:async()=>null,onRender:()=>{},onFinalize:()=>{},onError:e=>{console.error(e)},stats:void 0,autoResizeViewport:!1,animationFrameProvider:sf});let qa=hn;class rf{constructor(e){h(this,"id");h(this,"userData",{});h(this,"topology");h(this,"bufferLayout",[]);h(this,"vertexCount");h(this,"indices");h(this,"attributes");if(this.id=e.id||Nn("geometry"),this.topology=e.topology,this.indices=e.indices||null,this.attributes=e.attributes,this.vertexCount=e.vertexCount,this.bufferLayout=e.bufferLayout||[],this.indices&&!(this.indices.usage&W.INDEX))throw new Error("Index buffer must have INDEX usage")}destroy(){var e;(e=this.indices)==null||e.destroy();for(const t of Object.values(this.attributes))t.destroy()}getVertexCount(){return this.vertexCount}getAttributes(){return this.attributes}getIndexes(){return this.indices||null}_calculateVertexCount(e){return e.byteLength/12}}function UE(i,e){if(e instanceof rf)return e;const t=ME(e),n=$E(i,t),{attributes:s,bufferLayout:r}=GE(i,t);return new rf({topology:t.topology||"triangle-list",bufferLayout:r,vertexCount:t.vertexCount,indices:n,attributes:s})}function $E(i,e){if(!e.indices)return;const t=e.indices.value;return i.createBuffer({usage:W.INDEX,data:t})}function GE(i,e){var n;const t={};for(const[s,r]of Object.entries(e.attributes)){const o=((n=e.bufferLayout.find(a=>a.name===s))==null?void 0:n.name)||Pn(s);r&&(t[o]=i.createBuffer({data:r.value,id:`${s}-buffer`}))}return{attributes:t,bufferLayout:e.bufferLayout,vertexCount:e.vertexCount}}function jE(i,e){var s;const t={},n="Values";if(i.attributes.length===0&&!((s=i.varyings)!=null&&s.length))return{"No attributes or varyings":{[n]:"N/A"}};for(const r of i.attributes)if(r){const o=`${r.location} ${r.name}: ${r.type}`;t[`in ${o}`]={[n]:r.stepMode||"vertex"}}for(const r of i.varyings||[]){const o=`${r.location} ${r.name}`;t[`out ${o}`]={[n]:JSON.stringify(r)}}return t}const ss="__debugFramebufferState",To=8;function VE(i,e,t){if(i.device.type!=="webgl")return;const n=YE(i.device);if(!n.flushing){if(ZE(i)){WE(i,t,n);return}e&&qE(e)&&e.handle!==null&&(n.queuedFramebuffers.includes(e)||n.queuedFramebuffers.push(e))}}function WE(i,e,t){if(t.queuedFramebuffers.length===0)return;const n=i.device,{gl:s}=n,r=s.getParameter(36010),o=s.getParameter(36006),[a,c]=i.device.getDefaultCanvasContext().getDrawingBufferSize();let l=of(e.top,To);const u=of(e.left,To);t.flushing=!0;try{for(const f of t.queuedFramebuffers){const[d,g,p,m,_]=HE({framebuffer:f,targetWidth:a,targetHeight:c,topPx:l,leftPx:u,minimap:e.minimap});s.bindFramebuffer(36008,f.handle),s.bindFramebuffer(36009,null),s.blitFramebuffer(0,0,f.width,f.height,d,g,p,m,16384,9728),l+=_+To}}finally{s.bindFramebuffer(36008,r),s.bindFramebuffer(36009,o),t.flushing=!1}}function HE(i){const{framebuffer:e,targetWidth:t,targetHeight:n,topPx:s,leftPx:r}=i,o=Math.max(Math.floor(t/4),1),a=Math.max(Math.floor(n/4),1),c=Math.min(o/e.width,a/e.height),l=Math.max(Math.floor(e.width*c),1),u=Math.max(Math.floor(e.height*c),1),f=r,d=Math.max(n-s-u,0),g=f+l,p=d+u;return[f,d,g,p,u]}function YE(i){var e;return(e=i.userData)[ss]||(e[ss]={flushing:!1,queuedFramebuffers:[]}),i.userData[ss]}function qE(i){return"colorAttachments"in i}function ZE(i){const e=i.props.framebuffer;return!e||e.handle===null}function of(i,e){if(!i)return e;const t=Number.parseInt(i,10);return Number.isFinite(t)?t:e}function tn(i,e,t){if(i===e)return!0;if(!t||!i||!e)return!1;if(Array.isArray(i)){if(!Array.isArray(e)||i.length!==e.length)return!1;for(let n=0;n<i.length;n++)if(!tn(i[n],e[n],t-1))return!1;return!0}if(Array.isArray(e))return!1;if(typeof i=="object"&&typeof e=="object"){const n=Object.keys(i),s=Object.keys(e);if(n.length!==s.length)return!1;for(const r of n)if(!e.hasOwnProperty(r)||!tn(i[r],e[r],t-1))return!1;return!0}return!1}class Ao{constructor(e){h(this,"bufferLayouts");this.bufferLayouts=e}getBufferLayout(e){return this.bufferLayouts.find(t=>t.name===e)||null}getAttributeNamesForBuffer(e){return Ba(e)}mergeBufferLayouts(e,t){const n=[...e];for(const s of t){const r=n.findIndex(o=>o.name===s.name);r<0?n.push(s):n[r]=s}return n}}function XE(i,e){const t=o0(i),n=e.slice();return n.sort((s,r)=>{const o=au(Ba(s).map(c=>t[c])),a=au(Ba(r).map(c=>t[c]));return o-a}),n}function or(i,e){if(!i||!e.some(n=>{var s;return(s=n.bindingLayout)==null?void 0:s.length}))return i;const t={...i,bindings:i.bindings.map(n=>({...n}))};"attributes"in(i||{})&&(t.attributes=(i==null?void 0:i.attributes)||[]);for(const n of e)for(const s of n.bindingLayout||[])for(const r of JE(s.name)){const o=t.bindings.find(a=>a.name===r);(o==null?void 0:o.group)===0&&(o.group=s.group),o&&s.visibility!==void 0&&(o.visibility=s.visibility)}return t}function KE(i,e,t=[]){return i?e?{...i,attributes:i.attributes.length?i3(i.attributes,e.attributes.filter(n=>t.includes(n.name))):e.attributes,bindings:t3(i.bindings,e.bindings)}:i:e}function al(i){return!!(i.uniformTypes&&!e3(i.uniformTypes))}function QE(i){const e=[];for(const t of i){const n=Uc(t),s=new Set([t.vs,t.fs].flatMap(o=>o?$c(o).filter(a=>a.isStd140).map(a=>a.blockName):[])),r=s.has(n)?n:s.size===1?s.values().next().value:void 0;al(t)&&r&&e.push({name:r,uniformTypes:t.uniformTypes})}return e}function Og(i,e){const t=[],n=new Set;for(const s of[...i||[],...e||[]])n.has(s.name)||(n.add(s.name),t.push(s));return t}function JE(i){const e=new Set([i,`${i}Uniforms`]);return i.endsWith("Uniforms")||e.add(`${i}Sampler`),[...e]}function e3(i){for(const e in i)return!1;return!0}function t3(i,e){const t=i.map(r=>({...r})),n=new Set(i.map(r=>r.name)),s=new Set(i.map(r=>`${r.group}:${r.location}`));for(const r of e){const o=`${r.group}:${r.location}`;!n.has(r.name)&&!s.has(o)&&t.push({...r})}return t}function i3(i,e){const t=i.map(r=>({...r})),n=new Map(i.map(r=>[r.name,r])),s=new Map(i.map(r=>[r.location,r]));for(const r of e){const o=n.get(r.name);if(o){if(o.type!==r.type||o.location!==r.location)throw new Error(`Shader attribute "${r.name}" conflicts with its inferred type or location`);continue}const a=s.get(r.location);if(a)throw new Error(`Shader attributes "${a.name}" and "${r.name}" both use location ${r.location}`);t.push({...r})}return t}function n3(i){return gh(i)||typeof i=="number"||typeof i=="boolean"}function s3(i,e={}){const t={bindings:{},uniforms:{}};return Object.keys(i).forEach(n=>{const s=i[n];Object.prototype.hasOwnProperty.call(e,n)||n3(s)?t.uniforms[n]=s:t.bindings[n]=s}),t}class Bg{constructor(e,t){h(this,"options",{disableWarnings:!1});h(this,"modules");h(this,"moduleUniforms");h(this,"moduleBindings");h(this,"directBindings",{});Object.assign(this.options,t);const n=Gs(Object.values(e).filter(r3));for(const s of n)e[s.name]=s;M.log(1,"Creating ShaderInputs with modules",Object.keys(e))(),this.modules=e,this.moduleUniforms={},this.moduleBindings={};for(const[s,r]of Object.entries(e))r&&(this._addModule(r),r.name&&s!==r.name&&!this.options.disableWarnings&&M.warn(`Module name: ${s} vs ${r.name}`)())}destroy(){}setProps(e){var t;e.bindings&&Object.assign(this.directBindings,e.bindings);for(const n of Object.keys(e)){if(n==="bindings")continue;const s=n,r=e[s]||{},o=this.modules[s];if(!o)this.options.disableWarnings||M.warn(`Module ${n} not found`)();else{const a=this.moduleUniforms[s],c=this.moduleBindings[s],l=((t=o.getUniforms)==null?void 0:t.call(o,r,a))||r,{uniforms:u,bindings:f}=s3(l,o.uniformTypes);this.moduleUniforms[s]=af(a,u,o.uniformTypes),this.moduleBindings[s]={...c,...f}}}}getModules(){return Object.values(this.modules)}addModules(e){const t=Gs(e);for(const n of t){const s=n.name;this.modules[s]||(this.modules[s]=n,this._addModule(n))}}getUniformValues(){return this.moduleUniforms}getBindingValues(){const e={};for(const t of Object.values(this.moduleBindings))Object.assign(e,t);return Object.assign(e,this.directBindings),e}getModuleBindingValues(e){const t=this.moduleBindings[e];return t?{...t}:{}}getDebugTable(){var t;const e={};for(const[n,s]of Object.entries(this.moduleUniforms))for(const[r,o]of Object.entries(s))e[`${n}.${r}`]={type:(t=this.modules[n].uniformTypes)==null?void 0:t[r],value:String(o)};return e}_addModule(e){const t=e.name;this.moduleUniforms[t]=af({},e.defaultUniforms||{},e.uniformTypes),this.moduleBindings[t]={}}}function af(i={},e={},t={}){const n={...i};for(const[s,r]of Object.entries(e))r!==void 0&&(n[s]=Za(i[s],r,t[s]));return n}function Za(i,e,t){if(!t||typeof t=="string")return nn(e);if(Array.isArray(t)){if(Xa(e)||!Array.isArray(e))return nn(e);const o=Array.isArray(i)&&!Xa(i)?[...i]:[],a=o.slice();for(let c=0;c<e.length;c++){const l=e[c];l!==void 0&&(a[c]=Za(o[c],l,t[0]))}return a}if(!Ka(e))return nn(e);const n=t,s=Ka(i)?i:{},r={...s};for(const[o,a]of Object.entries(e))a!==void 0&&(r[o]=Za(s[o],a,n[o]));return r}function nn(i){return ArrayBuffer.isView(i)?Array.prototype.slice.call(i):Array.isArray(i)?Xa(i)?i.slice():i.map(t=>t===void 0?void 0:nn(t)):Ka(i)?Object.fromEntries(Object.entries(i).map(([e,t])=>[e,t===void 0?void 0:nn(t)])):i}function Xa(i){return ArrayBuffer.isView(i)||Array.isArray(i)&&(i.length===0||typeof i[0]=="number")}function Ka(i){return!!i&&typeof i=="object"&&!Array.isArray(i)&&!ArrayBuffer.isView(i)}function r3(i){return!!(i!=null&&i.dependencies)}const o3=W.DEBUG_DATA_MAX_LENGTH;class qe{constructor(e,t){h(this,"device");h(this,"id");h(this,"ready");h(this,"usage");h(this,"props");h(this,"isReady",!0);h(this,"destroyed",!1);h(this,"generation",0);h(this,"updateTimestamp");h(this,"debugData",new ArrayBuffer(0));h(this,"_debugDataEnabled");h(this,"_maxDebugDataByteLength");h(this,"_ownsBuffer");h(this,"_buffer");const{debugData:n=!1,buffer:s,ownsBuffer:r=!0,...o}=t;if(s&&s.device!==e)throw new Error("DynamicBuffer adopted buffers must belong to the supplied device");if(s&&(o.byteLength!==void 0||o.data!==void 0))throw new Error("DynamicBuffer cannot combine an adopted buffer with byteLength or data");const a=t.id||(s==null?void 0:s.id)||Nn("dynamic-buffer"),c={...o,id:a,usage:o.usage??(s==null?void 0:s.usage),indexType:o.indexType??(s==null?void 0:s.indexType)};(c.usage||0)&W.INDEX&&!c.indexType&&(o.data instanceof Uint32Array?c.indexType="uint32":o.data instanceof Uint16Array?c.indexType="uint16":o.data instanceof Uint8Array&&(c.indexType="uint8")),delete c.data,delete c.byteOffset,this.device=e,this.id=a,this.props=c,this.usage=c.usage||0,this._debugDataEnabled=!!n,this._maxDebugDataByteLength=typeof n=="object"&&n.maxByteLength!==void 0?n.maxByteLength:o3,this._ownsBuffer=r,this._buffer=s??this.device.createBuffer({...o,id:a}),this.ready=Promise.resolve(this._buffer),this.updateTimestamp=this._buffer.updateTimestamp,this._resetDebugData(this._buffer.byteLength),o.data&&this._writeDebugData(o.data,o.byteOffset||0)}get buffer(){return this._buffer}get byteLength(){return this._buffer.byteLength}get[Symbol.toStringTag](){return"DynamicBuffer"}toString(){return`DynamicBuffer:"${this.id}":${this.byteLength}B`}toJSON(){return this.toString()}write(e,t=0){this._buffer.write(e,t),this._touch(),this._writeDebugData(e,t)}async mapAndWriteAsync(e,t=0,n=this.byteLength-t){let s=null;await this._buffer.mapAndWriteAsync(async(r,o)=>{await e(r,o),s=new Uint8Array(r.slice(0,n))},t,n),this._touch(),s&&this._writeDebugData(s,t)}async readAsync(e=0,t=this.byteLength-e){const n=await this._buffer.readAsync(e,t);return this._writeDebugData(n,e)&&this._touch(),n}async mapAndReadAsync(e,t=0,n=this.byteLength-t){let s=null;const r=await this._buffer.mapAndReadAsync(async(o,a)=>(s=new Uint8Array(o.slice(0)),await e(o,a)),t,n);return s&&this._writeDebugData(s,t)&&this._touch(),r}resize(e){const{byteLength:t,preserveData:n=!1}=e;if(t===this.byteLength)return!1;const s=Math.min(e.copyByteLength??Math.min(this.byteLength,t),this.byteLength,t),r=this._buffer,o=this.debugData.slice(0),{data:a,byteOffset:c,...l}=this.props,u=this.device.createBuffer({...l,byteLength:t});return n&&s>0&&this._copyBufferContents(r,u,s),this._buffer=u,this._resetDebugData(t),n&&o.byteLength>0&&this._writeDebugData(o,0),this._ownsBuffer&&r.destroy(),this._ownsBuffer=!0,this.generation++,this._touch(),!0}ensureSize(e,t){return e<=this.byteLength?!1:this.resize({byteLength:e,preserveData:t==null?void 0:t.preserveData})}getBinding(e){return(e==null?void 0:e.offset)===void 0&&(e==null?void 0:e.size)===void 0?this._buffer:{buffer:this._buffer,offset:e==null?void 0:e.offset,size:e==null?void 0:e.size}}destroy(){this.destroyed||(this._ownsBuffer&&this._buffer.destroy(),this.destroyed=!0,this.debugData=new ArrayBuffer(0))}_copyBufferContents(e,t,n){const s=this.device.type==="webgpu"?Math.ceil(n/4)*4:n,r=this.device.createCommandEncoder();r.copyBufferToBuffer({sourceBuffer:e,destinationBuffer:t,size:s}),this.device.submit(r.finish())}_touch(){this.updateTimestamp=this.device.incrementTimestamp()}_resetDebugData(e){if(!this._debugDataEnabled){this.debugData=new ArrayBuffer(0);return}this.debugData=new ArrayBuffer(Math.min(e,this._maxDebugDataByteLength))}_writeDebugData(e,t){if(!this._debugDataEnabled||this.debugData.byteLength===0||t>=this.debugData.byteLength)return!1;const n=ArrayBuffer.isView(e)?new Uint8Array(e.buffer,e.byteOffset,e.byteLength):new Uint8Array(e),s=new Uint8Array(this.debugData),r=Math.min(n.byteLength,s.byteLength-t);return s.set(n.subarray(0,r),t),r>0}}function kg(i){return i!==null&&typeof i=="object"&&"buffer"in i}function a3(i){return i instanceof qe?i.buffer:i}function c3(i){return{buffer:a3(i.buffer),offset:i.offset,size:i.size}}function Es(i){return i!==null&&typeof i=="object"&&"resolveTextureBinding"in i&&typeof i.resolveTextureBinding=="function"}function l3(i){return(i==null?void 0:i.type)==="texture"||(i==null?void 0:i.type)==="external-texture"}function u3(i,e,t){const n=Dh(i,e,{ignoreWarnings:!0});return l3(n)?n:i.bindings.length===0&&(t==null?void 0:t.fallbackGroup)!==void 0?{type:"texture",name:e,group:t.fallbackGroup,location:0}:null}const We=2,f3=1e4,Mo="render pipeline initialization failed",d3=["stencil8","depth16unorm","depth24plus","depth24plus-stencil8","depth32float","depth32float-stencil8"],gn=class gn{constructor(e,t){h(this,"device");h(this,"id");h(this,"source");h(this,"vs");h(this,"fs");h(this,"pipelineFactory");h(this,"shaderFactory");h(this,"userData",{});h(this,"parameters");h(this,"topology");h(this,"bufferLayout");h(this,"isInstanced");h(this,"instanceCount",0);h(this,"vertexCount");h(this,"indexCount");h(this,"firstVertex");h(this,"firstIndex");h(this,"indexBuffer",null);h(this,"bufferAttributes",{});h(this,"constantAttributes",{});h(this,"bindings",{});h(this,"vertexArray");h(this,"transformFeedback",null);h(this,"pipeline");h(this,"shaderInputs");h(this,"material",null);h(this,"_uniformStore");h(this,"_attributeInfos",{});h(this,"_gpuGeometry",null);h(this,"props");h(this,"_dynamicIndexBufferSource",null);h(this,"_dynamicAttributeBufferSources",{});h(this,"_colorAttachmentFormats");h(this,"_depthStencilAttachmentFormat");h(this,"_pipelineNeedsUpdate","newly created");h(this,"_needsRedraw","initializing");h(this,"_drawBlockedReason",!1);h(this,"_destroyed",!1);h(this,"_vertexCountSet",!1);h(this,"_lastDrawTimestamp",-1);h(this,"_bindingTable",[]);h(this,"_lastLogTime",0);h(this,"_logOpen",!1);h(this,"_drawCount",0);var g;const n=gn.defaultProps.shaderAssembler,s=t.vertexCount!==void 0;this.props={...gn.defaultProps,...t,shaderAssembler:t.shaderAssembler??(Io(n,e.info.shadingLanguage)?n:vt.getDefaultShaderAssembler(e.info.shadingLanguage))},this._vertexCountSet=s,t=this.props,this.id=t.id||Nn("model"),this.device=e,Object.assign(this.userData,t.userData),this.material=t.material||null;const r=_3(e),o=Wh(this.props.plugins,r.shaderLanguage),a=Hh(this.props.modules,o.modules),c=Object.fromEntries(a.map(p=>[p.name,p])),l=t.shaderInputs||new Bg(c,{disableWarnings:this.props.disableWarnings});t.shaderInputs&&o.modules.length>0&&l.addModules(o.modules),this.setShaderInputs(l);const u=Og(this.props.modules,l.getModules()),f={...o.defines,...this.props.defines};if(this.device.type==="webgl"&&(this.props._uniformBlockLayouts=QE(u)),this.props.shaderLayout=or(this.props.shaderLayout,u)||null,this.device.type==="webgpu"&&this.props.source){const p=this.props.shaderAssembler;_n(Io(p,"wgsl"));const{source:m,getUniforms:_,bindingTable:v,shaderLayout:w}=p.assembleWGSLShader({platformInfo:r,...this.props,modules:u,defines:f,pluginInjections:o.injections,pluginVertexInputs:o.vertexInputs,pluginVaryings:o.varyings});this.source=m,this._getModuleUniforms=_,this._bindingTable=v;const y=w??((g=e.getShaderLayout)==null?void 0:g.call(e,this.source)),x=h3(y,o.vertexInputs),S=KE(this.props.shaderLayout,x,Object.keys(o.vertexInputs));this.props.shaderLayout=or(S||null,u)||null}else{const p=this.props.shaderAssembler;_n(Io(p,"glsl"));const{vs:m,fs:_,getUniforms:v}=p.assembleGLSLShaderPair({platformInfo:r,...this.props,modules:u,defines:f,pluginInjections:o.injections,pluginVertexInputs:o.vertexInputs,pluginVaryings:o.varyings});this.vs=m,this.fs=_,this._getModuleUniforms=v,this._bindingTable=[]}this.vertexCount=this.props.vertexCount,this.indexCount=this.props.indexCount,this.firstVertex=this.props.firstVertex,this.firstIndex=this.props.firstIndex,this.instanceCount=this.props.instanceCount,this.topology=this.props.topology,this.bufferLayout=this.props.bufferLayout,this.parameters=this.props.parameters,this._colorAttachmentFormats=this.props.colorAttachmentFormats,this._depthStencilAttachmentFormat=this.props.depthStencilAttachmentFormat,t.geometry&&this.setGeometry(t.geometry),this.pipelineFactory=t.pipelineFactory||qs.getDefaultPipelineFactory(this.device),this.shaderFactory=t.shaderFactory||Zs.getDefaultShaderFactory(this.device),this.pipeline=this._updatePipeline(),this.vertexArray=e.createVertexArray({shaderLayout:this.pipeline.shaderLayout,bufferLayout:this.pipeline.bufferLayout}),this._gpuGeometry&&this._setGeometryAttributes(this._gpuGeometry),"isInstanced"in t&&(this.isInstanced=t.isInstanced),t.instanceCount&&this.setInstanceCount(t.instanceCount),t.vertexCount&&this.setVertexCount(t.vertexCount),t.indexBuffer&&this.setIndexBuffer(t.indexBuffer),t.attributes&&this.setAttributes(t.attributes),t.constantAttributes&&this.setConstantAttributes(t.constantAttributes),t.bindings&&this.setBindings(t.bindings),t.transformFeedback&&(this.transformFeedback=t.transformFeedback)}get[Symbol.toStringTag](){return"Model"}toString(){return`Model(${this.id})`}destroy(){var e;this._destroyed||(this.pipelineFactory.release(this.pipeline),this.shaderFactory.release(this.pipeline.vs),this.pipeline.fs&&this.pipeline.fs!==this.pipeline.vs&&this.shaderFactory.release(this.pipeline.fs),this._uniformStore.destroy(),(e=this._gpuGeometry)==null||e.destroy(),this._destroyed=!0)}needsRedraw(){this._getBindingsUpdateTimestamp()>this._lastDrawTimestamp&&this.setNeedsRedraw("contents of bound textures or buffers updated");const e=this._needsRedraw;return this._needsRedraw=!1,e}setNeedsRedraw(e){this._needsRedraw||(this._needsRedraw=e)}getBindingDebugTable(){return this._bindingTable}predraw(e){var t;this._syncDynamicBuffers(),this.updateShaderInputs(e),(t=this.material)==null||t.updateShaderInputs(e),this.pipeline=this._updatePipeline()}draw(e){var r;if(this._drawBlockedReason&&!this._pipelineNeedsUpdate)return M.info(We,`>>> DRAWING ABORTED ${this.id}: ${this._drawBlockedReason}`)(),!1;const t=this._areBindingsLoading();if(t)return M.info(We,`>>> DRAWING ABORTED ${this.id}: ${t} not loaded`)(),!1;this._syncAttachmentFormats(e);try{e.pushDebugGroup(`${this}.predraw(${e})`),this.device.type==="webgpu"?(this.updateShaderInputs(),(r=this.material)==null||r.updateShaderInputs(),this._syncDynamicBuffers(),this.pipeline=this._updatePipeline()):this.predraw(this.device.commandEncoder)}finally{e.popDebugGroup()}let n,s=this.pipeline.isErrored;try{if(e.pushDebugGroup(`${this}.draw(${e})`),this._logDrawCallStart(),this.pipeline=this._updatePipeline(),s=this.pipeline.isErrored,s)M.info(We,`>>> DRAWING ABORTED ${this.id}: ${Mo}`)(),n=!1;else{const o=this.vertexArray.getDrawValidationError();if(o)M.info(We,`>>> DRAWING ABORTED ${this.id}: ${o}`)(),this._drawBlockedReason=o,n=!1;else{const a=this._getCurrentShaderLayout(),c=this._getBindings(a),l=this._getBindGroups(a,c),{indexBuffer:u}=this.vertexArray,f=u?this.indexCount??(this._vertexCountSet?this.vertexCount:u.byteLength/(u.indexType==="uint32"?4:2)):void 0;e.setPipeline(this.pipeline),e.setBindings(l,{_bindGroupCacheKeys:this._getBindGroupCacheKeys()}),e.setVertexArray(this.vertexArray),n=this.isInstanced===!0&&this.instanceCount===0?!0:e.draw({isInstanced:this.isInstanced,vertexCount:this.vertexCount,instanceCount:this.isInstanced?this.instanceCount:void 0,indexCount:f,firstVertex:this.firstVertex,firstIndex:this.firstIndex,transformFeedback:this.transformFeedback||void 0,uniforms:this.props.uniforms,parameters:this.parameters,topology:this.topology})}}}finally{e.popDebugGroup(),this._logDrawCallEnd()}return this._logFramebuffer(e),n?(this._lastDrawTimestamp=this.device.timestamp,this._needsRedraw=!1):s?(this._needsRedraw=Mo,this._drawBlockedReason=Mo):this._drawBlockedReason?this._needsRedraw=this._drawBlockedReason:this._needsRedraw="waiting for resource initialization",n}setGeometry(e){var n;(n=this._gpuGeometry)==null||n.destroy();const t=e&&UE(this.device,e);if(t){this.setTopology(t.topology||"triangle-list");const s=new Ao(this.bufferLayout);this.bufferLayout=s.mergeBufferLayouts(t.bufferLayout,this.bufferLayout),this.vertexArray&&this._setGeometryAttributes(t)}this._gpuGeometry=t}setTopology(e){e!==this.topology&&(this.topology=e,this._setPipelineNeedsUpdate("topology"))}setBufferLayout(e){const t=new Ao(this.bufferLayout),n=this._gpuGeometry?t.mergeBufferLayouts(e,this._gpuGeometry.bufferLayout):e;tn(n,this.bufferLayout,-1)||(this.bufferLayout=n,this._setPipelineNeedsUpdate("bufferLayout"),this.pipeline=this._updatePipeline(),this.vertexArray=this.device.createVertexArray({shaderLayout:this.pipeline.shaderLayout,bufferLayout:this.pipeline.bufferLayout}),this._gpuGeometry&&this._setGeometryAttributes(this._gpuGeometry))}setParameters(e){tn(e,this.parameters,2)||(this.parameters=e,this._setPipelineNeedsUpdate("parameters"))}setInstanceCount(e){this.instanceCount=e,this.isInstanced===void 0&&e>0&&(this.isInstanced=!0),this.setNeedsRedraw("instanceCount")}setVertexCount(e){this.vertexCount=e,this._vertexCountSet=!0,this.setNeedsRedraw("vertexCount")}setIndexCount(e){this.indexCount=e,this.setNeedsRedraw("indexCount")}setDrawOffsets({firstVertex:e,firstIndex:t}){this.firstVertex=e,this.firstIndex=t,this.setNeedsRedraw("drawOffsets")}setShaderInputs(e){var t;this.shaderInputs=e,this._uniformStore=new jh(this.device,this.shaderInputs.modules);for(const[n,s]of Object.entries(this.shaderInputs.modules))if(al(s)&&!((t=this.material)!=null&&t.ownsModule(n))){const r=this._uniformStore.getManagedUniformBuffer(n);this.bindings[`${n}Uniforms`]=r}this.setNeedsRedraw("shaderInputs")}setMaterial(e){this.material=e,this.setNeedsRedraw("material")}updateShaderInputs(e){this._uniformStore.setUniforms(this.shaderInputs.getUniformValues(),e),this.setBindings(this._getNonMaterialBindings(this.shaderInputs.getBindingValues())),this.setNeedsRedraw("shaderInputs")}setBindings(e){Object.assign(this.bindings,e),this.setNeedsRedraw("bindings")}setTransformFeedback(e){this.transformFeedback=e,this.setNeedsRedraw("transformFeedback")}setIndexBuffer(e){const t=e instanceof qe?e.buffer:e;this.indexBuffer=t,this._dynamicIndexBufferSource=e instanceof qe?{source:e,generation:e.generation}:null,this.vertexArray.setIndexBuffer(t),this.setNeedsRedraw("indexBuffer")}setAttributes(e,t){this._drawBlockedReason=!1;const n=(t==null?void 0:t.disableWarnings)??this.props.disableWarnings;e.indices&&M.warn(`Model:${this.id} setAttributes() - indexBuffer should be set using setIndexBuffer()`)(),this.bufferLayout=XE(this.pipeline.shaderLayout,this.bufferLayout);const s=new Ao(this.bufferLayout);for(const[r,o]of Object.entries(e)){const a=o instanceof qe?o.buffer:o,c=s.getBufferLayout(r);if(!c){n||M.warn(`Model(${this.id}): Missing layout for buffer "${r}".`)();continue}const l=s.getAttributeNamesForBuffer(c);let u=!1;for(const f of l){const d=this._attributeInfos[f];if(d){const g=this.device.type==="webgpu"?this.vertexArray.getBufferSlot(d.bufferName):d.location;if(g===null){n||M.warn(`Model(${this.id}): Missing vertex array slot for buffer "${d.bufferName}".`)();continue}this.vertexArray.setBuffer(g,a),o instanceof qe?this._dynamicAttributeBufferSources[g]={source:o,generation:o.generation}:delete this._dynamicAttributeBufferSources[g],u=!0}}!u&&!n&&M.warn(`Model(${this.id}): Ignoring buffer "${a.id}" for unknown attribute "${r}"`)()}this.setNeedsRedraw("attributes")}setConstantAttributes(e,t){for(const[n,s]of Object.entries(e)){const r=this._attributeInfos[n];r?this.vertexArray.setConstantWebGL(r.location,s):((t==null?void 0:t.disableWarnings)??this.props.disableWarnings)||M.warn(`Model "${this.id}: Ignoring constant supplied for unknown attribute "${n}"`)()}this.setNeedsRedraw("constants")}_areBindingsLoading(){var e;for(const t of Object.values(this.bindings))if(Es(t)&&!t.isReady)return t.id;for(const t of Object.values(((e=this.material)==null?void 0:e.bindings)||{}))if(Es(t)&&!t.isReady)return t.id;return!1}_getBindings(e=this._getCurrentShaderLayout()){const t={};for(const[n,s]of Object.entries(this.bindings)){const r=g3(n,s,e);r&&(t[n]=r)}return t}_getBindGroups(e=this._getCurrentShaderLayout(),t=this._getBindings(e)){const n=e.bindings.length?Dc(e,t):{0:t};if(!this.material)return n;for(const[s,r]of Object.entries(this.material.getBindingsByGroup(e))){const o=Number(s);n[o]={...n[o]||{},...r}}return n}_getBindGroupCacheKeys(){var t;const e=(t=this.material)==null?void 0:t.getBindGroupCacheKey(3);return e?{3:e}:{}}_getBindingsUpdateTimestamp(){var t;let e=0;this._dynamicIndexBufferSource&&(e=Math.max(e,this._dynamicIndexBufferSource.source.updateTimestamp));for(const n of Object.values(this._dynamicAttributeBufferSources))e=Math.max(e,n.source.updateTimestamp);for(const n of Object.values(this.bindings))n instanceof Ws?e=Math.max(e,n.texture.updateTimestamp):n instanceof W||n instanceof he||n instanceof Sa||n instanceof qe?e=Math.max(e,n.updateTimestamp):Es(n)?e=n.isReady?Math.max(e,n.updateTimestamp):1/0:kg(n)&&(e=Math.max(e,(n.buffer instanceof qe,n.buffer.updateTimestamp)));return Math.max(e,((t=this.material)==null?void 0:t.getBindingsUpdateTimestamp())||0)}_setGeometryAttributes(e){const t={...e.attributes};for(const[n]of Object.entries(t))!this.pipeline.shaderLayout.attributes.find(s=>s.name===n)&&n!=="positions"&&delete t[n];this.vertexCount=e.vertexCount,this._vertexCountSet=!0,this.setIndexBuffer(e.indices||null),this.setAttributes(e.attributes,{disableWarnings:!0}),this.setAttributes(t,{disableWarnings:this.props.disableWarnings}),this.setNeedsRedraw("geometry attributes")}_setPipelineNeedsUpdate(e){this._pipelineNeedsUpdate||(this._pipelineNeedsUpdate=e),this._drawBlockedReason=!1,this.setNeedsRedraw(e)}_updatePipeline(){if(this._pipelineNeedsUpdate){let e=null,t=null;this.pipeline&&(M.log(1,`Model ${this.id}: Recreating pipeline because "${this._pipelineNeedsUpdate}".`)(),e=this.pipeline.vs,t=this.pipeline.fs),this._pipelineNeedsUpdate=!1;const n=this.shaderFactory.createShader({id:`${this.id}-vertex`,stage:"vertex",source:this.source||this.vs,debugShaders:this.props.debugShaders});let s=null;this.source?s=n:this.fs&&(s=this.shaderFactory.createShader({id:`${this.id}-fragment`,stage:"fragment",source:this.source||this.fs,debugShaders:this.props.debugShaders})),this.pipeline=this.pipelineFactory.createRenderPipeline({...this.props,bindings:void 0,bufferLayout:this.bufferLayout,colorAttachmentFormats:this._colorAttachmentFormats,depthStencilAttachmentFormat:this._depthStencilAttachmentFormat,topology:this.topology,parameters:this.parameters,bindGroups:void 0,vs:n,fs:s}),this._attributeInfos=Vh(this.pipeline.shaderLayout,this.bufferLayout),e&&this.shaderFactory.release(e),t&&t!==e&&this.shaderFactory.release(t)}return this.pipeline}_logDrawCallStart(){const e=M.level>3?0:f3;M.level<2||Date.now()-this._lastLogTime<e||(this._lastLogTime=Date.now(),this._logOpen=!0,M.group(We,`>>> DRAWING MODEL ${this.id}`,{collapsed:M.level<=2})())}_logDrawCallEnd(){if(this._logOpen){const e=jE(this.pipeline.shaderLayout,this.id);M.table(We,e)();const t=this.shaderInputs.getDebugTable();M.table(We,t)();const n=this._getAttributeDebugTable();M.table(We,this._attributeInfos)(),M.table(We,n)(),M.groupEnd(We)(),this._logOpen=!1}}_logFramebuffer(e){const t=this.device.props.debugFramebuffers;if(this._drawCount++,!t)return;const n=e.props.framebuffer;VE(e,n,{id:(n==null?void 0:n.id)||`${this.id}-framebuffer`,minimap:!0})}_getAttributeDebugTable(){const e={};for(const[t,n]of Object.entries(this._attributeInfos)){const s=this.vertexArray.attributes[n.location];e[n.location]={name:t,type:n.shaderType,values:s?this._getBufferOrConstantValues(s,n.bufferDataType):"null"}}if(this.vertexArray.indexBuffer){const{indexBuffer:t}=this.vertexArray,n=t.indexType==="uint32"?new Uint32Array(t.debugData):new Uint16Array(t.debugData);e.indices={name:"indices",type:t.indexType,values:n.toString()}}return e}_getBufferOrConstantValues(e,t){const n=et.getTypedArrayConstructor(t);return(e instanceof W?new n(e.debugData):e).toString()}_getNonMaterialBindings(e){if(!this.material)return e;const t={};for(const[n,s]of Object.entries(e))this.material.ownsBinding(n)||(t[n]=s);return t}_getCurrentShaderLayout(){var e;return((e=this.pipeline)==null?void 0:e.shaderLayout)||this.props.shaderLayout||{bindings:[]}}_syncDynamicBuffers(){if(this._dynamicIndexBufferSource&&this._dynamicIndexBufferSource.generation!==this._dynamicIndexBufferSource.source.generation){const e=this._dynamicIndexBufferSource.source.buffer;this.indexBuffer=e,this.vertexArray.setIndexBuffer(e),this._dynamicIndexBufferSource.generation=this._dynamicIndexBufferSource.source.generation,this.setNeedsRedraw("dynamic index buffer")}for(const[e,t]of Object.entries(this._dynamicAttributeBufferSources))t.generation!==t.source.generation&&(this.vertexArray.setBuffer(Number(e),t.source.buffer),t.generation=t.source.generation,this.setNeedsRedraw("dynamic attribute buffer"))}_syncAttachmentFormats(e){var o,a,c;if(this.device.type!=="webgpu")return;const t=e.framebuffer||e.props.framebuffer,n=e.props,s=n.colorAttachmentFormats??((o=t==null?void 0:t.colorAttachments)==null?void 0:o.map(l=>{var u;return p3((u=l==null?void 0:l.texture)==null?void 0:u.format)})),r=n.depthStencilAttachmentFormat===!1?void 0:n.depthStencilAttachmentFormat??m3((c=(a=t==null?void 0:t.depthStencilAttachment)==null?void 0:a.texture)==null?void 0:c.format);(!tn(this._colorAttachmentFormats,s,1)||this._depthStencilAttachmentFormat!==r)&&(this._colorAttachmentFormats=s,this._depthStencilAttachmentFormat=r,this._setPipelineNeedsUpdate("attachment formats"))}};h(gn,"defaultProps",{...ht.defaultProps,source:void 0,vs:null,fs:null,id:"unnamed",handle:void 0,userData:{},defines:{},modules:[],plugins:[],geometry:null,indexBuffer:null,indexCount:void 0,firstVertex:0,firstIndex:0,attributes:{},constantAttributes:{},bindings:{},uniforms:{},varyings:[],isInstanced:void 0,instanceCount:0,vertexCount:0,shaderInputs:void 0,material:void 0,pipelineFactory:void 0,shaderFactory:void 0,transformFeedback:void 0,shaderAssembler:vt.getDefaultShaderAssembler("glsl"),debugShaders:void 0,disableWarnings:void 0});let Ue=gn;function Io(i,e){return i.shaderLanguage!==void 0&&i.shaderLanguage!==e?!1:e==="glsl"?"assembleGLSLShaderPair"in i&&typeof i.assembleGLSLShaderPair=="function":"assembleWGSLShader"in i&&typeof i.assembleWGSLShader=="function"}function h3(i,e){return!i||Object.keys(e).length===0?i:{...i,attributes:i.attributes.map(t=>{const n=t.name.startsWith("_luma_")?t.name.slice(6):null;return n&&e[n]?{...t,name:n}:t})}}function g3(i,e,t){if(Es(e)){const n=u3(t,i,{fallbackGroup:0});return n?e.resolveTextureBinding(n):null}return e instanceof qe?e.buffer:kg(e)?c3(e):e}function p3(i){return i&&!Dg(i)?i:null}function m3(i){return i&&Dg(i)?i:void 0}function Dg(i){return d3.includes(i)}function _3(i){return{type:i.type,shaderLanguage:i.info.shadingLanguage,shaderLanguageVersion:i.info.shadingLanguageVersion,gpu:i.info.gpu,limits:i.limits,features:i.features}}const y3=35980,b3=35981,pn=class pn{constructor(e,t=pn.defaultProps){h(this,"device");h(this,"model");h(this,"transformFeedback");if(!pn.isSupported(e))throw new Error("BufferTransform not yet implemented on WebGPU");this.device=e,this.model=new Ue(this.device,{id:t.id||"buffer-transform-model",fs:t.fs||Yw(),topology:t.topology||"point-list",varyings:t.outputs||t.varyings,...t,bufferMode:t.bufferMode||(t.feedbackBufferMode==="interleaved"?y3:b3)}),this.transformFeedback=this.device.createTransformFeedback({layout:this.model.pipeline.shaderLayout,buffers:t.feedbackBuffers}),this.model.setTransformFeedback(this.transformFeedback)}static isSupported(e){var t;return((t=e==null?void 0:e.info)==null?void 0:t.type)==="webgl"}destroy(){this.model&&this.model.destroy()}delete(){this.destroy()}run(e){e!=null&&e.inputBuffers&&this.model.setAttributes(e.inputBuffers),e!=null&&e.outputBuffers&&this.transformFeedback.setBuffers(e.outputBuffers);const t=this.device.beginRenderPass({discard:!0,...e});this.model.draw(t),t.end()}getBuffer(e){return this.transformFeedback.getBuffer(e)}readAsync(e){const t=this.getBuffer(e);if(!t)throw new Error("BufferTransform#getBuffer");if(t instanceof W)return t.readAsync();const{buffer:n,byteOffset:s=0,byteLength:r=n.byteLength}=t;return n.readAsync(s,r)}};h(pn,"defaultProps",{...Ue.defaultProps,feedbackBufferMode:"separate",outputs:void 0,feedbackBuffers:void 0});let Sn=pn;const Ro=2,v3=1e4,Ir=class Ir{constructor(e,t){h(this,"device");h(this,"id");h(this,"pipelineFactory");h(this,"shaderFactory");h(this,"userData",{});h(this,"bindings",{});h(this,"pipeline");h(this,"source");h(this,"shader");h(this,"shaderInputs");h(this,"_uniformStore");h(this,"_pipelineNeedsUpdate","newly created");h(this,"_getModuleUniforms");h(this,"props");h(this,"_destroyed",!1);h(this,"_lastLogTime",0);h(this,"_logOpen",!1);h(this,"_drawCount",0);var p,m;if(e.type!=="webgpu")throw new Error("Computation is only supported in WebGPU");this.props={...Ir.defaultProps,...t},t=this.props,this.id=t.id||Nn("model"),this.device=e,Object.assign(this.userData,t.userData);const n=w3(e),s=Wh(this.props.plugins,n.shaderLanguage);if(Object.keys(s.vertexInputs).length>0||Object.keys(s.varyings).length>0)throw new Error("Computation does not support ShaderPlugin vertex inputs or varyings");const r=Hh(this.props.modules,s.modules),o=Object.fromEntries(r.map(_=>[_.name,_]));this.shaderInputs=t.shaderInputs||new Bg(o),t.shaderInputs&&s.modules.length>0&&this.shaderInputs.addModules(s.modules),this.setShaderInputs(this.shaderInputs);const a=Og(this.props.modules,(p=this.shaderInputs)==null?void 0:p.getModules()),c={...s.defines,...this.props.defines};this.props.shaderLayout=or(this.props.shaderLayout,a)||null,this.pipelineFactory=t.pipelineFactory||qs.getDefaultPipelineFactory(this.device),this.shaderFactory=t.shaderFactory||Zs.getDefaultShaderFactory(this.device);const l=this.props.shaderAssembler;_n(l instanceof _i);const{source:u,getUniforms:f,shaderLayout:d}=l.assembleWGSLShader({platformInfo:n,...this.props,modules:a,defines:c,scanVertexAttributes:!1,pluginInjections:s.injections});this.source=u,this._getModuleUniforms=f;const g=d??((m=e.getShaderLayout)==null?void 0:m.call(e,this.source,{scanVertexAttributes:!1}));this.props.shaderLayout=or(this.props.shaderLayout||g||null,a)||null,this.pipeline=this._updatePipeline(),t.bindings&&this.setBindings(t.bindings)}destroy(){this._destroyed||(this.pipelineFactory.release(this.pipeline),this.shaderFactory.release(this.shader),this._uniformStore.destroy(),this._destroyed=!0)}predraw(e){this.updateShaderInputs(e)}dispatch(e,t,n,s){try{this._logDrawCallStart(),this._setPipeline(e),e.dispatch(t,n,s)}finally{this._logDrawCallEnd()}}dispatchIndirect(e,t,n=0){try{this._logDrawCallStart(),this._setPipeline(e),e.dispatchIndirect(t,n)}finally{this._logDrawCallEnd()}}_setPipeline(e){this.pipeline=this._updatePipeline(),this.pipeline.setBindings(this.bindings),e.setPipeline(this.pipeline),e.setBindings({})}setVertexCount(e){}setInstanceCount(e){}setShaderInputs(e){this.shaderInputs=e,this._uniformStore=new jh(this.device,this.shaderInputs.modules);for(const[t,n]of Object.entries(this.shaderInputs.modules))if(al(n)){const s=this._uniformStore.getManagedUniformBuffer(t);this.bindings[`${t}Uniforms`]=s}}setShaderModuleProps(e){const t=this._getModuleUniforms(e),n=Object.keys(t).filter(s=>{const r=t[s];return!gh(r)&&typeof r!="number"&&typeof r!="boolean"});for(const s of n)t[s],delete t[s]}updateShaderInputs(e){this._uniformStore.setUniforms(this.shaderInputs.getUniformValues(),e)}setBindings(e){Object.assign(this.bindings,e)}_setPipelineNeedsUpdate(e){this._pipelineNeedsUpdate=this._pipelineNeedsUpdate||e}_updatePipeline(){if(this._pipelineNeedsUpdate){let e=null;this.pipeline&&(M.log(1,`Model ${this.id}: Recreating pipeline because "${this._pipelineNeedsUpdate}".`)(),e=this.shader),this._pipelineNeedsUpdate=!1,this.shader=this.shaderFactory.createShader({id:`${this.id}-fragment`,stage:"compute",source:this.source,debugShaders:this.props.debugShaders}),this.pipeline=this.pipelineFactory.createComputePipeline({...this.props,shader:this.shader}),e&&this.shaderFactory.release(e)}return this.pipeline}_logDrawCallStart(){const e=M.level>3?0:v3;M.level<2||Date.now()-this._lastLogTime<e||(this._lastLogTime=Date.now(),this._logOpen=!0,M.group(Ro,`>>> DRAWING MODEL ${this.id}`,{collapsed:M.level<=2})())}_logDrawCallEnd(){if(this._logOpen){const e=this.shaderInputs.getDebugTable();M.table(Ro,e)(),M.groupEnd(Ro)(),this._logOpen=!1}}_getBufferOrConstantValues(e,t){const n=et.getTypedArrayConstructor(t);return(e instanceof W?new n(e.debugData):e).toString()}};h(Ir,"defaultProps",{...yn.defaultProps,id:"unnamed",handle:void 0,userData:{},source:"",modules:[],defines:{},plugins:[],bindings:void 0,shaderInputs:void 0,pipelineFactory:void 0,shaderFactory:void 0,shaderAssembler:vt.getDefaultShaderAssembler("wgsl"),debugShaders:void 0});let Qa=Ir;function w3(i){return{type:i.type,shaderLanguage:i.info.shadingLanguage,shaderLanguageVersion:i.info.shadingLanguageVersion,gpu:i.info.gpu,limits:i.limits,features:i.features}}const x3={blendColorOperation:"add",blendColorSrcFactor:"one",blendColorDstFactor:"zero",blendAlphaOperation:"add",blendAlphaSrcFactor:"constant",blendAlphaDstFactor:"zero"};class Fg extends sl{constructor(){super(...arguments),this._colorEncoderState=null}render(e){return"pickingFBO"in e?this._drawPickingBuffer(e):{decodePickingColor:null,stats:super._render(e)}}_drawPickingBuffer({layers:e,layerFilter:t,views:n,viewports:s,onViewportActive:r,pickingFBO:o,deviceRect:{x:a,y:c,width:l,height:u},cullRect:f,effects:d,pass:g="picking",pickZ:p,canvasContext:m,shaderModuleProps:_,clearColor:v}){this.pickZ=p;const w=this._resetColorEncoder(p),y=[a,c,l,u],x=super._render({target:o,layers:e,layerFilter:t,views:n,viewports:s,onViewportActive:r,cullRect:f,effects:d==null?void 0:d.filter(C=>C.useInPicking),pass:g,canvasContext:m,isPicking:!0,shaderModuleProps:_,clearColor:v??[0,0,0,0],colorMask:15,scissorRect:y});return this._colorEncoderState=null,{decodePickingColor:w&&P3.bind(null,w),stats:x}}shouldDrawLayer(e){const{pickable:t,operation:n}=e.props;return t&&n.includes("draw")||n.includes("terrain")||n.includes("mask")}getShaderModuleProps(e,t,n){var s;return{picking:{isActive:1,isAttribute:this.pickZ,disabledPickingIndices:(s=e.internalState)==null?void 0:s.disabledPickingIndices},lighting:{enabled:!1}}}getLayerParameters(e,t,n){var a;const s={...e.props.parameters},{pickable:r,operation:o}=e.props;return this._colorEncoderState?r&&o.includes("draw")?(Object.assign(s,x3),s.blend=!0,this.device.type==="webgpu"?s.blendConstant=cf(this._colorEncoderState,e,n):s.blendColor=cf(this._colorEncoderState,e,n),o.includes("terrain")&&((a=e.state)!=null&&a._hasPickingCover)&&(s.blendAlphaSrcFactor="one")):o.includes("terrain")&&(s.blend=!1):s.blend=!1,s}_resetColorEncoder(e){return this._colorEncoderState=e?null:{byLayer:new Map,byAlpha:[]},this._colorEncoderState}}function cf(i,e,t){const{byLayer:n,byAlpha:s}=i;let r,o=n.get(e);return o?(o.viewports.push(t),r=o.a):(r=n.size+1,r<=255?(o={a:r,layer:e,viewports:[t]},n.set(e,o),s[r]=o):(Y.warn("Too many pickable layers, only picking the first 255")(),r=0)),[0,0,0,r/255]}function P3(i,e){const t=i.byAlpha[e[3]];return t&&{pickedLayer:t.layer,pickedViewports:t.viewports,pickedObjectIndex:t.layer.decodePickingColor(e)}}const ti={NO_STATE:"Awaiting state",MATCHED:"Matched. State transferred from previous layer",INITIALIZED:"Initialized",AWAITING_GC:"Discarded. Awaiting garbage collection",AWAITING_FINALIZATION:"No longer matched. Awaiting garbage collection",FINALIZED:"Finalized! Awaiting garbage collection"},ar=Symbol.for("component"),_t=Symbol.for("propTypes"),Oo=Symbol.for("deprecatedProps"),ui=Symbol.for("asyncPropDefaults"),$t=Symbol.for("asyncPropOriginal"),gt=Symbol.for("asyncPropResolved");function wi(i,e=()=>!0){return Array.isArray(i)?zg(i,e,[]):e(i)?[i]:[]}function zg(i,e,t){let n=-1;for(;++n<i.length;){const s=i[n];Array.isArray(s)?zg(s,e,t):e(s)&&t.push(s)}return t}function S3({target:i,source:e,start:t=0,count:n=1}){const s=e.length,r=n*s;let o=0;for(let a=t;o<s;o++)i[a++]=e[o];for(;o<r;)o<r-o?(i.copyWithin(t+o,t,t+o),o*=2):(i.copyWithin(t+o,t,t+r-o),o=r);return i}class E3{constructor(e,t,n){this._loadCount=0,this._subscribers=new Set,this.id=e,this.context=n,this.setData(t)}subscribe(e){this._subscribers.add(e)}unsubscribe(e){this._subscribers.delete(e)}inUse(){return this._subscribers.size>0}delete(){}getData(){return this.isLoaded?this._error?Promise.reject(this._error):this._content:this._loader.then(()=>this.getData())}setData(e,t){if(e===this._data&&!t)return;this._data=e;const n=++this._loadCount;let s=e;typeof e=="string"&&(s=zs(e)),s instanceof Promise?(this.isLoaded=!1,this._loader=s.then(r=>{this._loadCount===n&&(this.isLoaded=!0,this._error=void 0,this._content=r)}).catch(r=>{this._loadCount===n&&(this.isLoaded=!0,this._error=r||!0)})):(this.isLoaded=!0,this._error=void 0,this._content=e);for(const r of this._subscribers)r.onChange(this.getData())}}class C3{constructor(e){var t;this.protocol=e.protocol||"resource://",this._context={device:e.device,gl:(t=e.device)==null?void 0:t.gl,resourceManager:this},this._resources={},this._consumers={},this._pruneRequest=null}contains(e){return e.startsWith(this.protocol)?!0:e in this._resources}add({resourceId:e,data:t,forceUpdate:n=!1,persistent:s=!0}){let r=this._resources[e];r?r.setData(t,n):(r=new E3(e,t,this._context),this._resources[e]=r),r.persistent=s}remove(e){const t=this._resources[e];t&&(t.delete(),delete this._resources[e])}unsubscribe({consumerId:e}){const t=this._consumers[e];if(t){for(const n in t){const s=t[n],r=this._resources[s.resourceId];r&&r.unsubscribe(s)}delete this._consumers[e],this.prune()}}subscribe({resourceId:e,onChange:t,consumerId:n,requestId:s="default"}){const{_resources:r,protocol:o}=this;e.startsWith(o)&&(e=e.replace(o,""),r[e]||this.add({resourceId:e,data:null,persistent:!1}));const a=r[e];if(this._track(n,s,a,t),a)return a.getData()}prune(){this._pruneRequest||(this._pruneRequest=setTimeout(()=>this._prune(),0))}finalize(){for(const e in this._resources)this._resources[e].delete()}_track(e,t,n,s){const r=this._consumers,o=r[e]=r[e]||{};let a=o[t];const c=a&&a.resourceId&&this._resources[a.resourceId];c&&(c.unsubscribe(a),this.prune()),n&&(a?(a.onChange=s,a.resourceId=n.id):a={onChange:s,resourceId:n.id},o[t]=a,n.subscribe(a))}_prune(){this._pruneRequest=null;for(const e of Object.keys(this._resources)){const t=this._resources[e];!t.persistent&&!t.inUse()&&(t.delete(),delete this._resources[e])}}}const L3="layerManager.setLayers",T3="layerManager.activateViewport";class A3{constructor(e,t){var a;this._lastRenderedLayers=[],this._needsRedraw=!1,this._needsUpdate=!1,this._nextLayers=null,this._debug=!1,this._defaultShaderModulesChanged=!1,this.activateViewport=c=>{ye(T3,this,c),c&&(this.context.viewport=c)};const{deck:n,stats:s,viewport:r,timeline:o}=t||{};this.layers=[],this.resourceManager=new C3({device:e,protocol:"deck://"}),this.context={mousePosition:null,userData:{},layerManager:this,device:e,gl:e==null?void 0:e.gl,deck:n,shaderAssembler:sE(((a=e==null?void 0:e.info)==null?void 0:a.shadingLanguage)||"glsl"),defaultShaderModules:[VP],renderPass:void 0,stats:s||new Rr({id:"deck.gl"}),viewport:r||new Ai({id:"DEFAULT-INITIAL-VIEWPORT"}),timeline:o||new Rg,resourceManager:this.resourceManager,onError:void 0},Object.seal(this)}finalize(){this.resourceManager.finalize();for(const e of this.layers)this._finalizeLayer(e)}needsRedraw(e={clearRedrawFlags:!1}){let t=this._needsRedraw;e.clearRedrawFlags&&(this._needsRedraw=!1);for(const n of this.layers){const s=n.getNeedsRedraw(e);t=t||s}return t}needsUpdate(){return this._nextLayers&&this._nextLayers!==this._lastRenderedLayers?"layers changed":this._defaultShaderModulesChanged?"shader modules changed":this._needsUpdate}setNeedsRedraw(e){this._needsRedraw=this._needsRedraw||e}setNeedsUpdate(e){this._needsUpdate=this._needsUpdate||e}getLayers({layerIds:e}={}){return e?this.layers.filter(t=>e.find(n=>t.id.indexOf(n)===0)):this.layers}setProps(e){"debug"in e&&(this._debug=e.debug),"userData"in e&&(this.context.userData=e.userData),"layers"in e&&(this._nextLayers=e.layers),"onError"in e&&(this.context.onError=e.onError)}setLayers(e,t){ye(L3,this,t,e),this._lastRenderedLayers=e;const n=wi(e,Boolean);for(const s of n)s.context=this.context;this._updateLayers(this.layers,n)}updateLayers(){const e=this.needsUpdate();e&&(this.setNeedsRedraw(`updating layers: ${e}`),this.setLayers(this._nextLayers||this._lastRenderedLayers,e)),this._nextLayers=null}addDefaultShaderModule(e){const{defaultShaderModules:t}=this.context;t.find(n=>n.name===e.name)||(t.push(e),this._defaultShaderModulesChanged=!0)}removeDefaultShaderModule(e){const{defaultShaderModules:t}=this.context,n=t.findIndex(s=>s.name===e.name);n>=0&&(t.splice(n,1),this._defaultShaderModulesChanged=!0)}_handleError(e,t,n){n.raiseError(t,`${e} of ${n}`)}_updateLayers(e,t){const n={};for(const o of e)n[o.id]?Y.warn(`Multiple old layers with same id ${o.id}`)():n[o.id]=o;if(this._defaultShaderModulesChanged){for(const o of e)o.setNeedsUpdate(),o.setChangeFlags({extensionsChanged:!0});this._defaultShaderModulesChanged=!1}const s=[];this._updateSublayersRecursively(t,n,s),this._finalizeOldLayers(n);let r=!1;for(const o of s)if(o.hasUniformTransition()){r=`Uniform transition in ${o}`;break}this._needsUpdate=r,this.layers=s}_updateSublayersRecursively(e,t,n){for(const s of e){s.context=this.context;const r=t[s.id];r===null&&Y.warn(`Multiple new layers with same id ${s.id}`)(),t[s.id]=null;let o=null;try{this._debug&&r!==s&&s.validateProps(),r?(this._transferLayerState(r,s),this._updateLayer(s)):this._initializeLayer(s),n.push(s),o=s.isComposite?s.getSubLayers():null}catch(a){this._handleError("matching",a,s)}o&&this._updateSublayersRecursively(o,t,n)}}_finalizeOldLayers(e){for(const t in e){const n=e[t];n&&this._finalizeLayer(n)}}_initializeLayer(e){try{e._initialize(),e.lifecycle=ti.INITIALIZED}catch(t){this._handleError("initialization",t,e)}}_transferLayerState(e,t){t._transferState(e),t.lifecycle=ti.MATCHED,t!==e&&(e.lifecycle=ti.AWAITING_GC)}_updateLayer(e){try{e._update()}catch(t){this._handleError("update",t,e)}}_finalizeLayer(e){this._needsRedraw=this._needsRedraw||`finalized ${e}`,e.lifecycle=ti.AWAITING_FINALIZATION;try{e._finalize(),e.lifecycle=ti.FINALIZED}catch(t){this._handleError("finalization",t,e)}}}function Pe(i,e,t){if(i===e)return!0;if(!t||!i||!e)return!1;if(Array.isArray(i)){if(!Array.isArray(e)||i.length!==e.length)return!1;for(let n=0;n<i.length;n++)if(!Pe(i[n],e[n],t-1))return!1;return!0}if(Array.isArray(e))return!1;if(typeof i=="object"&&typeof e=="object"){const n=Object.keys(i),s=Object.keys(e);if(n.length!==s.length)return!1;for(const r of n)if(!e.hasOwnProperty(r)||!Pe(i[r],e[r],t-1))return!1;return!0}return!1}const fi="default-canvas";class M3{constructor(e){this.views=[],this.width=100,this.height=100,this.viewState={},this.controllers={},this.timeline=e.timeline,this._viewports=[],this._viewportMap={},this._isUpdating=!1,this._needsRedraw="First render",this._needsUpdate="Initialize",this._eventManager=e.eventManager,this._eventManagers=e.eventManagers||{},this._viewEventManagers={},this._eventCallbacks={onViewStateChange:e.onViewStateChange,onInteractionStateChange:e.onInteractionStateChange},this._pickPosition=e.pickPosition,this._getCanvasContext=e.getCanvasContext,Object.seal(this),this.setProps(e)}finalize(){for(const e in this.controllers){const t=this.controllers[e];t&&t.finalize()}this.controllers={}}needsRedraw(e={clearRedrawFlags:!1}){const t=this._needsRedraw;return e.clearRedrawFlags&&(this._needsRedraw=!1),t}setNeedsUpdate(e){this._needsUpdate=this._needsUpdate||e,this._needsRedraw=this._needsRedraw||e}updateViewStates(){for(const e in this.controllers){const t=this.controllers[e];t&&t.updateTransition()}}getViewports(e){return e?this._viewports.filter(t=>{const n=!e.canvasId||this.getCanvasId(t.id)===e.canvasId,s=!("x"in e)||t.containsPixel(e);return n&&s}):this._viewports}getViews(){const e={};return this.views.forEach(t=>{e[t.id]=t}),e}getView(e){return this.views.find(t=>t.id===e)}getViewState(e){const t=typeof e=="string"?this.getView(e):e,n=t&&this.viewState[t.getViewStateId()]||this.viewState;return t?t.filterViewState(n):n}getViewport(e){return this._viewportMap[e]}getCanvasId(e){var n;const t=typeof e=="string"?this.getView(e):e;return t?((n=this._viewEventManagers[t.id])==null?void 0:n.canvasId)||this._getCanvasIdFromView(t):void 0}unproject(e,t){const n=this.getViewports(),s={x:e[0],y:e[1]};for(let r=n.length-1;r>=0;--r){const o=n[r];if(o.containsPixel(s)){const a=e.slice();return a[0]-=o.x,a[1]-=o.y,o.unproject(a,t)}}return null}setProps(e){e.views&&this._setViews(e.views),e.viewState&&this._setViewState(e.viewState),("width"in e||"height"in e)&&this._setSize(e.width,e.height),"pickPosition"in e&&(this._pickPosition=e.pickPosition),"eventManagers"in e&&this._setEventManagers(e.eventManagers||{}),this._isUpdating||this._update()}_update(){this._isUpdating=!0;try{this._needsUpdate&&(this._needsUpdate=!1,this._rebuildViewports()),this._needsUpdate&&(this._needsUpdate=!1,this._rebuildViewports())}finally{this._isUpdating=!1}}_hasViewState(e){const t=e.props.viewState;if(t&&typeof t=="object"&&!t.id||this.viewState[e.getViewStateId()])return!0;const n=Object.values(this.viewState);return n.length===0||n.some(s=>!s||typeof s!="object"||Array.isArray(s))}_setSize(e,t){(e!==this.width||t!==this.height)&&(this.width=e,this.height=t,this.setNeedsUpdate("Size changed"))}_setViews(e){e=wi(e,Boolean),this._diffViews(e,this.views)&&this.setNeedsUpdate("views changed"),this.views=e}_setViewState(e){e?(!Pe(e,this.viewState,3)&&this.setNeedsUpdate("viewState changed"),this.viewState=e):Y.warn("missing `viewState` or `initialViewState`")()}_setEventManagers(e){this._eventManagers!==e&&(this._eventManagers=e,this.setNeedsUpdate("eventManagers changed"))}_getCanvasIdFromView(e){var t,n;return e.props.canvasId||((n=(t=this._getCanvasContext)==null?void 0:t.call(this,e.id))==null?void 0:n.id)||fi}_getCanvasDimensions(e){var r;const t=(r=this._getCanvasContext)==null?void 0:r.call(this,e.id),[n,s]=(t==null?void 0:t.getCSSSize())||[this.width,this.height];return{width:n,height:s}}_getViewEventManager(e){const t=this.getCanvasId(e)||fi;return{canvasId:t,eventManager:this._eventManagers[t]||this._eventManager}}_startViewportRebuild(){const e=this.controllers,t=this._viewEventManagers;return this._viewports=[],this.controllers={},this._viewEventManagers={},{oldControllers:e,oldViewEventManagers:t}}_getReusableController(e,t,n){return e&&((t==null?void 0:t.canvasId)!==n.canvasId||(t==null?void 0:t.eventManager)!==n.eventManager)?(e.finalize(),null):e}_createController(e,t){const n=t.type;return new n({timeline:this.timeline,eventManager:this._getViewEventManager(e).eventManager,onViewStateChange:this._eventCallbacks.onViewStateChange,onStateChange:this._eventCallbacks.onInteractionStateChange,makeViewport:r=>{var o;return(o=this.getView(e.id))==null?void 0:o.makeViewport({viewState:r,...this._getCanvasDimensions(e)})},pickPosition:(r,o)=>{var a;return(a=this._pickPosition)==null?void 0:a.call(this,r,o,e.id)}})}_updateController(e,t,n,s){const r=e.controller;if(r&&n){const o={...t,...r,id:e.id,x:n.x,y:n.y,width:n.width,height:n.height};return(!s||s.constructor!==r.type)&&(s=this._createController(e,o)),s&&s.setProps(o),s}return null}_rebuildViewports(){const{views:e}=this,{oldControllers:t,oldViewEventManagers:n}=this._startViewportRebuild();let s=!1;for(let r=e.length;r--;){const o=e[r],{width:a,height:c}=this._getCanvasDimensions(o),l=this._getViewEventManager(o);this._viewEventManagers[o.id]=l;const u=this.getViewState(o),f=o.makeViewport({viewState:u,width:a,height:c});let d=this._getReusableController(t[o.id],n[o.id],l),g=!!o.controller;g&&!this._hasViewState(o)&&(g=!1),g&&!d&&(s=!0),(s||!g)&&d&&(d.finalize(),d=null),this.controllers[o.id]=g?this._updateController(o,u,f,d):null,f&&this._viewports.unshift(f)}for(const r in t){const o=t[r];o&&!this.controllers[r]&&o.finalize()}this._buildViewportMap()}_buildViewportMap(){this._viewportMap={},this._viewports.forEach(e=>{e.id&&(this._viewportMap[e.id]=this._viewportMap[e.id]||e)})}_diffViews(e,t){return e.length!==t.length?!0:e.some((n,s)=>!e[s].equals(t[s]))}}const I3=/^(?:\d+\.?\d*|\.\d+)$/;function Me(i){switch(typeof i){case"number":if(!Number.isFinite(i))throw new Error(`Could not parse position string ${i}`);return{type:"literal",value:i};case"string":try{const e=R3(i);return new O3(e).parseExpression()}catch(e){const t=e instanceof Error?e.message:String(e);throw new Error(`Could not parse position string ${i}: ${t}`)}default:throw new Error(`Could not parse position string ${i}`)}}function Ja(i,e){switch(i.type){case"literal":return i.value;case"percentage":return Math.round(i.value*e);case"binary":const t=Ja(i.left,e),n=Ja(i.right,e);return i.operator==="+"?t+n:t-n;default:throw new Error("Unknown layout expression type")}}function Ie(i,e){return Ja(i,e)}function R3(i){const e=[];let t=0;for(;t<i.length;){const n=i[t];if(/\s/.test(n)){t++;continue}if(n==="+"||n==="-"||n==="("||n===")"||n==="%"){e.push({type:"symbol",value:n}),t++;continue}if(lf(n)||n==="."){const s=t;let r=n===".";for(t++;t<i.length;){const a=i[t];if(lf(a)){t++;continue}if(a==="."&&!r){r=!0,t++;continue}break}const o=i.slice(s,t);if(!I3.test(o))throw new Error("Invalid number token");e.push({type:"number",value:parseFloat(o)});continue}if(uf(n)){const s=t;for(;t<i.length&&uf(i[t]);)t++;const r=i.slice(s,t).toLowerCase();e.push({type:"word",value:r});continue}throw new Error("Invalid token in position string")}return e}class O3{constructor(e){this.index=0,this.tokens=e}parseExpression(){const e=this.parseBinaryExpression();if(this.index<this.tokens.length)throw new Error("Unexpected token at end of expression");return e}parseBinaryExpression(){let e=this.parseFactor(),t=this.peek();for(;B3(t);){this.index++;const n=this.parseFactor();e={type:"binary",operator:t.value,left:e,right:n},t=this.peek()}return e}parseFactor(){const e=this.peek();if(!e)throw new Error("Unexpected end of expression");if(e.type==="symbol"&&e.value==="+")return this.index++,this.parseFactor();if(e.type==="symbol"&&e.value==="-"){this.index++;const t=this.parseFactor();return{type:"binary",operator:"-",left:{type:"literal",value:0},right:t}}if(e.type==="symbol"&&e.value==="("){this.index++;const t=this.parseBinaryExpression();if(!this.consumeSymbol(")"))throw new Error("Missing closing parenthesis");return t}if(e.type==="word"&&e.value==="calc"){if(this.index++,!this.consumeSymbol("("))throw new Error("Missing opening parenthesis after calc");const t=this.parseBinaryExpression();if(!this.consumeSymbol(")"))throw new Error("Missing closing parenthesis");return t}if(e.type==="number"){this.index++;const t=e.value,n=this.peek();return n&&n.type==="symbol"&&n.value==="%"?(this.index++,{type:"percentage",value:t/100}):n&&n.type==="word"&&n.value==="px"?(this.index++,{type:"literal",value:t}):{type:"literal",value:t}}throw new Error("Unexpected token in expression")}consumeSymbol(e){const t=this.peek();return t&&t.type==="symbol"&&t.value===e?(this.index++,!0):!1}peek(){return this.tokens[this.index]||null}}function lf(i){return i>="0"&&i<="9"}function uf(i){return i>="a"&&i<="z"||i>="A"&&i<="Z"}function B3(i){return!!(i&&i.type==="symbol"&&(i.value==="+"||i.value==="-"))}function k3(i,e){const t={...i};for(const n in e)n!=="id"&&(Array.isArray(t[n])&&Array.isArray(e[n])?t[n]=D3(t[n],e[n]):t[n]=e[n]);return t}function D3(i,e){i=i.slice();for(let t=0;t<e.length;t++){const n=e[t];Number.isFinite(n)&&(i[t]=n)}return i}class Ng{constructor(e){const{id:t,x:n=0,y:s=0,width:r="100%",height:o="100%",padding:a=null}=e;this.id=t||this.constructor.displayName||"view",this.props={...e,id:this.id},this._x=Me(n),this._y=Me(s),this._width=Me(r),this._height=Me(o),this._padding=a&&{left:Me(a.left||0),right:Me(a.right||0),top:Me(a.top||0),bottom:Me(a.bottom||0)},this.equals=this.equals.bind(this),Object.seal(this)}equals(e){return this===e?!0:this.constructor===e.constructor&&Pe(this.props,e.props,2)}clone(e){const t=this.constructor;return new t({...this.props,...e})}makeViewport({width:e,height:t,viewState:n}){n=this.filterViewState(n);const s=this.getDimensions({width:e,height:t});if(!s.height||!s.width)return null;const r=this.getViewportType(n);return new r({...n,...this.props,...s})}getViewStateId(){const{viewState:e}=this.props;return typeof e=="string"?e:(e==null?void 0:e.id)||this.id}filterViewState(e){return this.props.viewState&&typeof this.props.viewState=="object"?this.props.viewState.id?k3(e,this.props.viewState):this.props.viewState:e}getDimensions({width:e,height:t}){const n={x:Ie(this._x,e),y:Ie(this._y,t),width:Ie(this._width,e),height:Ie(this._height,t)};return this._padding&&(n.padding={left:Ie(this._padding.left,e),top:Ie(this._padding.top,t),right:Ie(this._padding.right,e),bottom:Ie(this._padding.bottom,t)}),n}get controller(){const e=this.props.controller;return e?e===!0?{type:this.ControllerType}:typeof e=="function"?{type:e}:{type:this.ControllerType,...e}:null}}class Vr{constructor(e){this._inProgress=!1,this._handle=null,this.time=0,this.settings={duration:0},this._timeline=e}get inProgress(){return this._inProgress}start(e){var t,n;this.cancel(),this.settings=e,this._inProgress=!0,(n=(t=this.settings).onStart)==null||n.call(t,this)}end(){var e,t;this._inProgress&&(this._timeline.removeChannel(this._handle),this._handle=null,this._inProgress=!1,(t=(e=this.settings).onEnd)==null||t.call(e,this))}cancel(){var e,t;this._inProgress&&((t=(e=this.settings).onInterrupt)==null||t.call(e,this),this._timeline.removeChannel(this._handle),this._handle=null,this._inProgress=!1)}update(){var e,t;if(!this._inProgress)return!1;if(this._handle===null){const{_timeline:n,settings:s}=this;this._handle=n.addChannel({delay:n.getTime(),duration:s.duration})}return this.time=this._timeline.getTime(this._handle),this._onUpdate(),(t=(e=this.settings).onUpdate)==null||t.call(e,this),this._timeline.isFinished(this._handle)&&this.end(),!0}_onUpdate(){}}const ff=()=>{},df={mode:"preserve"},F3={mode:"hard"},ec={BREAK:1,SNAP_TO_END:2,IGNORE:3},z3=i=>i,N3=ec.BREAK;class U3{constructor(e){this._onTransitionUpdate=t=>{const{time:n,settings:{interpolator:s,startProps:r,endProps:o,duration:a,easing:c}}=t,l=c(n/a),u=s.interpolateProps(r,o,l);this.propsInTransition=this.getControllerState({...this.props,...u},df).getViewportProps(),this.onViewStateChange({viewState:this.propsInTransition,oldViewState:this.props})},this.getControllerState=e.getControllerState,this.propsInTransition=null,this.transition=new Vr(e.timeline),this.onViewStateChange=e.onViewStateChange||ff,this.onStateChange=e.onStateChange||ff}finalize(){this.transition.cancel()}getViewportInTransition(){return this.propsInTransition}processViewStateChange(e){let t=!1;const n=this.props;if(this.props=e,!n||this._shouldIgnoreViewportChange(n,e))return!1;if(this._isTransitionEnabled(e)){let s=n;if(this.transition.inProgress){const{interruption:r,endProps:o}=this.transition.settings;s={...n,...r===ec.SNAP_TO_END?o:this.propsInTransition||n}}this._triggerTransition(s,e),t=!0}else this.transition.cancel();return t}updateTransition(){this.transition.update()}_isTransitionEnabled(e){const{transitionDuration:t,transitionInterpolator:n}=e;return(t>0||t==="auto")&&!!n}_isUpdateDueToCurrentTransition(e){return this.transition.inProgress&&this.propsInTransition?this.transition.settings.interpolator.arePropsEqual(e,this.propsInTransition):!1}_shouldIgnoreViewportChange(e,t){return this.transition.inProgress?this.transition.settings.interruption===ec.IGNORE||this._isUpdateDueToCurrentTransition(t):this._isTransitionEnabled(t)?t.transitionInterpolator.arePropsEqual(e,t):!0}_triggerTransition(e,t){const n=this.getControllerState(e,df),s=this.getControllerState(t,F3).shortestPathFrom(n),r=t.transitionInterpolator,o=r.getDuration?r.getDuration(e,t):t.transitionDuration;if(o===0)return;const a=r.initializeProps(e,s);this.propsInTransition={};const c={duration:o,easing:t.transitionEasing||z3,interpolator:r,interruption:t.transitionInterruption||N3,startProps:a.start,endProps:a.end,onStart:t.onTransitionStart,onUpdate:this._onTransitionUpdate,onInterrupt:this._onTransitionEnd(t.onTransitionInterrupt),onEnd:this._onTransitionEnd(t.onTransitionEnd)};this.transition.start(c),this.onStateChange({inTransition:!0}),this.updateTransition()}_onTransitionEnd(e){return t=>{this.propsInTransition=null,this.onStateChange({inTransition:!1,isZooming:!1,isPanning:!1,isRotating:!1}),e==null||e(t)}}}function Q(i,e){if(!i)throw new Error(e||"deck.gl: assertion failed.")}class Ug{constructor(e){const{compare:t,extract:n,required:s}=e;this._propsToCompare=t,this._propsToExtract=n||t,this._requiredProps=s}arePropsEqual(e,t){for(const n of this._propsToCompare)if(!(n in e)||!(n in t)||!ci(e[n],t[n]))return!1;return!0}initializeProps(e,t){const n={},s={};for(const r of this._propsToExtract)(r in e||r in t)&&(n[r]=e[r],s[r]=t[r]);return this._checkRequiredProps(n),this._checkRequiredProps(s),{start:n,end:s}}getDuration(e,t){return t.transitionDuration}_checkRequiredProps(e){this._requiredProps&&this._requiredProps.forEach(t=>{const n=e[t];Q(Number.isFinite(n)||Array.isArray(n),`${t} is required for transition`)})}}const $3=["longitude","latitude","zoom","bearing","pitch"],G3=["longitude","latitude","zoom"];class cl extends Ug{constructor(e={}){const t=Array.isArray(e)?e:e.transitionProps,n=Array.isArray(e)?{}:e;n.transitionProps=Array.isArray(t)?{compare:t,required:t}:t||{compare:$3,required:G3},super(n.transitionProps),this.opts=n}initializeProps(e,t){const n=super.initializeProps(e,t),{makeViewport:s,around:r}=this.opts;if(s&&r){const o=s(e),a=s(t),c=o.unproject(r);n.start.around=r,Object.assign(n.end,{around:a.project(c),aroundPosition:c,width:t.width,height:t.height})}return n}interpolateProps(e,t,n){const s={};for(const r of this._propsToExtract)s[r]=Qs(e[r]||0,t[r]||0,n);if(t.aroundPosition&&this.opts.makeViewport){const r=this.opts.makeViewport({...t,...s});Object.assign(s,r.panByPosition(t.aroundPosition,Qs(e.around,t.around,n)))}return s}}const He={transitionDuration:0},j3=300,V3=300,Bo=i=>1-(1-i)*(1-i),W3=i=>i===1?1:1-Math.pow(2,-10*i),St={WHEEL:["wheel"],PAN:["panstart","panmove","panend"],PINCH:["pinchstart","pinchmove","pinchend"],MULTI_PAN:["multipanstart","multipanmove","multipanend"],DOUBLE_CLICK:["dblclick"],DOUBLE_CLICK_DRAG:["dblclickdragstart","dblclickdragmove","dblclickdragend","dblclickdragcancel"],KEYBOARD:["keydown"]},Et={};class $g{constructor(e){this.state={},this._events={},this._interactionState={isDragging:!1},this._customEvents=[],this._eventStartBlocked=null,this._panMove=!1,this._multiPanMode=null,this._multiPanStartCenter=null,this._doubleClickDragAnchor=null,this._suppressDoubleClickUntil=0,this.invertPan=!1,this.dragMode="rotate",this.inertia=0,this.scrollZoom=!0,this.dragPan=!0,this.dragRotate=!0,this.doubleClickZoom=!0,this.doubleClickDragZoom=!0,this.touchZoom=!0,this.touchRotate=!1,this.multiTouchDrag=null,this.trackpadGesture=!1,this.zoomAround="pointer",this.keyboard=!0,this.transitionManager=new U3({...e,getControllerState:(t,n)=>new this.ControllerState({...t,constraintContext:n,makeViewport:e.makeViewport}),onViewStateChange:this._onTransition.bind(this),onStateChange:this._setInteractionState.bind(this)}),this.handleEvent=this.handleEvent.bind(this),this.eventManager=e.eventManager,this.onViewStateChange=e.onViewStateChange||(()=>{}),this.onStateChange=e.onStateChange||(()=>{}),this.makeViewport=e.makeViewport,this.pickPosition=e.pickPosition}set events(e){this.toggleEvents(this._customEvents,!1),this.toggleEvents(e,!0),this._customEvents=e,this.props&&this.setProps(this.props)}finalize(){var e;for(const t in this._events)this._events[t]&&((e=this.eventManager)==null||e.off(t,this.handleEvent));this.transitionManager.finalize()}handleEvent(e){this._controllerState=void 0;const t=this._eventStartBlocked;switch(e.type){case"panstart":return t?!1:this._onPanStart(e);case"panmove":return this._onPan(e);case"panend":return this._onPanEnd(e);case"pinchstart":return t||!this._isTrackpadGestureAllowed(e)?!1:this._onPinchStart(e);case"pinchmove":return this._isTrackpadGestureAllowed(e)?this._onPinch(e):!1;case"pinchend":return this._isTrackpadGestureAllowed(e)?this._onPinchEnd(e):!1;case"multipanstart":return t?!1:this._onMultiPanStart(e);case"multipanmove":return this._onMultiPan(e);case"multipanend":return this._onMultiPanEnd(e);case"dblclick":return this._onDoubleClick(e);case"dblclickdragstart":return t?!1:this._onDoubleClickDragStart(e);case"dblclickdragmove":return this._onDoubleClickDrag(e);case"dblclickdragend":case"dblclickdragcancel":return this._onDoubleClickDragEnd(e);case"wheel":return this._onWheel(e);case"keydown":return this._onKeyDown(e);default:return!1}}get controllerState(){return this._controllerState=this._controllerState||new this.ControllerState({makeViewport:this.makeViewport,...this.props,...this.state}),this._controllerState}getCenter(e){const{x:t,y:n}=this.props,{offsetCenter:s}=e;return[s.x-t,s.y-n]}getZoomPosition(e){if(this.zoomAround==="pointer")return e;const t=this.makeViewport(this.controllerState.getViewportProps()),[n,s]=nl(t.center,t.pixelProjectionMatrix);return[n,s]}isPointInBounds(e,t){const{width:n,height:s}=this.props;if(t&&t.handled)return!1;const r=e[0]>=0&&e[0]<=n&&e[1]>=0&&e[1]<=s;return r&&t&&t.stopPropagation(),r}isFunctionKeyPressed(e){const{srcEvent:t}=e;return!!(t.metaKey||t.altKey||t.ctrlKey||t.shiftKey)}isDragging(){return this._interactionState.isDragging||!1}blockEvents(e){const t=setTimeout(()=>{this._eventStartBlocked===t&&(this._eventStartBlocked=null)},e);this._eventStartBlocked=t}setProps(e){e.maxBoundsPadding===void 0&&(e.maxBoundsPadding=null),e.dragMode&&(this.dragMode=e.dragMode);const t=this.props;this.props=e,"transitionInterpolator"in e||(e.transitionInterpolator=this._getTransitionProps().transitionInterpolator),this.transitionManager.processViewStateChange(e);const{inertia:n}=e;this.inertia=Number.isFinite(n)?n:n===!0?j3:0;const{scrollZoom:s=!0,dragPan:r=!0,dragRotate:o=!0,doubleClickZoom:a=!0,doubleClickDragZoom:c=!1,touchZoom:l=!0,touchRotate:u=!1,multiTouchDrag:f=u?"rotate":null,trackpadGesture:d=!1,zoomAround:g="pointer",keyboard:p=!0}=e,m=!!this.onViewStateChange;if(this.toggleEvents(St.WHEEL,m&&s),this.toggleEvents(St.PAN,m),this.toggleEvents(St.PINCH,m&&(l||f==="rotate")),this.toggleEvents(St.MULTI_PAN,m&&!!f),this.toggleEvents(St.DOUBLE_CLICK,m&&a),this.toggleEvents(St.DOUBLE_CLICK_DRAG,m&&c),this.toggleEvents(St.KEYBOARD,m&&p),this.scrollZoom=s,this.dragPan=r,this.dragRotate=o,this.doubleClickZoom=a,this.doubleClickDragZoom=c,this.touchZoom=l,this.touchRotate=f==="rotate",this.multiTouchDrag=f,this.trackpadGesture=d,this.zoomAround=g,this.keyboard=p,(!t||t.height!==e.height||t.width!==e.width||t.maxBounds!==e.maxBounds||t.maxBoundsPadding!==e.maxBoundsPadding)&&e.maxBounds){const v=new this.ControllerState({...e,makeViewport:this.makeViewport}),w=v.getViewportProps();Object.keys(w).some(x=>!Pe(w[x],e[x],1))&&this.updateViewport(v)}}updateTransition(){this.transitionManager.updateTransition()}toggleEvents(e,t){this.eventManager&&e.forEach(n=>{this._events[n]!==t&&(this._events[n]=t,t?this.eventManager.on(n,this.handleEvent):this.eventManager.off(n,this.handleEvent))})}updateViewport(e,t=null,n={}){const s={...e.getViewportProps(),...t},r=this.controllerState!==e;if(this.state=e.getState(),this._setInteractionState(n),r){const o=this.controllerState&&this.controllerState.getViewportProps();this.onViewStateChange&&this.onViewStateChange({viewState:s,interactionState:this._interactionState,oldViewState:o,viewId:this.props.id})}}_onTransition(e){this.onViewStateChange({...e,interactionState:this._interactionState,viewId:this.props.id})}_setInteractionState(e){Object.assign(this._interactionState,e),this.onStateChange(this._interactionState)}_getConstraintContext(e,t){return this.props.rubberBand?{mode:t==="update"?"elastic":t==="end"?"rebound":"hard"}:{mode:"hard"}}_getReboundTransition(e,t){if(e.mode!=="rebound")return null;const n=t.getViewportProps();return Object.keys(n).some(r=>!Pe(this.props[r],n[r],1))?{...this._getTransitionProps(),transitionDuration:V3,transitionEasing:W3}:null}_onPanStart(e){const t=this.getCenter(e);if(!this.isPointInBounds(t,e))return!1;let n=this.isFunctionKeyPressed(e)||e.rightButton||!1;(this.invertPan||this.dragMode==="pan")&&(n=!n);const s=n?"pan":"rotate",r=this._getConstraintContext(s,"start"),o=n?this.controllerState.panStart({pos:t},r):this.controllerState.rotateStart({pos:t},r);return this._panMove=n,this.updateViewport(o,He,{isDragging:!0}),!0}_onPan(e){return this.isDragging()?this._panMove?this._onPanMove(e):this._onPanRotate(e):!1}_onPanEnd(e){return this.isDragging()?this._panMove?this._onPanMoveEnd(e):this._onPanRotateEnd(e):!1}_onPanMove(e){if(!this.dragPan)return!1;const t=this.getCenter(e),n=this.controllerState.pan({pos:t},this._getConstraintContext("pan","update"));return this.updateViewport(n,He,{isDragging:!0,isPanning:!0}),!0}_onPanMoveEnd(e){const{inertia:t}=this;if(this.dragPan&&t&&e.velocity){const n=this.getCenter(e),s=[n[0]+e.velocityX*t/2,n[1]+e.velocityY*t/2],r=this.controllerState.pan({pos:s}).panEnd();this.updateViewport(r,{...this._getTransitionProps(),transitionDuration:t,transitionEasing:Bo},{isDragging:!1,isPanning:!0})}else{const n=this.controllerState,s=this._getConstraintContext("pan","end"),r=n.panEnd(s),o=this._getReboundTransition(s,r);this.updateViewport(r,o,{isDragging:!1,isPanning:!!o})}return!0}_onPanRotate(e){if(!this.dragRotate)return!1;const t=this.getCenter(e),n=this.controllerState.rotate({pos:t},this._getConstraintContext("rotate","update"));return this.updateViewport(n,He,{isDragging:!0,isRotating:!0}),!0}_onPanRotateEnd(e){const{inertia:t}=this;if(this.dragRotate&&t&&e.velocity){const n=this.getCenter(e),s=[n[0]+e.velocityX*t/2,n[1]+e.velocityY*t/2],r=this.controllerState.rotate({pos:s}).rotateEnd();this.updateViewport(r,{...this._getTransitionProps(),transitionDuration:t,transitionEasing:Bo},{isDragging:!1,isRotating:!0})}else{const n=this.controllerState,s=this._getConstraintContext("rotate","end"),r=n.rotateEnd(s),o=this._getReboundTransition(s,r);this.updateViewport(r,o,{isDragging:!1,isRotating:!!o})}return!0}_onWheel(e){if(!this.scrollZoom||this.trackpadGesture&&e.device!=="mouse")return!1;const t=this.getCenter(e);if(!this.isPointInBounds(t,e))return!1;e.srcEvent.preventDefault();const{speed:n=.01,smooth:s=!1}=this.scrollZoom===!0?{}:this.scrollZoom,{delta:r}=e;let o=2/(1+Math.exp(-Math.abs(r*n)));r<0&&o!==0&&(o=1/o);const a=this.getZoomPosition(t),c=s?{...this._getTransitionProps({around:a}),transitionDuration:250}:He,l=this.controllerState.zoom({pos:a,scale:o});return this.updateViewport(l,c,{isZooming:!0,isPanning:!0}),s||this._setInteractionState({isZooming:!1,isPanning:!1}),!0}_onMultiPanStart(e){const{multiTouchDrag:t}=this;if(!t||!this._isMultiPanEventAllowed(e,t))return!1;const n=e.offsetCenter;if(!this.isPointInBounds(this.getCenter(e),e))return!1;const s=e.pointerType==="trackpad",r={x:n.x-(s?0:e.deltaX),y:n.y-(s?0:e.deltaY)},o={...e,offsetCenter:r},a=this.getCenter(o),c=t==="pan"?this.controllerState.panStart({pos:a},this._getConstraintContext("pan","start")):this.controllerState.rotateStart({pos:a},this._getConstraintContext("rotate","start"));return this._multiPanMode=t,this._multiPanStartCenter=r,this.updateViewport(c,He,{isDragging:!0}),!0}_onMultiPan(e){const{mode:t,event:n}=this._getMultiPanEvent(e);return!t||!n||!this.isDragging()?!1:t==="pan"?this._onPanMove(n):this._onPanRotate(n)}_onMultiPanEnd(e){const{mode:t,event:n}=this._getMultiPanEvent(e);if(!t||!n||!this.isDragging())return this._resetMultiPan(),!1;const s=t==="pan"?this._onPanMoveEnd(n):this._onPanRotateEnd(n);return this._resetMultiPan(),s}_isTrackpadGestureAllowed(e){return e.pointerType!=="trackpad"||this.trackpadGesture}_isMultiPanEventAllowed(e,t){return e.pointerType==="trackpad"?this.trackpadGesture&&(t==="pan"?this.dragPan:this.dragRotate):e.pointerType==="touch"&&(t==="pan"?this.dragPan:this.dragRotate)}_getMultiPanEvent(e){const t=this._multiPanMode,n=this._multiPanStartCenter;return!t||!n?{mode:null,event:null}:{mode:t,event:{...e,offsetCenter:{x:n.x+e.deltaX,y:n.y+e.deltaY}}}}_resetMultiPan(){this._multiPanMode=null,this._multiPanStartCenter=null}_onPinchStart(e){this._doubleClickDragAnchor=null;const t=this.getCenter(e);if(!this.isPointInBounds(t,e))return!1;const n=this.controllerState.zoomStart({pos:this.getZoomPosition(t)},this._getConstraintContext("zoom","start")).rotateStart({pos:t},this._getConstraintContext("rotate","start"));return Et._startPinchRotation=e.rotation,Et._lastPinchEvent=e,this.updateViewport(n,He,{isDragging:!0}),!0}_onPinch(e){if(!this.touchZoom&&!this.touchRotate||!this.isDragging())return!1;let t=this.controllerState;if(this.touchZoom){const{scale:n}=e,s=this.getCenter(e);t=t.zoom({pos:this.getZoomPosition(s),scale:n},this._getConstraintContext("zoom","update"))}if(this.touchRotate){const{rotation:n}=e;t=t.rotate({deltaAngleX:Et._startPinchRotation-n},this._getConstraintContext("rotate","update"))}return this.updateViewport(t,He,{isDragging:!0,isPanning:this.touchZoom,isZooming:this.touchZoom,isRotating:this.touchRotate}),Et._lastPinchEvent=e,!0}_onPinchEnd(e){if(!this.isDragging())return!1;const{inertia:t}=this,{_lastPinchEvent:n}=Et;if(this.touchZoom&&t&&n&&e.scale!==n.scale){const s=this.getCenter(e),r=this.getZoomPosition(s);let o=this.controllerState.rotateEnd();const a=Math.log2(e.scale),c=(a-Math.log2(n.scale))/(e.deltaTime-n.deltaTime),l=Math.pow(2,a+c*t/2);o=o.zoom({pos:r,scale:l}).zoomEnd(),this.updateViewport(o,{...this._getTransitionProps({around:r}),transitionDuration:t,transitionEasing:Bo},{isDragging:!1,isPanning:this.touchZoom,isZooming:this.touchZoom,isRotating:!1}),this.blockEvents(t)}else{const s=this.controllerState,r=this._getConstraintContext("zoom","end"),o=this._getConstraintContext("rotate","end"),a=s.zoomEnd(r).rotateEnd(o),c=this._getReboundTransition(this.touchZoom?r:o,a);this.updateViewport(a,c,{isDragging:!1,isPanning:!!c&&this.touchZoom,isZooming:!!c&&this.touchZoom,isRotating:!!c&&this.touchRotate})}return Et._startPinchRotation=null,Et._lastPinchEvent=null,!0}_onDoubleClick(e){if(!this.doubleClickZoom||Date.now()<this._suppressDoubleClickUntil)return!1;const t=this.getCenter(e);if(!this.isPointInBounds(t,e))return!1;const n=this.isFunctionKeyPressed(e),s=this.getZoomPosition(t),r=this.controllerState.zoom({pos:s,scale:n?.5:2});return this.updateViewport(r,this._getTransitionProps({around:s}),{isZooming:!0,isPanning:!0}),this.blockEvents(100),!0}_onDoubleClickDragStart(e){if(!this.doubleClickDragZoom)return this._doubleClickDragAnchor=null,!1;const t=this.getCenter(e);if(!this.isPointInBounds(t,e))return this._doubleClickDragAnchor=null,!1;this._doubleClickDragAnchor=this.getZoomPosition(t);let n=this.controllerState.zoomStart({pos:this._doubleClickDragAnchor},this._getConstraintContext("zoom","start"));return e.scale!==1&&(n=n.zoom({pos:this._doubleClickDragAnchor,scale:e.scale},this._getConstraintContext("zoom","update"))),this.updateViewport(n,He,{isDragging:!0,isPanning:!0,isZooming:!0}),!0}_onDoubleClickDrag(e){const t=this._doubleClickDragAnchor;if(!t)return!1;const n=this.controllerState.zoom({pos:t,scale:e.scale},this._getConstraintContext("zoom","update"));return this.updateViewport(n,He,{isDragging:!0,isPanning:!0,isZooming:!0}),!0}_onDoubleClickDragEnd(e){if(!this._doubleClickDragAnchor)return!1;this._doubleClickDragAnchor=null;const n=this.controllerState,s=this._getConstraintContext("zoom","end"),r=n.zoomEnd(s),o=this._getReboundTransition(s,r);return this.updateViewport(r,o,{isDragging:!1,isPanning:!!o,isZooming:!!o}),this._suppressDoubleClickUntil=Date.now()+100,this.blockEvents(100),!0}_onKeyDown(e){if(!this.keyboard)return!1;const t=this.isFunctionKeyPressed(e),{zoomSpeed:n,moveSpeed:s,rotateSpeedX:r,rotateSpeedY:o}=this.keyboard===!0?{}:this.keyboard,{controllerState:a}=this;let c;const l={};switch(e.srcEvent.code){case"Minus":c=t?a.zoomOut(n).zoomOut(n):a.zoomOut(n),l.isZooming=!0;break;case"Equal":c=t?a.zoomIn(n).zoomIn(n):a.zoomIn(n),l.isZooming=!0;break;case"ArrowLeft":t?(c=a.rotateLeft(r),l.isRotating=!0):(c=a.moveLeft(s),l.isPanning=!0);break;case"ArrowRight":t?(c=a.rotateRight(r),l.isRotating=!0):(c=a.moveRight(s),l.isPanning=!0);break;case"ArrowUp":t?(c=a.rotateUp(o),l.isRotating=!0):(c=a.moveUp(s),l.isPanning=!0);break;case"ArrowDown":t?(c=a.rotateDown(o),l.isRotating=!0):(c=a.moveDown(s),l.isPanning=!0);break;default:return!1}return this.updateViewport(c,this._getTransitionProps(),l),!0}_getTransitionProps(e){const{transition:t}=this;return!t||!t.transitionInterpolator?He:e?{...t,transitionInterpolator:new cl({...e,...t.transitionInterpolator.opts,makeViewport:this.controllerState.makeViewport})}:t}}const At=Symbol("constraintAround");class H3{constructor(e,t,n,s){this.makeViewport=n,this._viewportProps=this.applyConstraints(e,s),this._state=t}getViewportProps(){return this._viewportProps}getState(){return this._state}}function ko(i,e,t){const n=i-e;return n&&Number.isFinite(n)?e+n*t/(t+Math.abs(n)):e}function cr(i,e,t){const n=Ie(Me((t==null?void 0:t.left)??0),i),s=Ie(Me((t==null?void 0:t.right)??0),i),r=Ie(Me((t==null?void 0:t.top)??0),e),o=Ie(Me((t==null?void 0:t.bottom)??0),e);return{x:n,y:r,width:i-n-s,height:e-r-o}}function Gg(i,e,t){let[n,s]=i.project(e);return n=Number.isFinite(n)?n:i.width/2,s=Number.isFinite(s)?s:i.height/2,{left:n-t.x,right:t.x+t.width-n,top:s-t.y,bottom:t.y+t.height-s}}const hf=5,Y3=1.2,gf=512,jg=[[-1/0,-90],[1/0,90]],q3=1;function ki([i,e]){if(Math.abs(e)>90&&(e=Math.sign(e)*90),Number.isFinite(i)){const[n,s]=bi([i,e]);return[n,ae(s,0,gf)]}const[,t]=bi([0,e]);return[i,ae(t,0,gf)]}class Vg extends H3{constructor(e){const{width:t,height:n,latitude:s,longitude:r,zoom:o,bearing:a=0,pitch:c=0,altitude:l=1.5,position:u=[0,0,0],maxZoom:f=20,minZoom:d=0,maxPitch:g=60,minPitch:p=0,startPanLngLat:m,startZoomLngLat:_,startRotatePos:v,startRotateLngLat:w,startBearing:y,startPitch:x,startZoom:S,normalize:C=!0,rubberBand:O=!1}=e,{[At]:B}=e;Q(Number.isFinite(r)),Q(Number.isFinite(s)),Q(Number.isFinite(o));const D=e.maxBounds||(C?jg:null),k=e.maxBoundsPadding||null;super({width:t,height:n,latitude:s,longitude:r,zoom:o,bearing:a,pitch:c,altitude:l,maxZoom:f,minZoom:d,maxPitch:g,minPitch:p,normalize:C,position:u,maxBounds:D,maxBoundsPadding:k,rubberBand:O,[At]:B},{startPanLngLat:m,startZoomLngLat:_,startRotatePos:v,startRotateLngLat:w,startBearing:y,startPitch:x,startZoom:S},e.makeViewport,e.constraintContext),this.getAltitude=e.getAltitude}panStart({pos:e},t){return this._getUpdatedState({startPanLngLat:this._unproject(e)},t)}pan({pos:e,startPos:t},n){const s=this.getState().startPanLngLat||this._unproject(t);if(!s)return this;const o=this.makeViewport(this.getViewportProps()).panByPosition(s,e);return this._getUpdatedState(o,n)}panEnd(e){return this._getUpdatedState({startPanLngLat:null},e)}rotateStart({pos:e}){var n;const t=(n=this.getAltitude)==null?void 0:n.call(this,e);return this._getUpdatedState({startRotatePos:e,startRotateLngLat:t!==void 0?this._unproject3D(e,t):void 0,startBearing:this.getViewportProps().bearing,startPitch:this.getViewportProps().pitch})}rotate({pos:e,deltaAngleX:t=0,deltaAngleY:n=0}){const{startRotatePos:s,startRotateLngLat:r,startBearing:o,startPitch:a}=this.getState();if(!s||o===void 0||a===void 0)return this;let c;if(e?c=this._getNewRotation(e,s,a,o):c={bearing:o+t,pitch:a+n},r){const l=this.makeViewport({...this.getViewportProps(),...c}),u="panByPosition3D"in l?"panByPosition3D":"panByPosition";return this._getUpdatedState({...c,...l[u](r,s)})}return this._getUpdatedState(c)}rotateEnd(){return this._getUpdatedState({startRotatePos:null,startRotateLngLat:null,startBearing:null,startPitch:null})}zoomStart({pos:e},t){return this._getUpdatedState({startZoomLngLat:this._unproject(e),startZoom:this.getViewportProps().zoom},t)}zoom({pos:e,startPos:t,scale:n},s){let{startZoom:r,startZoomLngLat:o}=this.getState();return o||(r=this.getViewportProps().zoom,o=this._unproject(t)||this._unproject(e)),o?this._getUpdatedState({zoom:r+Math.log2(n),[At]:{position:o,screenPosition:e}},s):this}zoomEnd(e){return this._getUpdatedState({startZoomLngLat:null,startZoom:null},e)}zoomIn(e=2,t){return this._zoomFromCenter(e,t)}zoomOut(e=2,t){return this._zoomFromCenter(1/e,t)}moveLeft(e=100,t){return this._panFromCenter([e,0],t)}moveRight(e=100,t){return this._panFromCenter([-e,0],t)}moveUp(e=100,t){return this._panFromCenter([0,e],t)}moveDown(e=100,t){return this._panFromCenter([0,-e],t)}rotateLeft(e=15){return this._getUpdatedState({bearing:this.getViewportProps().bearing-e})}rotateRight(e=15){return this._getUpdatedState({bearing:this.getViewportProps().bearing+e})}rotateUp(e=10){return this._getUpdatedState({pitch:this.getViewportProps().pitch+e})}rotateDown(e=10){return this._getUpdatedState({pitch:this.getViewportProps().pitch-e})}shortestPathFrom(e){const t=e.getViewportProps(),n={...this.getViewportProps()},{bearing:s,longitude:r}=n;return Math.abs(s-t.bearing)>180&&(n.bearing=s<0?s+360:s-360),Math.abs(r-t.longitude)>180&&(n.longitude=r<0?r+360:r-360),n}applyConstraints(e,t){const n=e,s=n[At];delete n[At];const{maxPitch:r,minPitch:o,pitch:a,bearing:c,normalize:l,maxBounds:u,rubberBand:f}=e;l&&(c<-180||c>180)&&(e.bearing=xn(c+180,360)-180),e.pitch=ae(a,o,r);const d=this._constrainZoom(e.zoom,e),g=f&&(t==null?void 0:t.mode)==="elastic";if(e.zoom=(t==null?void 0:t.mode)==="preserve"?e.zoom:g?ko(e.zoom,d,q3):d,s){const p=this.makeViewport(e);Object.assign(e,p.panByPosition(s.position,s.screenPosition))}if(l&&(e.longitude<-180||e.longitude>180)&&(e.longitude=xn(e.longitude+180,360)-180),u){const p=cr(e.width,e.height,e.maxBoundsPadding),m=this.makeViewport({...e,bearing:0,pitch:0}),_=Gg(m,[e.longitude,e.latitude],p),v=ki(u[0]),w=ki(u[1]),y=2**e.zoom,x=[v[0]+_.left/y,v[1]+_.bottom/y],S=[w[0]-_.right/y,w[1]-_.top/y],C=ki([e.longitude,e.latitude]),O=[ae(C[0],x[0],S[0]),ae(C[1],x[1],S[1])],B=C.slice();if(p.width>=0&&(B[0]=(t==null?void 0:t.mode)==="preserve"?C[0]:g?ko(C[0],O[0],p.width/2/y):O[0]),p.height>=0&&(B[1]=(t==null?void 0:t.mode)==="preserve"?C[1]:g?ko(C[1],O[1],p.height/2/y):O[1]),B[0]!==C[0]||B[1]!==C[1]){const[D,k]=Fn(B);B[0]!==C[0]&&(e.longitude=D),B[1]!==C[1]&&(e.latitude=k)}}return e}_constrainZoom(e,t){t||(t=this.getViewportProps());const{maxZoom:n,maxBounds:s}=t,r=s!==null&&t.width>0&&t.height>0;let{minZoom:o}=t;if(r){const a=cr(t.width,t.height,t.maxBoundsPadding),c=ki(s[0]),l=ki(s[1]),u=l[0]-c[0],f=l[1]-c[1];a.width>0&&Number.isFinite(u)&&u>0&&(o=Math.max(o,Math.log2(a.width/u))),a.height>0&&Number.isFinite(f)&&f>0&&(o=Math.max(o,Math.log2(a.height/f))),o>n&&(o=n)}return ae(e,o,n)}_zoomFromCenter(e,t){const{width:n,height:s}=this.getViewportProps();return this.zoom({pos:[n/2,s/2],scale:e},t)}_panFromCenter(e,t){const{width:n,height:s}=this.getViewportProps();return this.pan({startPos:[n/2,s/2],pos:[n/2+e[0],s/2+e[1]]},t)}_getUpdatedState(e,t){return new this.constructor({makeViewport:this.makeViewport,...this.getViewportProps(),...this.getState(),...e,constraintContext:t})}_unproject(e){const t=this.makeViewport(this.getViewportProps());return e&&t.unproject(e)}_unproject3D(e,t){return this.makeViewport(this.getViewportProps()).unproject(e,{targetZ:t})}_getNewRotation(e,t,n,s){const r=e[0]-t[0],o=e[1]-t[1],a=e[1],c=t[1],{width:l,height:u}=this.getViewportProps(),f=r/l;let d=0;o>0?Math.abs(u-c)>hf&&(d=o/(c-u)*Y3):o<0&&c>hf&&(d=1-a/c),d=ae(d,-1,1);const{minPitch:g,maxPitch:p}=this.getViewportProps(),m=s+180*f;let _=n;return d>0?_=n+d*(p-n):d<0&&(_=n-d*(g-n)),{pitch:_,bearing:m}}}class Z3 extends $g{constructor(){super(...arguments),this.ControllerState=Vg,this.transition={transitionDuration:300,transitionInterpolator:new cl({transitionProps:{compare:["longitude","latitude","zoom","bearing","pitch","position"],required:["longitude","latitude","zoom"]}})},this.dragMode="pan",this.rotationPivot="center",this._getAltitude=e=>{if(this.rotationPivot==="2d")return 0;if(this.rotationPivot==="3d"&&this.pickPosition){const{x:t,y:n}=this.props,s=this.pickPosition(t+e[0],n+e[1]);if(s&&s.coordinate&&s.coordinate.length>=3)return s.coordinate[2]}}}setProps(e){"rotationPivot"in e&&(this.rotationPivot=e.rotationPivot||"center"),e.getAltitude=this._getAltitude,e.position=e.position||[0,0,0],e.maxBounds=e.maxBounds||(e.normalize===!1?null:jg),super.setProps(e)}updateViewport(e,t=null,n={}){const s=e.getState();n.isDragging&&s.startRotateLngLat?n={...n,rotationPivotPosition:s.startRotateLngLat}:n.isDragging===!1&&(n={...n,rotationPivotPosition:void 0}),super.updateViewport(e,t,n)}}class ll extends Ng{constructor(e={}){super(e)}getViewportType(){return ot}get ControllerType(){return Z3}}ll.displayName="MapView";const X3=new rl;function K3(i,e){const t=i.order??1/0,n=e.order??1/0;return t-n}class Q3{constructor(e){this._resolvedEffects=[],this._defaultEffects=[],this.effects=[],this._context=e,this._needsRedraw="Initial render",this._setEffects([])}addDefaultEffect(e){const t=this._defaultEffects;if(!t.find(n=>n.id===e.id)){const n=t.findIndex(s=>K3(s,e)>0);n<0?t.push(e):t.splice(n,0,e),e.setup(this._context),this._setEffects(this.effects)}}setProps(e){"effects"in e&&(Pe(e.effects,this.effects,1)||this._setEffects(e.effects))}needsRedraw(e={clearRedrawFlags:!1}){const t=this._needsRedraw;return e.clearRedrawFlags&&(this._needsRedraw=!1),t}getEffects(){return this._resolvedEffects}_setEffects(e){const t={};for(const s of this.effects)t[s.id]=s;const n=[];for(const s of e){const r=t[s.id];let o=s;r&&r!==s?r.setProps?(r.setProps(s.props),o=r):r.cleanup(this._context):r||s.setup(this._context),n.push(o),delete t[s.id]}for(const s in t)t[s].cleanup(this._context);this.effects=n,this._resolvedEffects=n.concat(this._defaultEffects),e.some(s=>s instanceof rl)||this._resolvedEffects.push(X3),this._needsRedraw="effects changed"}finalize(){for(const e of this._resolvedEffects)e.cleanup(this._context);this.effects.length=0,this._resolvedEffects.length=0,this._defaultEffects.length=0}}class J3 extends sl{shouldDrawLayer(e){const{operation:t}=e.props;return t.includes("draw")||t.includes("terrain")}render(e){return this._render(e)}}const eC="deckRenderer.renderLayers";class tC{constructor(e,t={}){this.device=e,this.stats=t.stats,this.layerFilter=null,this.drawPickingColors=!1,this.drawLayersPass=new J3(e),this.pickLayersPass=new Fg(e),this.renderCount=0,this._needsRedraw="Initial render",this.renderBuffers=[],this.lastPostProcessEffect=null}setProps(e){this.layerFilter!==e.layerFilter&&(this.layerFilter=e.layerFilter,this._needsRedraw="layerFilter changed"),this.drawPickingColors!==e.drawPickingColors&&(this.drawPickingColors=e.drawPickingColors,this._needsRedraw="drawPickingColors changed")}renderLayers(e){const t=this.drawPickingColors?this.pickLayersPass:this.drawLayersPass,n={layerFilter:this.layerFilter,isPicking:this.drawPickingColors,...e};if(!e.viewports.length){const a=t.render(n),c="stats"in a?a.stats:a;this._updateStats(c);return}n.effects&&this._preRender(n.effects,n);const s=this.lastPostProcessEffect?this.renderBuffers[0]:n.target;this.lastPostProcessEffect&&(n.clearColor=[0,0,0,0],n.clearCanvas=!0);const r=t.render({...n,target:s}),o="stats"in r?r.stats:r;n.effects&&(this.lastPostProcessEffect&&(n.clearCanvas=e.clearCanvas===void 0?!0:e.clearCanvas),this._postRender(n.effects,n)),this.renderCount++,ye(eC,this,o,e),this._updateStats(o)}needsRedraw(e={clearRedrawFlags:!1}){const t=this._needsRedraw;return e.clearRedrawFlags&&(this._needsRedraw=!1),t}finalize(){const{renderBuffers:e}=this;for(const t of e)t.delete();e.length=0}_updateStats(e){if(!this.stats)return;let t=0;for(const{visibleCount:n}of e)t+=n;this.stats.get("Layers rendered").addCount(t)}_preRender(e,t){this.lastPostProcessEffect=null,t.preRenderStats=t.preRenderStats||{};for(const n of e)t.preRenderStats[n.id]=n.preRender(t),n.postRender&&(this.lastPostProcessEffect=n.id);this.lastPostProcessEffect&&this._resizeRenderBuffers(t.canvasContext)}_resizeRenderBuffers(e=this.device.canvasContext){const{renderBuffers:t}=this,n=e.getDrawingBufferSize(),[s,r]=n;t.length===0&&[0,1].map(o=>{const a=this.device.createTexture({sampler:{minFilter:"linear",magFilter:"linear"},width:s,height:r});t.push(this.device.createFramebuffer({id:`deck-renderbuffer-${o}`,colorAttachments:[a]}))});for(const o of t)o.resize(n)}_postRender(e,t){var o;const{renderBuffers:n}=this,s=t.target??((o=t.canvasContext)==null?void 0:o.getCurrentFramebuffer())??t.target,r={...t,inputBuffer:n[0],swapBuffer:n[1]};for(const a of e)if(a.postRender){r.target=a.id===this.lastPostProcessEffect?s:void 0;const c=a.postRender(r);r.inputBuffer=c,r.swapBuffer=c===n[0]?n[1]:n[0]}}}const iC={pickedColor:null,pickedObjectIndex:-1};function pf({pickedColors:i,decodePickingColor:e,deviceX:t,deviceY:n,deviceRadius:s,deviceRect:r}){const{x:o,y:a,width:c,height:l}=r;let u=s*s,f=-1,d=0;for(let g=0;g<l;g++){const p=g+a-n,m=p*p;if(m>u)d+=4*c;else for(let _=0;_<c;_++){if(i[d+3]-1>=0){const w=_+o-t,y=w*w+m;y<=u&&(u=y,f=d)}d+=4}}if(f>=0){const g=i.slice(f,f+4),p=e(g);if(p){const m=Math.floor(f/4/c),_=f/4-m*c;return{...p,pickedColor:g,pickedX:o+_,pickedY:a+m}}Y.error("Picked non-existent layer. Is picking buffer corrupt?")()}return iC}function mf({pickedColors:i,decodePickingColor:e}){const t=new Map;if(i){for(let n=0;n<i.length;n+=4)if(i[n+3]-1>=0){const r=i.slice(n,n+4),o=r.join(",");if(!t.has(o)){const a=e(r);a?t.set(o,{...a,color:r}):Y.error("Picked non-existent layer. Is picking buffer corrupt?")()}}}return Array.from(t.values())}function tc({pickInfo:i,viewports:e,pixelRatio:t,x:n,y:s,z:r}){let o=e[0];e.length>1&&(o=nC((i==null?void 0:i.pickedViewports)||e,{x:n,y:s}));let a;if(o){const c=[n-o.x,s-o.y];r!==void 0&&(c[2]=r),a=o.unproject(c)}return{color:null,layer:null,viewport:o,index:-1,picked:!1,x:n,y:s,pixel:[n,s],coordinate:a,devicePixel:i&&"pickedX"in i?[i.pickedX,i.pickedY]:void 0,pixelRatio:t}}function _f(i){const{pickInfo:e,lastPickedInfo:t,mode:n,layers:s}=i,{pickedColor:r,pickedLayer:o,pickedObjectIndex:a}=e,c=o?[o]:[];if(n==="hover"){const f=t.index,d=t.layerId,g=o?o.props.id:null;if(g!==d||a!==f){if(g!==d){const p=s.find(m=>m.props.id===d);p&&c.unshift(p)}t.layerId=g,t.index=a,t.info=null}}const l=tc(i),u=new Map;return u.set(null,l),c.forEach(f=>{let d={...l};f===o&&(d.color=r,d.index=a,d.picked=!0),d=ic({layer:f,info:d,mode:n});const g=d.layer;f===o&&n==="hover"&&(t.info=d),u.set(g.id,d),n==="hover"&&g.updateAutoHighlight(d)}),u}function ic({layer:i,info:e,mode:t}){for(;i&&e;){const n=e.layer||null;e.sourceLayer=n,e.layer=i,e=i.getPickingInfo({info:e,mode:t,sourceLayer:n}),i=i.parent}return e}function nC(i,e){for(let t=i.length-1;t>=0;t--){const n=i[t];if(n.containsPixel(e))return n}return i[0]}class sC{constructor(e,t={}){this._pickable=!0,this.device=e,this.stats=t.stats,this.pickLayersPass=new Fg(e),this.lastPickedInfo={index:-1,layerId:null,info:null}}setProps(e){"layerFilter"in e&&(this.layerFilter=e.layerFilter),"_pickable"in e&&(this._pickable=e._pickable)}finalize(){this.pickingFBO&&this.pickingFBO.destroy(),this.depthFBO&&this.depthFBO.destroy()}pickObjectAsync(e){return this._pickClosestObjectAsync(e)}pickObjectsAsync(e){return this._pickVisibleObjectsAsync(e)}pickObject(e){return this._pickClosestObject(e)}pickObjects(e){return this._pickVisibleObjects(e)}getLastPickedObject({x:e,y:t,layers:n,viewports:s},r=this.lastPickedInfo.info){const o=r&&r.layer&&r.layer.id,a=r&&r.viewport&&r.viewport.id,c=o?n.find(d=>d.id===o):null,l=a&&s.find(d=>d.id===a)||s[0],u=l&&l.unproject([e-l.x,t-l.y]);return{...r,...{x:e,y:t,viewport:l,coordinate:u,layer:c}}}_resizeBuffer(e=this.device.getDefaultCanvasContext()){var s,r;if(!this.pickingFBO){const o=this.device.createTexture({format:"rgba8unorm",width:1,height:1,usage:he.RENDER_ATTACHMENT|he.COPY_SRC});if(this.pickingFBO=this.device.createFramebuffer({colorAttachments:[o],depthStencilAttachment:"depth16unorm"}),this.device.isTextureFormatRenderable("rgba32float")){const a=this.device.createTexture({format:"rgba32float",width:1,height:1,usage:he.RENDER_ATTACHMENT|he.COPY_SRC}),c=this.device.createFramebuffer({colorAttachments:[a],depthStencilAttachment:"depth16unorm"});this.depthFBO=c}}const[t,n]=e.getDrawingBufferSize();(s=this.pickingFBO)==null||s.resize({width:t,height:n}),(r=this.depthFBO)==null||r.resize({width:t,height:n})}_getPickable(e){if(this._pickable===!1)return null;const t=e.filter(n=>this.pickLayersPass.shouldDrawLayer(n)&&!n.isComposite);return t.length?t:null}async _pickClosestObjectAsync({layers:e,views:t,viewports:n,x:s,y:r,radius:o=0,depth:a=1,mode:c="query",unproject3D:l,canvasContext:u=this.device.getDefaultCanvasContext(),onViewportActive:f,effects:d}){const g=u.cssToDeviceRatio(),p=this._getPickable(e);if(!p||n.length===0)return{result:[],emptyInfo:tc({viewports:n,x:s,y:r,pixelRatio:g})};this._resizeBuffer(u);const m=u.cssToDevicePixels([s,r],!0),_=[m.x+Math.floor(m.width/2),m.y+Math.floor(m.height/2)],v=Math.round(o*g),{width:w,height:y}=this.pickingFBO,x=this._getPickingRect({deviceX:_[0],deviceY:_[1],deviceRadius:v,deviceWidth:w,deviceHeight:y}),S={x:s-o,y:r-o,width:o*2+1,height:o*2+1};let C;const O=[],B=new Set;for(let D=0;D<a;D++){let k;if(x){const z=await this._drawAndSampleAsync({layers:p,views:t,viewports:n,onViewportActive:f,deviceRect:x,cullRect:S,effects:d,pass:`picking:${c}`,canvasContext:u});k=pf({...z,deviceX:_[0],deviceY:_[1],deviceRadius:v,deviceRect:x})}else k={pickedColor:null,pickedObjectIndex:-1};let N;const F=this._getDepthLayers(k,p,l);if(F.length>0){const{pickedColors:z}=await this._drawAndSampleAsync({layers:F,views:t,viewports:n,onViewportActive:f,deviceRect:{x:k.pickedX??_[0],y:k.pickedY??_[1],width:1,height:1},cullRect:S,effects:d,pass:`picking:${c}:z`,canvasContext:u},!0);z[3]&&(N=z[0])}k.pickedLayer&&D+1<a&&(B.add(k.pickedLayer),k.pickedLayer.disablePickingIndex(k.pickedObjectIndex)),C=_f({pickInfo:k,lastPickedInfo:this.lastPickedInfo,mode:c,layers:p,viewports:n,x:s,y:r,z:N,pixelRatio:g});for(const z of C.values())z.layer&&O.push(z);if(!k.pickedColor)break}for(const D of B)D.restorePickingColors();return{result:O,emptyInfo:C.get(null)}}_pickClosestObject({layers:e,views:t,viewports:n,x:s,y:r,radius:o=0,depth:a=1,mode:c="query",unproject3D:l,canvasContext:u=this.device.getDefaultCanvasContext(),onViewportActive:f,effects:d}){const g=u.cssToDeviceRatio(),p=this._getPickable(e);if(!p||n.length===0)return{result:[],emptyInfo:tc({viewports:n,x:s,y:r,pixelRatio:g})};this._resizeBuffer(u);const m=u.cssToDevicePixels([s,r],!0),_=[m.x+Math.floor(m.width/2),m.y+Math.floor(m.height/2)],v=Math.round(o*g),{width:w,height:y}=this.pickingFBO,x=this._getPickingRect({deviceX:_[0],deviceY:_[1],deviceRadius:v,deviceWidth:w,deviceHeight:y}),S={x:s-o,y:r-o,width:o*2+1,height:o*2+1};let C;const O=[],B=new Set;for(let D=0;D<a;D++){let k;if(x){const z=this._drawAndSample({layers:p,views:t,viewports:n,onViewportActive:f,deviceRect:x,cullRect:S,effects:d,pass:`picking:${c}`,canvasContext:u});k=pf({...z,deviceX:_[0],deviceY:_[1],deviceRadius:v,deviceRect:x})}else k={pickedColor:null,pickedObjectIndex:-1};let N;const F=this._getDepthLayers(k,p,l);if(F.length>0){const{pickedColors:z}=this._drawAndSample({layers:F,views:t,viewports:n,onViewportActive:f,deviceRect:{x:k.pickedX??_[0],y:k.pickedY??_[1],width:1,height:1},cullRect:S,effects:d,pass:`picking:${c}:z`,canvasContext:u},!0);z[3]&&(N=z[0])}k.pickedLayer&&D+1<a&&(B.add(k.pickedLayer),k.pickedLayer.disablePickingIndex(k.pickedObjectIndex)),C=_f({pickInfo:k,lastPickedInfo:this.lastPickedInfo,mode:c,layers:p,viewports:n,x:s,y:r,z:N,pixelRatio:g});for(const z of C.values())z.layer&&O.push(z);if(!k.pickedColor)break}for(const D of B)D.restorePickingColors();return{result:O,emptyInfo:C.get(null)}}async _pickVisibleObjectsAsync({layers:e,views:t,viewports:n,x:s,y:r,width:o=1,height:a=1,mode:c="query",maxObjects:l=null,canvasContext:u=this.device.getDefaultCanvasContext(),onViewportActive:f,effects:d}){const g=this._getPickable(e);if(!g||n.length===0)return[];this._resizeBuffer(u);const p=u.cssToDeviceRatio(),m=u.cssToDevicePixels([s,r],!0),_=m.x,v=m.y+m.height,w=u.cssToDevicePixels([s+o,r+a],!0),y=w.x+w.width,x=w.y,S={x:_,y:x,width:y-_,height:v-x},C=await this._drawAndSampleAsync({layers:g,views:t,viewports:n,onViewportActive:f,deviceRect:S,cullRect:{x:s,y:r,width:o,height:a},effects:d,pass:`picking:${c}`,canvasContext:u}),O=mf(C),B=new Map,D=[],k=Number.isFinite(l);for(let N=0;N<O.length&&!(k&&D.length>=l);N++){const F=O[N];let z={color:F.pickedColor,layer:null,index:F.pickedObjectIndex,picked:!0,x:s,y:r,pixelRatio:p};z=ic({layer:F.pickedLayer,info:z,mode:c});const L=z.layer.id;B.has(L)||B.set(L,new Set);const G=B.get(L),b=z.object??z.index;G.has(b)||(G.add(b),D.push(z))}return D}_pickVisibleObjects({layers:e,views:t,viewports:n,x:s,y:r,width:o=1,height:a=1,mode:c="query",maxObjects:l=null,canvasContext:u=this.device.getDefaultCanvasContext(),onViewportActive:f,effects:d}){const g=this._getPickable(e);if(!g||n.length===0)return[];this._resizeBuffer(u);const p=u.cssToDeviceRatio(),m=u.cssToDevicePixels([s,r],!0),_=m.x,v=m.y+m.height,w=u.cssToDevicePixels([s+o,r+a],!0),y=w.x+w.width,x=w.y,S={x:_,y:x,width:y-_,height:v-x},C=this._drawAndSample({layers:g,views:t,viewports:n,onViewportActive:f,deviceRect:S,cullRect:{x:s,y:r,width:o,height:a},effects:d,pass:`picking:${c}`,canvasContext:u}),O=mf(C),B=new Map,D=[],k=Number.isFinite(l);for(let N=0;N<O.length&&!(k&&D.length>=l);N++){const F=O[N];let z={color:F.pickedColor,layer:null,index:F.pickedObjectIndex,picked:!0,x:s,y:r,pixelRatio:p};z=ic({layer:F.pickedLayer,info:z,mode:c});const L=z.layer.id;B.has(L)||B.set(L,new Set);const G=B.get(L),b=z.object??z.index;G.has(b)||(G.add(b),D.push(z))}return D}async _drawAndSampleAsync({layers:e,views:t,viewports:n,onViewportActive:s,deviceRect:r,cullRect:o,effects:a,pass:c,canvasContext:l},u=!1){var S;const f=u?this.depthFBO:this.pickingFBO,d={layers:e,layerFilter:this.layerFilter,views:t,viewports:n,onViewportActive:s,pickingFBO:f,deviceRect:r,cullRect:o,effects:a,pass:c,canvasContext:l,pickZ:u,preRenderStats:{},isPicking:!0};for(const C of a)C.useInPicking&&(d.preRenderStats[C.id]=C.preRender(d));const{decodePickingColor:g,stats:p}=this.pickLayersPass.render(d);this._updateStats(p);const{x:m,y:_,width:v,height:w}=r,y=(S=f.colorAttachments[0])==null?void 0:S.texture;if(!y)throw new Error("Picking framebuffer color attachment is missing");const x=await this._readTextureDataAsync(y,{x:m,y:_,width:v,height:w},u?Float32Array:Uint8Array);if(!u){let C=!1;for(let O=3;O<x.length;O+=4)if(x[O]!==0){C=!0;break}!C&&x.length>0&&Y.warn("Async pick readback returned only zero alpha values",{deviceRect:r,bytes:Array.from(x.subarray(0,Math.min(x.length,16)))})()}return{pickedColors:x,decodePickingColor:g}}async _readTextureDataAsync(e,t,n){const{width:s,height:r}=t,o=e.computeMemoryLayout(t),a=this.device.createBuffer({byteLength:o.byteLength,usage:W.COPY_DST|W.MAP_READ});try{e.readBuffer(t,a);const c=await a.readAsync(0,o.byteLength),l=n.BYTES_PER_ELEMENT;if(o.bytesPerRow%l!==0)throw new Error(`Texture readback row stride ${o.bytesPerRow} is not aligned to ${l}-byte elements.`);const u=new n(c.buffer,c.byteOffset,o.byteLength/l),f=s*4,d=o.bytesPerRow/l;if(d<f)throw new Error(`Texture readback row stride ${d} is smaller than packed row length ${f}.`);const g=new n(s*r*4);for(let p=0;p<r;p++){const m=p*d;g.set(u.subarray(m,m+f),p*f)}return g}finally{a.destroy()}}_drawAndSample({layers:e,views:t,viewports:n,onViewportActive:s,deviceRect:r,cullRect:o,effects:a,pass:c,canvasContext:l},u=!1){const f=u?this.depthFBO:this.pickingFBO,d={layers:e,layerFilter:this.layerFilter,views:t,viewports:n,onViewportActive:s,pickingFBO:f,deviceRect:r,cullRect:o,effects:a,pass:c,canvasContext:l,pickZ:u,preRenderStats:{},isPicking:!0};for(const x of a)x.useInPicking&&(d.preRenderStats[x.id]=x.preRender(d));const{decodePickingColor:g,stats:p}=this.pickLayersPass.render(d);this._updateStats(p);const{x:m,y:_,width:v,height:w}=r,y=new(u?Float32Array:Uint8Array)(v*w*4);return this.device.readPixelsToArrayWebGL(f,{sourceX:m,sourceY:_,sourceWidth:v,sourceHeight:w,target:y}),{pickedColors:y,decodePickingColor:g}}_updateStats(e){if(!this.stats)return;let t=0;for(const{visibleCount:n}of e)t+=n;this.stats.get("Layers picked").addCount(t)}_getDepthLayers(e,t,n){var o;if(!n||!this.depthFBO)return[];const{pickedLayer:s}=e,r=((o=s==null?void 0:s.state)==null?void 0:o.terrainDrawMode)==="drape";return s&&!r?[s]:t.filter(a=>a.props.operation.includes("terrain"))}_getPickingRect({deviceX:e,deviceY:t,deviceRadius:n,deviceWidth:s,deviceHeight:r}){const o=Math.max(0,e-n),a=Math.max(0,t-n),c=Math.min(s,e+n+1)-o,l=Math.min(r,t+n+1)-a;return c<=0||l<=0?null:{x:o,y:a,width:c,height:l}}}const rC={"top-left":{top:0,left:0},"top-right":{top:0,right:0},"bottom-left":{bottom:0,left:0},"bottom-right":{bottom:0,right:0},fill:{top:0,left:0,bottom:0,right:0}},oC="top-left",yf="root";class aC{constructor({deck:e,parentElement:t}){this.defaultWidgets=[],this.widgets=[],this.resolvedWidgets=[],this.containers={},this.lastViewports={},this.deck=e,t==null||t.classList.add("deck-widget-container"),this.parentElement=t}getWidgets(){return this.resolvedWidgets}setProps(e){if(e.widgets&&!Pe(e.widgets,this.widgets,1)){const t=e.widgets.filter(Boolean);this._setWidgets(t)}}finalize(){for(const e of this.getWidgets())this._removeWidget(e);this.defaultWidgets.length=0,this.resolvedWidgets.length=0;for(const e in this.containers)this.containers[e].remove()}addDefault(e){this.defaultWidgets.find(t=>t.id===e.id)||(this._addWidget(e),this.defaultWidgets.push(e),this._setWidgets(this.widgets))}onRedraw({viewports:e,layers:t}){var s,r;const n=e.reduce((o,a)=>(o[a.id]=a,o),{});for(const o of this.getWidgets()){const{viewId:a}=o;if(a){const c=n[a];c&&(o.onViewportChange&&o.onViewportChange(c),(s=o.onRedraw)==null||s.call(o,{viewports:[c],layers:t}))}else{if(o.onViewportChange)for(const c of e)o.onViewportChange(c);(r=o.onRedraw)==null||r.call(o,{viewports:e,layers:t})}}this.lastViewports=n,this._updateContainers()}onHover(e,t){var n,s;for(const r of this.getWidgets()){const{viewId:o}=r;(!o||o===((n=e.viewport)==null?void 0:n.id))&&((s=r.onHover)==null||s.call(r,e,t))}}getCanvasBounds(e){var o,a,c,l,u,f,d;const t=(a=(o=this.deck)==null?void 0:o.getCanvas)==null?void 0:a.call(o),n=t==null?void 0:t.getBoundingClientRect(),s=(c=this.parentElement)==null?void 0:c.getBoundingClientRect(),r=(u=(l=this.deck)==null?void 0:l.getCanvasContext)==null?void 0:u.call(l,e==null?void 0:e.id);if(r&&s){r.updatePosition();const[g,p]=r.getPosition(),[m,_]=r.getCSSSize();return{x:g-s.left,y:p-s.top,width:m,height:_}}return{x:n&&s?n.left-s.left:0,y:n&&s?n.top-s.top:0,width:(n==null?void 0:n.width)||((f=this.deck)==null?void 0:f.width)||0,height:(n==null?void 0:n.height)||((d=this.deck)==null?void 0:d.height)||0}}onEvent(e,t){var s,r;const n=Ps[t.type];if(n)for(const o of this.getWidgets()){const{viewId:a}=o;(!a||a===((s=e.viewport)==null?void 0:s.id))&&((r=o[n])==null||r.call(o,e,t))}}_setWidgets(e){const t={};for(const n of this.resolvedWidgets)t[n.id]=n;this.resolvedWidgets.length=0;for(const n of this.defaultWidgets)t[n.id]=null,this.resolvedWidgets.push(n);for(let n of e){const s=t[n.id];s?s.viewId!==n.viewId||s.placement!==n.placement?(this._removeWidget(s),this._addWidget(n)):n!==s&&(s.setProps(n.props),n=s):this._addWidget(n),t[n.id]=null,this.resolvedWidgets.push(n)}for(const n in t){const s=t[n];s&&this._removeWidget(s)}this.widgets=e}_addWidget(e){const{viewId:t=null,placement:n=oC}=e,s=e.props._container??t;e.widgetManager=this,e.deck=this.deck,e.rootElement=e._onAdd({deck:this.deck,viewId:t}),e.rootElement&&this._getContainer(s,n).append(e.rootElement),e.updateHTML()}_removeWidget(e){var t;(t=e.onRemove)==null||t.call(e),e.rootElement&&e.rootElement.remove(),e.rootElement=void 0,e.deck=void 0,e.widgetManager=void 0}_getContainer(e,t){var o;if(e&&typeof e!="string")return e;const n=e||yf;let s=this.containers[n];s||(s=document.createElement("div"),s.style.pointerEvents="none",s.style.position="absolute",s.style.overflow="hidden",(o=this.parentElement)==null||o.append(s),this.containers[n]=s);let r=s.querySelector(`.${t}`);return r||(r=globalThis.document.createElement("div"),r.className=t,r.style.position="absolute",r.style.zIndex="2",Object.assign(r.style,rC[t]),s.append(r)),r}_updateContainers(){for(const e in this.containers){const t=this.lastViewports[e]||null,n=e===yf||t,s=this.containers[e];if(n){const r=this._getContainerBounds(t);s.style.display="block",s.style.left=`${r.x}px`,s.style.top=`${r.y}px`,s.style.width=`${r.width}px`,s.style.height=`${r.height}px`}else s.style.display="none"}}_getContainerBounds(e){var n,s;if(!e)return{x:0,y:0,width:((n=this.parentElement)==null?void 0:n.clientWidth)||this.deck.width,height:((s=this.parentElement)==null?void 0:s.clientHeight)||this.deck.height};const t=this.getCanvasBounds(e);return{x:t.x+e.x,y:t.y+e.y,width:e.width,height:e.height}}}function bf(i,e){e&&Object.entries(e).map(([t,n])=>{t.startsWith("--")?i.style.setProperty(t,n):i.style[t]=n})}function cC(i,e){e&&Object.keys(e).map(t=>{t.startsWith("--")?i.style.removeProperty(t):i.style[t]=""})}class ul{constructor(e){this.viewId=null,this.props={...this.constructor.defaultProps,...e},this.id=this.props.id}setProps(e){const t=this.props,n=this.rootElement;n&&t.className!==e.className&&(t.className&&n.classList.remove(t.className),e.className&&n.classList.add(e.className)),n&&!Pe(t.style,e.style,1)&&(cC(n,t.style),bf(n,e.style)),Object.assign(this.props,e),this.updateHTML()}updateHTML(){this.rootElement&&this.onRenderHTML(this.rootElement)}get viewIds(){var e;return this.viewId?[this.viewId]:((e=this.deck)==null?void 0:e.getViews().map(t=>t.id))??[]}getViewState(e){var t,n;return((n=(t=this.deck)==null?void 0:t.viewManager)==null?void 0:n.getViewState(e))||{}}setViewState(e,t){var n;(n=this.deck)==null||n._onViewStateChange({viewId:e,viewState:t,interactionState:{}})}onCreateRootElement(){const e=["deck-widget",this.className,this.props.className],t=document.createElement("div");return e.filter(n=>typeof n=="string"&&n.length>0).forEach(n=>t.classList.add(n)),bf(t,this.props.style),t}_onAdd(e){return this.onAdd(e)??this.onCreateRootElement()}onAdd(e){}onRemove(){}onViewportChange(e){}onRedraw(e){}onHover(e,t){}onClick(e,t){}onDrag(e,t){}onDragStart(e,t){}onDragEnd(e,t){}}ul.defaultProps={id:"widget",style:{},_container:null,className:""};const lC={zIndex:"1",position:"absolute",pointerEvents:"none",color:"#a0a7b4",backgroundColor:"#29323c",padding:"10px",top:"0",left:"0",display:"none"};class Wg extends ul{constructor(e={}){super(e),this.id="default-tooltip",this.placement="fill",this.className="deck-tooltip",this.isVisible=!1,this.setProps(e)}onCreateRootElement(){const e=document.createElement("div");return e.className=this.className,Object.assign(e.style,lC),e}onRenderHTML(e){}onViewportChange(e){var t;this.isVisible&&e.id===((t=this.lastViewport)==null?void 0:t.id)&&!e.equals(this.lastViewport)&&this.setTooltip(null),this.lastViewport=e}onHover(e){var c;const{deck:t}=this,n=t&&t.props.getTooltip;if(!n)return;const s=n(e),r=(c=this.widgetManager)==null?void 0:c.getCanvasBounds(e.viewport),o=e.x+((r==null?void 0:r.x)||0),a=e.y+((r==null?void 0:r.y)||0);this.setTooltip(s,o,a)}setTooltip(e,t,n){const s=this.rootElement;if(s){if(typeof e=="string")s.innerText=e;else if(e)e.text&&(s.innerText=e.text),e.html&&(s.innerHTML=e.html),e.className&&(s.className=e.className);else{this.isVisible=!1,s.style.display="none";return}this.isVisible=!0,s.style.display="block",s.style.transform=`translate(${t}px, ${n}px)`,e&&typeof e=="object"&&"style"in e&&Object.assign(s.style,e.style)}}}Wg.defaultProps={...ul.defaultProps};class uC{constructor(e){this.targets={},this.order=[],this.eventManagers={},this._eventRootToCanvasId=new WeakMap,this._createEventManager=e.createEventManager,this._getEventRoot=e.getEventRoot}finalize(){for(const e of Object.values(this.targets))e.eventManager.destroy(),e.presentationContext.destroy();this.targets={},this.order=[],this.eventManagers={},this._eventRootToCanvasId=new WeakMap}syncCanvasEntries(e){const t=this._normalizeCanvasList(e.canvases),n={},s=[],r=new Map;for(const{canvas:a}of t){const c=this._getEventRoot(a);r.set(c,(r.get(c)||0)+1)}for(const{id:a,canvas:c}of t){const l=this._getEventRoot(c),u=r.get(l)===1?l:c;let f=this.targets[a];if(!f||f.device!==e.device||f.canvas!==c||f.eventRoot!==u){f==null||f.eventManager.destroy(),f==null||f.presentationContext.destroy();const d=e.device.createPresentationContext({id:a,canvas:c,useDevicePixels:e.useDevicePixels,autoResize:!0});f={id:a,device:e.device,canvas:c,eventRoot:u,presentationContext:d,eventManager:this._createEventManager(u)}}this._eventRootToCanvasId.set(u,a),this._eventRootToCanvasId.set(c,a),n[a]=f,s.push(a)}for(const[a,c]of Object.entries(this.targets))n[a]||(c.eventManager.destroy(),c.presentationContext.destroy());this.targets=n,this.order=s;const o=Object.fromEntries(Object.entries(n).map(([a,c])=>[a,c.eventManager]));this._haveSameEventManagers(o)||(this.eventManagers=o)}getCanvasIdFromEvent(e){return e?this._eventRootToCanvasId.get(e):void 0}getTarget(e){return this.targets[e||this.order[0]||fi]||null}_normalizeCanvasList(e=[]){const t=new Set;return e.map((n,s)=>{let r,o;return typeof n=="string"?(r=document.getElementById(n),Q(r,`Canvas with id ${n} not found`),o=n):(r=n,o=r.id||`deckgl-canvas-${s}`),Q(!t.has(o),`Duplicate canvas id ${o}`),t.add(o),{id:o,canvas:r}})}_haveSameEventManagers(e){const t=Object.keys(e),n=Object.keys(this.eventManagers);return t.length===n.length&&t.every(s=>e[s]===this.eventManagers[s])}}const fC={WEBGL_depth_texture:{UNSIGNED_INT_24_8_WEBGL:34042},OES_element_index_uint:{},OES_texture_float:{},OES_texture_half_float:{HALF_FLOAT_OES:5131},EXT_color_buffer_float:{},OES_standard_derivatives:{FRAGMENT_SHADER_DERIVATIVE_HINT_OES:35723},EXT_frag_depth:{},EXT_blend_minmax:{MIN_EXT:32775,MAX_EXT:32776},EXT_shader_texture_lod:{}},dC=i=>({drawBuffersWEBGL(e){return i.drawBuffers(e)},COLOR_ATTACHMENT0_WEBGL:36064,COLOR_ATTACHMENT1_WEBGL:36065,COLOR_ATTACHMENT2_WEBGL:36066,COLOR_ATTACHMENT3_WEBGL:36067}),hC=i=>({VERTEX_ARRAY_BINDING_OES:34229,createVertexArrayOES(){return i.createVertexArray()},deleteVertexArrayOES(e){return i.deleteVertexArray(e)},isVertexArrayOES(e){return i.isVertexArray(e)},bindVertexArrayOES(e){return i.bindVertexArray(e)}}),gC=i=>({VERTEX_ATTRIB_ARRAY_DIVISOR_ANGLE:35070,drawArraysInstancedANGLE(...e){return i.drawArraysInstanced(...e)},drawElementsInstancedANGLE(...e){return i.drawElementsInstanced(...e)},vertexAttribDivisorANGLE(...e){return i.vertexAttribDivisor(...e)}});function pC(i=!0){const e=HTMLCanvasElement.prototype;if(!i&&e.originalGetContext){e.getContext=e.originalGetContext,e.originalGetContext=void 0;return}e.originalGetContext=e.getContext,e.getContext=function(t,n){if(t==="webgl"||t==="experimental-webgl"){const s=this.originalGetContext("webgl2",n);return s instanceof HTMLElement&&mC(s),s}return this.originalGetContext(t,n)}}function mC(i){i.getExtension("EXT_color_buffer_float");const e={...fC,WEBGL_disjoint_timer_query:i.getExtension("EXT_disjoint_timer_query_webgl2"),WEBGL_draw_buffers:dC(i),OES_vertex_array_object:hC(i),ANGLE_instanced_arrays:gC(i)},t=i.getExtension.bind(i);i.getExtension=function(s){const r=t(s);return r||(s in e?e[s]:null)};const n=i.getSupportedExtensions;i.getSupportedExtensions=function(){const s=n.apply(i)||[];return s==null?void 0:s.concat(Object.keys(e))}}let vf=!1;async function _C(){{fl();return}}function yC(i,e){return fl(),i}async function bC(i){{fl();return}}function vC(i){return null}function fl(){vf||(vf=!0,M.warn("Import @luma.gl/webgl/debug before enabling WebGL debugging.")())}const Di=1;class wC extends Eb{constructor(){super(...arguments);h(this,"type","webgl")}enforceWebGL2(t){pC(t)}isSupported(){return typeof WebGL2RenderingContext<"u"}isDeviceHandle(t){return typeof WebGL2RenderingContext<"u"&&t instanceof WebGL2RenderingContext?!0:(typeof WebGLRenderingContext<"u"&&t instanceof WebGLRenderingContext&&M.warn("WebGL1 is not supported",t)(),!1)}async attach(t,n={}){const{WebGLDevice:s}=await Os(async()=>{const{WebGLDevice:a}=await Promise.resolve().then(()=>Ff);return{WebGLDevice:a}},void 0,import.meta.url);if(t instanceof s)return t;const r=s.getDeviceFromContext(t);if(r)return r;if(!xC(t))throw new Error("Invalid WebGL2RenderingContext");n=wf(n),await xf(n);const o=n.createCanvasContext===!0?{}:n.createCanvasContext;return new s({...n,_handle:t,createCanvasContext:{canvas:t.canvas,autoResize:!1,...o}})}async create(t={}){const{WebGLDevice:n}=await Os(async()=>{const{WebGLDevice:s}=await Promise.resolve().then(()=>Ff);return{WebGLDevice:s}},void 0,import.meta.url);t=wf(t),await xf(t);try{const s=new n(t);M.groupCollapsed(Di,`WebGLDevice ${s.id} created`)();const r=`${s._reused?"Reusing":"Created"} device with WebGL2 ${s.props.debug?"debug ":""}context: ${s.info.vendor}, ${s.info.renderer} for canvas: ${s.canvasContext.id}`;return M.probe(Di,r)(),M.table(Di,s.info)(),s}finally{M.groupEnd(Di)(),M.info(Di,"%cWebGL call tracing: luma.log.set('debug-webgl') ","color: white; background: blue; padding: 2px 6px; border-radius: 3px;")()}}}function xC(i){return typeof WebGL2RenderingContext<"u"&&i instanceof WebGL2RenderingContext?!0:!!(i&&typeof i.createVertexArray=="function")}const Do=new wC;function wf(i){return{...i,debug:i.debug??gi.defaultProps.debug,debugWebGL:i.debugWebGL??gi.defaultProps.debugWebGL,debugSpectorJS:i.debugSpectorJS??!!M.get("debug-spectorjs")}}async function xf(i){const e=[];(i.debugWebGL||i.debug)&&e.push(_C()),i.debugSpectorJS&&e.push(bC());const t=await Promise.allSettled(e);for(const n of t)n.status==="rejected"&&M.error(`Failed to initialize debug libraries ${n.reason}`)()}const dl={3042:!1,32773:new Float32Array([0,0,0,0]),32777:32774,34877:32774,32969:1,32968:0,32971:1,32970:0,3106:new Float32Array([0,0,0,0]),3107:[!0,!0,!0,!0],2884:!1,2885:1029,2929:!1,2931:1,2932:513,2928:new Float32Array([0,1]),2930:!0,3024:!0,35725:null,36006:null,36007:null,34229:null,34964:null,2886:2305,33170:4352,2849:1,32823:!1,32824:0,10752:0,32926:!1,32928:!1,32938:1,32939:!1,3089:!1,3088:new Int32Array([0,0,1024,1024]),2960:!1,2961:0,2968:4294967295,36005:4294967295,2962:519,2967:0,2963:4294967295,34816:519,36003:0,36004:4294967295,2964:7680,2965:7680,2966:7680,34817:7680,34818:7680,34819:7680,2978:[0,0,1024,1024],36389:null,36662:null,36663:null,35053:null,35055:null,35723:4352,36010:null,35977:!1,3333:4,3317:4,37440:!1,37441:!1,37443:37444,3330:0,3332:0,3331:0,3314:0,32878:0,3316:0,3315:0,32877:0},ue=(i,e,t)=>e?i.enable(t):i.disable(t),Pf=(i,e,t)=>i.hint(t,e),Le=(i,e,t)=>i.pixelStorei(t,e),Sf=(i,e,t)=>{const n=t===36006?36009:36008;return i.bindFramebuffer(n,e)},Fi=(i,e,t)=>{const s={34964:34962,36662:36662,36663:36663,35053:35051,35055:35052}[t];i.bindBuffer(s,e)};function Fo(i){return Array.isArray(i)||ArrayBuffer.isView(i)&&!(i instanceof DataView)}const PC={3042:ue,32773:(i,e)=>i.blendColor(...e),32777:"blendEquation",34877:"blendEquation",32969:"blendFunc",32968:"blendFunc",32971:"blendFunc",32970:"blendFunc",3106:(i,e)=>i.clearColor(...e),3107:(i,e)=>i.colorMask(...e),2884:ue,2885:(i,e)=>i.cullFace(e),2929:ue,2931:(i,e)=>i.clearDepth(e),2932:(i,e)=>i.depthFunc(e),2928:(i,e)=>i.depthRange(...e),2930:(i,e)=>i.depthMask(e),3024:ue,35723:Pf,35725:(i,e)=>i.useProgram(e),36007:(i,e)=>i.bindRenderbuffer(36161,e),36389:(i,e)=>{var t;return(t=i.bindTransformFeedback)==null?void 0:t.call(i,36386,e)},34229:(i,e)=>i.bindVertexArray(e),36006:Sf,36010:Sf,34964:Fi,36662:Fi,36663:Fi,35053:Fi,35055:Fi,2886:(i,e)=>i.frontFace(e),33170:Pf,2849:(i,e)=>i.lineWidth(e),32823:ue,32824:"polygonOffset",10752:"polygonOffset",35977:ue,32926:ue,32928:ue,32938:"sampleCoverage",32939:"sampleCoverage",3089:ue,3088:(i,e)=>i.scissor(...e),2960:ue,2961:(i,e)=>i.clearStencil(e),2968:(i,e)=>i.stencilMaskSeparate(1028,e),36005:(i,e)=>i.stencilMaskSeparate(1029,e),2962:"stencilFuncFront",2967:"stencilFuncFront",2963:"stencilFuncFront",34816:"stencilFuncBack",36003:"stencilFuncBack",36004:"stencilFuncBack",2964:"stencilOpFront",2965:"stencilOpFront",2966:"stencilOpFront",34817:"stencilOpBack",34818:"stencilOpBack",34819:"stencilOpBack",2978:(i,e)=>i.viewport(...e),34383:ue,10754:ue,12288:ue,12289:ue,12290:ue,12291:ue,12292:ue,12293:ue,12294:ue,12295:ue,3333:Le,3317:Le,37440:Le,37441:Le,37443:Le,3330:Le,3332:Le,3331:Le,3314:Le,32878:Le,3316:Le,3315:Le,32877:Le,framebuffer:(i,e)=>{const t=e&&"handle"in e?e.handle:e;return i.bindFramebuffer(36160,t)},blend:(i,e)=>e?i.enable(3042):i.disable(3042),blendColor:(i,e)=>i.blendColor(...e),blendEquation:(i,e)=>{const t=typeof e=="number"?[e,e]:e;i.blendEquationSeparate(...t)},blendFunc:(i,e)=>{const t=(e==null?void 0:e.length)===2?[...e,...e]:e;i.blendFuncSeparate(...t)},clearColor:(i,e)=>i.clearColor(...e),clearDepth:(i,e)=>i.clearDepth(e),clearStencil:(i,e)=>i.clearStencil(e),colorMask:(i,e)=>i.colorMask(...e),cull:(i,e)=>e?i.enable(2884):i.disable(2884),cullFace:(i,e)=>i.cullFace(e),depthTest:(i,e)=>e?i.enable(2929):i.disable(2929),depthFunc:(i,e)=>i.depthFunc(e),depthMask:(i,e)=>i.depthMask(e),depthRange:(i,e)=>i.depthRange(...e),dither:(i,e)=>e?i.enable(3024):i.disable(3024),derivativeHint:(i,e)=>{i.hint(35723,e)},frontFace:(i,e)=>i.frontFace(e),mipmapHint:(i,e)=>i.hint(33170,e),lineWidth:(i,e)=>i.lineWidth(e),polygonOffsetFill:(i,e)=>e?i.enable(32823):i.disable(32823),polygonOffset:(i,e)=>i.polygonOffset(...e),sampleCoverage:(i,e)=>i.sampleCoverage(e[0],e[1]||!1),scissorTest:(i,e)=>e?i.enable(3089):i.disable(3089),scissor:(i,e)=>i.scissor(...e),stencilTest:(i,e)=>e?i.enable(2960):i.disable(2960),stencilMask:(i,e)=>{e=Fo(e)?e:[e,e];const[t,n]=e;i.stencilMaskSeparate(1028,t),i.stencilMaskSeparate(1029,n)},stencilFunc:(i,e)=>{e=Fo(e)&&e.length===3?[...e,...e]:e;const[t,n,s,r,o,a]=e;i.stencilFuncSeparate(1028,t,n,s),i.stencilFuncSeparate(1029,r,o,a)},stencilOp:(i,e)=>{e=Fo(e)&&e.length===3?[...e,...e]:e;const[t,n,s,r,o,a]=e;i.stencilOpSeparate(1028,t,n,s),i.stencilOpSeparate(1029,r,o,a)},viewport:(i,e)=>i.viewport(...e)};function ce(i,e,t){return e[i]!==void 0?e[i]:t[i]}const SC={blendEquation:(i,e,t)=>i.blendEquationSeparate(ce(32777,e,t),ce(34877,e,t)),blendFunc:(i,e,t)=>i.blendFuncSeparate(ce(32969,e,t),ce(32968,e,t),ce(32971,e,t),ce(32970,e,t)),polygonOffset:(i,e,t)=>i.polygonOffset(ce(32824,e,t),ce(10752,e,t)),sampleCoverage:(i,e,t)=>i.sampleCoverage(ce(32938,e,t),ce(32939,e,t)),stencilFuncFront:(i,e,t)=>i.stencilFuncSeparate(1028,ce(2962,e,t),ce(2967,e,t),ce(2963,e,t)),stencilFuncBack:(i,e,t)=>i.stencilFuncSeparate(1029,ce(34816,e,t),ce(36003,e,t),ce(36004,e,t)),stencilOpFront:(i,e,t)=>i.stencilOpSeparate(1028,ce(2964,e,t),ce(2965,e,t),ce(2966,e,t)),stencilOpBack:(i,e,t)=>i.stencilOpSeparate(1029,ce(34817,e,t),ce(34818,e,t),ce(34819,e,t))},Ef={enable:(i,e)=>i({[e]:!0}),disable:(i,e)=>i({[e]:!1}),pixelStorei:(i,e,t)=>i({[e]:t}),hint:(i,e,t)=>i({[e]:t}),useProgram:(i,e)=>i({35725:e}),bindRenderbuffer:(i,e,t)=>i({36007:t}),bindTransformFeedback:(i,e,t)=>i({36389:t}),bindVertexArray:(i,e)=>i({34229:e}),bindFramebuffer:(i,e,t)=>{switch(e){case 36160:return i({36006:t,36010:t});case 36009:return i({36006:t});case 36008:return i({36010:t});default:return null}},bindBuffer:(i,e,t)=>{const n={34962:[34964],36662:[36662],36663:[36663],35051:[35053],35052:[35055]}[e];return n?i({[n]:t}):{valueChanged:!0}},blendColor:(i,e,t,n,s)=>i({32773:new Float32Array([e,t,n,s])}),blendEquation:(i,e)=>i({32777:e,34877:e}),blendEquationSeparate:(i,e,t)=>i({32777:e,34877:t}),blendFunc:(i,e,t)=>i({32969:e,32968:t,32971:e,32970:t}),blendFuncSeparate:(i,e,t,n,s)=>i({32969:e,32968:t,32971:n,32970:s}),clearColor:(i,e,t,n,s)=>i({3106:new Float32Array([e,t,n,s])}),clearDepth:(i,e)=>i({2931:e}),clearStencil:(i,e)=>i({2961:e}),colorMask:(i,e,t,n,s)=>i({3107:[e,t,n,s]}),cullFace:(i,e)=>i({2885:e}),depthFunc:(i,e)=>i({2932:e}),depthRange:(i,e,t)=>i({2928:new Float32Array([e,t])}),depthMask:(i,e)=>i({2930:e}),frontFace:(i,e)=>i({2886:e}),lineWidth:(i,e)=>i({2849:e}),polygonOffset:(i,e,t)=>i({32824:e,10752:t}),sampleCoverage:(i,e,t)=>i({32938:e,32939:t}),scissor:(i,e,t,n,s)=>i({3088:new Int32Array([e,t,n,s])}),stencilMask:(i,e)=>i({2968:e,36005:e}),stencilMaskSeparate:(i,e,t)=>i({[e===1028?2968:36005]:t}),stencilFunc:(i,e,t,n)=>i({2962:e,2967:t,2963:n,34816:e,36003:t,36004:n}),stencilFuncSeparate:(i,e,t,n,s)=>i({[e===1028?2962:34816]:t,[e===1028?2967:36003]:n,[e===1028?2963:36004]:s}),stencilOp:(i,e,t,n)=>i({2964:e,2965:t,2966:n,34817:e,34818:t,34819:n}),stencilOpSeparate:(i,e,t,n,s)=>i({[e===1028?2964:34817]:t,[e===1028?2965:34818]:n,[e===1028?2966:34819]:s}),viewport:(i,e,t,n,s)=>i({2978:[e,t,n,s]})},Ye=(i,e)=>i.isEnabled(e),Cf={3042:Ye,2884:Ye,2929:Ye,3024:Ye,32823:Ye,32926:Ye,32928:Ye,3089:Ye,2960:Ye,35977:Ye},EC=new Set([34016,36388,36387,35983,35368,34965,35739,35738,3074,34853,34854,34855,34856,34857,34858,34859,34860,34861,34862,34863,34864,34865,34866,34867,34868,35097,32873,35869,32874,34068]);function Mi(i,e){var s;if(LC(e))return;const t={};for(const r in e){const o=Number(r),a=PC[r];a&&(typeof a=="string"?t[a]=!0:a(i,e[r],o))}const n=(s=i.lumaState)==null?void 0:s.cache;if(n)for(const r in t){const o=SC[r];o(i,e,n)}}function Hg(i,e=dl){if(typeof e=="number"){const s=e,r=Cf[s];return r?r(i,s):i.getParameter(s)}const t=Array.isArray(e)?e:Object.keys(e),n={};for(const s of t){const r=Cf[s];n[s]=r?r(i,Number(s)):i.getParameter(Number(s))}return n}function CC(i){Mi(i,dl)}function LC(i){for(const e in i)return!1;return!0}function TC(i,e){if(i===e)return!0;if(Lf(i)&&Lf(e)&&i.length===e.length){for(let t=0;t<i.length;++t)if(i[t]!==e[t])return!1;return!0}return!1}function Lf(i){return Array.isArray(i)||ArrayBuffer.isView(i)}class Bt{constructor(e,t){h(this,"gl");h(this,"program",null);h(this,"stateStack",[]);h(this,"enable",!0);h(this,"cache",null);h(this,"log");h(this,"initialized",!1);this.gl=e,this.log=(t==null?void 0:t.log)||(()=>{}),this._updateCache=this._updateCache.bind(this),Object.seal(this)}static get(e){return e.lumaState}push(e={}){this.stateStack.push({})}pop(){const e=this.stateStack[this.stateStack.length-1];Mi(this.gl,e),this.stateStack.pop()}trackState(e,t){if(this.cache=t!=null&&t.copyState?Hg(e):Object.assign({},dl),this.initialized)throw new Error("WebGLStateTracker");this.initialized=!0,this.gl.lumaState=this,MC(e);for(const n in Ef){const s=Ef[n];AC(e,n,s)}Tf(e,"getParameter"),Tf(e,"isEnabled")}_updateCache(e){let t=!1,n;const s=this.stateStack.length>0?this.stateStack[this.stateStack.length-1]:null;for(const r in e){const o=e[r],a=this.cache[r];TC(o,a)||(t=!0,n=a,s&&!(r in s)&&(s[r]=a),this.cache[r]=o)}return{valueChanged:t,oldValue:n}}}function Tf(i,e){const t=i[e].bind(i);i[e]=function(s){if(s===void 0||EC.has(s))return t(s);const r=Bt.get(i);return s in r.cache||(r.cache[s]=t(s)),r.enable?r.cache[s]:t(s)},Object.defineProperty(i[e],"name",{value:`${e}-from-cache`,configurable:!1})}function AC(i,e,t){if(!i[e])return;const n=i[e].bind(i);i[e]=function(...r){const o=Bt.get(i),{valueChanged:a,oldValue:c}=t(o._updateCache,...r);return a&&n(...r),c},Object.defineProperty(i[e],"name",{value:`${e}-to-cache`,configurable:!1})}function MC(i){const e=i.useProgram.bind(i);i.useProgram=function(n){const s=Bt.get(i);s.program!==n&&(e(n),s.program=n)}}function nc(i){const e=i.luma||{_polyfilled:!1,extensions:{},softwareRenderer:!1};return e._polyfilled??(e._polyfilled=!1),e.extensions||(e.extensions={}),i.luma=e,e}function IC(i,e,t){let n="";const s=c=>{const l=c.statusMessage;l&&(n||(n=l))};i.addEventListener("webglcontextcreationerror",s,!1);const r=t.failIfMajorPerformanceCaveat!==!0,o={preserveDrawingBuffer:!0,...t,failIfMajorPerformanceCaveat:!0};let a=null;try{a||(a=i.getContext("webgl2",o)),!a&&o.failIfMajorPerformanceCaveat&&(n||(n="Only software GPU is available. Set `failIfMajorPerformanceCaveat: false` to allow."));let c=!1;if(!a&&r&&(o.failIfMajorPerformanceCaveat=!1,a=i.getContext("webgl2",o),c=!0),a||(a=i.getContext("webgl",{}),a&&(a=null,n||(n="Your browser only supports WebGL1"))),!a)throw n||(n="Your browser does not support WebGL"),new Error(`Failed to create WebGL context: ${n}`);const l=nc(a);l.softwareRenderer=c;const{onContextLost:u,onContextRestored:f}=e;return i.addEventListener("webglcontextlost",d=>u(d),!1),i.addEventListener("webglcontextrestored",d=>f(d),!1),a}finally{i.removeEventListener("webglcontextcreationerror",s,!1)}}function Gt(i,e,t){return t[e]===void 0&&(t[e]=i.getExtension(e)||null),t[e]}function RC(i,e){const t=i.getParameter(7936),n=i.getParameter(7937);Gt(i,"WEBGL_debug_renderer_info",e);const s=e.WEBGL_debug_renderer_info,r=i.getParameter(s?s.UNMASKED_VENDOR_WEBGL:7936),o=i.getParameter(s?s.UNMASKED_RENDERER_WEBGL:7937),a=r||t,c=o||n,l=i.getParameter(7938),u=Yg(a,c),f=OC(a,c),d=BC(a,c);return{type:"webgl",gpu:u,gpuType:d,gpuBackend:f,vendor:a,renderer:c,version:l,shadingLanguage:"glsl",shadingLanguageVersion:300}}function Yg(i,e){return/NVIDIA/i.exec(i)||/NVIDIA/i.exec(e)?"nvidia":/INTEL/i.exec(i)||/INTEL/i.exec(e)?"intel":/Apple/i.exec(i)||/Apple/i.exec(e)?"apple":/AMD/i.exec(i)||/AMD/i.exec(e)||/ATI/i.exec(i)||/ATI/i.exec(e)?"amd":/SwiftShader/i.exec(i)||/SwiftShader/i.exec(e)?"software":"unknown"}function OC(i,e){return/Metal/i.exec(i)||/Metal/i.exec(e)?"metal":/ANGLE/i.exec(i)||/ANGLE/i.exec(e)?"opengl":"unknown"}function BC(i,e){if(/SwiftShader/i.exec(i)||/SwiftShader/i.exec(e))return"cpu";switch(Yg(i,e)){case"apple":return kC(i,e)?"integrated":"unknown";case"intel":return"integrated";case"software":return"cpu";case"unknown":return"unknown";default:return"discrete"}}function kC(i,e){return/Apple (M\d|A\d|GPU)/i.test(`${i} ${e}`)}function qg(i){switch(i){case"uint8":return 5121;case"sint8":return 5120;case"unorm8":return 5121;case"snorm8":return 5120;case"uint16":return 5123;case"sint16":return 5122;case"unorm16":return 5123;case"snorm16":return 5122;case"uint32":return 5125;case"sint32":return 5124;case"float16":return 5131;case"float32":return 5126}throw new Error(String(i))}const qi="WEBGL_compressed_texture_s3tc",Zi="WEBGL_compressed_texture_s3tc_srgb",ni="EXT_texture_compression_rgtc",si="EXT_texture_compression_bptc",DC="WEBGL_compressed_texture_etc",FC="WEBGL_compressed_texture_astc",zC="WEBGL_compressed_texture_etc1",NC="WEBGL_compressed_texture_pvrtc",UC="WEBGL_compressed_texture_atc",$C="EXT_texture_norm16",Af="EXT_render_snorm",Zg="EXT_color_buffer_float",zo="snorm8-renderable-webgl",No="norm16-renderable-webgl",Uo="snorm16-renderable-webgl",$o="float16-renderable-webgl",rs="float32-renderable-webgl",GC="rgb9e5ufloat-renderable-webgl",hl={"float32-renderable-webgl":{extensions:[Zg]},"float16-renderable-webgl":{extensions:["EXT_color_buffer_half_float"]},"rgb9e5ufloat-renderable-webgl":{extensions:["WEBGL_render_shared_exponent"]},"snorm8-renderable-webgl":{extensions:[Af]},"norm16-webgl":{extensions:[$C]},"norm16-renderable-webgl":{features:["norm16-webgl"]},"snorm16-renderable-webgl":{features:["norm16-webgl"],extensions:[Af]},"float32-filterable":{extensions:["OES_texture_float_linear"]},"float16-filterable-webgl":{extensions:["OES_texture_half_float_linear"]},"texture-filterable-anisotropic-webgl":{extensions:["EXT_texture_filter_anisotropic"]},"texture-blend-float-webgl":{extensions:["EXT_float_blend"]},"texture-compression-bc":{extensions:[qi,Zi,ni,si]},"texture-compression-bc5-webgl":{extensions:[ni]},"texture-compression-bc7-webgl":{extensions:[si]},"texture-compression-etc2":{extensions:[DC]},"texture-compression-astc":{extensions:[FC]},"texture-compression-etc1-webgl":{extensions:[zC]},"texture-compression-pvrtc-webgl":{extensions:[NC]},"texture-compression-atc-webgl":{extensions:[UC]}};function jC(i){return i in hl}function Xg(i,e,t){return Kg(i,e,t,new Set)}function Kg(i,e,t,n){const s=hl[e];if(!s||n.has(e))return!1;n.add(e);const r=(s.features||[]).every(o=>Kg(i,o,t,n));return n.delete(e),r?(s.extensions||[]).every(o=>!!Gt(i,o,t)):!1}const Wr={r8unorm:{gl:33321,rb:!0},r8snorm:{gl:36756,r:zo},r8uint:{gl:33330,rb:!0},r8sint:{gl:33329,rb:!0},rg8unorm:{gl:33323,rb:!0},rg8snorm:{gl:36757,r:zo},rg8uint:{gl:33336,rb:!0},rg8sint:{gl:33335,rb:!0},r16uint:{gl:33332,rb:!0},r16sint:{gl:33331,rb:!0},r16float:{gl:33325,rb:!0,r:$o},r16unorm:{gl:33322,rb:!0,r:No},r16snorm:{gl:36760,r:Uo},"rgba4unorm-webgl":{gl:32854,rb:!0},"rgb565unorm-webgl":{gl:36194,rb:!0},"rgb5a1unorm-webgl":{gl:32855,rb:!0},"rgb8unorm-webgl":{gl:32849},"rgb8snorm-webgl":{gl:36758},rgba8unorm:{gl:32856},"rgba8unorm-srgb":{gl:35907},rgba8snorm:{gl:36759,r:zo},rgba8uint:{gl:36220},rgba8sint:{gl:36238},bgra8unorm:{},"bgra8unorm-srgb":{},rg16uint:{gl:33338},rg16sint:{gl:33337},rg16float:{gl:33327,rb:!0,r:$o},rg16unorm:{gl:33324,r:No},rg16snorm:{gl:36761,r:Uo},r32uint:{gl:33334,rb:!0},r32sint:{gl:33333,rb:!0},r32float:{gl:33326,r:rs},rgb9e5ufloat:{gl:35901,r:GC},rg11b10ufloat:{gl:35898,rb:!0},rgb10a2unorm:{gl:32857,rb:!0},rgb10a2uint:{gl:36975,rb:!0},"rgb16unorm-webgl":{gl:32852,r:!1},"rgb16snorm-webgl":{gl:36762,r:!1},rg32uint:{gl:33340,rb:!0},rg32sint:{gl:33339,rb:!0},rg32float:{gl:33328,rb:!0,r:rs},rgba16uint:{gl:36214,rb:!0},rgba16sint:{gl:36232,rb:!0},rgba16float:{gl:34842,r:$o},rgba16unorm:{gl:32859,rb:!0,r:No},rgba16snorm:{gl:36763,r:Uo},"rgb32float-webgl":{gl:34837,x:Zg,r:rs,dataFormat:6407,types:[5126]},rgba32uint:{gl:36208,rb:!0},rgba32sint:{gl:36226,rb:!0},rgba32float:{gl:34836,rb:!0,r:rs},stencil8:{gl:36168,rb:!0},depth16unorm:{gl:33189,dataFormat:6402,types:[5123],rb:!0},depth24plus:{gl:33190,dataFormat:6402,types:[5125]},depth32float:{gl:36012,dataFormat:6402,types:[5126],rb:!0},"depth24plus-stencil8":{gl:35056,rb:!0,depthTexture:!0,dataFormat:34041,types:[34042]},"depth32float-stencil8":{gl:36013,dataFormat:34041,types:[36269],rb:!0},"bc1-rgb-unorm-webgl":{gl:33776,x:qi},"bc1-rgb-unorm-srgb-webgl":{gl:35916,x:Zi},"bc1-rgba-unorm":{gl:33777,x:qi},"bc1-rgba-unorm-srgb":{gl:35916,x:Zi},"bc2-rgba-unorm":{gl:33778,x:qi},"bc2-rgba-unorm-srgb":{gl:35918,x:Zi},"bc3-rgba-unorm":{gl:33779,x:qi},"bc3-rgba-unorm-srgb":{gl:35919,x:Zi},"bc4-r-unorm":{gl:36283,x:ni},"bc4-r-snorm":{gl:36284,x:ni},"bc5-rg-unorm":{gl:36285,x:ni},"bc5-rg-snorm":{gl:36286,x:ni},"bc6h-rgb-ufloat":{gl:36495,x:si},"bc6h-rgb-float":{gl:36494,x:si},"bc7-rgba-unorm":{gl:36492,x:si},"bc7-rgba-unorm-srgb":{gl:36493,x:si},"etc2-rgb8unorm":{gl:37492},"etc2-rgb8unorm-srgb":{gl:37494},"etc2-rgb8a1unorm":{gl:37496},"etc2-rgb8a1unorm-srgb":{gl:37497},"etc2-rgba8unorm":{gl:37493},"etc2-rgba8unorm-srgb":{gl:37495},"eac-r11unorm":{gl:37488},"eac-r11snorm":{gl:37489},"eac-rg11unorm":{gl:37490},"eac-rg11snorm":{gl:37491},"astc-4x4-unorm":{gl:37808},"astc-4x4-unorm-srgb":{gl:37840},"astc-5x4-unorm":{gl:37809},"astc-5x4-unorm-srgb":{gl:37841},"astc-5x5-unorm":{gl:37810},"astc-5x5-unorm-srgb":{gl:37842},"astc-6x5-unorm":{gl:37811},"astc-6x5-unorm-srgb":{gl:37843},"astc-6x6-unorm":{gl:37812},"astc-6x6-unorm-srgb":{gl:37844},"astc-8x5-unorm":{gl:37813},"astc-8x5-unorm-srgb":{gl:37845},"astc-8x6-unorm":{gl:37814},"astc-8x6-unorm-srgb":{gl:37846},"astc-8x8-unorm":{gl:37815},"astc-8x8-unorm-srgb":{gl:37847},"astc-10x5-unorm":{gl:37816},"astc-10x5-unorm-srgb":{gl:37848},"astc-10x6-unorm":{gl:37817},"astc-10x6-unorm-srgb":{gl:37849},"astc-10x8-unorm":{gl:37818},"astc-10x8-unorm-srgb":{gl:37850},"astc-10x10-unorm":{gl:37819},"astc-10x10-unorm-srgb":{gl:37851},"astc-12x10-unorm":{gl:37820},"astc-12x10-unorm-srgb":{gl:37852},"astc-12x12-unorm":{gl:37821},"astc-12x12-unorm-srgb":{gl:37853},"pvrtc-rgb4unorm-webgl":{gl:35840},"pvrtc-rgba4unorm-webgl":{gl:35842},"pvrtc-rgb2unorm-webgl":{gl:35841},"pvrtc-rgba2unorm-webgl":{gl:35843},"etc1-rbg-unorm-webgl":{gl:36196},"atc-rgb-unorm-webgl":{gl:35986},"atc-rgba-unorm-webgl":{gl:35986},"atc-rgbai-unorm-webgl":{gl:34798}};function VC(i,e,t){let n=e.create;const s=Wr[e.format];(s==null?void 0:s.gl)===void 0&&(n=!1),s!=null&&s.x&&(n=n&&!!Gt(i,s.x,t)),e.format==="stencil8"&&(n=!1);const r=(s==null?void 0:s.r)===!1?!1:(s==null?void 0:s.r)===void 0||Xg(i,s.r,t),o=n&&e.render&&r&&WC(i,e.format,t);return{format:e.format,create:n&&e.create,render:o,filter:n&&e.filter,blend:n&&e.blend,store:n&&e.store}}function WC(i,e,t){const n=Wr[e],s=n==null?void 0:n.gl;if(s===void 0||n!=null&&n.x&&!Gt(i,n.x,t))return!1;const r=i.getParameter(32873),o=i.getParameter(36006),a=i.createTexture(),c=i.createFramebuffer();if(!a||!c)return!1;const l=0;let u=Number(i.getError());for(;u!==l;)u=i.getError();let f=!1;try{if(i.bindTexture(3553,a),i.texStorage2D(3553,1,s,1,1),Number(i.getError())!==l)return!1;i.bindFramebuffer(36160,c),i.framebufferTexture2D(36160,36064,3553,a,0),f=Number(i.checkFramebufferStatus(36160))===36053&&Number(i.getError())===l}finally{i.bindFramebuffer(36160,o),i.deleteFramebuffer(c),i.bindTexture(3553,r),i.deleteTexture(a)}return f}function Qg(i){var s;const e=Wr[i],t=qC(i),n=Fe.getInfo(i);return n.compressed&&(e.dataFormat=t),{internalFormat:t,format:(e==null?void 0:e.dataFormat)||YC(n.channels,n.integer,n.normalized,t),type:n.dataType?qg(n.dataType):((s=e==null?void 0:e.types)==null?void 0:s[0])||5121,compressed:n.compressed||!1}}function HC(i){switch(Fe.getInfo(i).attachment){case"depth":return 36096;case"stencil":return 36128;case"depth-stencil":return 33306;default:throw new Error(`Not a depth stencil format: ${i}`)}}function YC(i,e,t,n){if(n===6408||n===6407)return n;switch(i){case"r":return e&&!t?36244:6403;case"rg":return e&&!t?33320:33319;case"rgb":return e&&!t?36248:6407;case"rgba":return e&&!t?36249:6408;case"bgra":throw new Error("bgra pixels not supported by WebGL");default:return 6408}}function qC(i){const e=Wr[i],t=e==null?void 0:e.gl;if(t===void 0)throw new Error(`Unsupported texture format ${i}`);return t}const Mf={"depth-clip-control":"EXT_depth_clamp","timestamp-query":"EXT_disjoint_timer_query_webgl2","compilation-status-async-webgl":"KHR_parallel_shader_compile","html-in-canvas":i=>wv()&&typeof i.texElementImage2D=="function","polygon-mode-webgl":"WEBGL_polygon_mode","provoking-vertex-webgl":"WEBGL_provoking_vertex","shader-clip-cull-distance-webgl":"WEBGL_clip_cull_distance","shader-noperspective-interpolation-webgl":"NV_shader_noperspective_interpolation","shader-conservative-depth-webgl":"EXT_conservative_depth"};class ZC extends vv{constructor(t,n,s){super([],s);h(this,"gl");h(this,"extensions");h(this,"testedFeatures",new Set);this.gl=t,this.extensions=n,Gt(t,"EXT_color_buffer_float",n)}*[Symbol.iterator](){const t=this.getFeatures();for(const n of t)this.has(n)&&(yield n);return[]}has(t){var n;return(n=this.disabledFeatures)!=null&&n[t]?!1:(this.testedFeatures.has(t)||(this.testedFeatures.add(t),jC(t)&&Xg(this.gl,t,this.extensions)&&this.features.add(t),this.getWebGLFeature(t)&&this.features.add(t)),this.features.has(t))}initializeFeatures(){const t=this.getFeatures().filter(n=>n!=="polygon-mode-webgl");for(const n of t)this.has(n)}getFeatures(){return[...Object.keys(Mf),...Object.keys(hl)]}getWebGLFeature(t){const n=Mf[t];return typeof n=="string"?!!Gt(this.gl,n,this.extensions):typeof n=="function"?n(this.gl):!!n}}class XC extends pv{constructor(t){super();h(this,"gl");h(this,"limits",{});this.gl=t}get maxTextureDimension1D(){return 0}get maxTextureDimension2D(){return this.getParameter(3379)}get maxTextureDimension3D(){return this.getParameter(32883)}get maxTextureArrayLayers(){return this.getParameter(35071)}get maxBindGroups(){return 0}get maxBindGroupsPlusVertexBuffers(){return 0}get maxBindingsPerBindGroup(){return 0}get maxDynamicUniformBuffersPerPipelineLayout(){return 0}get maxDynamicStorageBuffersPerPipelineLayout(){return 0}get maxSampledTexturesPerShaderStage(){return this.getParameter(35660)}get maxSamplersPerShaderStage(){return this.getParameter(35661)}get maxStorageBuffersPerShaderStage(){return 0}get maxStorageBuffersInVertexStage(){return 0}get maxStorageBuffersInFragmentStage(){return 0}get maxStorageTexturesPerShaderStage(){return 0}get maxStorageTexturesInVertexStage(){return 0}get maxStorageTexturesInFragmentStage(){return 0}get maxUniformBuffersPerShaderStage(){return this.getParameter(35375)}get maxUniformBufferBindingSize(){return this.getParameter(35376)}get maxStorageBufferBindingSize(){return 0}get maxBufferSize(){return Number.MAX_SAFE_INTEGER}get minUniformBufferOffsetAlignment(){return this.getParameter(35380)}get minStorageBufferOffsetAlignment(){return 0}get maxVertexBuffers(){return 16}get maxVertexAttributes(){return this.getParameter(34921)}get maxVertexBufferArrayStride(){return 2048}get maxInterStageShaderVariables(){return this.getParameter(35659)}get maxColorAttachments(){return this.getParameter(36063)}get maxColorAttachmentBytesPerSample(){return 0}get maxComputeWorkgroupStorageSize(){return 0}get maxComputeInvocationsPerWorkgroup(){return 0}get maxComputeWorkgroupSizeX(){return 0}get maxComputeWorkgroupSizeY(){return 0}get maxComputeWorkgroupSizeZ(){return 0}get maxComputeWorkgroupsPerDimension(){return 0}getParameter(t){return this.limits[t]===void 0&&(this.limits[t]=this.gl.getParameter(t)),this.limits[t]||0}}class sn extends Ys{constructor(t,n){super(t,n);h(this,"device");h(this,"gl");h(this,"handle");h(this,"colorAttachments",[]);h(this,"depthStencilAttachment",null);const s=n.handle,r=s===null;this.device=t,this.gl=t.gl,this.handle=s||r?s:this.gl.createFramebuffer(),r||(t._setWebGLDebugMetadata(this.handle,this,{spector:this.props}),n.handle||(this.autoCreateAttachmentTextures(),this.updateAttachments()))}destroy(){super.destroy(),!this.destroyed&&this.handle!==null&&!this.props.handle&&this.gl.deleteFramebuffer(this.handle)}updateAttachments(){const t=this.gl.bindFramebuffer(36160,this.handle);for(let n=0;n<this.colorAttachments.length;++n){const s=this.colorAttachments[n];if(s){const r=36064+n;this._attachTextureView(r,s)}}if(this.depthStencilAttachment){const n=HC(this.depthStencilAttachment.props.format);this._attachTextureView(n,this.depthStencilAttachment)}if(this.device.props.debug){const n=this.gl.checkFramebufferStatus(36160);if(n!==36053)throw new Error(`Framebuffer ${QC(n)}`)}this.gl.bindFramebuffer(36160,t)}_attachTextureView(t,n){const{gl:s}=this.device,{texture:r}=n,o=n.props.baseMipLevel,a=n.props.baseArrayLayer;switch(s.bindTexture(r.glTarget,r.handle),r.glTarget){case 35866:case 32879:s.framebufferTextureLayer(36160,t,r.handle,o,a);break;case 34067:const c=KC(a);s.framebufferTexture2D(36160,t,c,r.handle,o);break;case 3553:s.framebufferTexture2D(36160,t,3553,r.handle,o);break;default:throw new Error("Illegal texture type")}s.bindTexture(r.glTarget,null)}resizeAttachments(t,n){if(this.handle===null){this.width=t,this.height=n;return}super.resizeAttachments(t,n)}}function KC(i){return i<34069?i+34069:i}function QC(i){switch(i){case 36053:return"success";case 36054:return"Mismatched attachments";case 36055:return"No attachments";case 36057:return"Height/width mismatch";case 36061:return"Unsupported or split attachments";case 36182:return"Samples mismatch";default:return`${i}`}}class JC extends Bh{constructor(t,n){super(n);h(this,"device");h(this,"handle",null);h(this,"_framebuffer",null);this.device=t,this._setAutoCreatedCanvasId(`${this.device.id}-canvas`),this._configureDevice()}get[Symbol.toStringTag](){return"WebGLCanvasContext"}_configureDevice(){var n,s,r;(this.drawingBufferWidth!==((n=this._framebuffer)==null?void 0:n.width)||this.drawingBufferHeight!==((s=this._framebuffer)==null?void 0:s.height))&&((r=this._framebuffer)==null||r.resize([this.drawingBufferWidth,this.drawingBufferHeight]))}_getCurrentFramebuffer(){return this._framebuffer||(this._framebuffer=new sn(this.device,{id:"canvas-context-framebuffer",handle:null,width:this.drawingBufferWidth,height:this.drawingBufferHeight})),this._framebuffer}}class eL extends Tv{constructor(t,n={}){super(n);h(this,"device");h(this,"handle",null);h(this,"context2d");this.device=t;const s=`${this[Symbol.toStringTag]}(${this.id})`;if(!this.device.getDefaultCanvasContext().offscreenCanvas)throw new Error(`${s}: WebGL PresentationContext requires the default CanvasContext canvas to be an OffscreenCanvas`);const o=this.canvas.getContext("2d");if(!o)throw new Error(`${s}: Failed to create 2d presentation context`);this.context2d=o,this._setAutoCreatedCanvasId(`${this.device.id}-presentation-canvas`),this._configureDevice(),this._startObservers()}get[Symbol.toStringTag](){return"WebGLPresentationContext"}present(){this._resizeDrawingBufferIfNeeded(),this.device.submit();const t=this.device.getDefaultCanvasContext(),[n,s]=t.getDrawingBufferSize();if(!(this.drawingBufferWidth===0||this.drawingBufferHeight===0||n===0||s===0||t.canvas.width===0||t.canvas.height===0)){if(n!==this.drawingBufferWidth||s!==this.drawingBufferHeight||t.canvas.width!==this.drawingBufferWidth||t.canvas.height!==this.drawingBufferHeight)throw new Error(`${this[Symbol.toStringTag]}(${this.id}): Default canvas context size ${n}x${s} does not match presentation size ${this.drawingBufferWidth}x${this.drawingBufferHeight}`);this.context2d.clearRect(0,0,this.drawingBufferWidth,this.drawingBufferHeight),this.context2d.drawImage(t.canvas,0,0)}}_configureDevice(){}_getCurrentFramebuffer(t){const n=this.device.getDefaultCanvasContext();return n.setDrawingBufferSize(this.drawingBufferWidth,this.drawingBufferHeight),n.getCurrentFramebuffer(t)}}const Go={};function tL(i="id"){Go[i]=Go[i]||1;const e=Go[i]++;return`${i}-${e}`}class rn extends W{constructor(t,n={}){super(t,n);h(this,"device");h(this,"gl");h(this,"handle");h(this,"glTarget");h(this,"glUsage");h(this,"glIndexType",5123);h(this,"byteLength",0);h(this,"bytesUsed",0);this.device=t,this.gl=this.device.gl;const s=typeof n=="object"?n.handle:void 0;this.handle=s||this.gl.createBuffer(),t._setWebGLDebugMetadata(this.handle,this,{spector:{...this.props,data:typeof this.props.data}}),this.glTarget=iL(this.props.usage),this.glUsage=nL(this.props.usage),this.glIndexType=this.props.indexType==="uint32"?5125:5123,n.data?this._initWithData(n.data,n.byteOffset,n.byteLength):this._initWithByteLength(n.byteLength||0)}destroy(){!this.destroyed&&this.handle&&(this.removeStats(),this.props.handle?this.trackDeallocatedReferencedMemory("Buffer"):(this.trackDeallocatedMemory(),this.gl.deleteBuffer(this.handle)),this.destroyed=!0,this.handle=null)}_initWithData(t,n=0,s=t.byteLength+n){const r=this.glTarget;this.gl.bindBuffer(r,this.handle),this.gl.bufferData(r,s,this.glUsage),this.gl.bufferSubData(r,n,t),this.gl.bindBuffer(r,null),this.bytesUsed=s,this.byteLength=s,this._setDebugData(t,n,s),this.props.handle?this.trackReferencedMemory(s,"Buffer"):this.trackAllocatedMemory(s)}_initWithByteLength(t){let n=t;t===0&&(n=new Float32Array(0));const s=this.glTarget;return this.gl.bindBuffer(s,this.handle),this.gl.bufferData(s,n,this.glUsage),this.gl.bindBuffer(s,null),this.bytesUsed=t,this.byteLength=t,this._setDebugData(null,0,t),this.props.handle?this.trackReferencedMemory(t,"Buffer"):this.trackAllocatedMemory(t),this}write(t,n=0){const s=ArrayBuffer.isView(t)?t:new Uint8Array(t),r=36663;this.gl.bindBuffer(r,this.handle),this.gl.bufferSubData(r,n,s),this.gl.bindBuffer(r,null),this._setDebugData(t,n,t.byteLength)}async mapAndWriteAsync(t,n=0,s=this.byteLength-n){const r=new ArrayBuffer(s);await t(r,"copied"),this.write(r,n)}async readAsync(t=0,n){return this.readSyncWebGL(t,n)}async mapAndReadAsync(t,n=0,s){const r=await this.readAsync(n,s);return await t(r.buffer,"copied")}readSyncWebGL(t=0,n){n=n??this.byteLength-t;const s=new Uint8Array(n),r=0;return this.gl.bindBuffer(36662,this.handle),this.gl.getBufferSubData(36662,t,s,r,n),this.gl.bindBuffer(36662,null),this._setDebugData(s,t,n),s}}function iL(i){return i&W.INDEX?34963:i&W.VERTEX?34962:i&W.UNIFORM?35345:34962}function nL(i){return i&W.INDEX||i&W.VERTEX?35044:i&W.UNIFORM?35048:35044}function sL(i){var n;const e=i.split(/\r?\n/),t=[];for(const s of e){if(s.length<=1)continue;const r=s.trim(),o=s.split(":"),a=(n=o[0])==null?void 0:n.trim();if(o.length===2){const[p,m]=o;if(!p||!m){t.push({message:r,type:os(a||"info"),lineNum:0,linePos:0});continue}t.push({message:m.trim(),type:os(p),lineNum:0,linePos:0});continue}const[c,l,u,...f]=o;if(!c||!l||!u){t.push({message:o.slice(1).join(":").trim()||r,type:os(a||"info"),lineNum:0,linePos:0});continue}let d=parseInt(u,10);Number.isNaN(d)&&(d=0);let g=parseInt(l,10);Number.isNaN(g)&&(g=0),t.push({message:f.join(":").trim(),type:os(c),lineNum:d,linePos:g})}return t}function os(i){const e=["warning","error","info"],t=i.toLowerCase();return e.includes(t)?t:"info"}class rL extends Hs{constructor(t,n){super(t,n);h(this,"device");h(this,"handle");h(this,"_compilationInfoLog","");this.device=t;const s=this.props.handle;switch(this.props.stage){case"vertex":this.handle=s||this.device.gl.createShader(35633);break;case"fragment":this.handle=s||this.device.gl.createShader(35632);break;default:throw new Error(this.props.stage)}t._setWebGLDebugMetadata(this.handle,this,{spector:this.props});const r=this._compile(this.source);r&&typeof r.catch=="function"&&r.catch(()=>{this.compilationStatus="error"})}destroy(){this.handle&&(this.removeStats(),this.device.gl.deleteShader(this.handle),this.destroyed=!0,this.handle.destroyed=!0)}get asyncCompilationStatus(){return this._waitForCompilationComplete().then(()=>(this._getCompilationStatus(),this.compilationStatus))}async getCompilationInfo(){return await this._waitForCompilationComplete(),this.getCompilationInfoSync()}getCompilationInfoSync(){const t=this._getCompilationInfoLog();return t?sL(t):[]}getTranslatedSource(){const n=this.device.getExtension("WEBGL_debug_shaders").WEBGL_debug_shaders;return(n==null?void 0:n.getTranslatedShaderSource(this.handle))||null}_compile(t){t=t.startsWith("#version ")?t:`#version 300 es
${t}`;const{gl:n}=this.device;if(n.shaderSource(this.handle,t),n.compileShader(this.handle),!this.device.props.debug){this.compilationStatus="pending";return}if(!this.device.features.has("compilation-status-async-webgl")){if(this._getCompilationStatus(),this.debugShader(),this.compilationStatus==="error")throw new Error(this._getCompilationErrorMessage(t));return}return M.once(1,"Shader compilation is asynchronous")(),this._waitForCompilationComplete().then(()=>{M.info(2,`Shader ${this.id} - async compilation complete: ${this.compilationStatus}`)(),this._getCompilationStatus(),this.debugShader()})}async _waitForCompilationComplete(){const t=async r=>await new Promise(o=>setTimeout(o,r));if(!this.device.features.has("compilation-status-async-webgl")){await t(10);return}const{gl:s}=this.device;for(;;){if(s.getShaderParameter(this.handle,37297))return;await t(10)}}_getCompilationStatus(){this.compilationStatus=this.device.gl.getShaderParameter(this.handle,35713)?"success":"error",this.compilationStatus==="error"&&this._getCompilationInfoLog()}_getCompilationErrorMessage(t){var f;const n=`${this.props.stage} shader ${this.props.id}`,s=oL(this._getCompilationInfoLog()),r=this.getCompilationInfoSync(),o=r.find(d=>d.type==="error"&&d.message.trim())||r.find(d=>d.message.trim())||r.find(d=>d.type==="error")||r[0];if(!o)return s?`GLSL compilation errors in ${n}: ${s}`:`GLSL compilation errors in ${n}: WebGL did not provide a shader compiler log`;const a=o.lineNum?(f=t.split(/\r?\n/)[o.lineNum-1])==null?void 0:f.trim():void 0,c=o.lineNum?` line ${o.lineNum}`:"",l=a?`
Source: ${a}`:"",u=o.message.trim()||s||"WebGL did not provide a shader compiler log";return`GLSL compilation errors in ${n}:${c}: ${u}${l}`}_getCompilationInfoLog(){var n;const t=(n=this.device.gl.getShaderInfoLog(this.handle))==null?void 0:n.trim();return t&&(this._compilationInfoLog=t),this._compilationInfoLog}}function oL(i){var e;return(e=i.split(/\r?\n/).find(t=>t.trim()))==null?void 0:e.trim()}function aL(i,e,t,n){if(fL(e))return n(i);const s=i;s.pushState();try{return cL(i,e),Mi(s.gl,t),n(i)}finally{s.popState()}}function cL(i,e){const t=i,{gl:n}=t;if(e.cullMode)switch(e.cullMode){case"none":n.disable(2884);break;case"front":n.enable(2884),n.cullFace(1028);break;case"back":n.enable(2884),n.cullFace(1029);break}if(e.frontFace&&n.frontFace(kt("frontFace",e.frontFace,{ccw:2305,cw:2304})),e.unclippedDepth&&i.features.has("depth-clip-control")&&n.enable(34383),e.depthBias!==void 0&&(n.enable(32823),n.polygonOffset(e.depthBias,e.depthBiasSlopeScale||0)),e.provokingVertex&&i.features.has("provoking-vertex-webgl")){const r=t.getExtension("WEBGL_provoking_vertex").WEBGL_provoking_vertex,o=kt("provokingVertex",e.provokingVertex,{first:36429,last:36430});r==null||r.provokingVertexWEBGL(o)}if((e.polygonMode||e.polygonOffsetLine)&&i.features.has("polygon-mode-webgl")){if(e.polygonMode){const r=t.getExtension("WEBGL_polygon_mode").WEBGL_polygon_mode,o=kt("polygonMode",e.polygonMode,{fill:6914,line:6913});r==null||r.polygonModeWEBGL(1028,o),r==null||r.polygonModeWEBGL(1029,o)}e.polygonOffsetLine&&n.enable(10754)}if(i.features.has("shader-clip-cull-distance-webgl")&&(e.clipDistance0&&n.enable(12288),e.clipDistance1&&n.enable(12289),e.clipDistance2&&n.enable(12290),e.clipDistance3&&n.enable(12291),e.clipDistance4&&n.enable(12292),e.clipDistance5&&n.enable(12293),e.clipDistance6&&n.enable(12294),e.clipDistance7&&n.enable(12295)),e.depthWriteEnabled!==void 0&&n.depthMask(uL("depthWriteEnabled",e.depthWriteEnabled)),e.depthCompare&&(e.depthCompare!=="always"?n.enable(2929):n.disable(2929),n.depthFunc(sc("depthCompare",e.depthCompare))),e.clearDepth!==void 0&&n.clearDepth(e.clearDepth),e.stencilWriteMask){const s=e.stencilWriteMask;n.stencilMaskSeparate(1028,s),n.stencilMaskSeparate(1029,s)}if(e.stencilReadMask&&M.warn("stencilReadMask not supported under WebGL"),e.stencilCompare){const s=e.stencilReadMask||4294967295,r=sc("depthCompare",e.stencilCompare);e.stencilCompare!=="always"?n.enable(2960):n.disable(2960),n.stencilFuncSeparate(1028,r,0,s),n.stencilFuncSeparate(1029,r,0,s)}if(e.stencilPassOperation&&e.stencilFailOperation&&e.stencilDepthFailOperation){const s=jo("stencilPassOperation",e.stencilPassOperation),r=jo("stencilFailOperation",e.stencilFailOperation),o=jo("stencilDepthFailOperation",e.stencilDepthFailOperation);n.stencilOpSeparate(1028,r,o,s),n.stencilOpSeparate(1029,r,o,s)}switch(e.blend){case!0:n.enable(3042);break;case!1:n.disable(3042);break}if(e.blendColorOperation||e.blendAlphaOperation){const s=If("blendColorOperation",e.blendColorOperation||"add"),r=If("blendAlphaOperation",e.blendAlphaOperation||"add");n.blendEquationSeparate(s,r);const o=as("blendColorSrcFactor",e.blendColorSrcFactor||"one"),a=as("blendColorDstFactor",e.blendColorDstFactor||"zero"),c=as("blendAlphaSrcFactor",e.blendAlphaSrcFactor||"one"),l=as("blendAlphaDstFactor",e.blendAlphaDstFactor||"zero");n.blendFuncSeparate(o,a,c,l)}}function sc(i,e){return kt(i,e,{never:512,less:513,equal:514,"less-equal":515,greater:516,"not-equal":517,"greater-equal":518,always:519})}function jo(i,e){return kt(i,e,{keep:7680,zero:0,replace:7681,invert:5386,"increment-clamp":7682,"decrement-clamp":7683,"increment-wrap":34055,"decrement-wrap":34056})}function If(i,e){return kt(i,e,{add:32774,subtract:32778,"reverse-subtract":32779,min:32775,max:32776})}function as(i,e,t="color"){return kt(i,e,{one:1,zero:0,src:768,"one-minus-src":769,dst:774,"one-minus-dst":775,"src-alpha":770,"one-minus-src-alpha":771,"dst-alpha":772,"one-minus-dst-alpha":773,"src-alpha-saturated":776,constant:t==="color"?32769:32771,"one-minus-constant":t==="color"?32770:32772,src1:768,"one-minus-src1":769,"src1-alpha":770,"one-minus-src1-alpha":771})}function lL(i,e){return`Illegal parameter ${e} for ${i}`}function kt(i,e,t){if(!(e in t))throw new Error(lL(i,e));return t[e]}function uL(i,e){return e}function fL(i){let e=!0;for(const t in i){e=!1;break}return e}function Jg(i){const e={};return i.addressModeU&&(e[10242]=Vo(i.addressModeU)),i.addressModeV&&(e[10243]=Vo(i.addressModeV)),i.addressModeW&&(e[32882]=Vo(i.addressModeW)),i.magFilter&&(e[10240]=rc(i.magFilter)),(i.minFilter||i.mipmapFilter)&&(e[10241]=dL(i.minFilter||"linear",i.mipmapFilter)),i.lodMinClamp!==void 0&&(e[33082]=i.lodMinClamp),i.lodMaxClamp!==void 0&&(e[33083]=i.lodMaxClamp),i.type==="comparison-sampler"&&(e[34892]=34894),i.compare&&(e[34893]=sc("compare",i.compare)),i.maxAnisotropy&&(e[34046]=i.maxAnisotropy),e}function Vo(i){switch(i){case"clamp-to-edge":return 33071;case"repeat":return 10497;case"mirror-repeat":return 33648}}function rc(i){switch(i){case"nearest":return 9728;case"linear":return 9729}}function dL(i,e="none"){if(!e)return rc(i);switch(e){case"none":return rc(i);case"nearest":switch(i){case"nearest":return 9984;case"linear":return 9985}break;case"linear":switch(i){case"nearest":return 9986;case"linear":return 9987}}}class hL extends Vs{constructor(t,n){super(t,n);h(this,"device");h(this,"handle");h(this,"parameters");this.device=t,this.parameters=Jg(n),this.handle=n.handle||this.device.gl.createSampler(),this._setSamplerParameters(this.parameters)}destroy(){this.handle&&(this.device.gl.deleteSampler(this.handle),this.handle=void 0)}toString(){return`Sampler(${this.id},${JSON.stringify(this.props)})`}_setSamplerParameters(t){for(const[n,s]of Object.entries(t)){const r=Number(n);switch(r){case 33082:case 33083:this.device.gl.samplerParameterf(this.handle,r,s);break;default:this.device.gl.samplerParameteri(this.handle,r,s);break}}}}function dt(i,e,t){if(gL(e))return t(i);const{nocatch:n=!0}=e,s=Bt.get(i);s.push(),Mi(i,e);let r;if(n)r=t(i),s.pop();else try{r=t(i)}finally{s.pop()}return r}function gL(i){for(const e in i)return!1;return!0}class ri extends Ws{constructor(t,n){super(t,{...he.defaultProps,...n});h(this,"device");h(this,"gl");h(this,"handle");h(this,"texture");this.device=t,this.gl=this.device.gl,this.handle=null,this.texture=n.texture}}function ep(i){return pL[i]}const pL={5124:"sint32",5125:"uint32",5122:"sint16",5123:"uint16",5120:"sint8",5121:"uint8",5126:"float32",5131:"float16",33635:"uint16",32819:"uint16",32820:"uint16",33640:"uint32",35899:"uint32",35902:"uint32",34042:"uint32",36269:"uint32"};class on extends he{constructor(t,n){super(t,n,{byteAlignment:1});h(this,"device");h(this,"gl");h(this,"handle");h(this,"sampler");h(this,"view");h(this,"glTarget");h(this,"glFormat");h(this,"glType");h(this,"glInternalFormat");h(this,"compressed");h(this,"_textureUnit",0);h(this,"_framebuffer",null);h(this,"_framebufferAttachmentKey",null);this.device=t,this.gl=this.device.gl;const s=Qg(this.props.format);if(this.glTarget=yL(this.props.dimension),this.glInternalFormat=s.internalFormat,this.glFormat=s.format,this.glType=s.type,this.compressed=s.compressed,this.isHandleBorrowed&&this.props.handle===void 0)throw new Error("Borrowed WebGL textures require a texture handle");if(this.handle=this.props.handle||this.gl.createTexture(),this.device._setWebGLDebugMetadata(this.handle,this,{spector:this.props}),!this.isHandleBorrowed){this.gl.bindTexture(this.glTarget,this.handle);const{dimension:r,width:o,height:a,depth:c,mipLevels:l,glTarget:u,glInternalFormat:f}=this;if(!this.compressed)switch(r){case"2d":case"cube":this.gl.texStorage2D(u,l,f,o,a);break;case"2d-array":case"3d":this.gl.texStorage3D(u,l,f,o,a,c);break;default:throw new Error(r)}this.gl.bindTexture(this.glTarget,null),this._initializeData(n.data)}this.ownsHandle?this.trackAllocatedMemory(this.getAllocatedByteLength(),"Texture"):this.trackReferencedMemory(this.getAllocatedByteLength(),"Texture"),this.isHandleBorrowed||this.setSampler(this.props.sampler),this.view=new ri(this.device,{...this.props,texture:this}),Object.seal(this)}destroy(){var t;this.handle&&((t=this._framebuffer)==null||t.destroy(),this._framebuffer=null,this._framebufferAttachmentKey=null,this.removeStats(),this.ownsHandle?(this.gl.deleteTexture(this.handle),this.trackDeallocatedMemory("Texture")):this.trackDeallocatedReferencedMemory("Texture"),this.destroyed=!0)}createView(t){return new ri(this.device,{...t,texture:this})}clone(t){if(this.isHandleBorrowed&&t&&(t.width!==this.width||t.height!==this.height))throw new Error(`Cannot resize borrowed read-only ${this}`);return super.clone(t)}setSampler(t={}){this._assertWritable("set sampler parameters on"),super.setSampler(t);const n=Jg(this.sampler.props);this._setSamplerParameters(n)}copyExternalImage(t){this._assertWritable("copy external image data into");const n=this._normalizeCopyExternalImageOptions(t);if(n.sourceX||n.sourceY)throw new Error("WebGL does not support sourceX/sourceY)");const{glFormat:s,glType:r}=this,{image:o,depth:a,mipLevel:c,x:l,y:u,z:f,width:d,height:g}=n,p=zi(this.glTarget,this.dimension,f),m=n.flipY?{37440:!0}:{};return this.gl.bindTexture(this.glTarget,this.handle),dt(this.gl,m,()=>{switch(this.dimension){case"2d":case"cube":this.gl.texSubImage2D(p,c,l,u,d,g,s,r,o);break;case"2d-array":case"3d":this.gl.texSubImage3D(p,c,l,u,f,d,g,a,s,r,o);break;default:}}),this.gl.bindTexture(this.glTarget,null),{width:n.width,height:n.height}}copyElementImage(t){this._assertWritable("copy element image data into");const n=this._normalizeCopyElementImageOptions(t),{glFormat:s}=this,{element:r,depth:o,mipLevel:a,sourceX:c,sourceY:l,sourceWidth:u,sourceHeight:f,x:d,y:g,z:p,width:m,height:_}=n,v=zi(this.glTarget,this.dimension,p),w=n.flipY?{37440:!0}:{},y=this.gl;if(o!==1||this.dimension!=="2d"&&this.dimension!=="cube")throw new Error(`${this} copyElementImage only supports 2d and cube textures on WebGL`);if(a!==0||d!==0||g!==0)throw new Error(`${this} copyElementImage only supports full base-level uploads on WebGL`);if(typeof y.texElementImage2D!="function")throw new Error(`${this} copyElementImage is not supported by this WebGL implementation`);return this.gl.bindTexture(this.glTarget,this.handle),dt(this.gl,w,()=>{var x;(x=y.texElementImage2D)==null||x.call(y,v,s,r,{sx:c,sy:l,swidth:u??m,sheight:f??_,width:m,height:_})}),this.gl.bindTexture(this.glTarget,null),{width:n.width,height:n.height}}copyImageData(t){super.copyImageData(t)}readBuffer(t={},n){if(!n)throw new Error(`${this} readBuffer requires a destination buffer`);const s=this._getSupportedColorReadOptions(t),r=t.byteOffset??0,o=this.computeMemoryLayout(s);if(n.byteLength<r+o.byteLength)throw new Error(`${this} readBuffer target is too small (${n.byteLength} < ${r+o.byteLength})`);const a=n;this.gl.bindBuffer(35051,a.handle);try{this._readColorTextureLayers(s,o,c=>{this.gl.readPixels(s.x,s.y,s.width,s.height,this.glFormat,this.glType,r+c)})}finally{this.gl.bindBuffer(35051,null)}return n}async readDataAsync(t={}){throw new Error(`${this} readDataAsync is deprecated; use readBuffer() with an explicit destination buffer or DynamicTexture.readAsync()`)}writeBuffer(t,n={}){this._assertWritable("write buffer data into");const s=this._normalizeTextureWriteOptions(n),{width:r,height:o,depthOrArrayLayers:a,mipLevel:c,byteOffset:l,x:u,y:f,z:d}=s,{glFormat:g,glType:p,compressed:m}=this,_=zi(this.glTarget,this.dimension,d);if(m)throw new Error("writeBuffer for compressed textures is not implemented in WebGL");const{bytesPerPixel:v}=this.device.getTextureFormatInfo(this.format),w=v?s.bytesPerRow/v:void 0,y={3317:this.byteAlignment,...w!==void 0?{3314:w}:{},32878:s.rowsPerImage};this.gl.bindTexture(this.glTarget,this.handle),this.gl.bindBuffer(35052,t.handle),dt(this.gl,y,()=>{switch(this.dimension){case"2d":case"cube":this.gl.texSubImage2D(_,c,u,f,r,o,g,p,l);break;case"2d-array":case"3d":this.gl.texSubImage3D(_,c,u,f,d,r,o,a,g,p,l);break;default:}}),this.gl.bindBuffer(35052,null),this.gl.bindTexture(this.glTarget,null)}writeData(t,n={}){this._assertWritable("write data into");const s=this._normalizeTextureWriteOptions(n),r=ArrayBuffer.isView(t)?t:new Uint8Array(t),{width:o,height:a,depthOrArrayLayers:c,mipLevel:l,x:u,y:f,z:d,byteOffset:g}=s,{glFormat:p,glType:m,compressed:_}=this,v=zi(this.glTarget,this.dimension,d);let w;if(!_){const{bytesPerPixel:B}=this.device.getTextureFormatInfo(this.format);B&&(w=s.bytesPerRow/B)}const y=this.compressed?{}:{3317:this.byteAlignment,...w!==void 0?{3314:w}:{},32878:s.rowsPerImage},x=_L(r,g),S=_?mL(r,g):r,C=this._getMipLevelSize(l),O=u===0&&f===0&&d===0&&o===C.width&&a===C.height&&c===C.depthOrArrayLayers;this.gl.bindTexture(this.glTarget,this.handle),this.gl.bindBuffer(35052,null),dt(this.gl,y,()=>{switch(this.dimension){case"2d":case"cube":_?O?this.gl.compressedTexImage2D(v,l,p,o,a,0,S):this.gl.compressedTexSubImage2D(v,l,u,f,o,a,p,S):this.gl.texSubImage2D(v,l,u,f,o,a,p,m,r,x);break;case"2d-array":case"3d":_?O?this.gl.compressedTexImage3D(v,l,p,o,a,c,0,S):this.gl.compressedTexSubImage3D(v,l,u,f,d,o,a,c,p,S):this.gl.texSubImage3D(v,l,u,f,d,o,a,c,p,m,r,x);break;default:}}),this.gl.bindTexture(this.glTarget,null)}_getRowByteAlignment(t,n){return 1}_getFramebuffer(){return this._framebuffer||(this._framebuffer=this.device.createFramebuffer({id:`framebuffer-for-${this.id}`,width:this.width,height:this.height,colorAttachments:[this]})),this._framebuffer}readDataSyncWebGL(t={}){const n=this._getSupportedColorReadOptions(t),s=this.computeMemoryLayout(n),r=ep(this.glType),o=Ic(r),a=new o(s.byteLength/o.BYTES_PER_ELEMENT);return this._readColorTextureLayers(n,s,c=>{const l=new o(a.buffer,a.byteOffset+c,s.bytesPerImage/o.BYTES_PER_ELEMENT);this.gl.readPixels(n.x,n.y,n.width,n.height,this.glFormat,this.glType,l)}),a.buffer}_readColorTextureLayers(t,n,s){const r=this._getFramebuffer(),o=n.bytesPerRow/n.bytesPerPixel,a={3333:this.byteAlignment,...o!==t.width?{3330:o}:{}},c=this.gl.getParameter(3074),l=this.gl.bindFramebuffer(36160,r.handle);try{this.gl.readBuffer(36064),dt(this.gl,a,()=>{for(let u=0;u<t.depthOrArrayLayers;u++)this._attachReadSubresource(r,t.mipLevel,t.z+u),s(u*n.bytesPerImage)})}finally{this.gl.bindFramebuffer(36160,l||null),this.gl.readBuffer(c)}}_attachReadSubresource(t,n,s){const r=`${n}:${s}`;if(this._framebufferAttachmentKey!==r){switch(this.dimension){case"2d":this.gl.framebufferTexture2D(36160,36064,3553,this.handle,n);break;case"cube":this.gl.framebufferTexture2D(36160,36064,zi(this.glTarget,this.dimension,s),this.handle,n);break;case"2d-array":case"3d":this.gl.framebufferTextureLayer(36160,36064,this.handle,n,s);break;default:throw new Error(`${this} color readback does not support ${this.dimension} textures`)}if(this.device.props.debug){const o=Number(this.gl.checkFramebufferStatus(36160));if(o!==36053)throw new Error(`${t} incomplete for ${this} readback (${o})`)}this._framebufferAttachmentKey=r}}generateMipmapsWebGL(t){if(this._assertWritable("generate mipmaps for"),!(!(this.device.isTextureFormatRenderable(this.props.format)&&this.device.isTextureFormatFilterable(this.props.format))&&(M.warn(`${this} is not renderable or filterable, may not be able to generate mipmaps`)(),!(t!=null&&t.force))))try{this.gl.bindTexture(this.glTarget,this.handle),this.gl.generateMipmap(this.glTarget)}catch(s){M.warn(`Error generating mipmap for ${this}: ${s.message}`)()}finally{this.gl.bindTexture(this.glTarget,null)}}_setSamplerParameters(t){M.level>=2&&M.log(2,`${this.id} sampler parameters`,this.device.getGLKeys(t))(),this.gl.bindTexture(this.glTarget,this.handle);for(const[n,s]of Object.entries(t)){const r=Number(n),o=s;switch(r){case 33082:case 33083:this.gl.texParameterf(this.glTarget,r,o);break;case 10240:case 10241:this.gl.texParameteri(this.glTarget,r,o);break;case 10242:case 10243:case 32882:this.gl.texParameteri(this.glTarget,r,o);break;case 34046:this.device.features.has("texture-filterable-anisotropic-webgl")&&this.gl.texParameteri(this.glTarget,r,o);break;case 34892:case 34893:this.gl.texParameteri(this.glTarget,r,o);break}}this.gl.bindTexture(this.glTarget,null)}_getActiveUnit(){return this.gl.getParameter(34016)-33984}_bind(t){const{gl:n}=this;return t!==void 0&&(this._textureUnit=t,n.activeTexture(33984+t)),n.bindTexture(this.glTarget,this.handle),t}_unbind(t){const{gl:n}=this;return t!==void 0&&(this._textureUnit=t,n.activeTexture(33984+t)),n.bindTexture(this.glTarget,null),t}_assertWritable(t){if(this.isHandleBorrowed)throw new Error(`Cannot ${t} borrowed read-only ${this}`)}}function mL(i,e=0){return e?new i.constructor(i.buffer,i.byteOffset+e,(i.byteLength-e)/i.BYTES_PER_ELEMENT):i}function _L(i,e){if(e%i.BYTES_PER_ELEMENT!==0)throw new Error(`Texture byteOffset ${e} must align to typed array element size ${i.BYTES_PER_ELEMENT}`);return e/i.BYTES_PER_ELEMENT}function yL(i){switch(i){case"1d":break;case"2d":return 3553;case"3d":return 32879;case"cube":return 34067;case"2d-array":return 35866}throw new Error(i)}function zi(i,e,t){return e==="cube"?34069+t:i}function bL(i,e,t,n){const s=i;let r=n;r===!0&&(r=1),r===!1&&(r=0);const o=typeof r=="number"?[r]:r;switch(t){case 35678:case 35680:case 35679:case 35682:case 36289:case 36292:case 36293:case 36298:case 36299:case 36300:case 36303:case 36306:case 36307:case 36308:case 36311:if(typeof n!="number")throw new Error("samplers must be set to integers");return i.uniform1i(e,n);case 5126:return i.uniform1fv(e,o);case 35664:return i.uniform2fv(e,o);case 35665:return i.uniform3fv(e,o);case 35666:return i.uniform4fv(e,o);case 5124:return i.uniform1iv(e,o);case 35667:return i.uniform2iv(e,o);case 35668:return i.uniform3iv(e,o);case 35669:return i.uniform4iv(e,o);case 35670:return i.uniform1iv(e,o);case 35671:return i.uniform2iv(e,o);case 35672:return i.uniform3iv(e,o);case 35673:return i.uniform4iv(e,o);case 5125:return s.uniform1uiv(e,o,1);case 36294:return s.uniform2uiv(e,o,2);case 36295:return s.uniform3uiv(e,o,3);case 36296:return s.uniform4uiv(e,o,4);case 35674:return i.uniformMatrix2fv(e,!1,o);case 35675:return i.uniformMatrix3fv(e,!1,o);case 35676:return i.uniformMatrix4fv(e,!1,o);case 35685:return s.uniformMatrix2x3fv(e,!1,o);case 35686:return s.uniformMatrix2x4fv(e,!1,o);case 35687:return s.uniformMatrix3x2fv(e,!1,o);case 35688:return s.uniformMatrix3x4fv(e,!1,o);case 35689:return s.uniformMatrix4x2fv(e,!1,o);case 35690:return s.uniformMatrix4x3fv(e,!1,o)}throw new Error("Illegal uniform")}function vL(i){return PL[i]}function gl(i){return xL[i]}function tp(i){return!!ip[i]}function wL(i){return ip[i]}const xL={5126:"f32",35664:"vec2<f32>",35665:"vec3<f32>",35666:"vec4<f32>",5124:"i32",35667:"vec2<i32>",35668:"vec3<i32>",35669:"vec4<i32>",5125:"u32",36294:"vec2<u32>",36295:"vec3<u32>",36296:"vec4<u32>",35670:"f32",35671:"vec2<f32>",35672:"vec3<f32>",35673:"vec4<f32>",35674:"mat2x2<f32>",35685:"mat2x3<f32>",35686:"mat2x4<f32>",35687:"mat3x2<f32>",35675:"mat3x3<f32>",35688:"mat3x4<f32>",35689:"mat4x2<f32>",35690:"mat4x3<f32>",35676:"mat4x4<f32>"},ip={35678:{viewDimension:"2d",sampleType:"float"},35680:{viewDimension:"cube",sampleType:"float"},35679:{viewDimension:"3d",sampleType:"float"},35682:{viewDimension:"3d",sampleType:"depth"},36289:{viewDimension:"2d-array",sampleType:"float"},36292:{viewDimension:"2d-array",sampleType:"depth"},36293:{viewDimension:"cube",sampleType:"float"},36298:{viewDimension:"2d",sampleType:"sint"},36299:{viewDimension:"3d",sampleType:"sint"},36300:{viewDimension:"cube",sampleType:"sint"},36303:{viewDimension:"2d-array",sampleType:"uint"},36306:{viewDimension:"2d",sampleType:"uint"},36307:{viewDimension:"3d",sampleType:"uint"},36308:{viewDimension:"cube",sampleType:"uint"},36311:{viewDimension:"2d-array",sampleType:"uint"}},PL={uint8:5121,sint8:5120,unorm8:5121,snorm8:5120,uint16:5123,sint16:5122,unorm16:5123,snorm16:5122,uint32:5125,sint32:5124,float16:5131,float32:5126};function SL(i,e,t={}){const n={attributes:[],bindings:[]};n.attributes=EL(i,e);const s=TL(i,e,t);for(const c of s){const l=c.uniforms.map(u=>({name:u.name,format:u.format,byteOffset:u.byteOffset,byteStride:u.byteStride,arrayLength:u.arrayLength}));n.bindings.push({type:"uniform",name:c.name,group:0,location:c.location,visibility:(c.vertex?1:0)|(c.fragment?2:0),minBindingSize:c.byteLength,uniforms:l})}const r=LL(i,e);let o=0;for(const c of r)if(tp(c.type)){const{viewDimension:l,sampleType:u}=wL(c.type);n.bindings.push({type:"texture",name:c.name,group:0,location:o,viewDimension:l,sampleType:u}),c.textureUnit=o,o+=1}r.length&&(n.uniforms=r);const a=CL(i,e);return a!=null&&a.length&&(n.varyings=a),n}function EL(i,e){const t=[],n=i.getProgramParameter(e,35721);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s);if(!r)throw new Error("activeInfo");const{name:o,type:a}=r,c=i.getAttribLocation(e,o);if(c>=0){const l=gl(a),u=/instance/i.test(o)?"instance":"vertex";t.push({name:o,location:c,stepMode:u,type:l})}}return t.sort((s,r)=>s.location-r.location),t}function CL(i,e){const t=[],n=i.getProgramParameter(e,35971);for(let s=0;s<n;s++){const r=i.getTransformFeedbackVarying(e,s);if(!r)throw new Error("activeInfo");const{name:o,type:a,size:c}=r,l=gl(a),{type:u,components:f}=Fc(l);t.push({location:s,name:o,type:u,size:c*f})}return t.sort((s,r)=>s.location-r.location),t}function LL(i,e){const t=[],n=i.getProgramParameter(e,35718);for(let s=0;s<n;s++){const r=i.getActiveUniform(e,s);if(!r)throw new Error("activeInfo");const{name:o,size:a,type:c}=r,{name:l,isArray:u}=kL(o);let f=i.getUniformLocation(e,l);const d={location:f,name:l,size:a,type:c,isArray:u};if(t.push(d),d.size>1)for(let g=0;g<d.size;g++){const p=`${l}[${g}]`;f=i.getUniformLocation(e,p);const m={...d,name:p,location:f};t.push(m)}}return t}function TL(i,e,t){const n=[],s=ML(i,e,t);for(const[o,a]of s){n.push(a);try{const c=Rf(i,e,o,a.name);AL(c,a)}catch(c){const l=c instanceof Error?c.message:String(c);M.once(0,`WebGL uniform block reflection failed for "${a.name}"; using supplied std140 metadata. ${l}`)()}}const r=i.getProgramParameter(e,35382);if(!Number.isInteger(r)||r<0)throw new Error(`Failed to reflect WebGL uniform blocks: ACTIVE_UNIFORM_BLOCKS returned ${String(r)}`);for(let o=0;o<r;o++)s.has(o)||n.push(Rf(i,e,o));return n.sort((o,a)=>o.location-a.location),n}function AL(i,e){for(const t of i.uniforms){const n=e.uniforms.find(s=>t.name===s.name||t.name.endsWith(`.${s.name}`));if(!n)throw new Error(`Failed to validate WebGL uniform block "${e.name}": reflected unexpected member "${t.name}"`);if(t.format!==n.format||t.arrayLength!==n.arrayLength||t.byteOffset!==n.byteOffset||t.byteStride!==n.byteStride)throw new Error(`Failed to validate WebGL uniform block "${e.name}": reflected layout for "${t.name}" does not match supplied std140 metadata`)}}function ML(i,e,t){var r;const n=new Map;for(const o of t.uniformBlockLayouts||[])n.set(o.name,RL(o));for(const o of((r=t.shaderLayout)==null?void 0:r.bindings)||[])BL(o)&&n.set(o.name,o);const s=new Map;for(const o of n.values()){const a=IL(i,e,o.name);if(!a)continue;const{blockIndex:c,blockName:l}=a;if(s.has(c))throw new Error(`Multiple supplied uniform block layouts resolve to active WebGL block "${l}"`);s.set(c,{name:l,location:c,byteLength:o.minBindingSize,vertex:!!(o.visibility&&o.visibility&1),fragment:!!(o.visibility&&o.visibility&2),uniformCount:o.uniforms.length,uniforms:o.uniforms.map(u=>({...u}))})}return s}function IL(i,e,t){const n=t.endsWith("Uniforms")?[t,t.slice(0,-8)]:[t,`${t}Uniforms`];for(const s of n){const r=i.getUniformBlockIndex(e,s);if(r!==4294967295){if(!Number.isInteger(r)||r<0)throw new Error(`Failed to resolve WebGL uniform block "${s}": getUniformBlockIndex returned ${String(r)}`);return{blockIndex:r,blockName:s}}}return null}function Rf(i,e,t,n){const s=n||i.getActiveUniformBlockName(e,t);if(!s)throw new Error(`Failed to reflect WebGL uniform block at index ${t}: missing block name`);const r=(y,x)=>{const S=i.getActiveUniformBlockParameter(e,t,y);if(S==null)throw new Error(`Failed to reflect WebGL uniform block "${s}": ${x} returned null`);return S},o=Ct(r(35391,"UNIFORM_BLOCK_BINDING"),s,"UNIFORM_BLOCK_BINDING",0),a=Ct(r(35392,"UNIFORM_BLOCK_DATA_SIZE"),s,"UNIFORM_BLOCK_DATA_SIZE",0),c=Ct(r(35394,"UNIFORM_BLOCK_ACTIVE_UNIFORMS"),s,"UNIFORM_BLOCK_ACTIVE_UNIFORMS",0),l=np(r(35395,"UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES"),s,"UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES",c),u=Ni(i,e,l,35383,"UNIFORM_TYPE",s,c),f=Ni(i,e,l,35384,"UNIFORM_SIZE",s,c),d=Ni(i,e,l,35386,"UNIFORM_BLOCK_INDEX",s,c),g=Ni(i,e,l,35387,"UNIFORM_OFFSET",s,c),p=Ni(i,e,l,35388,"UNIFORM_ARRAY_STRIDE",s,c),m=[];for(let y=0;y<c;y++){if(d[y]!==t)throw new Error(`Failed to reflect WebGL uniform block "${s}": active uniform index ${l[y]} belongs to block ${d[y]}, expected ${t}`);const x=l[y],S=i.getActiveUniform(e,x);if(!S)throw new Error(`Failed to reflect WebGL uniform block "${s}": getActiveUniform(${x}) returned null`);const C=Ct(u[y],s,`UNIFORM_TYPE[${y}]`,1),O=Ct(f[y],s,`UNIFORM_SIZE[${y}]`,1),B=Ct(g[y],s,`UNIFORM_OFFSET[${y}]`,0),D=Ct(p[y],s,`UNIFORM_ARRAY_STRIDE[${y}]`,0);if(S.type!==C||S.size!==O)throw new Error(`Failed to reflect WebGL uniform block "${s}": getActiveUniform(${x}) disagrees with getActiveUniforms`);m.push({name:S.name,format:gl(C),arrayLength:O,byteOffset:B,byteStride:D})}const _={name:s,location:o,byteLength:a,vertex:!!r(35396,"UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER"),fragment:!!r(35398,"UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER"),uniformCount:c,uniforms:m},v=new Set(_.uniforms.map(y=>y.name.split(".")[0]).filter(y=>!!y)),w=_.name.replace(/Uniforms$/,"");if(v.size===1&&!v.has(_.name)&&!v.has(w)){const[y]=v;M.warn(`Uniform block "${_.name}" uses GLSL instance "${y}". luma.gl binds uniform buffers by block name ("${_.name}") and alias ("${w}"). Prefer matching the instance name to one of those to avoid confusing silent mismatches.`)()}return _}function Ni(i,e,t,n,s,r,o){const a=i.getActiveUniforms(e,t,n);if(a===null)throw new Error(`Failed to reflect WebGL uniform block "${r}": ${s} returned null`);return np(a,r,s,o)}function np(i,e,t,n){if(!Array.isArray(i)&&!ArrayBuffer.isView(i))throw new Error(`Failed to reflect WebGL uniform block "${e}": ${t} returned a non-array value`);const s=Array.from(i);if(s.length!==n||s.some(r=>!Number.isInteger(r)))throw new Error(`Failed to reflect WebGL uniform block "${e}": ${t} returned ${s.length} invalid values, expected ${n}`);return s}function Ct(i,e,t,n){if(!Number.isInteger(i)||i<n)throw new Error(`Failed to reflect WebGL uniform block "${e}": ${t} returned ${String(i)}`);return i}function RL(i){const e=Nc(i.uniformTypes,{layout:"std140"}),t=OL(i.uniformTypes,e.fields);return{type:"uniform",name:i.name,group:0,location:0,minBindingSize:e.byteLength,uniforms:t}}function OL(i,e){const t=[],n=(r,o)=>{if(typeof o=="string"){const a=e[r];if(!a)throw new Error(`Missing std140 layout field ${r}`);t.push({name:r,format:a.shaderType,arrayLength:1,byteOffset:a.offset*4,byteStride:0});return}if(Array.isArray(o)){s(r,o[0],o[1]);return}for(const[a,c]of Object.entries(o))n(`${r}.${a}`,c)},s=(r,o,a)=>{if(typeof o=="string"){const c=e[`${r}[0]`],l=a>1?e[`${r}[1]`]:void 0;if(!c)throw new Error(`Missing std140 array layout field ${r}[0]`);t.push({name:`${r}[0]`,format:c.shaderType,arrayLength:a,byteOffset:c.offset*4,byteStride:l?(l.offset-c.offset)*4:0});return}if(Array.isArray(o))throw new Error(`Nested uniform arrays are not supported for ${r}`);for(const[c,l]of Object.entries(o)){if(typeof l!="string")throw new Error(`Composite uniform array members are not supported for ${r}`);const u=`${r}[0].${c}`,f=`${r}[1].${c}`,d=e[u],g=a>1?e[f]:void 0;if(!d)throw new Error(`Missing std140 array layout field ${u}`);t.push({name:u,format:d.shaderType,arrayLength:a,byteOffset:d.offset*4,byteStride:g?(g.offset-d.offset)*4:0})}};for(const[r,o]of Object.entries(i))n(r,o);return t}function BL(i){return i.type==="uniform"&&Number.isInteger(i.minBindingSize)&&i.minBindingSize>=0&&Array.isArray(i.uniforms)&&i.uniforms.every(e=>typeof e.name=="string"&&typeof e.format=="string"&&Number.isInteger(e.arrayLength)&&e.arrayLength>0&&Number.isInteger(e.byteOffset)&&e.byteOffset>=0&&Number.isInteger(e.byteStride)&&e.byteStride>=0)}function kL(i){if(i[i.length-1]!=="]")return{name:i,length:1,isArray:!1};const t=/([^[]*)(\[[0-9]+\])?/.exec(i);return{name:js(t==null?void 0:t[1],`Failed to parse GLSL uniform name ${i}`),length:t!=null&&t[2]?1:0,isArray:!!(t!=null&&t[2])}}class DL extends ht{constructor(t,n){super(t,n);h(this,"device");h(this,"handle");h(this,"vs");h(this,"fs");h(this,"introspectedLayout");h(this,"bindings",{});h(this,"uniforms",{});h(this,"varyings",null);h(this,"_uniformCount",0);h(this,"_uniformSetters",{});this.device=t;const s=this.sharedRenderPipeline||this.device._createSharedRenderPipelineWebGL(n);this.sharedRenderPipeline=s,this.handle=s.handle,this.vs=s.vs,this.fs=s.fs,this.linkStatus=s.linkStatus,this.introspectedLayout=SL(this.device.gl,this.handle,{uniformBlockLayouts:n._uniformBlockLayouts,shaderLayout:n.shaderLayout}),this.device._setWebGLDebugMetadata(this.handle,this,{spector:{id:this.props.id}}),this.shaderLayout=n.shaderLayout?FL(this.introspectedLayout,n.shaderLayout):this.introspectedLayout}get[Symbol.toStringTag](){return"WEBGLRenderPipeline"}destroy(){this.destroyed||(this.sharedRenderPipeline&&!this.props._sharedRenderPipeline&&this.sharedRenderPipeline.destroy(),this.destroyResource())}setBindings(t,n){const s=Ea(Dc(this.shaderLayout,t));for(const[r,o]of Object.entries(s)){const a=sp(this.shaderLayout,r);if(a){switch(o||M.warn(`Unsetting binding "${r}" in render pipeline "${this.id}"`)(),a.type){case"uniform":if(!(o instanceof rn)&&!(o.buffer instanceof rn))throw new Error("buffer value");break;case"texture":if(!(o instanceof ri||o instanceof on||o instanceof sn))throw new Error(`${this} Bad texture binding for ${r}`);break;case"sampler":M.warn(`Ignoring sampler ${r}`)();break;default:throw new Error(a.type)}this.bindings[r]=o}else{const c=this.shaderLayout.bindings.map(l=>`"${l.name}"`).join(", ");n!=null&&n.disableWarnings||M.warn(`No binding "${r}" in render pipeline "${this.id}", expected one of ${c}`,o)()}}}draw(t){const n=t.renderPass,s=t.bindGroups?Ea(t.bindGroups):t.bindings||this.bindings;return n.setPipeline(this),n.setBindings(s),n.setVertexArray(t.vertexArray),n.draw({parameters:t.parameters,topology:t.topology,isInstanced:t.isInstanced,vertexCount:t.vertexCount,indexCount:t.indexCount,instanceCount:t.instanceCount,firstVertex:t.firstVertex,firstIndex:t.firstIndex,firstInstance:t.firstInstance,baseVertex:t.baseVertex,transformFeedback:t.transformFeedback,uniforms:t.uniforms})}_areTexturesRenderable(t){let n=!0;for(const s of this.shaderLayout.bindings)Of(t,s.name)||(M.warn(`Binding ${s.name} not found in ${this.id}`)(),n=!1);return n}_applyBindings(t,n){if(this._syncLinkStatus(),this.linkStatus!=="success")return;const{gl:s}=this.device;s.useProgram(this.handle);let r=0,o=0;for(const a of this.shaderLayout.bindings){const c=Of(t,a.name);if(!c)throw new Error(`No value for binding ${a.name} in ${this.id}`);switch(a.type){case"uniform":const{name:l}=a,u=s.getUniformBlockIndex(this.handle,l);if(u===4294967295)throw new Error(`Invalid uniform block name ${l}`);if(s.uniformBlockBinding(this.handle,u,o),c instanceof rn)s.bindBufferBase(35345,o,c.handle);else{const d=c;s.bindBufferRange(35345,o,d.buffer.handle,d.offset||0,d.size||d.buffer.byteLength-(d.offset||0))}o+=1;break;case"texture":if(!(c instanceof ri||c instanceof on||c instanceof sn))throw new Error("texture");let f;if(c instanceof ri)f=c.texture;else if(c instanceof on)f=c;else if(c instanceof sn&&c.colorAttachments[0]instanceof ri)M.warn("Passing framebuffer in texture binding may be deprecated. Use fbo.colorAttachments[0] instead")(),f=c.colorAttachments[0].texture;else throw new Error("No texture");s.activeTexture(33984+r),s.bindTexture(f.glTarget,f.handle),r+=1;break;case"sampler":break;case"storage":case"read-only-storage":throw new Error(`binding type '${a.type}' not supported in WebGL`)}}}_applyUniforms(t){for(const n of this.shaderLayout.uniforms||[]){const{name:s,location:r,type:o,textureUnit:a}=n,c=t[s]??a;c!==void 0&&bL(this.device.gl,r,o,c)}}_syncLinkStatus(){this.linkStatus=this.sharedRenderPipeline.linkStatus}}function FL(i,e){const t={...i,attributes:i.attributes.map(n=>({...n})),bindings:i.bindings.map(n=>({...n}))};for(const n of(e==null?void 0:e.attributes)||[]){const s=t.attributes.find(r=>r.name===n.name);s?(s.type=n.type||s.type,s.stepMode=n.stepMode||s.stepMode):M.warn(`shader layout attribute ${n.name} not present in shader`)}for(const n of(e==null?void 0:e.bindings)||[]){const s=sp(t,n.name);if(!s){M.warn(`shader layout binding ${n.name} not present in shader`);continue}Object.assign(s,n)}return t}function sp(i,e){return i.bindings.find(t=>t.name===e||t.name===`${e}Uniforms`||`${t.name}Uniforms`===e)}function Of(i,e){return i[e]||i[`${e}Uniforms`]||i[e.replace(/Uniforms$/,"")]}const Bf=4;class zL extends Dv{constructor(t,n){super(t,n);h(this,"device");h(this,"handle");h(this,"vs");h(this,"fs");h(this,"linkStatus","pending");this.device=t,this.handle=n.handle||this.device.gl.createProgram(),this.vs=n.vs,this.fs=n.fs,n.varyings&&n.varyings.length>0&&this.device.gl.transformFeedbackVaryings(this.handle,n.varyings,n.bufferMode||35981),this._linkShaders()}destroy(){this.destroyed||(this.device.gl.useProgram(null),this.device.gl.deleteProgram(this.handle),this.handle.destroyed=!0,this.destroyResource())}async _linkShaders(){const{gl:t}=this.device;if(t.attachShader(this.handle,this.vs.handle),t.attachShader(this.handle,this.fs.handle),M.time(Bf,`linkProgram for ${this.id}`)(),t.linkProgram(this.handle),M.timeEnd(Bf,`linkProgram for ${this.id}`)(),!this.device.features.has("compilation-status-async-webgl")){const s=this._getLinkStatus();this._reportLinkStatus(s);return}M.once(1,"RenderPipeline linking is asynchronous")(),await this._waitForLinkComplete(),M.info(2,`RenderPipeline ${this.id} - async linking complete: ${this.linkStatus}`)();const n=this._getLinkStatus();this._reportLinkStatus(n)}async _reportLinkStatus(t){var n;switch(t){case"success":return;default:const s=t==="link-error"?"Link error":"Validation error";switch(this.vs.compilationStatus){case"error":throw this.vs.debugShader(),new Error(`${this} ${s} during compilation of ${this.vs}`);case"pending":await this.vs.asyncCompilationStatus,this.vs.debugShader();break}switch((n=this.fs)==null?void 0:n.compilationStatus){case"error":throw this.fs.debugShader(),new Error(`${this} ${s} during compilation of ${this.fs}`);case"pending":await this.fs.asyncCompilationStatus,this.fs.debugShader();break}const r=this.device.gl.getProgramInfoLog(this.handle);this.device.reportError(new Error(`${s} during ${t}: ${r}`),this)(),this.device.debug()}}_getLinkStatus(){const{gl:t}=this.device;return t.getProgramParameter(this.handle,35714)?(this._initializeSamplerUniforms(),t.validateProgram(this.handle),t.getProgramParameter(this.handle,35715)?(this.linkStatus="success","success"):(this.linkStatus="error","validation-error")):(this.linkStatus="error","link-error")}_initializeSamplerUniforms(){const{gl:t}=this.device;t.useProgram(this.handle);let n=0;const s=t.getProgramParameter(this.handle,35718);for(let r=0;r<s;r++){const o=t.getActiveUniform(this.handle,r);if(o&&tp(o.type)){const a=o.name.endsWith("[0]"),c=a?o.name.slice(0,-3):o.name,l=t.getUniformLocation(this.handle,c);l!==null&&(n=this._assignSamplerUniform(l,o,a,n))}}}_assignSamplerUniform(t,n,s,r){const{gl:o}=this.device;if(s&&n.size>1){const a=Int32Array.from({length:n.size},(c,l)=>r+l);return o.uniform1iv(t,a),r+n.size}return o.uniform1i(t,r),r+1}async _waitForLinkComplete(){const t=async r=>await new Promise(o=>setTimeout(o,r));if(!this.device.features.has("compilation-status-async-webgl")){await t(10);return}const{gl:s}=this.device;for(;;){if(s.getProgramParameter(this.handle,37297))return;await t(10)}}}class NL extends Ta{constructor(t,n={}){super(t,n);h(this,"device");h(this,"handle",null);h(this,"commands",[]);this.device=t}_executeCommands(t=this.commands){for(const n of t)switch(n.name){case"copy-buffer-to-buffer":UL(this.device,n.options);break;case"copy-buffer-to-texture":$L(this.device,n.options);break;case"copy-texture-to-buffer":GL(this.device,n.options);break;case"copy-texture-to-texture":jL(this.device,n.options);break;default:throw new Error(n.name)}}}function UL(i,e){const t=e.sourceBuffer,n=e.destinationBuffer;i.gl.bindBuffer(36662,t.handle),i.gl.bindBuffer(36663,n.handle),i.gl.copyBufferSubData(36662,36663,e.sourceOffset??0,e.destinationOffset??0,e.size),i.gl.bindBuffer(36662,null),i.gl.bindBuffer(36663,null)}function $L(i,e){const{sourceBuffer:t,byteOffset:n=0,destinationTexture:s,mipLevel:r=0,origin:o=[0,0,0],aspect:a="all",bytesPerRow:c,rowsPerImage:l,size:u}=e;if(a!=="all")throw new Error("copyBufferToTexture aspect is not supported in WebGL");s.writeBuffer(t,{byteOffset:n,bytesPerRow:c,rowsPerImage:l,mipLevel:r,x:o[0]??0,y:o[1]??0,z:o[2]??0,width:u[0],height:u[1],depthOrArrayLayers:u[2]})}function GL(i,e){const{sourceTexture:t,mipLevel:n=0,aspect:s="all",width:r=e.sourceTexture.width,height:o=e.sourceTexture.height,depthOrArrayLayers:a,origin:c=[0,0,0],destinationBuffer:l,byteOffset:u=0,bytesPerRow:f,rowsPerImage:d}=e;if(t instanceof he){t.readBuffer({x:c[0]??0,y:c[1]??0,z:c[2]??0,width:r,height:o,depthOrArrayLayers:a,mipLevel:n,aspect:s,byteOffset:u},l);return}if(s!=="all")throw new Error("aspect not supported in WebGL");if(n!==0||a!==void 0||f||d)throw new Error("not implemented");const{framebuffer:g,destroyFramebuffer:p}=rp(t);let m;try{const _=l,v=r||g.width,w=o||g.height,y=js(g.colorAttachments[0]),x=Qg(y.texture.props.format),S=x.format,C=x.type;i.gl.bindBuffer(35051,_.handle),m=i.gl.bindFramebuffer(36160,g.handle),i.gl.readPixels(c[0],c[1],v,w,S,C,u)}finally{i.gl.bindBuffer(35051,null),m!==void 0&&i.gl.bindFramebuffer(36160,m),p&&g.destroy()}}function jL(i,e){const{sourceTexture:t,destinationMipLevel:n=0,origin:s=[0,0],destinationOrigin:r=[0,0,0],destinationTexture:o}=e;let{width:a=e.destinationTexture.width,height:c=e.destinationTexture.height}=e;const{framebuffer:l,destroyFramebuffer:u}=rp(t),[f=0,d=0]=s,[g,p,m]=r,_=i.gl.bindFramebuffer(36160,l.handle);let v,w;if(o instanceof on)v=o,a=Number.isFinite(a)?a:v.width,c=Number.isFinite(c)?c:v.height,v._bind(0),w=v.glTarget;else throw new Error("invalid destination");switch(w){case 3553:case 34067:i.gl.copyTexSubImage2D(w,n,g,p,f,d,a,c);break;case 35866:case 32879:i.gl.copyTexSubImage3D(w,n,g,p,m,f,d,a,c);break}v&&v._unbind(),i.gl.bindFramebuffer(36160,_),u&&l.destroy()}function rp(i){if(i instanceof he){const{width:e,height:t,id:n}=i;return{framebuffer:i.device.createFramebuffer({id:`framebuffer-for-${n}`,width:e,height:t,colorAttachments:[i]}),destroyFramebuffer:!0}}return{framebuffer:i,destroyFramebuffer:!1}}function VL(i){switch(i){case"point-list":return 0;case"line-list":return 1;case"line-strip":return 3;case"triangle-list":return 4;case"triangle-strip":return 5;default:throw new Error(i)}}function WL(i){switch(i){case"point-list":return 0;case"line-list":return 1;case"line-strip":return 1;case"triangle-list":return 4;case"triangle-strip":return 4;default:throw new Error(i)}}const HL=[1,2,4,8];class YL extends Ca{constructor(t,n){var a;super(t,n);h(this,"device");h(this,"handle",null);h(this,"glParameters",{});h(this,"pipeline",null);h(this,"bindings",{});h(this,"bindingsPipeline",null);h(this,"vertexArray",null);this.device=t;const s=this.props.framebuffer,r=!s||s.handle===null;r&&t.getDefaultCanvasContext()._resizeDrawingBufferIfNeeded();let o;if(!((a=n==null?void 0:n.parameters)!=null&&a.viewport))if(!r&&s){const{width:c,height:l}=s;o=[0,0,c,l]}else{const[c,l]=t.getDefaultCanvasContext().getDrawingBufferSize();o=[0,0,c,l]}if(this.device.pushState(),this.setParameters({viewport:o,...this.props.parameters}),!r&&(s!=null&&s.colorAttachments.length)){const c=s.colorAttachments.map((l,u)=>36064+u);this.device.gl.drawBuffers(c)}else r&&this.device.gl.drawBuffers([1029]);this.clear(),this.props.timestampQuerySet&&this.props.beginTimestampIndex!==void 0&&this.props.timestampQuerySet.writeTimestamp(this.props.beginTimestampIndex)}end(){this.destroyed||(this.props.timestampQuerySet&&this.props.endTimestampIndex!==void 0&&this.props.timestampQuerySet.writeTimestamp(this.props.endTimestampIndex),this.device.popState(),this.destroy())}pushDebugGroup(t){}popDebugGroup(){}insertDebugMarker(t){}executeBundles(t){throw new Error("Render bundles are only supported in WebGPU")}setParameters(t={}){const n={...this.glParameters};n.framebuffer=this.props.framebuffer||null,this.props.depthReadOnly&&(n.depthMask=!this.props.depthReadOnly),n.stencilMask=this.props.stencilReadOnly?0:1,n[35977]=this.props.discard,t.viewport&&(t.viewport.length>=6?(n.viewport=t.viewport.slice(0,4),n.depthRange=[t.viewport[4],t.viewport[5]]):n.viewport=t.viewport),t.scissorRect&&(n.scissorTest=!0,n.scissor=t.scissorRect),t.blendConstant&&(n.blendColor=t.blendConstant),t.stencilReference!==void 0&&(n[2967]=t.stencilReference,n[36003]=t.stencilReference),"colorMask"in t&&(n.colorMask=HL.map(s=>!!(s&t.colorMask))),this.glParameters=n,Mi(this.device.gl,n)}setPipeline(t){this.pipeline=t}setBindings(t,n){if(!this.pipeline)throw new Error("RenderPass.setPipeline() must be called before setBindings()");this.bindings=Ea(Dc(this.pipeline.shaderLayout,t)),this.bindingsPipeline=this.pipeline}setVertexArray(t){this.vertexArray=t}draw(t){var y;const n=this.pipeline,s=this.vertexArray;if(!n)throw new Error("RenderPass.setPipeline() must be called before draw()");if(!s)throw new Error("RenderPass.setVertexArray() must be called before draw()");if(n.shaderLayout.bindings.length>0&&this.bindingsPipeline!==n)throw new Error("RenderPass.setBindings() must be called after setPipeline() before draw()");n._syncLinkStatus();const{parameters:r=n.props.parameters,topology:o=n.props.topology,vertexCount:a,indexCount:c,instanceCount:l,isInstanced:u=!1,firstVertex:f=0,transformFeedback:d,uniforms:g=n.uniforms}=t,p=VL(o),m=!!s.indexBuffer,_=(y=s.indexBuffer)==null?void 0:y.glIndexType,v=c??a??0;if(n.linkStatus!=="success")return M.info(2,`RenderPipeline:${n.id}.draw() aborted - waiting for shader linking`)(),!1;if(!n._areTexturesRenderable(this.bindings))return M.info(2,`RenderPipeline:${n.id}.draw() aborted - textures not yet loaded`)(),!1;this.device.gl.useProgram(n.handle),s.bindBeforeRender(this);const w=d;return w&&w.begin(n.props.topology),n._applyBindings(this.bindings,{disableWarnings:n.props.disableWarnings}),n._applyUniforms(g),aL(this.device,r,this.glParameters,()=>{m&&u?this.device.gl.drawElementsInstanced(p,v,_,f,l||0):m?this.device.gl.drawElements(p,v,_,f):u?this.device.gl.drawArraysInstanced(p,f,a||0,l||0):this.device.gl.drawArrays(p,f,a||0),w&&w.end()}),s.unbindAfterRender(this),!0}drawIndirect(t,n=0){throw new Error("Indirect drawing is only supported in WebGPU")}drawIndexedIndirect(t,n=0){throw new Error("Indirect drawing is only supported in WebGPU")}beginOcclusionQuery(t){const n=this.props.occlusionQuerySet;n==null||n.beginOcclusionQuery()}endOcclusionQuery(){const t=this.props.occlusionQuerySet;t==null||t.endOcclusionQuery()}clear(){const t={...this.glParameters};let n=0;this.props.clearColors&&this.props.clearColors.forEach((s,r)=>{s&&this.clearColorBuffer(r,s)}),this.props.clearColor!==!1&&this.props.clearColors===void 0&&(n|=16384,t.clearColor=this.props.clearColor),this.props.clearDepth!==!1&&(n|=256,t.clearDepth=this.props.clearDepth),this.props.clearStencil!==!1&&(n|=1024,t.clearStencil=this.props.clearStencil),n!==0&&dt(this.device.gl,t,()=>{this.device.gl.clear(n)})}clearColorBuffer(t=0,n=[0,0,0,0]){dt(this.device.gl,{framebuffer:this.props.framebuffer},()=>{switch(n.constructor){case Int8Array:case Int16Array:case Int32Array:this.device.gl.clearBufferiv(6144,t,n);break;case Uint8Array:case Uint8ClampedArray:case Uint16Array:case Uint32Array:this.device.gl.clearBufferuiv(6144,t,n);break;case Float32Array:this.device.gl.clearBufferfv(6144,t,n);break;default:throw new Error("clearColorBuffer: color must be typed array")}})}}class kf extends La{constructor(t,n){super(t,n);h(this,"device");h(this,"handle",null);h(this,"commandBuffer");this.device=t,this.commandBuffer=new NL(t,{id:this.id,userData:this.userData})}destroy(){this.destroyResource()}finish(){return this.destroy(),this.commandBuffer}beginRenderPass(t={}){return new YL(this.device,this._applyTimeProfilingToPassProps(t))}beginComputePass(t={}){throw new Error("ComputePass not supported in WebGL")}copyBufferToBuffer(t){this.commandBuffer.commands.push({name:"copy-buffer-to-buffer",options:t})}copyBufferToTexture(t){this.commandBuffer.commands.push({name:"copy-buffer-to-texture",options:t})}copyTextureToBuffer(t){this.commandBuffer.commands.push({name:"copy-texture-to-buffer",options:t})}copyTextureToTexture(t){this.commandBuffer.commands.push({name:"copy-texture-to-texture",options:t})}pushDebugGroup(t){}popDebugGroup(){}insertDebugMarker(t){}resolveQuerySet(t,n,s){throw new Error("resolveQuerySet is not supported in WebGL")}writeTimestamp(t,n){t.writeTimestamp(n)}}function qL(i){const{target:e,source:t,start:n=0,count:s=1}=i,r=t.length,o=s*r;let a=0;for(let c=n;a<r;a++)e[c++]=t[a]??0;for(;a<o;)a<o-a?(e.copyWithin(n+a,n,n+a),a*=2):(e.copyWithin(n+a,n,n+o-a),a=o);return i.target}class pl extends Aa{constructor(t,n){super(t,n);h(this,"device");h(this,"handle");h(this,"attributeInfosByLocation");h(this,"buffer",null);h(this,"bufferValue",null);this.device=t,this.handle=this.device.gl.createVertexArray(),this.attributeInfosByLocation=new Array(this.maxVertexAttributes).fill(null);for(const s of Object.values(Vh(n.shaderLayout,n.bufferLayout)))this.attributeInfosByLocation[s.location]=s}get[Symbol.toStringTag](){return"VertexArray"}static isConstantAttributeZeroSupported(t){return ym()==="Chrome"}destroy(){var t;super.destroy(),this.buffer&&((t=this.buffer)==null||t.destroy()),this.handle&&(this.device.gl.deleteVertexArray(this.handle),this.handle=void 0)}setIndexBuffer(t){const n=t;if(n&&n.glTarget!==34963)throw new Error("Use .setBuffer()");this.device.gl.bindVertexArray(this.handle),this.device.gl.bindBuffer(34963,n?n.handle:null),this.indexBuffer=n,this.device.gl.bindVertexArray(null)}setBuffer(t,n){const s=n;if(s.glTarget===34963)throw new Error("Use .setIndexBuffer()");const{size:r,type:o,stride:a,offset:c,normalized:l,integer:u,divisor:f}=this._getAccessor(t);this.device.gl.bindVertexArray(this.handle),this.device.gl.bindBuffer(34962,s.handle),u?this.device.gl.vertexAttribIPointer(t,r,o,a,c):this.device.gl.vertexAttribPointer(t,r,o,l,a,c),this.device.gl.bindBuffer(34962,null),this.device.gl.enableVertexAttribArray(t),this.device.gl.vertexAttribDivisor(t,f||0),this.attributes[t]=s,this.device.gl.bindVertexArray(null)}setConstantWebGL(t,n){this._enable(t,!1),this.attributes[t]=n}bindBeforeRender(){this.device.gl.bindVertexArray(this.handle),this._applyConstantAttributes()}unbindAfterRender(){this.device.gl.bindVertexArray(null)}_applyConstantAttributes(){for(let t=0;t<this.maxVertexAttributes;++t){const n=this.attributes[t];ArrayBuffer.isView(n)&&this.device.setConstantAttributeWebGL(t,n)}}_getAccessor(t){const n=this.attributeInfosByLocation[t];if(!n)throw new Error(`Unknown attribute location ${t}`);const s=qg(n.bufferDataType);return{size:n.bufferComponents,type:s,stride:n.byteStride,offset:n.byteOffset,normalized:n.normalized,integer:n.integer,divisor:n.stepMode==="instance"?1:0}}_enable(t,n=!0){const r=pl.isConstantAttributeZeroSupported(this.device)||t!==0;(n||r)&&(t=Number(t),this.device.gl.bindVertexArray(this.handle),n?this.device.gl.enableVertexAttribArray(t):this.device.gl.disableVertexAttribArray(t),this.device.gl.bindVertexArray(null))}getConstantBuffer(t,n){const s=ZL(n),r=s.byteLength*t,o=s.length*t;if(this.buffer&&r!==this.buffer.byteLength)throw new Error(`Buffer size is immutable, byte length ${r} !== ${this.buffer.byteLength}.`);let a=!this.buffer;if(this.buffer=this.buffer||this.device.createBuffer({byteLength:r}),a||(a=!XL(s,this.bufferValue)),a){const c=Zv(n.constructor,o);qL({target:c,source:s,start:0,count:o}),this.buffer.write(c),this.bufferValue=n}return this.buffer}}function ZL(i){return Array.isArray(i)?new Float32Array(i):i}function XL(i,e){if(!i||!e||i.length!==e.length||i.constructor!==e.constructor)return!1;for(let t=0;t<i.length;++t)if(i[t]!==e[t])return!1;return!0}class KL extends Ma{constructor(t,n){super(t,n);h(this,"device");h(this,"gl");h(this,"handle");h(this,"layout");h(this,"buffers",{});h(this,"unusedBuffers",{});h(this,"bindOnUse",!0);h(this,"_bound",!1);this.device=t,this.gl=t.gl,this.handle=this.props.handle||this.gl.createTransformFeedback(),this.layout=this.props.layout,n.buffers&&this.setBuffers(n.buffers),Object.seal(this)}destroy(){this.gl.deleteTransformFeedback(this.handle),super.destroy()}begin(t="point-list"){this.gl.bindTransformFeedback(36386,this.handle),this.bindOnUse&&this._bindBuffers(),this.gl.beginTransformFeedback(WL(t))}end(){this.gl.endTransformFeedback(),this.bindOnUse&&this._unbindBuffers(),this.gl.bindTransformFeedback(36386,null)}setBuffers(t){this.buffers={},this.unusedBuffers={},this.bind(()=>{for(const[n,s]of Object.entries(t))this.setBuffer(n,s)})}setBuffer(t,n){const s=this._getVaryingIndex(t),{buffer:r,byteLength:o,byteOffset:a}=this._getBufferRange(n);if(s<0){this.unusedBuffers[t]=r,M.warn(`${this.id} unusedBuffers varying buffer ${t}`)();return}this.buffers[s]={buffer:r,byteLength:o,byteOffset:a},this.bindOnUse||this._bindBuffer(s,r,a,o)}getBuffer(t){if(Df(t))return this.buffers[t]||null;const n=this._getVaryingIndex(t);return this.buffers[n]??null}bind(t=this.handle){if(typeof t!="function")return this.gl.bindTransformFeedback(36386,t),this;let n;return this._bound?n=t():(this.gl.bindTransformFeedback(36386,this.handle),this._bound=!0,n=t(),this._bound=!1,this.gl.bindTransformFeedback(36386,null)),n}unbind(){this.bind(null)}_getBufferRange(t){if(t instanceof rn)return{buffer:t,byteOffset:0,byteLength:t.byteLength};const{buffer:n,byteOffset:s=0,byteLength:r=t.buffer.byteLength}=t;return{buffer:n,byteOffset:s,byteLength:r}}_getVaryingIndex(t){if(Df(t))return Number(t);for(const n of this.layout.varyings||[])if(t===n.name)return n.location;return-1}_bindBuffers(){for(const[t,n]of Object.entries(this.buffers)){const{buffer:s,byteLength:r,byteOffset:o}=this._getBufferRange(n);this._bindBuffer(Number(t),s,o,r)}}_unbindBuffers(){for(const t in this.buffers)this.gl.bindBufferBase(35982,Number(t),null)}_bindBuffer(t,n,s=0,r){const o=n&&n.handle;!o||r===void 0?this.gl.bindBufferBase(35982,t,o):this.gl.bindBufferRange(35982,t,o,s,r)}}function Df(i){return typeof i=="number"?Number.isInteger(i):/^\d+$/.test(i)}class QL extends Ia{constructor(t,n){super(t,n);h(this,"device");h(this,"handle");h(this,"_timestampPairs",[]);h(this,"_pendingReads",new Set);h(this,"_occlusionQuery",null);h(this,"_occlusionActive",!1);if(this.device=t,n.type==="timestamp"){if(n.count<2)throw new Error("Timestamp QuerySet requires at least two query slots");this._timestampPairs=new Array(Math.ceil(n.count/2)).fill(null).map(()=>({activeQuery:null,completedQueries:[]})),this.handle=null}else{if(n.count>1)throw new Error("WebGL occlusion QuerySet can only have one value");const s=this.device.gl.createQuery();if(!s)throw new Error("WebGL query not supported");this.handle=s}Object.seal(this)}get[Symbol.toStringTag](){return"QuerySet"}destroy(){if(!this.destroyed){this.handle&&this.device.gl.deleteQuery(this.handle);for(const t of this._timestampPairs){t.activeQuery&&(this._cancelPendingQuery(t.activeQuery),this.device.gl.deleteQuery(t.activeQuery.handle));for(const n of t.completedQueries)this._cancelPendingQuery(n),this.device.gl.deleteQuery(n.handle)}this._occlusionQuery&&(this._cancelPendingQuery(this._occlusionQuery),this.device.gl.deleteQuery(this._occlusionQuery.handle));for(const t of Array.from(this._pendingReads))this._cancelPendingQuery(t);this.destroyResource()}}isResultAvailable(t){return this.props.type==="timestamp"?t===void 0?this._timestampPairs.some((n,s)=>this._isTimestampPairAvailable(s)):this._isTimestampPairAvailable(this._getTimestampPairIndex(t)):this._occlusionQuery?this._pollQueryAvailability(this._occlusionQuery):!1}async readResults(t){const n=(t==null?void 0:t.firstQuery)||0,s=(t==null?void 0:t.queryCount)||this.props.count-n;if(this._validateRange(n,s),this.props.type==="timestamp"){const r=new Array(s).fill(0n),o=Math.floor(n/2),a=Math.floor((n+s-1)/2);for(let c=o;c<=a;c++){const l=await this._consumeTimestampPairResult(c),u=c*2,f=u+1;u>=n&&u<n+s&&(r[u-n]=0n),f>=n&&f<n+s&&(r[f-n]=l)}return r}if(!this._occlusionQuery)throw new Error("Occlusion query has not been started");return[await this._consumeQueryResult(this._occlusionQuery)]}async readTimestampDuration(t,n){if(this.props.type!=="timestamp")throw new Error("Timestamp durations require a timestamp QuerySet");if(t<0||n>=this.props.count||n<=t)throw new Error("Timestamp duration range is out of bounds");if(t%2!==0||n!==t+1)throw new Error("WebGL timestamp durations require adjacent even/odd query indices");const s=await this._consumeTimestampPairResult(this._getTimestampPairIndex(t));return Number(s)/1e6}beginOcclusionQuery(){if(this.props.type!=="occlusion")throw new Error("Occlusion queries require an occlusion QuerySet");if(!this.handle)throw new Error("WebGL occlusion query is not available");if(this._occlusionActive)throw new Error("Occlusion query is already active");this.device.gl.beginQuery(35887,this.handle),this._occlusionQuery={handle:this.handle,promise:null,result:null,disjoint:!1,cancelled:!1,pollRequestId:null,resolve:null,reject:null},this._occlusionActive=!0}endOcclusionQuery(){if(!this._occlusionActive)throw new Error("Occlusion query is not active");this.device.gl.endQuery(35887),this._occlusionActive=!1}writeTimestamp(t){if(this.props.type!=="timestamp")throw new Error("Timestamp writes require a timestamp QuerySet");const n=this._getTimestampPairIndex(t),s=this._timestampPairs[n];if(t%2===0){if(s.activeQuery)throw new Error("Timestamp query pair is already active");const r=this.device.gl.createQuery();if(!r)throw new Error("WebGL query not supported");const o={handle:r,promise:null,result:null,disjoint:!1,cancelled:!1,pollRequestId:null,resolve:null,reject:null};this.device.gl.beginQuery(35007,r),s.activeQuery=o;return}if(!s.activeQuery)throw new Error("Timestamp query pair was ended before it was started");this.device.gl.endQuery(35007),s.completedQueries.push(s.activeQuery),s.activeQuery=null}_validateRange(t,n){if(t<0||n<0||t+n>this.props.count)throw new Error("Query read range is out of bounds")}_getTimestampPairIndex(t){if(t<0||t>=this.props.count)throw new Error("Query index is out of bounds");return Math.floor(t/2)}_isTimestampPairAvailable(t){const n=this._timestampPairs[t];return!n||n.completedQueries.length===0?!1:this._pollQueryAvailability(n.completedQueries[0])}_pollQueryAvailability(t){if(t.cancelled||this.destroyed)return t.result=0n,!0;if(t.result!==null||t.disjoint)return!0;if(!this.device.gl.getQueryParameter(t.handle,34919))return!1;const s=!!this.device.gl.getParameter(36795);return t.disjoint=s,t.result=s?0n:BigInt(this.device.gl.getQueryParameter(t.handle,34918)),!0}async _consumeTimestampPairResult(t){const n=this._timestampPairs[t];if(!n||n.completedQueries.length===0)throw new Error("Timestamp query pair has no completed result");const s=n.completedQueries.shift();try{return await this._consumeQueryResult(s)}finally{this.device.gl.deleteQuery(s.handle)}}_consumeQueryResult(t){return t.promise||(this._pendingReads.add(t),t.promise=new Promise((n,s)=>{t.resolve=n,t.reject=s;const r=()=>{if(t.pollRequestId=null,t.cancelled||this.destroyed){this._pendingReads.delete(t),t.promise=null,t.resolve=null,t.reject=null,n(0n);return}if(!this._pollQueryAvailability(t)){t.pollRequestId=this._requestAnimationFrame(r);return}this._pendingReads.delete(t),t.promise=null,t.resolve=null,t.reject=null,t.disjoint?s(new Error("GPU timestamp query was invalidated by a disjoint event")):n(t.result||0n)};r()})),t.promise}_cancelPendingQuery(t){if(this._pendingReads.delete(t),t.cancelled=!0,t.pollRequestId!==null&&(this._cancelAnimationFrame(t.pollRequestId),t.pollRequestId=null),t.resolve){const n=t.resolve;t.promise=null,t.resolve=null,t.reject=null,n(0n)}}_requestAnimationFrame(t){return requestAnimationFrame(t)}_cancelAnimationFrame(t){cancelAnimationFrame(t)}}class JL extends Ra{constructor(t,n={}){super(t,{});h(this,"device");h(this,"gl");h(this,"handle");h(this,"signaled");h(this,"_signaled",!1);this.device=t,this.gl=t.gl;const s=this.props.handle||this.gl.fenceSync(this.gl.SYNC_GPU_COMMANDS_COMPLETE,0);if(!s)throw new Error("Failed to create WebGL fence");this.handle=s,this.signaled=new Promise(r=>{const o=()=>{const a=this.gl.clientWaitSync(this.handle,0,0);a===this.gl.ALREADY_SIGNALED||a===this.gl.CONDITION_SATISFIED?(this._signaled=!0,r()):setTimeout(o,1)};o()})}isSignaled(){if(this._signaled)return!0;const t=this.gl.getSyncParameter(this.handle,this.gl.SYNC_STATUS);return this._signaled=t===this.gl.SIGNALED,this._signaled}destroy(){this.destroyed||this.gl.deleteSync(this.handle)}}function op(i){switch(i){case 6406:case 33326:case 6403:case 36244:return 1;case 33339:case 33340:case 33328:case 33320:case 33319:return 2;case 6407:case 36248:case 34837:return 3;case 6408:case 36249:case 34836:return 4;default:return 0}}function eT(i){switch(i){case 5121:return 1;case 33635:case 32819:case 32820:return 2;case 5126:return 4;default:return 0}}function tT(i,e){var w;const{sourceX:t=0,sourceY:n=0,sourceAttachment:s=0}=e||{};let{target:r=null,sourceWidth:o,sourceHeight:a,sourceDepth:c,sourceFormat:l,sourceType:u}=e||{};const{framebuffer:f,deleteFramebuffer:d}=ap(i),{gl:g,handle:p}=f;o||(o=f.width),a||(a=f.height);const m=(w=f.colorAttachments[s])==null?void 0:w.texture;if(!m)throw new Error(`Invalid framebuffer attachment ${s}`);c=(m==null?void 0:m.depth)||1,l||(l=(m==null?void 0:m.glFormat)||6408),u||(u=(m==null?void 0:m.glType)||5121),r=sT(r,u,l,o,a);const _=et.getDataType(r);u=u||vL(_);const v=g.bindFramebuffer(36160,p);return g.readBuffer(36064+s),g.readPixels(t,n,o,a,l,u,r),g.readBuffer(36064),g.bindFramebuffer(36160,v||null),d&&f.destroy(),r}function iT(i,e){const{target:t,sourceX:n=0,sourceY:s=0,sourceFormat:r=6408,targetByteOffset:o=0}=e||{};let{sourceWidth:a,sourceHeight:c,sourceType:l}=e||{};const{framebuffer:u,deleteFramebuffer:f}=ap(i);a=a||u.width,c=c||u.height;const d=u;l=l||5121;let g=t;if(!g){const m=op(r),_=eT(l),v=o+a*c*m*_;g=d.device.createBuffer({byteLength:v})}const p=i.device.createCommandEncoder();return p.copyTextureToBuffer({sourceTexture:i,width:a,height:c,origin:[n,s],destinationBuffer:g,byteOffset:o}),p.destroy(),f&&u.destroy(),g}function ap(i){return i instanceof Ys?{framebuffer:i,deleteFramebuffer:!1}:{framebuffer:nT(i),deleteFramebuffer:!0}}function nT(i,e){const{device:t,width:n,height:s,id:r}=i;return t.createFramebuffer({...e,id:`framebuffer-for-${r}`,width:n,height:s,colorAttachments:[i]})}function sT(i,e,t,n,s,r){if(i)return i;e||(e=5121);const o=ep(e),a=et.getTypedArrayConstructor(o),c=op(t);return new a(n*s*c)}function rT(i){const e=new Map;for(const t in i){const n=i[t];if(t<"a"){const s=e.get(n);e.set(n,s?`${s}, GL.${t}`:`GL.${t}`)}}return e}class Dt extends gi{constructor(t){var f;super({...t,id:t.id||tL("webgl-device")});h(this,"type","webgl");h(this,"handle");h(this,"features");h(this,"limits");h(this,"info");h(this,"canvasContext");h(this,"preferredColorFormat","rgba8unorm");h(this,"preferredDepthFormat","depth24plus");h(this,"commandEncoder");h(this,"lost");h(this,"_resolveContextLost");h(this,"_isLost",!1);h(this,"gl");h(this,"_glKeyByValue",null);h(this,"_constants");h(this,"extensions");h(this,"_polyfilled",!1);h(this,"spectorJS");const n=gi._getCanvasContextProps(t);if(!n)throw new Error("WebGLDevice requires props.createCanvasContext to be set");const s=((f=n.canvas)==null?void 0:f.gl)??null;let r=Dt.getDeviceFromContext(s);if(r)throw new Error(`WebGL context already attached to device ${r.id}`);this.canvasContext=new JC(this,n),this.lost=new Promise(d=>{this._resolveContextLost=d});const o={...t.webgl};n.alphaMode==="premultiplied"&&(o.premultipliedAlpha=!0),t.powerPreference!==void 0&&(o.powerPreference=t.powerPreference),t.failIfMajorPerformanceCaveat!==void 0&&(o.failIfMajorPerformanceCaveat=t.failIfMajorPerformanceCaveat);const c=this.props._handle||IC(this.canvasContext.canvas,{onContextLost:d=>{var g;return(g=this._resolveContextLost)==null?void 0:g.call(this,{reason:"destroyed",message:"Entered sleep mode, or too many apps or browser tabs are using the GPU."})},onContextRestored:d=>{console.log("WebGL context restored")}},o);if(!c)throw new Error("WebGL context creation failed");if(r=Dt.getDeviceFromContext(c),r){if(t._reuseDevices)return M.log(1,`Not creating a new Device, instead returning a reference to Device ${r.id} already attached to WebGL context`,r)(),this.canvasContext.destroy(),r._reused=!0,r;throw new Error(`WebGL context already attached to device ${r.id}`)}this.handle=c,this.gl=c,this.spectorJS=vC({...this.props,gl:this.handle});const l=nc(this.handle);l.device=this,l.extensions||(l.extensions={}),this.extensions=l.extensions,this.info=RC(this.gl,this.extensions),this.limits=new XC(this.gl),this.features=new ZC(this.gl,this.extensions,this.props._disabledFeatures),this.props._initializeFeatures&&this.features.initializeFeatures(),new Bt(this.gl,{log:(...d)=>M.log(1,...d)()}).trackState(this.gl,{copyState:!1}),(t.debug||t.debugWebGL)&&(this.gl=yC(this.gl,{traceWebGL:t.debugWebGL}),M.warn("WebGL debug mode activated. Performance reduced.")()),t.debugWebGL&&(M.level=Math.max(M.level,1)),this.commandEncoder=new kf(this,{id:`${this}-command-encoder`}),this.canvasContext._startObservers()}static getDeviceFromContext(t){var n;return t?((n=t.luma)==null?void 0:n.device)??null:null}get[Symbol.toStringTag](){return"WebGLDevice"}toString(){return`${this[Symbol.toStringTag]}(${this.id})`}isVertexFormatSupported(t){switch(t){case"unorm8x4-bgra":return!1;default:return!0}}destroy(){var t;if(!this.props._reuseDevices&&!this._reused){this._isLost=!0,(t=this.commandEncoder)==null||t.destroy();const n=nc(this.handle);n.device=null}}get isLost(){return this._isLost||this.gl.isContextLost()}createCanvasContext(t){throw new Error("WebGL only supports a single canvas")}createPresentationContext(t){return new eL(this,t||{})}createBuffer(t){const n=this._normalizeBufferProps(t);return new rn(this,n)}createTexture(t){return new on(this,t)}createExternalTexture(t){throw new Error("ExternalTexture is not available on WebGL")}createSampler(t){return new hL(this,t)}createShader(t){return new rL(this,t)}createFramebuffer(t){return new sn(this,t)}createVertexArray(t){return new pl(this,t)}createTransformFeedback(t){return new KL(this,t)}createQuerySet(t){return new QL(this,t)}createFence(){return new JL(this)}createRenderPipeline(t){return new DL(this,t)}_createSharedRenderPipelineWebGL(t){return new zL(this,t)}createComputePipeline(t){throw new Error("ComputePipeline not supported in WebGL")}createRenderBundleEncoder(t){throw new Error("Render bundles are only supported in WebGPU")}createCommandEncoder(t={}){return new kf(this,t)}submit(t){let n=null;t||({submittedCommandEncoder:n,commandBuffer:t}=this._finalizeDefaultCommandEncoderForSubmit());try{t._executeCommands(),n&&n.resolveTimeProfilingQuerySet().then(()=>{this.commandEncoder._gpuTimeMs=n._gpuTimeMs}).catch(()=>{})}finally{t.destroy()}}writeBufferViaCommandEncoder(t,n,s,r=0){n.write(s,r)}_finalizeDefaultCommandEncoderForSubmit(){const t=this.commandEncoder,n=t.finish();return this.commandEncoder.destroy(),this.commandEncoder=this.createCommandEncoder({id:t.props.id,timeProfilingQuerySet:t.getTimeProfilingQuerySet()}),{submittedCommandEncoder:t,commandBuffer:n}}readPixelsToArrayWebGL(t,n){return tT(t,n)}readPixelsToBufferWebGL(t,n){return iT(t,n)}setParametersWebGL(t){Mi(this.gl,t)}getParametersWebGL(t){return Hg(this.gl,t)}withParametersWebGL(t,n){return dt(this.gl,t,n)}resetWebGL(){M.warn("WebGLDevice.resetWebGL is deprecated, use only for debugging")(),CC(this.gl)}_getDeviceSpecificTextureFormatCapabilities(t){return VC(this.gl,t,this.extensions)}loseDevice(){var r;let t=!1;const s=this.getExtension("WEBGL_lose_context").WEBGL_lose_context;return s&&(t=!0,s.loseContext()),(r=this._resolveContextLost)==null||r.call(this,{reason:"destroyed",message:"Application triggered context loss"}),t}pushState(){Bt.get(this.gl).push()}popState(){Bt.get(this.gl).pop()}getGLKey(t,n){const s=this._getGLKeyByValue().get(Number(t));return s||(n!=null&&n.emptyIfUnknown?"":String(t))}getGLKeys(t){const n={emptyIfUnknown:!0};return Object.entries(t).reduce((s,[r,o])=>(s[`${r}:${this.getGLKey(r,n)}`]=`${o}:${this.getGLKey(o,n)}`,s),{})}_getGLKeyByValue(){return this._glKeyByValue??(this._glKeyByValue=rT(this.gl)),this._glKeyByValue}setConstantAttributeWebGL(t,n){const s=this.limits.maxVertexAttributes;this._constants=this._constants||new Array(s).fill(null);const r=this._constants[t];switch(r&&lT(r,n)&&M.info(1,`setConstantAttributeWebGL(${t}) could have been skipped, value unchanged`)(),this._constants[t]=n,n.constructor){case Float32Array:oT(this,t,n);break;case Int32Array:aT(this,t,n);break;case Uint32Array:cT(this,t,n);break;default:throw new Error("constant")}}getExtension(t){return Gt(this.gl,t,this.extensions),this.extensions}_setWebGLDebugMetadata(t,n,s){t.luma=n;const r={props:s.spector,id:s.spector.id};t.__SPECTOR_Metadata=r}}function oT(i,e,t){switch(t.length){case 1:i.gl.vertexAttrib1fv(e,t);break;case 2:i.gl.vertexAttrib2fv(e,t);break;case 3:i.gl.vertexAttrib3fv(e,t);break;case 4:i.gl.vertexAttrib4fv(e,t);break}}function aT(i,e,t){i.gl.vertexAttribI4iv(e,t)}function cT(i,e,t){i.gl.vertexAttribI4uiv(e,t)}function lT(i,e){if(!i||!e||i.length!==e.length||i.constructor!==e.constructor)return!1;for(let t=0;t<i.length;++t)if(i[t]!==e[t])return!1;return!0}const Ff=Object.freeze(Object.defineProperty({__proto__:null,WebGLDevice:Dt},Symbol.toStringTag,{value:"Module"}));function it(){}const uT=({isDragging:i})=>i?"grabbing":"grab";function zf(i){var e;return((e=i.deviceProps)==null?void 0:e.debug)??i.debug}const cp={id:"",width:"100%",height:"100%",style:null,viewState:null,initialViewState:null,pickingRadius:0,pickAsync:"auto",layerFilter:null,parameters:{},parent:null,device:null,deviceProps:{},gl:null,canvas:null,_canvases:null,layers:[],effects:[],views:null,controller:null,useDevicePixels:!0,touchAction:"none",eventRecognizerOptions:{},_framebuffer:null,_animate:!1,_pickable:!0,_typedArrayManagerProps:{},_customRender:null,widgets:[],onDeviceInitialized:it,onWebGLInitialized:it,onResize:it,onViewStateChange:it,onInteractionStateChange:it,onBeforeRender:it,onAfterRender:it,onLoad:it,onError:i=>Y.error(i.message,i.cause)(),onHover:null,onClick:null,onDragStart:null,onDrag:null,onDragEnd:null,_onMetrics:null,getCursor:uT,getTooltip:null,debug:!1,drawPickingColors:!1};class Hr{constructor(e){this.width=0,this.height=0,this.userData={},this.device=null,this.canvas=null,this.viewManager=null,this.layerManager=null,this.effectManager=null,this.deckRenderer=null,this.deckPicker=null,this.eventManager=null,this.eventManagers={},this.widgetManager=null,this.tooltip=null,this.animationLoop=null,this._canvasContext=null,this._deviceResizeHandler=null,this.cursorState={isHovering:!1,isDragging:!1},this.stats=new Rr({id:"deck.gl"}),this.metrics={fps:0,setPropsTime:0,layersCount:0,drawLayersCount:0,updateLayersCount:0,updateAttributesCount:0,updateAttributesTime:0,framesRedrawn:0,pickTime:0,pickCount:0,pickLayersCount:0,gpuTime:0,gpuTimePerFrame:0,cpuTime:0,cpuTimePerFrame:0,bufferMemory:0,textureMemory:0,renderbufferMemory:0,gpuMemory:0},this._metricsCounter=0,this._hoverPickSequence=0,this._pointerDownPickSequence=0,this._needsRedraw="Initial render",this._canvasManager=new uC({createEventManager:s=>this._createEventManager(s),getEventRoot:s=>this._getEventRoot(s)}),this._ownedCanvas=null,this._pickRequest={mode:"hover",x:-1,y:-1,radius:0,canvasId:void 0,event:null,unproject3D:!1},this._lastPointerDownInfo=null,this._lastPointerDownInfoPromise=null,this._onPointerMove=s=>{const{_pickRequest:r}=this,o=this._getCanvasIdFromEvent(s);if(s.type==="pointerleave")r.x=-1,r.y=-1,r.radius=0,r.canvasId=o;else{if(s.leftButton||s.rightButton)return;{const a=s.offsetCenter;if(!a)return;r.x=a.x,r.y=a.y,r.radius=this.props.pickingRadius,r.canvasId=o}}this.layerManager&&(this.layerManager.context.mousePosition={x:r.x,y:r.y}),r.event=s},this._onEvent=s=>{const r=Ps[s.type],o=s.offsetCenter,a=this._getCanvasIdFromEvent(s);if(!r||!o||!this.layerManager)return;const c=this.layerManager.getLayers(),l=this._getInternalPickingMode();if(!l)return;if(l==="sync"){const f=s.type==="click"&&this._shouldUnproject3D(c)?this._getFirstPickedInfo(this._pickPointSync(this._getPointPickOptions(o.x,o.y,{unproject3D:!0,canvasId:a},c))):this._getLastPointerDownPickingInfo(o.x,o.y,a,c);this._dispatchPickingEvent(f,s);return}(this._lastPointerDownInfoPromise||Promise.resolve(this._getLastPointerDownPickingInfo(o.x,o.y,a,c))).then(f=>{this._dispatchPickingEvent(f,s)}).catch(f=>{var d,g;return(g=(d=this.props).onError)==null?void 0:g.call(d,f)})},this._onPointerDown=s=>{var f;const r=s.offsetCenter,o=this._getCanvasIdFromEvent(s);if(!r)return;const a=this._getInternalPickingMode();if(!a)return;const c=((f=this.layerManager)==null?void 0:f.getLayers())||[],l=++this._pointerDownPickSequence;if(a==="sync"){const d=this._pickPointSync({x:r.x,y:r.y,canvasId:o,radius:this.props.pickingRadius}),g=this._getFirstPickedInfo(d);this._lastPointerDownInfo=g,this._lastPointerDownInfoPromise=Promise.resolve(g);return}const u=this._pickPointAsync(this._getPointPickOptions(r.x,r.y,{canvasId:o},c)).then(d=>this._getFirstPickedInfo(d)).then(d=>(l===this._pointerDownPickSequence&&(this._lastPointerDownInfo=d),d)).catch(d=>{var p,m;(m=(p=this.props).onError)==null||m.call(p,d);const g=this.deckPicker&&this.viewManager?this._getLastPointerDownPickingInfo(r.x,r.y,o,c):{};return l===this._pointerDownPickSequence&&(this._lastPointerDownInfo=g),g});this._lastPointerDownInfo=null,this._lastPointerDownInfoPromise=u};const t=e;this.props={...cp,...e},e=this.props,this._validateCanvasConfiguration(e),e.viewState&&e.initialViewState&&Y.warn("View state tracking is disabled. Use either `initialViewState` for auto update or `viewState` for manual update.")(),this.viewState=this.props.initialViewState,e.device&&(this.device=e.device,this._setDeviceCanvasContext(e.device));let n=this.device;!n&&e.gl&&(e.gl instanceof WebGLRenderingContext&&Y.error("WebGL1 context not supported.")(),n=Do.attach(e.gl,{_cacheShaders:!0,_cachePipelines:!0,...e.deviceProps,debug:zf(e)})),n||(n=this._createDevice(e)),this.animationLoop=this._createAnimationLoop(n,e),this.setProps(t),e._typedArrayManagerProps&&vi.setOptions(e._typedArrayManagerProps),this.animationLoop.start()}finalize(){var e,t,n,s,r,o,a,c,l,u;this._restoreDeviceResizeHandler(),(e=this.animationLoop)==null||e.stop(),(t=this.animationLoop)==null||t.destroy(),this.animationLoop=null,this._hoverPickSequence++,this._pointerDownPickSequence++,this._lastPointerDownInfo=null,this._lastPointerDownInfoPromise=null,(n=this.layerManager)==null||n.finalize(),this.layerManager=null,(s=this.viewManager)==null||s.finalize(),this.viewManager=null,(r=this.effectManager)==null||r.finalize(),this.effectManager=null,(o=this.deckRenderer)==null||o.finalize(),this.deckRenderer=null,(a=this.deckPicker)==null||a.finalize(),this.deckPicker=null,Object.keys(this._canvasManager.targets).length||(c=this.eventManager)==null||c.destroy(),this.eventManager=null,this.eventManagers={},(l=this.widgetManager)==null||l.finalize(),this.widgetManager=null,this._canvasManager.finalize(),this._isMultiCanvasMode()?this.canvas=null:this.canvas&&this.canvas===this._ownedCanvas&&((u=this.canvas.parentElement)==null||u.removeChild(this.canvas),this.canvas=null,this._ownedCanvas=null),this._canvasContext=null}setProps(e){var n,s,r,o,a,c;this.stats.get("setProps Time").timeStart(),"onLayerHover"in e&&Y.removed("onLayerHover","onHover")(),"onLayerClick"in e&&Y.removed("onLayerClick","onClick")(),e.initialViewState&&!Pe(this.props.initialViewState,e.initialViewState,3)&&(this.viewState=e.initialViewState),Q(!("_canvases"in e)||Array.isArray(e._canvases)===this._isMultiCanvasMode()),Object.assign(this.props,e),this._validateCanvasConfiguration(this.props),this._validateInternalPickingMode(),this.device&&this._isMultiCanvasMode()&&this._syncCanvasTargets(),this._setCanvasSize(this.props);const t=Object.create(this.props);if(Object.assign(t,{views:this._getViews(),width:this.width,height:this.height,viewState:this._getViewState(),eventManagers:this.eventManagers}),e.device&&e.device.id!==((n=this.device)==null?void 0:n.id)){const l=e.device.getDefaultCanvasContext();(s=this.animationLoop)==null||s.stop(),!this._isMultiCanvasMode()&&this.canvas!==l.canvas&&((r=this.canvas)==null||r.remove(),(o=this.eventManager)==null||o.destroy(),this.canvas=null),this._setDeviceCanvasContext(e.device),Y.log(`recreating animation loop for new device! id=${e.device.id}`)(),this.animationLoop=this._createAnimationLoop(e.device,e),this.animationLoop.start()}if((a=this.animationLoop)==null||a.setProps(t),e.useDevicePixels!==void 0&&((c=this._canvasContext)!=null&&c.setProps)){this._canvasContext.setProps({useDevicePixels:e.useDevicePixels});for(const l of Object.values(this._canvasManager.targets))l.presentationContext.setProps({useDevicePixels:e.useDevicePixels})}this.layerManager&&(this.viewManager.setProps(t),this.layerManager.activateViewport(this.getViewports()[0]),this.layerManager.setProps(t),this.effectManager.setProps(t),this.deckRenderer.setProps(t),this.deckPicker.setProps(t),this.widgetManager.setProps(t)),this.stats.get("setProps Time").timeEnd()}needsRedraw(e={clearRedrawFlags:!1}){if(!this.layerManager)return!1;if(this.props._animate)return"Deck._animate";let t=this._needsRedraw;e.clearRedrawFlags&&(this._needsRedraw=!1);const n=this.viewManager.needsRedraw(e),s=this.layerManager.needsRedraw(e),r=this.effectManager.needsRedraw(e),o=this.deckRenderer.needsRedraw(e);return t=t||n||s||r||o,t}redraw(e){if(!this.layerManager)return;let t=this.needsRedraw({clearRedrawFlags:!0});t=e||t,t&&(this.stats.get("Redraw Count").incrementCount(),this.props._customRender?this.props._customRender(t):this._drawLayers(t))}get isInitialized(){return this.viewManager!==null}getViews(){return Q(this.viewManager),this.viewManager.views}getView(e){return Q(this.viewManager),this.viewManager.getView(e)}getViewports(e){return Q(this.viewManager),this.viewManager.getViewports(e)}getCanvas(){return this.canvas}getCanvasContext(e){var n,s;const t=e?(s=(n=this.viewManager)==null?void 0:n.getView(e))==null?void 0:s.props.canvasId:void 0;return this._getCanvasContext(t)}getEventManager(e){if(!e||!this.viewManager)return this.eventManager;const t=this.viewManager.getCanvasId(e)||fi;return this.eventManagers[t]||this.eventManager}async pickObjectAsync(e){const t=(await this._pickAsync("pickObjectAsync","pickObject Time",e)).result;return t.length?t[0]:null}async pickObjectsAsync(e){return await this._pickAsync("pickObjectsAsync","pickObjects Time",e)}pickObject(e){const t=this._pick("pickObject","pickObject Time",e).result;return t.length?t[0]:null}pickMultipleObjects(e){return e.depth=e.depth||10,this._pick("pickObject","pickMultipleObjects Time",e).result}pickObjects(e){return this._pick("pickObjects","pickObjects Time",e)}_pickPositionForController(e,t,n){var r;return this._getInternalPickingMode()!=="sync"?null:this.pickObject({x:e,y:t,radius:0,unproject3D:!0,canvasId:n?(r=this.viewManager)==null?void 0:r.getCanvasId(n):void 0})}_addResources(e,t=!1){for(const n in e)this.layerManager.resourceManager.add({resourceId:n,data:e[n],forceUpdate:t})}_removeResources(e){for(const t of e)this.layerManager.resourceManager.remove(t)}_addDefaultEffect(e){this.effectManager.addDefaultEffect(e)}_addDefaultShaderModule(e){this.layerManager.addDefaultShaderModule(e)}_removeDefaultShaderModule(e){var t;(t=this.layerManager)==null||t.removeDefaultShaderModule(e)}_resolveInternalPickingMode(){var n,s;const{pickAsync:e}=this.props,t=((n=this.device)==null?void 0:n.type)||((s=this.props.deviceProps)==null?void 0:s.type);if(e==="auto")return t==="webgpu"?"async":"sync";if(e==="sync"&&t==="webgpu")throw new Error('`pickAsync: "sync"` is not supported when Deck is using a WebGPU device.');return e}_getInternalPickingMode(){var e,t;try{return this._resolveInternalPickingMode()}catch(n){return(t=(e=this.props).onError)==null||t.call(e,n),null}}_validateInternalPickingMode(){this._getInternalPickingMode()}_getFirstPickedInfo({result:e,emptyInfo:t}){return e[0]||t}_shouldUnproject3D(e=(t=>(t=this.layerManager)==null?void 0:t.getLayers())()||[]){return e.some(n=>n.props.pickable==="3d")}_getPointPickOptions(e,t,n={},s=(r=>(r=this.layerManager)==null?void 0:r.getLayers())()||[]){return{x:e,y:t,canvasId:n.canvasId,radius:this.props.pickingRadius,unproject3D:this._shouldUnproject3D(s),...n}}_pickPointSync(e){return this._pick("pickObject","pickObject Time",e)}_pickPointAsync(e){return this._pickAsync("pickObjectAsync","pickObject Time",e)}_getLastPointerDownPickingInfo(e,t,n,s=(r=>(r=this.layerManager)==null?void 0:r.getLayers())()||[]){return this.deckPicker.getLastPickedObject({x:e,y:t,layers:s,viewports:this.getViewports({x:e,y:t,canvasId:n})},this._lastPointerDownInfo)}_applyHoverCallbacks({result:e,emptyInfo:t},n){var o,a,c;if(!this.widgetManager)return;this.cursorState.isHovering=e.length>0;let s=t,r=!1;for(const l of e)s=l,r=((o=l.layer)==null?void 0:o.onHover(l,n))||r;r||((c=(a=this.props).onHover)==null||c.call(a,s,n),this.widgetManager.onHover(s,n))}_dispatchPickingEvent(e,t){if(!this.layerManager||!this.widgetManager)return;const n=Ps[t.type];if(!n)return;const{layer:s}=e,r=s&&(s[n]||s.props[n]),o=this.props[n];let a=!1;r&&(a=r.call(s,e,t)),a||(o==null||o(e,t),this.widgetManager.onEvent(e,t))}_pickAsync(e,t,n){Q(this.deckPicker);const{stats:s}=this,r=this._isMultiCanvasMode()?n.canvasId||this._getDefaultCanvasId():n.canvasId,o=this._getCanvasContext(r)||void 0;s.get("Pick Count").incrementCount(),s.get(t).timeStart(),this._resizeForCanvasTarget(r);const a=this.deckPicker[e]({layers:this.layerManager.getLayers(n),views:this.viewManager.getViews(),viewports:this.getViewports({...n,canvasId:r}),onViewportActive:this.layerManager.activateViewport,effects:this.effectManager.getEffects(),...n,canvasId:r,canvasContext:o});return s.get(t).timeEnd(),a}_pick(e,t,n){Q(this.deckPicker);const{stats:s}=this,r=this._isMultiCanvasMode()?n.canvasId||this._getDefaultCanvasId():n.canvasId,o=this._getCanvasContext(r)||void 0;s.get("Pick Count").incrementCount(),s.get(t).timeStart(),this._resizeForCanvasTarget(r);const a=this.deckPicker[e]({layers:this.layerManager.getLayers(n),views:this.viewManager.getViews(),viewports:this.getViewports({...n,canvasId:r}),onViewportActive:this.layerManager.activateViewport,effects:this.effectManager.getEffects(),...n,canvasId:r,canvasContext:o});return s.get(t).timeEnd(),a}_createCanvas(e){let t=e.canvas;return typeof t=="string"&&(t=document.getElementById(t),Q(t)),t?this._ownedCanvas=null:(t=document.createElement("canvas"),t.id=e.id||"deckgl-overlay",e.width&&typeof e.width=="number"&&(t.width=e.width),e.height&&typeof e.height=="number"&&(t.height=e.height),(e.parent||document.body).appendChild(t),this._ownedCanvas=t),Object.assign(t.style,e.style),t}_isMultiCanvasMode(){return Array.isArray(this.props._canvases)}_getDefaultCanvasId(){return this._canvasManager.order[0]||fi}_validateCanvasConfiguration(e){var t;Array.isArray(e._canvases)&&(Q(!e.canvas),Q(!e.gl),Q(!((t=e.device)!=null&&t.canvasContext)||e.device.getDefaultCanvasContext().offscreenCanvas))}_createEventManager(e){const t=new rS(e,{touchAction:this.props.touchAction,recognizers:Object.keys(Wu).map(n=>{var u;const[s,r,o,a]=Wu[n],c=(u=this.props.eventRecognizerOptions)==null?void 0:u[n],l={...r,...c,event:n};return{recognizer:new s(l),recognizeWith:o,requireFailure:a}}),events:{pointerdown:this._onPointerDown,pointermove:this._onPointerMove,pointerleave:this._onPointerMove}});for(const n in Ps)n==="dblclick"?t.watch(n,this._onEvent):t.on(n,this._onEvent);return t}_getEventRoot(e){var t;return e.closest(".deck-events-root")||((t=this.props.parent)==null?void 0:t.querySelector(".deck-events-root"))||e}_syncCanvasTargets(){var t;if(!this.device||!this._isMultiCanvasMode())return;this._canvasManager.syncCanvasEntries({device:this.device,canvases:this.props._canvases||[],useDevicePixels:this.props.useDevicePixels}),this.eventManagers=this._canvasManager.eventManagers;const e=this._getDefaultCanvasId();this.eventManager=this.eventManagers[e]||null,this.canvas=((t=this._canvasManager.targets[e])==null?void 0:t.canvas)||null}_setCanvasContext(e){this._canvasContext=e,"style"in e.canvas&&(this.canvas=e.canvas)}_setDeviceCanvasContext(e,t={}){const n=e.getDefaultCanvasContext();this._setCanvasContext(n),this._setDeviceResizeHandler(e,t)}_setDeviceResizeHandler(e,t={}){var r;const n=!!t.syncDrawingBuffer;if(((r=this._deviceResizeHandler)==null?void 0:r.device)===e){this._deviceResizeHandler.syncDrawingBuffer=n;return}this._restoreDeviceResizeHandler();const s=o=>{var a;this._isMultiCanvasMode()?this._updateMultiCanvasDimensions():o===this._canvasContext&&this._canvasContext&&this._onCanvasContextResize(this._canvasContext,{syncDrawingBuffer:(a=this._deviceResizeHandler)==null?void 0:a.syncDrawingBuffer})};e.props.onResize=s,this._deviceResizeHandler={device:e,onResize:s,syncDrawingBuffer:n}}_restoreDeviceResizeHandler(){var t;const e=this._deviceResizeHandler;e&&((t=e.device.props)==null?void 0:t.onResize)===e.onResize&&(e.device.props.onResize=it),this._deviceResizeHandler=null}_setCanvasSize(e){var s;if(this._isMultiCanvasMode()||!this.canvas)return;const{width:t,height:n}=e;if(t||t===0){const r=Number.isFinite(t)?`${t}px`:t;this.canvas.style.width=r}if(n||n===0){const r=Number.isFinite(n)?`${n}px`:n;this.canvas.style.position=((s=e.style)==null?void 0:s.position)||"absolute",this.canvas.style.height=r}}_getCanvasIdFromEvent(e){return this._canvasManager.getCanvasIdFromEvent(e==null?void 0:e.rootElement)}_getCanvasContext(e){var t;return((t=this._canvasManager.getTarget(e))==null?void 0:t.presentationContext)||this._canvasContext}_resizeForCanvasTarget(e){var r;const t=this._canvasManager.getTarget(e);if(!t||!((r=this.device)!=null&&r.canvasContext))return;const[n,s]=t.presentationContext.getDrawingBufferSize();this.device.canvasContext.setDrawingBufferSize(n,s)}_createDeviceCanvas(e){if(this._isMultiCanvasMode()){const t=globalThis.OffscreenCanvas;if(!t)throw new Error("`_canvases` requires OffscreenCanvas support.");const n=typeof e.width=="number"&&Number.isFinite(e.width)?e.width:1,s=typeof e.height=="number"&&Number.isFinite(e.height)?e.height:1;return new t(n,s)}return this._createCanvas(e)}_updateCanvasSize(e=this._canvasContext){var r,o;if(this._isMultiCanvasMode()){this._updateMultiCanvasDimensions();return}const{canvas:t}=this,[n,s]=e?e.getCSSSize():[(t==null?void 0:t.clientWidth)??(t==null?void 0:t.width)??0,(t==null?void 0:t.clientHeight)??(t==null?void 0:t.height)??0];(n!==this.width||s!==this.height)&&(this.width=n,this.height=s,(r=this.viewManager)==null||r.setProps({width:n,height:s}),(o=this.layerManager)==null||o.activateViewport(this.getViewports()[0]),this.props.onResize({width:n,height:s},e||void 0))}_onCanvasContextResize(e,t={}){if(t.syncDrawingBuffer){const{width:n,height:s}=e.canvas;e.setDrawingBufferSize(n,s)}this._needsRedraw="Canvas resized",this._updateCanvasSize(e)}_updateMultiCanvasDimensions(){var n,s,r;const[e,t]=((n=this._getCanvasContext())==null?void 0:n.getCSSSize())||[0,0];(e!==this.width||t!==this.height)&&(this.width=e,this.height=t,this.props.onResize({width:e,height:t})),this._needsRedraw="Canvas resized",(s=this.viewManager)==null||s.setNeedsUpdate("Canvas resized"),(r=this.viewManager)==null||r.setProps({width:this.width,height:this.height})}_createAnimationLoop(e,t){const{gl:n,onError:s}=t;return new qa({device:e,autoResizeDrawingBuffer:!n&&!Array.isArray(t._canvases),autoResizeViewport:!1,onInitialize:r=>this._setDevice(r.device),onRender:this._onRenderFrame.bind(this),onError:s})}_createDevice(e){var o,a;const t=(o=this.props.deviceProps)==null?void 0:o.createCanvasContext,n=typeof t=="object"?t:void 0,s={adapters:[],_cacheShaders:!0,_cachePipelines:!0,...e.deviceProps,debug:zf(e)};s.adapters.includes(Do)||s.adapters.push(Do);const r={alphaMode:((a=this.props.deviceProps)==null?void 0:a.type)==="webgpu"?"premultiplied":void 0};return va.createDevice({_reuseDevices:!0,type:"webgl",...s,createCanvasContext:{...r,...n,canvas:this._createDeviceCanvas(e),useDevicePixels:this.props.useDevicePixels,autoResize:!0}})}_getViewState(){return this.props.viewState||this.viewState}_getViews(){const{views:e}=this.props,t=Array.isArray(e)?e:e?[e]:[new ll({id:"default-view"})];return t.length&&this.props.controller&&(t[0]=t[0].clone({controller:this.props.controller})),t}_onContextLost(){const{onError:e}=this.props;this.animationLoop&&e&&e(new Error("WebGL context is lost"))}_pickAndCallback(){var t;const{_pickRequest:e}=this;if(e.event){const n=e.event,s=((t=this.layerManager)==null?void 0:t.getLayers())||[],r=this._getPointPickOptions(e.x,e.y,{canvasId:e.canvasId,radius:e.radius,mode:e.mode},s),o=this._getInternalPickingMode(),a=++this._hoverPickSequence;if(e.event=null,e.canvasId=void 0,!o)return;if(o==="sync"){this._applyHoverCallbacks(this._pickPointSync(r),n);return}this._pickPointAsync(r).then(({result:c,emptyInfo:l})=>{a===this._hoverPickSequence&&this._applyHoverCallbacks({result:c,emptyInfo:l},n)}).catch(c=>{var l,u;return(u=(l=this.props).onError)==null?void 0:u.call(l,c)})}}_updateCursor(){const e=this.props.getCursor(this.cursorState);if(this._isMultiCanvasMode()){for(const n of Object.values(this._canvasManager.targets))n.canvas.style.cursor=e;return}const t=this.props.parent||this.canvas;t&&(t.style.cursor=e)}_setDevice(e){var r,o,a;if(this.device=e,this._validateInternalPickingMode(),!this.animationLoop)return;this._setDeviceCanvasContext(e,{syncDrawingBuffer:!!(this.props.gl&&this.props.device!==e)}),this._isMultiCanvasMode()?this._syncCanvasTargets():this.canvas&&!this.canvas.isConnected&&this.props.parent&&this.props.parent.insertBefore(this.canvas,this.props.parent.firstChild),this.device.type==="webgl"&&this.device.setParametersWebGL({blend:!0,blendFunc:[770,771,1,771],polygonOffsetFill:!0,depthTest:!0,depthFunc:515}),this.props.onDeviceInitialized(this.device),this.device.type==="webgl"&&this.props.onWebGLInitialized(this.device.gl);const t=new Rg;if(t.play(),this.animationLoop.attachTimeline(t),!this._isMultiCanvasMode()){const c=this.canvas&&this._getEventRoot(this.canvas);Q(c),this.eventManager=this._createEventManager(c),this.eventManagers={[fi]:this.eventManager}}this.viewManager=new M3({timeline:t,eventManager:this.eventManager,eventManagers:this.eventManagers,getCanvasContext:this._isMultiCanvasMode()?this.getCanvasContext.bind(this):void 0,onViewStateChange:this._onViewStateChange.bind(this),onInteractionStateChange:this._onInteractionStateChange.bind(this),pickPosition:this._pickPositionForController.bind(this),views:this._getViews(),viewState:this._getViewState(),width:this.width,height:this.height});const n=this.viewManager.getViewports()[0];this.layerManager=new A3(this.device,{deck:this,stats:this.stats,viewport:n,timeline:t}),this.effectManager=new Q3({deck:this,device:this.device}),this.deckRenderer=new tC(this.device,{stats:this.stats}),this.deckPicker=new sC(this.device,{stats:this.stats});const s=((r=this.props.parent)==null?void 0:r.querySelector(".deck-widgets-root"))||(this._isMultiCanvasMode()?this.props.parent||((o=this.canvas)==null?void 0:o.parentElement):null)||((a=this.canvas)==null?void 0:a.parentElement);this.widgetManager=new aC({deck:this,parentElement:s}),this.widgetManager.addDefault(new Wg),this.setProps({}),this._updateCanvasSize(this._canvasContext),this.props.onLoad()}_drawLayers(e,t){var o,a,c;const{device:n,gl:s}=this.layerManager.context;this.props.onBeforeRender({device:n,gl:s});const r={target:this.props._framebuffer,layers:this.layerManager.getLayers(),viewports:this.viewManager.getViewports(),onViewportActive:this.layerManager.activateViewport,views:this.viewManager.getViews(),pass:"screen",effects:this.effectManager.getEffects(),...t};if(this._isMultiCanvasMode()&&r.pass==="screen"&&!r.target&&this._canvasManager.order.length)for(const l of this._canvasManager.order){const u=r.viewports.filter(g=>this.viewManager.getCanvasId(g.id)===l);if(!u.length){const g=this._canvasManager.targets[l];this._resizeForCanvasTarget(l),(o=this.deckRenderer)==null||o.renderLayers({...r,canvasContext:g.presentationContext,target:g.presentationContext.getCurrentFramebuffer(),viewports:[],clearCanvas:!0}),g.presentationContext.present();continue}const f=this._canvasManager.targets[l];this._resizeForCanvasTarget(l);const d=f.presentationContext.getCurrentFramebuffer();(a=this.deckRenderer)==null||a.renderLayers({...r,canvasContext:f.presentationContext,target:d,viewports:u}),f.presentationContext.present()}else(c=this.deckRenderer)==null||c.renderLayers(r);r.pass==="screen"&&this.widgetManager.onRedraw({viewports:r.viewports,layers:r.layers}),this.props.onAfterRender({device:n,gl:s})}_onRenderFrame(){this._getFrameStats(),this._metricsCounter++%60===0&&(this._getMetrics(),this.stats.reset(),Y.table(4,this.metrics)(),this.props._onMetrics&&this.props._onMetrics(this.metrics)),this._updateCursor(),this.layerManager.updateLayers(),this._pickAndCallback(),this.redraw(),this.viewManager&&this.viewManager.updateViewStates()}_onViewStateChange(e){const t=this.props.onViewStateChange(e)||e.viewState;this.viewState&&(this.viewState={...this.viewState,[e.viewId]:t},this.props.viewState||this.viewManager&&this.viewManager.setProps({viewState:this.viewState}))}_onInteractionStateChange(e){this.cursorState.isDragging=e.isDragging||!1,this.props.onInteractionStateChange(e)}_getFrameStats(){const{stats:e}=this;e.get("frameRate").timeEnd(),e.get("frameRate").timeStart();const t=this.animationLoop.stats;e.get("GPU Time").addTime(t.get("GPU Time").lastTiming),e.get("CPU Time").addTime(t.get("CPU Time").lastTiming)}_getMetrics(){var s;const{metrics:e,stats:t}=this;e.fps=t.get("frameRate").getHz(),e.setPropsTime=t.get("setProps Time").time,e.updateAttributesTime=t.get("Update Attributes").time,e.framesRedrawn=t.get("Redraw Count").count,e.pickTime=t.get("pickObject Time").time+t.get("pickMultipleObjects Time").time+t.get("pickObjects Time").time,e.pickCount=t.get("Pick Count").count,e.layersCount=((s=this.layerManager)==null?void 0:s.layers.length)??0,e.drawLayersCount=t.get("Layers rendered").lastSampleCount,e.pickLayersCount=t.get("Layers picked").lastSampleCount,e.updateLayersCount=t.get("Layer updates").count,e.updateAttributesCount=t.get("Attributes updated").count,e.gpuTime=t.get("GPU Time").time,e.cpuTime=t.get("CPU Time").time,e.gpuTimePerFrame=t.get("GPU Time").getAverageTime(),e.cpuTimePerFrame=t.get("CPU Time").getAverageTime();const n=va.stats.get("GPU Time and Memory");e.bufferMemory=n.get("Buffer Memory").count,e.textureMemory=n.get("Texture Memory").count,e.renderbufferMemory=n.get("Renderbuffer Memory").count,e.gpuMemory=n.get("GPU Memory").count}}Hr.defaultProps=cp;Hr.VERSION=Gy;function fT(i){switch(i){case"float64":return Float64Array;case"uint8":case"unorm8":return Uint8ClampedArray;default:return Ic(i)}}const dT=et.getDataType.bind(et);function cs(i,e,t){if(e.size>4)return null;const n=t==="webgpu"&&e.type==="uint8"?"unorm8":e.type,s=e.size,r=!!(t!=="webgpu"&&s===3&&n&&["uint8","sint8","unorm8","snorm8","uint16","sint16","unorm16","snorm16"].includes(n));return{attribute:i,format:s>1?`${n}x${s}${r?"-webgl":""}`:e.type,byteOffset:e.offset||0}}function Qe(i){return i.stride||i.size*i.bytesPerElement}function hT(i,e){return i.type===e.type&&i.size===e.size&&Qe(i)===Qe(e)&&(i.offset||0)===(e.offset||0)}function oc(i,e){e.offset&&Y.removed("shaderAttribute.offset","vertexOffset, elementOffset")();const t=Qe(i),n=e.vertexOffset!==void 0?e.vertexOffset:i.vertexOffset||0,s=e.elementOffset||0,r=n*t+s*i.bytesPerElement+(i.offset||0);return{...e,offset:r,stride:t}}function gT(i,e){const t=oc(i,e);return{high:t,low:{...t,offset:t.offset+i.size*4}}}class pT{constructor(e,t,n){this._buffer=null,this.device=e,this.id=t.id||"",this.size=t.size||1;const s=t.logicalType||t.type,r=s==="float64";let{defaultValue:o}=t;o=Number.isFinite(o)?[o]:o||new Array(this.size).fill(0);let a;r?a="float32":!s&&t.isIndexed?a="uint32":a=s||"float32";let c=fT(s||a);this.doublePrecision=r,r&&t.fp64===!1&&(c=Float32Array),this.value=null,this.settings={...t,defaultType:c,defaultValue:o,logicalType:s,type:a,normalized:a.includes("norm"),size:this.size,bytesPerElement:c.BYTES_PER_ELEMENT},this.state={...n,externalBuffer:null,bufferAccessor:this.settings,allocatedValue:null,numInstances:0,bounds:null,constant:!1}}get isConstant(){return this.state.constant}get buffer(){return this._buffer}get byteOffset(){const e=this.getAccessor();return e.vertexOffset?e.vertexOffset*Qe(e):0}get numInstances(){return this.state.numInstances}set numInstances(e){this.state.numInstances=e}get isDoublePrecisionBuffer(){return this._shouldSplitDoublePrecisionValue(this.value)}delete(){this._buffer&&(this._buffer.delete(),this._buffer=null),vi.release(this.state.allocatedValue),this.state.allocatedValue=null}getBuffer(){return this.state.constant&&this.device.type!=="webgpu"?null:this.state.externalBuffer||this._buffer}getValue(e=this.id,t=null){const n={};if(this.state.constant){const s=this.value;if(this.device.type==="webgpu"&&this._buffer)n[e]=this._buffer;else if(t){const r=oc(this.getAccessor(),t),o=r.offset/s.BYTES_PER_ELEMENT,a=r.size||this.size;n[e]=s.subarray(o,o+a)}else n[e]=s}else n[e]=this.getBuffer();return this.doublePrecision&&(this.isDoublePrecisionBuffer?n[`${e}64Low`]=n[e]:n[`${e}64Low`]=new Float32Array(this.size)),n}_getBufferLayout(e=this.id,t=null){const n=this.getAccessor(),s=[],r={name:this.id,byteStride:this.device.type==="webgpu"&&this.state.constant?0:Qe(n)};if(this.doublePrecision){const o=gT(n,t||{});s.push(cs(e,{...n,...o.high},this.device.type),cs(`${e}64Low`,{...n,...o.low},this.device.type))}else if(t){const o=oc(n,t);s.push(cs(e,{...n,...o},this.device.type))}else s.push(cs(e,n,this.device.type));return r.attributes=s.filter(Boolean),r}setAccessor(e){this.state.bufferAccessor=e}getAccessor(){return this.state.bufferAccessor}getBounds(){if(this.state.bounds)return this.state.bounds;let e=null;if(this.state.constant&&this.value){const t=Array.from(this.value);e=[t,t]}else{const{value:t,numInstances:n,size:s}=this,r=n*s;if(t&&r&&t.length>=r){const o=new Array(s).fill(1/0),a=new Array(s).fill(-1/0);for(let c=0;c<r;)for(let l=0;l<s;l++){const u=t[c++];u<o[l]&&(o[l]=u),u>a[l]&&(a[l]=u)}e=[o,a]}}return this.state.bounds=e,e}setData(e){const{state:t}=this;let n;ArrayBuffer.isView(e)?n={value:e}:e instanceof W?n={buffer:e}:n=e;const s={...this.settings,...n};if(ArrayBuffer.isView(n.value)){if(!n.type)if(this.doublePrecision&&n.value instanceof Float64Array)s.type="float32";else{const o=dT(n.value);s.type=s.normalized?o.replace("int","norm"):o}s.bytesPerElement=n.value.BYTES_PER_ELEMENT,s.stride=Qe(s)}if(t.bounds=null,n.constant){let r=n.value;if(r=this._normalizeValue(r,[],0),this.settings.normalized&&(r=this.normalizeConstant(r)),!(!t.constant||!this._areValuesEqual(r,this.value)))return!1;t.externalBuffer=null,t.constant=!0,this.value=ArrayBuffer.isView(r)?r:new Float32Array(r)}else if(n.buffer){const r=n.buffer;t.externalBuffer=r,t.constant=!1,this.value=n.value||null}else if(n.value){this._checkExternalBuffer(n);const r=n.value;let o=r;t.externalBuffer=null,t.constant=!1,this.value=r,this._shouldSplitDoublePrecisionValue(o)&&(o=Ss(o,s),r instanceof Float32Array&&(s.stride=s.size*2*Float32Array.BYTES_PER_ELEMENT));let{buffer:a}=this;const c=Qe(s),l=(s.vertexOffset||0)*c;if(this.settings.isIndexed){const f=this.settings.defaultType;o.constructor!==f&&(o=new f(o))}const u=o.byteLength+l+c*2;(!a||a.byteLength<u)&&(a=this._createBuffer(u)),a.write(o,l)}return this.setAccessor(s),!0}updateSubBuffer(e={}){this.state.bounds=null;const t=this.value,{startOffset:n=0,endOffset:s}=e,r=this._shouldSplitDoublePrecisionValue(t);this.buffer.write(r?Ss(t,{size:this.size,startIndex:n,endIndex:s}):t.subarray(n,s),n*(r?8:t.BYTES_PER_ELEMENT)+this.byteOffset)}allocate(e,t=!1){const{state:n}=this,s=n.allocatedValue,r=vi.allocate(s,e+1,{size:this.size,type:this.settings.defaultType,copy:t});this.value=r;const o=this._shouldSplitDoublePrecisionValue(r),a=o&&r instanceof Float32Array?{...this.settings,stride:this.size*2*Float32Array.BYTES_PER_ELEMENT}:this.settings;this.setAccessor(a);const{byteOffset:c}=this;let{buffer:l}=this;const u=r.byteLength*(o&&r instanceof Float32Array?2:1);return(!l||l.byteLength<u+c)&&(l=this._createBuffer(u+c),t&&s&&l.write(this._shouldSplitDoublePrecisionValue(s)?Ss(s,this):s,c)),n.allocatedValue=r,n.constant=!1,n.externalBuffer=null,!0}_shouldSplitDoublePrecisionValue(e){return!!(this.doublePrecision&&(e instanceof Float64Array||this.device.type==="webgpu"&&e instanceof Float32Array))}_checkExternalBuffer(e){const{value:t}=e;if(!ArrayBuffer.isView(t))throw new Error(`Attribute ${this.id} value is not TypedArray`);const n=this.settings.defaultType;let s=!1;if(this.doublePrecision&&(s=t.BYTES_PER_ELEMENT<4),s)throw new Error(`Attribute ${this.id} does not support ${t.constructor.name}`);!(t instanceof n)&&this.settings.normalized&&!("normalized"in e)&&Y.warn(`Attribute ${this.id} is normalized`)()}normalizeConstant(e){switch(this.settings.type){case"snorm8":return new Float32Array(e).map(t=>(t+128)/255*2-1);case"snorm16":return new Float32Array(e).map(t=>(t+32768)/65535*2-1);case"unorm8":return new Float32Array(e).map(t=>t/255);case"unorm16":return new Float32Array(e).map(t=>t/65535);default:return e}}_normalizeValue(e,t,n){const{defaultValue:s,size:r}=this.settings;if(Number.isFinite(e))return t[n]=e,t;if(!e){let o=r;for(;--o>=0;)t[n+o]=s[o];return t}switch(r){case 4:t[n+3]=Number.isFinite(e[3])?e[3]:s[3];case 3:t[n+2]=Number.isFinite(e[2])?e[2]:s[2];case 2:t[n+1]=Number.isFinite(e[1])?e[1]:s[1];case 1:t[n+0]=Number.isFinite(e[0])?e[0]:s[0];break;default:let o=r;for(;--o>=0;)t[n+o]=Number.isFinite(e[o])?e[o]:s[o]}return t}_areValuesEqual(e,t){if(!e||!t)return!1;const{size:n}=this;for(let s=0;s<n;s++)if(e[s]!==t[s])return!1;return!0}_createBuffer(e){var r;this._buffer&&this._buffer.destroy();const{isIndexed:t,type:n}=this.settings,s=this.device.type==="webgpu"&&!t?W.VERTEX|W.STORAGE|W.COPY_DST|W.COPY_SRC:(t?W.INDEX:W.VERTEX)|W.COPY_DST;return this._buffer=this.device.createBuffer({...(r=this._buffer)==null?void 0:r.props,id:this.id,usage:s,indexType:t?n:void 0,byteLength:e}),this._buffer}}const Nf=[],Uf=[];function Ii(i,e=0,t=1/0){let n=Nf;const s={index:-1,data:i,target:[]};return i?typeof i[Symbol.iterator]=="function"?n=i:i.length>0&&(Uf.length=i.length,n=Uf):n=Nf,(e>0||Number.isFinite(t))&&(n=(Array.isArray(n)?n:Array.from(n)).slice(e,t),s.index=e-1),{iterable:n,objectInfo:s}}function lp(i){return i&&i[Symbol.asyncIterator]}function up(i,e){const{size:t,stride:n,offset:s,startIndices:r,nested:o}=e,a=i.BYTES_PER_ELEMENT,c=n?n/a:t,l=s?s/a:0,u=Math.floor((i.length-l)/c);return(f,{index:d,target:g})=>{if(!r){const v=d*c+l;for(let w=0;w<t;w++)g[w]=i[v+w];return g}const p=r[d],m=r[d+1]||u;let _;if(o){_=new Array(m-p);for(let v=p;v<m;v++){const w=v*c+l;g=new Array(t);for(let y=0;y<t;y++)g[y]=i[w+y];_[v-p]=g}}else if(c===t)_=i.subarray(p*t+l,m*t+l);else{_=new i.constructor((m-p)*t);let v=0;for(let w=p;w<m;w++){const y=w*c+l;for(let x=0;x<t;x++)_[v++]=i[y+x]}}return _}}const mT=[],Cs=[[0,1/0]];function _T(i,e){if(i===Cs||(e[0]<0&&(e[0]=0),e[0]>=e[1]))return i;const t=[],n=i.length;let s=0;for(let r=0;r<n;r++){const o=i[r];o[1]<e[0]?(t.push(o),s=r+1):o[0]>e[1]?t.push(o):e=[Math.min(o[0],e[0]),Math.max(o[1],e[1])]}return t.splice(s,0,e),t}const yT={interpolation:{duration:0,easing:i=>i},spring:{stiffness:.05,damping:.5}};function fp(i,e){if(!i)return null;Number.isFinite(i)&&(i={type:"interpolation",duration:i});const t=i.type||"interpolation";return{...yT[t],...e,...i,type:t}}class dp extends pT{constructor(e,t){super(e,t,{startIndices:null,constantValue:null,lastExternalBuffer:null,binaryValue:null,binaryAccessor:null,needsUpdate:!0,needsRedraw:!1,layoutChanged:!1,updateRanges:Cs}),this.constant=!1,this.settings.update=t.update||(t.accessor?this._autoUpdater:void 0),Object.seal(this.settings),Object.seal(this.state),this._validateAttributeUpdaters()}get startIndices(){return this.state.startIndices}set startIndices(e){this.state.startIndices=e}needsUpdate(){return this.state.needsUpdate}needsRedraw({clearChangedFlags:e=!1}={}){const t=this.state.needsRedraw;return this.state.needsRedraw=t&&!e,t}layoutChanged(){return this.state.layoutChanged}setAccessor(e){var t;(t=this.state).layoutChanged||(t.layoutChanged=!hT(e,this.getAccessor())),super.setAccessor(e)}getUpdateTriggers(){const{accessor:e}=this.settings;return[this.id].concat(typeof e!="function"&&e||[])}supportsTransition(){return!!this.settings.transition}getTransitionSetting(e){if(!e||!this.supportsTransition())return null;const{accessor:t}=this.settings,n=this.settings.transition,s=Array.isArray(t)?e[t.find(r=>e[r])]:e[t];return fp(s,n)}setNeedsUpdate(e=this.id,t){if(this.state.needsUpdate=this.state.needsUpdate||e,this.setNeedsRedraw(e),t){const{startRow:n=0,endRow:s=1/0}=t;this.state.updateRanges=_T(this.state.updateRanges,[n,s])}else this.state.updateRanges=Cs}clearNeedsUpdate(){this.state.needsUpdate=!1,this.state.updateRanges=mT}setNeedsRedraw(e=this.id){this.state.needsRedraw=this.state.needsRedraw||e}allocate(e){const{state:t,settings:n}=this;if(n.noAlloc)return!1;if(n.update){const s=this.isConstant;return super.allocate(e,t.updateRanges!==Cs),t.layoutChanged||(t.layoutChanged=s&&this.device.type==="webgpu"),!0}return!1}updateBuffer({numInstances:e,data:t,props:n,context:s}){if(!this.needsUpdate())return!1;const{state:{updateRanges:r},settings:{update:o,noAlloc:a}}=this;let c=!0;if(o){for(const[l,u]of r)o.call(s,this,{data:t,startRow:l,endRow:u,props:n,numInstances:e});if(this.value)if(this.constant||!this.buffer||this.buffer.byteLength<this.value.byteLength+this.byteOffset){if(this.constant){const l=this.value;this.value=null,this.setConstantValue(s,l)}else this.setData({value:this.value,constant:this.constant});this.constant=!1}else for(const[l,u]of r){const f=Number.isFinite(l)?this.getVertexOffset(l):0,d=Number.isFinite(u)?this.getVertexOffset(u):a||!Number.isFinite(e)?this.value.length:e*this.size;super.updateSubBuffer({startOffset:f,endOffset:d})}this._checkAttributeArray()}else c=!1;return this.clearNeedsUpdate(),this.setNeedsRedraw(),c}setConstantValue(e,t){var n;if(t===void 0||typeof t=="function")return!1;const s=this.isConstant,r=this.settings.transform&&e?this.settings.transform.call(e,t):t,o=this.settings.defaultType;this.state.constantValue=this._normalizeValue(r,new o(this.size),0);const a=this.setData({constant:!0,value:r});if(this.device.type==="webgpu"){let c=this.state.constantValue;this.doublePrecision&&(c instanceof Float32Array||c instanceof Float64Array)&&(c=Ss(c,{size:this.size}),this.setAccessor({...this.getAccessor(),stride:this.size*2*Float32Array.BYTES_PER_ELEMENT}));let l=this._buffer;(!l||l.byteLength<c.byteLength)&&(l=this._createBuffer(c.byteLength)),l.write(c),(n=this.state).layoutChanged||(n.layoutChanged=!s),this.constant=!1}return a&&this.setNeedsRedraw(),this.clearNeedsUpdate(),!0}getConstantValue(){return this.isConstant?this.state.constantValue:null}setExternalBuffer(e){const{state:t}=this;return e?(this.clearNeedsUpdate(),t.lastExternalBuffer===e||(t.lastExternalBuffer=e,this.setNeedsRedraw(),this.setData(e)),!0):(t.lastExternalBuffer=null,!1)}setBinaryValue(e,t=null){const{state:n,settings:s}=this;if(!e)return n.binaryValue=null,n.binaryAccessor=null,!1;if(s.noAlloc)return!1;if(n.binaryValue===e)return this.clearNeedsUpdate(),!0;if(n.binaryValue=e,this.setNeedsRedraw(),s.transform||t!==this.startIndices){ArrayBuffer.isView(e)&&(e={value:e});const o=e;Q(ArrayBuffer.isView(o.value),`invalid ${s.accessor}`);const a=!!o.size&&o.size!==this.size;return n.binaryAccessor=up(o.value,{size:o.size||this.size,stride:o.stride,offset:o.offset,startIndices:t,nested:a}),!1}return this.clearNeedsUpdate(),this.setData(e),!0}getVertexOffset(e){const{startIndices:t}=this;return(t?e<t.length?t[e]:this.numInstances:e)*this.size}getValue(){const e=this.settings.shaderAttributes,t=super.getValue();if(!e)return t;for(const n in e)Object.assign(t,super.getValue(n,e[n]));return t}getBufferLayout(e){this.state.layoutChanged=!1;const t=this.settings.shaderAttributes,n=super._getBufferLayout(),{stepMode:s}=this.settings;if(s==="dynamic"?n.stepMode=e?e.isInstanced?"instance":"vertex":"instance":n.stepMode=s??"vertex",!t)return n;for(const r in t){const o=super._getBufferLayout(r,t[r]);n.attributes.push(...o.attributes)}return n}_autoUpdater(e,{data:t,startRow:n,endRow:s,props:r,numInstances:o}){const{settings:a,state:c,value:l,size:u,startIndices:f}=e,{accessor:d,transform:g}=a,p=c.binaryAccessor||(typeof d=="function"?d:r[d]);Q(typeof p=="function",`accessor "${d}" is not a function`);let m=e.getVertexOffset(n);const{iterable:_,objectInfo:v}=Ii(t,n,s);for(const w of _){v.index++;let y=p(w,v);if(g&&(y=g.call(this,y)),f){const x=(v.index<f.length-1?f[v.index+1]:o)-f[v.index];if(y&&Array.isArray(y[0])){let S=m;for(const C of y)e._normalizeValue(C,l,S),S+=u}else y&&y.length>u?l.set(y,m):(e._normalizeValue(y,v.target,0),S3({target:l,source:v.target,start:m,count:x}));m+=x*u}else e._normalizeValue(y,l,m),m+=u}}_validateAttributeUpdaters(){const{settings:e}=this;if(!(e.noAlloc||typeof e.update=="function"))throw new Error(`Attribute ${this.id} missing update or accessor`)}_checkAttributeArray(){const{value:e}=this,t=Math.min(4,this.size);if(e&&e.length>=t){let n=!0;switch(t){case 4:n=n&&Number.isFinite(e[3]);case 3:n=n&&Number.isFinite(e[2]);case 2:n=n&&Number.isFinite(e[1]);case 1:n=n&&Number.isFinite(e[0]);break;default:n=!1}if(!n)throw new Error(`Illegal attribute generated for ${this.id}`)}}}const hp=/^vertex-list<([^<>]+)>$/,gp=/^value-list<([^<>]+)>$/;function pp(i){return hp.test(i)}function mp(i){return gp.test(i)}function bT(i){const e=hp.exec(i),t=gp.exec(i),n=(e==null?void 0:e[1])??(t==null?void 0:t[1])??i;try{be.getVertexFormatInfo(n)}catch{throw new Error(`Unsupported GPUVector format ${i}`)}return n}function Un(i){const e=bT(i),t=pp(i),n=mp(i),s=be.getVertexFormatInfo(e),r=s.type,o=s.normalized,a=vT(r,o);return{format:i,elementFormat:e,vertexList:t,valueList:n,type:r,signedDataType:wT(e,r),primitiveType:a,components:s.components,byteLength:s.byteLength,integer:s.integer,signed:s.signed,normalized:o,...s.webglOnly?{webglOnly:!0}:{}}}function vT(i,e){if(e)return"f32";switch(i){case"float32":return"f32";case"float16":return"f16";case"uint8":case"uint16":case"uint32":return"u32";case"sint8":case"sint16":case"sint32":return"i32";default:throw new Error(`Unsupported GPUVector component type ${i}`)}}function wT(i,e){if(i==="unorm10-10-10-2")return"uint32";switch(e){case"unorm8":return"uint8";case"snorm8":return"sint8";case"unorm16":return"uint16";case"snorm16":return"sint16";default:return e}}class lr{constructor(e){h(this,"buffer");h(this,"format");h(this,"length");h(this,"byteOffset");h(this,"byteStride");const t=be.getVertexFormatInfo(e.format).byteLength,n=e.byteOffset??0,s=e.byteStride??t;if(Wo(e.length,"GPUDataView length"),Wo(n,"GPUDataView byteOffset"),Wo(s,"GPUDataView byteStride"),s<t)throw new Error(`GPUDataView byteStride ${s} is smaller than ${e.format} byte length ${t}`);const r=e.length===0?0:(e.length-1)*s+t,o=n+r;if(!Number.isSafeInteger(r)||!Number.isSafeInteger(o))throw new Error("GPUDataView byte range must use safe integers");if(o>e.buffer.byteLength)throw new Error("GPUDataView exceeds its backing buffer byte length");this.buffer=e.buffer,this.format=e.format,this.length=e.length,this.byteOffset=n,this.byteStride=s}get elementByteLength(){return be.getVertexFormatInfo(this.format).byteLength}get byteLength(){return this.length===0?0:(this.length-1)*this.byteStride+this.elementByteLength}}function Wo(i,e){if(!Number.isSafeInteger(i)||i<0)throw new Error(`${e} must be a non-negative safe integer`)}function Ho(i){return!!(i&&typeof i=="object"&&i.type==="struct")}function xT(i,e){const t=Object.entries(i);if(t.length===0)throw new Error("GPUData struct format must declare at least one field");return e==="packed"?PT(t):ST(t)}function PT(i){const e=[];let t=0,n=0;for(const[s,r]of i){const o=be.getVertexFormatInfo(r);if(o.webglOnly)throw new Error(`Packed GPUData struct field "${s}" uses WebGL-only format ${r}`);t=$f(t,Math.min(4,o.byteLength)),e.push([s,Object.freeze({format:r,byteOffset:t,byteLength:o.byteLength})]),t+=o.byteLength,n+=o.components}return Object.freeze({type:"struct",layout:"packed",fields:Object.freeze(Object.fromEntries(e)),components:n,byteStride:$f(t,4),rowByteLength:t})}function ST(i){const e=Object.fromEntries(i.map(([o,a])=>[o,ET(a)])),t=Nc(e,{layout:"wgsl-storage"}),n=[];let s=0,r=0;for(const[o,a]of i){const c=be.getVertexFormatInfo(a),l=t.fields[o].offset*4;n.push([o,Object.freeze({format:a,byteOffset:l,byteLength:c.byteLength})]),s=Math.max(s,l+c.byteLength),r+=c.components}return Object.freeze({type:"struct",layout:"wgsl-storage",fields:Object.freeze(Object.fromEntries(n)),components:r,byteStride:t.byteLength,rowByteLength:s})}function ET(i){const e=be.getVertexFormatInfo(i);switch(e.type){case"float32":return ls("f32",e.components);case"sint32":return ls("i32",e.components);case"uint32":return ls("u32",e.components);default:{const t=Math.ceil(e.byteLength/4);return ls("u32",t)}}}function ls(i,e){return e===1?i:`vec${e}<${i}>`}function $f(i,e){return Math.ceil(i/e)*e}class CT{constructor(e,t){h(this,"buffer");h(this,"ownsDataBuffer");this.buffer=e,this.ownsDataBuffer=t}get ownsBuffer(){return this.ownsDataBuffer}transferBufferOwnership(e){if(e.buffer!==this.buffer)throw new Error("GPUData ownership can only be transferred to the same buffer");e.ownsDataBuffer=this.ownsDataBuffer,this.ownsDataBuffer=!1}destroy(){this.ownsDataBuffer&&(this.buffer.destroy(),this.ownsDataBuffer=!1)}}class LT extends CT{constructor(t){const{buffer:n,format:s,length:r,valueLength:o,stride:a,byteOffset:c=0,byteStride:l,rowByteLength:u,ownsBuffer:f=!1,readbackMetadata:d,valueOffsets:g,nullBitmap:p,valueByteLength:m,dataType:_}=t;super(n,f);h(this,"dataType");h(this,"format");h(this,"length");h(this,"valueLength");h(this,"stride");h(this,"byteOffset");h(this,"byteStride");h(this,"rowByteLength");h(this,"readbackMetadata");h(this,"valueOffsets");h(this,"nullBitmap");h(this,"valueByteLength");let v;s?typeof s=="string"?v=s:v=xT(s,t.layout??"wgsl-storage"):v=void 0;const w=Ho(v)?v:void 0,y=typeof v=="string"?Un(v):void 0;if(this.dataType=_,this.format=v,this.length=r,this.valueLength=o??r,this.stride=a??(y==null?void 0:y.components)??(w==null?void 0:w.components)??l??u??1,this.byteOffset=c,this.rowByteLength=u??(w==null?void 0:w.rowByteLength)??(y==null?void 0:y.byteLength)??l??this.stride,this.byteStride=l??(w==null?void 0:w.byteStride)??this.rowByteLength,w){if(this.rowByteLength<w.rowByteLength)throw new Error(`GPUData rowByteLength ${this.rowByteLength} is smaller than struct format row byte length ${w.rowByteLength}`);if(this.byteStride<Math.max(w.byteStride,this.rowByteLength))throw new Error(`GPUData byteStride ${this.byteStride} is smaller than its struct row layout`)}this.readbackMetadata=d,this.valueOffsets=g,this.nullBitmap=p,this.valueByteLength=m}getChild(t){if(!Ho(this.format))return null;const n=this.format.fields[t];return n?new lr({buffer:this.buffer,format:n.format,length:this.length,byteOffset:this.byteOffset+n.byteOffset,byteStride:this.byteStride}):null}getChildAt(t){if(!Ho(this.format))return null;const n=Object.values(this.format.fields)[t];return n?new lr({buffer:this.buffer,format:n.format,length:this.length,byteOffset:this.byteOffset+n.byteOffset,byteStride:this.byteStride}):null}}const ac=LT;class an{constructor(e){h(this,"name");h(this,"dataType");h(this,"format");h(this,"length");h(this,"valueLength");h(this,"stride");h(this,"byteOffset");h(this,"byteStride");h(this,"rowByteLength");h(this,"bufferLayout");h(this,"data",[]);h(this,"device");h(this,"bufferProps");h(this,"isAppendable",!1);h(this,"ownsDataChunks",!0);h(this,"ownedVectors",[]);h(this,"appendableByteLength",0);var t,n,s;switch(e.type){case"buffer":{const{name:r,buffer:o,format:a,length:c,valueLength:l=c,byteOffset:u=0,ownsBuffer:f=!1}=e,{stride:d,byteStride:g,rowByteLength:p}=Gf(e);this.name=r,this.dataType=e.dataType,this.format=a,this.length=c,this.valueLength=l,this.stride=d,this.byteOffset=u,this.byteStride=g,this.rowByteLength=p,this.data.push(new ac({buffer:o,format:a,length:c,valueLength:l,stride:d,byteOffset:u,byteStride:g,rowByteLength:p,ownsBuffer:f,dataType:e.dataType}));return}case"interleaved":{const{name:r,buffer:o,format:a,length:c,valueLength:l=c,byteOffset:u=0,byteStride:f,attributes:d,ownsBuffer:g=!1}=e;this.name=r,this.dataType=e.dataType,this.format=a,this.length=c,this.valueLength=l,this.stride=f,this.byteOffset=u,this.byteStride=f,this.rowByteLength=f,this.bufferLayout={name:r,byteStride:f,attributes:d},this.data.push(new ac({buffer:o,format:a,length:c,valueLength:l,stride:f,byteOffset:u,byteStride:f,rowByteLength:f,ownsBuffer:g,dataType:e.dataType}));return}case"data":{const r=e.format??TT(e.data),o=r?Un(r):void 0,{name:a,data:c,stride:l=((t=c[0])==null?void 0:t.stride)??(o==null?void 0:o.components)??1,valueLength:u=c.reduce((m,_)=>m+_.valueLength,0),byteStride:f=((n=c[0])==null?void 0:n.byteStride)??(o==null?void 0:o.byteLength),rowByteLength:d=((s=c[0])==null?void 0:s.rowByteLength)??(o==null?void 0:o.byteLength),bufferLayout:g,ownsData:p=!1}=e;if(f===void 0||d===void 0)throw new Error("GPUVector requires format or explicit byte layout metadata");r&&AT(c,r),this.name=a,this.dataType=e.dataType,this.format=r,this.length=c.reduce((m,_)=>m+_.length,0),this.valueLength=u,this.stride=l,this.byteOffset=c.length===1?c[0].byteOffset:0,this.byteStride=f,this.rowByteLength=d,this.bufferLayout=g,this.ownsDataChunks=p,this.data.push(...c);return}case"appendable":{const{name:r,device:o,format:a,valueLength:c=0,bufferProps:l}=e,{stride:u,byteStride:f,rowByteLength:d}=Gf(e);this.name=r,this.dataType=e.dataType,this.format=a,this.length=0,this.valueLength=c,this.stride=u,this.byteOffset=0,this.byteStride=f,this.rowByteLength=d,this.device=o,this.bufferProps=l,this.isAppendable=!0;return}}}get ownsBuffer(){return this.ownsDataChunks&&this.data.some(e=>e.ownsBuffer)||this.ownedVectors.some(e=>e.ownsBuffer)}get capacityRows(){return this.isAppendable?this.length:void 0}get appendedByteLength(){return this.appendableByteLength}addData(e){if(this.format&&e.format!==this.format)throw new Error("GPUVector.addData() requires matching formats");if(e.byteStride!==this.byteStride)throw new Error("GPUVector.addData() requires matching byteStride");if(e.rowByteLength!==this.rowByteLength)throw new Error("GPUVector.addData() requires matching rowByteLength");return this.data.push(e),this.length+=e.length,this.valueLength+=e.valueLength,this}appendDataChunk(e,t=this.appendableByteLength+e.buffer.byteLength){if(!this.isAppendable)throw new Error("GPUVector.appendDataChunk() requires appendable vector storage");if(this.format&&e.format!==this.format)throw new Error("GPUVector.appendDataChunk() requires matching formats");if(e.byteStride!==this.byteStride||e.rowByteLength!==this.rowByteLength)throw new Error("GPUVector.appendDataChunk() requires matching byte layout metadata");return this.data.push(e),this.length+=e.length,this.valueLength+=e.valueLength,this.appendableByteLength=t,this}resetLastBatch(){if(!this.isAppendable)throw new Error("GPUVector.resetLastBatch() requires appendable vector storage");for(const e of this.data.splice(0))e.destroy();return this.length=0,this.valueLength=0,this.appendableByteLength=0,this}retainOwnedVectors(e){return this.ownedVectors.push(...e),this}transferBufferOwnership(e){const t=this.data[0],n=e.data[0];if(!t||!n||t.buffer!==n.buffer)throw new Error("GPUVector ownership can only be transferred to the same buffer");t.transferBufferOwnership(n)}destroy(){if(this.ownsDataChunks)for(const e of this.data)e.destroy();for(const e of this.ownedVectors.splice(0))e.destroy()}}function Gf(i){const e=i.format?Un(i.format):void 0,t=i.rowByteLength??i.byteStride??(e==null?void 0:e.byteLength);if(t===void 0)throw new Error("GPUVector requires format or explicit rowByteLength");return{stride:i.stride??(e==null?void 0:e.components)??1,byteStride:i.byteStride??t,rowByteLength:t}}function TT(i){var e;return(e=i[0])==null?void 0:e.format}function AT(i,e){if(i.find(n=>n.format!==e))throw new Error("GPUVector data chunks must share the declared format")}class MT{constructor(){h(this,"poolSize",20);h(this,"bufferPools");this.bufferPools=new Map}createOrReuse(e,t){if(t>e.limits.maxBufferSize)throw new Error(`Buffer pool cannot allocate ${t} bytes: device.limits.maxBufferSize is ${e.limits.maxBufferSize}`);const n=this.bufferPools.get(e),s=n?n.findIndex(o=>o.byteLength>=t):-1;if(s<0)return e.createBuffer({usage:W.VERTEX|W.STORAGE|W.COPY_DST|W.COPY_SRC,byteLength:t});const[r]=n.splice(s,1);return r}recycle(e){const t=e.device;this.bufferPools.has(t)||this.bufferPools.set(t,[]);const n=this.bufferPools.get(t),s=n.findIndex(r=>r.byteLength>e.byteLength);s<0?n.push(e):n.splice(s,0,e),this.purge()}purge(){for(const[e,t]of this.bufferPools){const n=e.isLost?0:this.poolSize;for(;t.length>n;)t.shift().destroy();t.length===0&&this.bufferPools.delete(e)}}}const Ui=new MT;class se{constructor(e){h(this,"type");h(this,"size");h(this,"normalized");h(this,"isConstant");h(this,"length");h(this,"ValueType");h(this,"source",null);h(this,"format");h(this,"_id");h(this,"_destroyed",!1);h(this,"_value");h(this,"_offset");h(this,"_stride");h(this,"_byteLength");h(this,"_gpuVector");h(this,"_bufferOwnership","owned");h(this,"_targetBuffer");const{id:t,value:n,buffer:s,gpuData:r,format:o,source:a=null,isConstant:c=!1}=e;if(!a&&!n&&!s&&!r)throw new Error("GPUDataEvaluator must have a value source");let{type:l,size:u,offset:f,stride:d,normalized:g,length:p}=e;if(a instanceof se?(l=l??a.type,u=u??a.size,f=f??a.offset,d=d??a.stride,g=g??a.normalized,p=p??a.length):(u=u??1,f=f??0,g=g??!1,p=c?1:p),!l)throw new Error("GPUDataEvaluator: type not defined");if(this._id=t,this.type=l,this.size=u,this.ValueType=Qi(this.type),this._offset=f,this._stride=d||this.ValueType.BYTES_PER_ELEMENT*u,this.normalized=g,this.source=a,this.format=o,p===void 0)if(c)p=1;else{if(!n)throw new Error("GPUDataEvaluator: length not defined");p=Math.ceil(n.byteLength/this.stride)}this.isConstant=c,this.length=p;const m=this.ValueType.BYTES_PER_ELEMENT*this.size;this._byteLength=p===0?0:(p-1)*this.stride+m,this._value=n,this._bufferOwnership=a instanceof se||s||r?"borrowed":"owned",r?this._gpuVector=new an({type:"data",name:this._id??"data",format:r.format,data:[r],stride:r.stride,byteStride:r.byteStride,rowByteLength:r.rowByteLength}):s&&(this._gpuVector=this.createGPUVectorView({buffer:s,name:this._id,format:this.format}))}static get bufferPoolSize(){return Ui.poolSize}static set bufferPoolSize(e){if(!Number.isSafeInteger(e)||e<0)throw new Error("GPUDataEvaluator.bufferPoolSize must be a non-negative safe integer");Ui.poolSize=e,Ui.purge()}get offset(){return this._offset}get stride(){return this._stride}get byteLength(){return this._byteLength}static fromArray(e,{type:t,size:n=1,offset:s=0,stride:r=0,normalized:o=!1}){let a=t,c;if(Array.isArray(e)){a=a||"float32";const u=Qi(a);c=new u(e)}else e instanceof Float64Array?(a="uint32",n*=2,s*=2,r*=2,c=new Uint32Array(e.buffer,e.byteOffset,e.byteLength/4)):(a=a||Mh(e),c=e);const l=`<${a} * ${n}>`;return new se({id:l,type:a,size:n,offset:s,stride:r,normalized:o,value:c})}static fromConstant(e,t="float32"){const n=Qi(t);let s;return Array.isArray(e)?s=`[${e.join(",")}]`:(s=String(e),e=[e]),new se({id:s,isConstant:!0,type:t,size:e.length,value:new n(e)})}static fromGPUData(e,t={}){RT(e);const n=new lr({buffer:e.buffer,format:e.format,length:e.length,byteOffset:e.byteOffset,byteStride:e.byteStride});return new se({...Vf(n),id:t.id,gpuData:e})}static fromGPUDataView(e,t={}){return new se({...Vf(e),id:t.id,buffer:e.buffer})}get value(){return this._value||(this.source instanceof se?this.source.value:void 0)}get evaluated(){return!!this._gpuVector}get id(){return this._id}get gpuVector(){if(!this._gpuVector)throw new Error(`${this} not evaluated`);return this._gpuVector}get buffer(){return us(this.gpuVector)}setTargetBuffer({buffer:e,byteOffset:t=0,byteStride:n=this.stride}){if(this._destroyed)throw new Error(`GPUDataEvaluator ${this} already destroyed`);if(this._gpuVector)throw new Error(`GPUDataEvaluator ${this} already evaluated`);if(!this.source||this.source instanceof se)throw new Error("GPUDataEvaluator target buffers require a deferred operation source");this._targetBuffer={buffer:e,byteOffset:t,byteStride:n}}async evaluate(e,t={}){if(this._destroyed)throw new Error(`GPUDataEvaluator ${this} already destroyed`);if(this._gpuVector)return this._gpuVector;let n;if(this.source instanceof se){const s=await this.source.evaluate(e);return this._gpuVector=this.createGPUVectorView({...t,buffer:us(s)}),this._gpuVector}if(n=this._getEvaluationBuffer(e),this._value)n.write(this._value);else{const s=await this.source.execute(e,n);if(!s.success)throw s.error||new Error(`${this.source} evaluation failed`);s.value&&(this._value=s.value)}return this._gpuVector=this.createGPUVectorView({...t,buffer:n}),this._gpuVector}evaluateSync(e,t={}){if(this._destroyed)throw new Error(`GPUDataEvaluator ${this} already destroyed`);if(this._gpuVector)return this._gpuVector;let n;if(this.source instanceof se){const s=this.source.evaluateSync(e);return this._gpuVector=this.createGPUVectorView({...t,buffer:us(s)}),this._gpuVector}if(n=this._getEvaluationBuffer(e),this._value)n.write(this._value);else{const s=this.source.executeSync(e,n);if(!s.success)throw s.error||new Error(`${this.source} evaluation failed`);s.value&&(this._value=s.value)}return this._gpuVector=this.createGPUVectorView({...t,buffer:n}),this._gpuVector}createGPUVectorView(e){const t=e.name??this._id??"vector",n=e.format??this.format??kT(this.type,this.size,this.normalized);if(e.interleaved){const s=typeof e.interleaved=="object"&&e.interleaved.attributes?e.interleaved.attributes:BT(this);return new an({type:"interleaved",name:t,buffer:e.buffer,format:e.format??this.format,length:this.length,byteOffset:this.offset,byteStride:this.stride,attributes:s,ownsBuffer:!1})}return new an({type:"buffer",name:t,buffer:e.buffer,format:n,length:this.length,stride:this.size,byteOffset:this.offset,byteStride:this.stride,rowByteLength:this.ValueType.BYTES_PER_ELEMENT*this.size,ownsBuffer:!1})}_getEvaluationBuffer(e){const t=this._targetBuffer;if(!t)return Ui.createOrReuse(e,this.byteLength);if(t.buffer.device!==e)throw new Error("GPUDataEvaluator target buffer belongs to a different device");const n=this.ValueType.BYTES_PER_ELEMENT*this.size,s=this.length===0?0:(this.length-1)*t.byteStride+n;if(t.byteOffset+s>t.buffer.byteLength)throw new Error("GPUDataEvaluator target buffer is too small for the output layout");return this._offset=t.byteOffset,this._stride=t.byteStride,this._byteLength=s,this._bufferOwnership="borrowed",this._targetBuffer=void 0,t.buffer}async readValue(e=0,t){const{ValueType:n}=this,{size:s,offset:r,stride:o,length:a}=this,c=n.BYTES_PER_ELEMENT*s;if(t=t??a,e=Math.max(0,Math.min(a,e)),t=Math.max(e,Math.min(a,t)),this._value)return IT(this,this._value,e,t);const l=t-e;if(l===0)return new n(0);const u=r+e*o,f=o===c?l*c:(l-1)*o+c,d=await this.buffer.readAsync(u,f),g=new n(d.buffer,d.byteOffset,d.byteLength/n.BYTES_PER_ELEMENT);if(o===c)return g;const p=new Uint8Array(c*l);for(let m=0;m<l;m++){const _=m*o;p.set(d.subarray(_,_+c),m*c)}return new n(p.buffer)}async ensureCPUValue(){const e=this.value;if(e)return e;const t=await this.buffer.readAsync(0,this.offset+this.byteLength);if(t.byteLength%this.ValueType.BYTES_PER_ELEMENT!==0)throw new Error(`${this} backing buffer byte length is not aligned to its scalar type`);const n=t.slice();return this._value=new this.ValueType(n.buffer,n.byteOffset,n.byteLength/this.ValueType.BYTES_PER_ELEMENT),this._value}ensureCPUValueSync(){const e=this.value;if(e)return e;throw new Error(`${this} CPU value is not available for synchronous evaluation`)}toString(){var e;return this._id??((e=this.source)==null?void 0:e.toString())??this.constructor.name}destroy(){this._gpuVector&&(this._bufferOwnership==="owned"&&Ui.recycle(us(this._gpuVector)),this._gpuVector=void 0),this._targetBuffer=void 0,this._destroyed=!0}}function IT(i,e,t,n){const{ValueType:s,size:r,offset:o,stride:a}=i,c=a/s.BYTES_PER_ELEMENT,l=o/s.BYTES_PER_ELEMENT,u=n-t;if(c===r){const d=l+t*c;return e.subarray(d,d+u*r)}const f=new s(u*r);for(let d=0;d<u;d++){const g=l+(t+d)*c;f.set(e.subarray(g,g+r),d*r)}return f}function jf(i){if(i instanceof se)return i;if(typeof i=="number"||Array.isArray(i))return se.fromConstant(i);if(i instanceof ac)return se.fromGPUData(i);if(i instanceof lr)return se.fromGPUDataView(i);throw new Error("getGPUDataEvaluator() requires GPUDataEvaluator, GPUData, GPUDataView, number, or number[]")}function RT(i){if(!i.format)throw new Error("GPUDataEvaluator.fromGPUData() requires GPUData format metadata");if(pp(i.format)||mp(i.format))throw new Error("GPUDataEvaluator.fromGPUData() does not support variable-length input");const t=Un(i.format).byteLength;if(i.rowByteLength!==t)throw new Error(`GPUDataEvaluator.fromGPUData() requires rowByteLength ${t} for GPUData`)}function Vf(i){const e=Un(i.format),t=Qi(e.signedDataType),n=t.BYTES_PER_ELEMENT*e.components;if(e.byteLength!==n)throw new Error(`GPUDataEvaluator does not support packed vertex format ${i.format}: ${e.byteLength} physical bytes cannot expose ${e.components} ${e.signedDataType} components`);if(i.byteOffset%t.BYTES_PER_ELEMENT!==0||i.byteStride%t.BYTES_PER_ELEMENT!==0)throw new Error(`GPUDataEvaluator requires ${i.format} offset and stride aligned to ${t.BYTES_PER_ELEMENT} bytes`);return{type:e.signedDataType,size:e.components,offset:i.byteOffset,stride:i.byteStride,normalized:e.normalized,length:i.length,format:i.format}}function us(i){const e=OT(i).buffer;return e instanceof qe?e.buffer:e}function OT(i){const[e,...t]=i.data;if(!e||t.length>0)throw new Error(`GPUDataEvaluator requires exactly one GPUData chunk for "${i.name}"`);return e}function BT(i){const e=[];return _p(i,e,{byteOffset:0}),e}function _p(i,e,t){const n=i.source;if(n&&!(n instanceof se)&&n.name==="interleave"){for(const s of Object.values(n.inputs))s instanceof se&&_p(s,e,t);return}e.push({attribute:i.id??i.toString(),format:yp(i.type,i.size,i.normalized),byteOffset:t.byteOffset}),t.byteOffset+=i.ValueType.BYTES_PER_ELEMENT*i.size}function yp(i,e,t=!1){if(e<1||e>4)throw new Error(`Cannot synthesize a GPUVector vertex format with ${e} components`);let n=i;if(t)switch(i){case"uint8":n="unorm8";break;case"sint8":n="snorm8";break;case"uint16":n="unorm16";break;case"sint16":n="snorm16";break;case"float32":n="float32";break;default:throw new Error(`Unsupported normalized vertex format for ${i}`)}return(n==="uint8"||n==="sint8"||n==="uint16"||n==="sint16"||n==="unorm8"||n==="snorm8"||n==="unorm16"||n==="snorm16")&&e===3?`${n}x3-webgl`:`${n}${e===1?"":`x${e}`}`}function kT(i,e,t=!1){return e>=1&&e<=4?yp(i,e,t):void 0}class di{constructor({id:e,gpuDataEvaluators:t,gpuVector:n,format:s}){h(this,"gpuDataEvaluators");h(this,"format");h(this,"length");h(this,"id");h(this,"_gpuVector");h(this,"_ownsGPUDataEvaluators");h(this,"_destroyed",!1);if(t.length===0)throw new Error("GPUVectorEvaluator requires at least one GPUData evaluator");DT(t),this.id=e,this.gpuDataEvaluators=t,this.format=s??t[0].format,this.length=t.reduce((r,o)=>r+o.length,0),this._gpuVector=n,this._ownsGPUDataEvaluators=!n}static fromGPUVector(e){if(e.bufferLayout)throw new Error(`GPUVectorEvaluator.fromGPUVector() does not accept interleaved vector "${e.name}"`);if(e.data.length===0)throw new Error(`GPUVectorEvaluator.fromGPUVector() requires GPUData for "${e.name}"`);return new di({id:e.name,gpuDataEvaluators:e.data.map(t=>se.fromGPUData(t,{id:e.name})),gpuVector:e,format:e.format})}static fromGPUDataEvaluators(e,t={}){return new di({id:t.id,gpuDataEvaluators:e,format:t.format})}get evaluated(){return!!this._gpuVector}get gpuVector(){if(!this._gpuVector)throw new Error(`${this} not evaluated`);return this._gpuVector}mapGPUData(e){return di.fromGPUDataEvaluators(this.gpuDataEvaluators.map((t,n)=>e(t,n)),{id:this.id})}async evaluate(e,t={}){if(this._destroyed)throw new Error(`GPUVectorEvaluator ${this} already destroyed`);if(this._gpuVector)return this._gpuVector;const n=await Promise.all(this.gpuDataEvaluators.map(a=>a.evaluate(e,t))),s=n[0],r=n.map(Wf),o=t.format??this.format??s.format;return this._gpuVector=new an({type:"data",name:t.name??this.id??"vector",format:o,data:r,stride:s.stride,byteStride:s.byteStride,rowByteLength:s.rowByteLength,bufferLayout:s.bufferLayout}),this._gpuVector}evaluateSync(e,t={}){if(this._destroyed)throw new Error(`GPUVectorEvaluator ${this} already destroyed`);if(this._gpuVector)return this._gpuVector;const n=this.gpuDataEvaluators.map(a=>a.evaluateSync(e,t)),s=n[0],r=n.map(Wf),o=t.format??this.format??s.format;return this._gpuVector=new an({type:"data",name:t.name??this.id??"vector",format:o,data:r,stride:s.stride,byteStride:s.byteStride,rowByteLength:s.rowByteLength,bufferLayout:s.bufferLayout}),this._gpuVector}destroy(){if(this._ownsGPUDataEvaluators)for(const e of this.gpuDataEvaluators)e.destroy();this._gpuVector=void 0,this._destroyed=!0}toString(){return this.id??this.constructor.name}}function DT(i){const e=i[0];for(const t of i.slice(1))if(t.type!==e.type||t.size!==e.size||t.normalized!==e.normalized||t.format!==e.format)throw new Error("GPUVectorEvaluator requires matching GPUData evaluator layouts")}function Wf(i){const[e,...t]=i.data;if(!e||t.length>0)throw new Error(`GPUVectorEvaluator requires one GPUData chunk for "${i.name}"`);return e}const FT={add:{arity:2,symbol:"arithmetic_add"},subtract:{arity:2,symbol:"arithmetic_subtract"},multiply:{arity:2,symbol:"arithmetic_multiply"},divide:{arity:2,symbol:"arithmetic_divide"},pow:{arity:2,symbol:"pow"},sqrt:{arity:1,symbol:"sqrt"},abs:{arity:1,symbol:"abs"},sin:{arity:1,symbol:"sin"},cos:{arity:1,symbol:"cos"},tan:{arity:1,symbol:"arithmetic_tan"},exp:{arity:1,symbol:"exp"},log:{arity:1,symbol:"log"}};function ml({elementWise:i,func:e,inputs:t,output:n,outputBuffer:s}){const r=Array.isArray(t)?t:Object.values(t);for(const p of r)if(!p.value)throw new Error(`${p} does not have CPU value`);const o=n.length,a=n.size,c=new n.ValueType(o*a);for(let p=0;p<o;p++){const m=r.map(_=>Ee(_,p));if(i)for(let _=0;_<a;_++)c[p*a+_]=e.apply(null,m.map(v=>v[_]));else e.call(null,c.subarray(p*a,p*a+a),...m)}const l=n.ValueType.BYTES_PER_ELEMENT,u=n.offset/l,f=n.stride/l,d=a;let g=c;if(u!==0||f!==d){g=new n.ValueType(u+n.byteLength/l);for(let p=0;p<o;p++){const m=p*d,_=u+p*f,v=c.subarray(m,m+a);g.set(v,_),s.write(v,_*l)}}else s.write(c);return{success:!0,value:g}}function Ee(i,e){const t=i.value,n=i.size,s=i.offset/i.ValueType.BYTES_PER_ELEMENT,r=i.stride/i.ValueType.BYTES_PER_ELEMENT,o=i.isConstant?0:e,a=s+o*r,c=t.slice(a,a+n);if(!i.normalized)return c;const l=new Float32Array(n);for(let u=0;u<n;u++)l[u]=zT(c[u],i.type);return l}function zT(i,e){switch(e){case"uint8":return i/255;case"uint16":return i/65535;case"uint32":return i/4294967295;case"sint8":return Math.max(i/127,-1);case"sint16":return Math.max(i/32767,-1);case"sint32":return Math.max(i/2147483647,-1);case"float32":return i;default:throw new Error(`Unsupported normalized source type ${e}`)}}const NT=({inputs:i,output:e,target:t})=>{for(const s of Object.values(i.namedInputs))if(!s.value)throw new Error(`${s} does not have CPU value`);const n=new e.ValueType(e.length*e.size);for(let s=0;s<e.length;s++){const r=Object.fromEntries(Object.entries(i.namedInputs).map(([o,a])=>[o,Ee(a,s)]));for(let o=0;o<e.size;o++)n[s*e.size+o]=bp(i.expression,r,o)}return t.write(n),{success:!0,value:n}};function bp(i,e,t){switch(i.kind){case"input":{const n=e[i.name];return t<n.length?n[t]:n.length===1?n[0]:0}case"literal":return Array.isArray(i.value)?i.value[t]??0:i.value;case"call":{UT(i.op,i.args.length);const n=i.args.map(s=>bp(s,e,t));switch(i.op){case"add":return n[0]+n[1];case"subtract":return n[0]-n[1];case"multiply":return n[0]*n[1];case"divide":return n[0]/n[1];case"pow":return Math.pow(n[0],n[1]);case"sqrt":return Math.sqrt(n[0]);case"abs":return Math.abs(n[0]);case"sin":return Math.sin(n[0]);case"cos":return Math.cos(n[0]);case"tan":return Math.tan(n[0]);case"exp":return Math.exp(n[0]);case"log":return Math.log(n[0]);default:{const s=i.op;throw new Error(`Unsupported arithmetic op ${s}`)}}}default:{const n=i;throw new Error(`Unsupported expression node ${n.kind}`)}}}function UT(i,e){const t=FT[i].arity;if(e!==t)throw new Error(`Arithmetic op '${i}' expects ${t} args, got ${e}`)}const $T=({inputs:i,output:e,target:t})=>{const{sourceValues:n}=i;if(!n.value)throw new Error(`${n} does not have CPU value`);const r=new e.ValueType(e.length*e.size);if(n.length===0)return{success:!1,error:new Error(`${n} is empty`)};for(let o=0;o<n.size;o++){const a=Ee(n,0)[o],c=o*e.size,l=c+1;r[c]=a,r[l]=a;for(let u=1;u<n.length;u++){const f=Ee(n,u)[o];f<r[c]&&(r[c]=f),f>r[l]&&(r[l]=f)}}return t.write(r),{success:!0,value:r}},GT=({inputs:i,output:e,target:t})=>ml({func:(n,s)=>{const r=n.length/2,o=new Float64Array(s.buffer);for(let a=0;a<r;a++){const c=o[a];n[a]=Math.fround(c),n[a+r]=c-n[a]}return n},inputs:i,output:e,outputBuffer:t}),jT=async({inputs:i,output:e,target:t})=>{const{ids:n,sourceValues:s}=i,r=n.value,o=s.value;if(!r)throw new Error(`${n} does not have CPU value`);if(!o)throw new Error(`${s} does not have CPU value`);const a=new e.ValueType(e.length*e.size),c=new Array(e.size).fill(0);for(let l=0;l<e.length;l++){const u=Ee(n,l),f=Number(u[0]),d=VT(f,s.length)?Ee(s,f):c;a.set(d,l*e.size)}return t.write(a),{success:!0,value:a}};function VT(i,e){return Number.isInteger(i)&&i>=0&&i<e}const WT=({inputs:i,output:e,target:t})=>ml({func:(n,...s)=>{let r=0;for(const o of s)n.set(o,r),r+=o.length},inputs:i,output:e,outputBuffer:t}),HT=({inputs:i,output:e,target:t})=>{const{x:n,y:s}=i,r=new e.ValueType(e.length);for(let o=0;o<e.length;o++){const a=Ee(n,o),c=Ee(s,o);let l=0;for(let u=0;u<n.size;u++)l+=a[u]*c[u];r[o]=l}return t.write(r),{success:!0,value:r}},YT=({inputs:i,output:e,target:t})=>{const{x:n,y:s}=i,r=new e.ValueType(e.length);for(let o=0;o<e.length;o++){const a=Ee(n,o),c=Ee(s,o);let l=1;for(let u=0;u<n.size;u++)if(a[u]!==c[u]){l=0;break}r[o]=l}return t.write(r),{success:!0,value:r}},qT=({inputs:i,output:e,target:t})=>{const{x:n}=i,s=new e.ValueType(e.length);for(let r=0;r<e.length;r++){const o=Ee(n,r);let a=0;for(let c=0;c<n.size;c++)a+=o[c]*o[c];s[r]=Math.sqrt(a)}return t.write(s),{success:!0,value:s}},ZT=async({inputs:i,output:e,target:t})=>{const{segments:n,vertexCount:s}=i,r=n.value;if(!r)throw new Error(`${n} does not have CPU value`);XT(r,n,s);const o=new e.ValueType(e.length*e.size);let a=0;for(let c=0;c<s;c++){for(;a+1<n.length&&r[cc(n,a+1)]<=c;)a++;const l=r[cc(n,a)],u=c*e.size;o[u]=a,o[u+1]=c-l}return t.write(o),{success:!0,value:o}};function XT(i,e,t){if(e.length<1)throw new Error("segmentedMap segments must contain at least one segment start");let n=0;for(let s=0;s<e.length;s++){const r=i[cc(e,s)];if(s===0&&r!==0)throw new Error(`segmentedMap segments must start at 0, got ${r}`);if(s>0&&r<n)throw new Error(`segmentedMap segments must be non-decreasing, got ${r} after ${n}`);n=r}if(n>t)throw new Error(`segmentedMap last segment start must be <= vertexCount, got ${n} > ${t}`)}function cc(i,e){return i.offset/i.ValueType.BYTES_PER_ELEMENT+e*(i.stride/i.ValueType.BYTES_PER_ELEMENT)}const KT=async({inputs:i,output:e,target:t})=>{const{condition:n,whenTrue:s,whenFalse:r}=i,o=new e.ValueType(e.length*e.size);for(let a=0;a<e.length;a++){const c=Ee(n,a),l=Ee(s,a),u=Ee(r,a);for(let f=0;f<e.size;f++){const d=Yo(c,n.size,f);o[a*e.size+f]=d!==0?Yo(l,s.size,f):Yo(u,r.size,f)}}return t.write(o),{success:!0,value:o}};function Yo(i,e,t){return t<e?i[t]:e===1?i[0]:0}const QT=({inputs:i,output:e,target:t})=>{const n=new e.ValueType(e.length);for(let s=0;s<e.length;s++)n[s]=i.start+s*i.step;return t.write(n),{success:!0,value:n}},JT=({inputs:i,output:e,target:t})=>{const{columns:n}=i;return ml({func:(s,r)=>{for(let o=0;o<n.length;o++)s[o]=r[n[o]]},inputs:{x:i.x},output:e,outputBuffer:t})},e1=Object.freeze(Object.defineProperty({__proto__:null,arithmetic:NT,dot:HT,equalAll:YT,extent:$T,fround:GT,gather:jT,interleave:WT,length:qT,segmentedMap:ZT,select:KT,sequence:QT,swizzle:JT},Symbol.toStringTag,{value:"Module"}));class t1{constructor(){h(this,"_modules",{cpu:e1})}add(e,t){const n=this._modules[e];if(typeof t.then=="function"){const r=Promise.all([Promise.resolve(n||{}),t]).then(([o,a])=>({...o,...a}));return this._modules[e]=r,r.then(o=>{this._modules[e]=o}).catch(o=>{M.error(`Failed to register ${e} backend: ${o}`)()}),r}if(n&&typeof n.then=="function"){const r=Promise.resolve(n).then(o=>({...o,...t})).then(o=>(this._modules[e]=o,o)).catch(o=>{throw M.error(`Failed to register ${e} backend: ${o}`)(),o});return this._modules[e]=r,r}const s={...n||{},...t};return this._modules[e]=s,Promise.resolve(s)}async get(e,t){let n=this._modules[e];if(!n)if(e==="webgl")n=this.add("webgl",Os(()=>import("./index-BOotR11c.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url));else if(e==="webgpu")n=this.add("webgpu",Os(()=>import("./index-B_hu9CzQ.js"),__vite__mapDeps([6,1,2,3,4,5]),import.meta.url));else throw new Error(`${e} backend not registered`);const r=(await n)[t];if(typeof r!="function")throw new Error(`${e} backend does not implement ${t}`);return r}getSync(e,t){const n=this._modules[e];if(!n)throw new Error(`${e} backend not registered`);if(typeof n.then=="function")throw new Error(`${e} backend is not loaded yet`);const r=n[t];if(typeof r!="function")throw new Error(`${e} backend does not implement ${t}`);return r}clear(){this._modules={}}}const lc=new t1;class i1{constructor(e){h(this,"inputs");h(this,"dependencies");this.inputs=e,this.dependencies=Array.from(e instanceof Array?e:Object.values(e)).filter(t=>t instanceof se)}async execute(e,t){return await this._resolveDependencies(e),await this._executeWithHandler(await lc.get(this._getHandlerRegistry(e),this.name),t)}executeSync(e,t){this._resolveDependenciesSync(e);const n=this._executeWithHandler(lc.getSync(this._getHandlerRegistry(e),this.name),t);if(n1(n))throw new Error(`${this.name} returned a Promise in executeSync()`);return n}shouldExecuteOnCPU(){return this.output.length<=1&&Array.from(this.dependencies).every(e=>!!e.value)}_getHandlerRegistry(e){return this.shouldExecuteOnCPU()?"cpu":e.type}async _resolveDependencies(e){for(const n of this.dependencies)await n.evaluate(e);if(this._getHandlerRegistry(e)==="cpu"||e.type==="null")for(const n of this.dependencies)await n.ensureCPUValue()}_resolveDependenciesSync(e){for(const n of this.dependencies)n.evaluateSync(e);if(this._getHandlerRegistry(e)==="cpu"||e.type==="null")for(const n of this.dependencies)n.ensureCPUValueSync()}_executeWithHandler(e,t){return e({device:t.device,inputs:this.inputs,output:this.output,target:t})}}function n1(i){return typeof(i==null?void 0:i.then)=="function"}function s1(...i){let e=r1(i.map(t=>t.type));return e[0]!=="f"&&i.some(t=>t.normalized)&&(e="float32"),{isConstant:i.every(t=>t.isConstant),type:e,size:i.reduce((t,n)=>Math.max(t,n.size),0),length:i.reduce((t,n)=>Math.max(t,n.length),0)}}function r1(i){let e=0,t=0;for(const n of i){if(n[0]==="f")return"float32";const s=n.endsWith("8")?8:n.endsWith("6")?16:32;n[0]==="u"?e=Math.max(e,s):t=Math.max(t,s)}return e&&!t?`uint${e}`:t&&e<32?`sint${Math.max(t,e*2)}`:"float32"}class o1 extends i1{constructor(t){super(t);h(this,"name","interleave");h(this,"output");const{isConstant:n,type:s,length:r}=s1(...t);this.output=new se({isConstant:n,type:s,size:t.reduce((o,a)=>o+a.size,0),length:r,source:this})}toString(){return`_${this.inputs.join("_")}_`}}function a1(...i){if(i.length===0)throw new Error("interleave() requires at least one input");return i.length===1?jf(i[0]):new o1(i.map(jf)).output}function c1(i,e){const t=u1(e);for(const n of t)n.evaluateSync(i);return l1(t),e}function l1(i){const e=new Set(i.flatMap(d1)),t=new Set;for(const n of i)Ls(n,t);for(const n of t)n.evaluated&&!e.has(n.buffer)&&n.destroy()}function u1(i){const e=new Set;return uc(i,e,new Set),Array.from(e)}function uc(i,e,t){if(h1(i)){e.add(i);return}if(!(!i||typeof i!="object"||t.has(i))){if(t.add(i),Array.isArray(i)){for(const n of i)uc(n,e,t);return}if(f1(i))for(const n of Object.values(i))uc(n,e,t)}}function f1(i){const e=Object.getPrototypeOf(i);return e===Object.prototype||e===null}function Ls(i,e){if(i instanceof di){for(const n of i.gpuDataEvaluators)Ls(n,e);return}const t=i.source;if(t){if(t instanceof se){e.has(t)||(e.add(t),Ls(t,e));return}for(const n of t.dependencies)e.has(n)||(e.add(n),Ls(n,e))}}function d1(i){return i instanceof se?[i.buffer]:i.gpuVector.data.map(e=>e.buffer instanceof qe?e.buffer.buffer:e.buffer)}function h1(i){return i instanceof se||i instanceof di}const g1=65535;function p1(i,e){const t=y1(e),n=Math.max(1,Math.ceil(i)),s=Math.min(n,t),r=Math.min(Math.ceil(n/s),t),o=Math.ceil(n/s/r);if(o>t)throw new Error(`WebGPU dispatch requires ${n} workgroups, exceeding the 3D dispatch limit of ${t} per dimension`);return{x:s,y:r,z:o}}function m1(i,e="workgroupId"){return`((${e}.z * ${i.y}u + ${e}.y) * ${i.x}u + ${e}.x)`}function _1(i,e,t="workgroupId",n="localId"){return`(${m1(i,t)} * ${e}u + ${n}.x)`}function y1(i){return Number.isFinite(i)&&i>0?Math.floor(i):g1}function fc(i,e){switch(i){case"u32":return`${e}u`;case"f32":return Number.isInteger(e)?`${e}.0`:`${e}`;default:return`${e}`}}function wR(i,e){switch(i){case"uint32":return fc("u32",Math.trunc(e));case"sint32":return`${Math.trunc(e)}`;case"float32":return fc("f32",e);default:throw new Error(`WebGPU operations only support 32-bit output types, got ${i}`)}}function b1(i){switch(i){case"uint32":return"0u";case"sint32":return"0";case"float32":return"0.0";default:throw new Error(`WebGPU operations only support 32-bit output types, got ${i}`)}}function wt(i){switch(i){case"uint32":return"u32";case"sint32":return"i32";case"float32":return"f32";default:throw new Error(`WebGPU operations only support 32-bit storage types, got ${i}`)}}const qo=64,v1="GPGPU Operation Counts",w1="Computation Runs",x1=new _i;function P1({module:i,elementWise:e=!1,expression:t,inputs:n,output:s,operationType:r=s.type,outputBuffer:o}){if(!i.source)throw new Error(`WebGPU computation ${i.name} requires WGSL source`);const a=A1(n),c=a.map(([w,y])=>({name:w,input:y})),l=c.filter(({input:w})=>!w.isConstant).map((w,y)=>({...w,index:y})),u=wt(r),f=wt(s.type),d={TYPE:u,RESULT_LEN:s.size.toString()},g=p1(Math.ceil(s.length/qo),o.device.limits.maxComputeWorkgroupsPerDimension);for(const[w,y]of a)d[`${w.toUpperCase()}_LEN`]=y.size.toString();const p=`
${I1(i.source,d)}
${l.map(({name:w,input:y,index:x})=>S1(w,y,x)).join(`
`)}
${c.map(({name:w,input:y})=>E1(w,y,r)).join(`
`)}
${C1(s,l.length)}
${L1(s)}

@compute @workgroup_size(${qo}) fn main(
  @builtin(workgroup_id) workgroupId: vec3<u32>,
  @builtin(local_invocation_id) localId: vec3<u32>
) {
  let rowIndex = ${_1(g,qo)};
  if (rowIndex >= ${s.length}u) {
    return;
  }

${c.map(({name:w})=>`  let ${w} = read_${w}(rowIndex);`).join(`
`)}
  var result: array<${f}, ${s.size}>;
${T1(i.name,a,s,e,t)}
  write_result(rowIndex, result);
}
`,m=new Qa(o.device,{source:p,modules:i.dependencies,shaderAssembler:x1,shaderLayout:{bindings:[...l.map(({name:w},y)=>({name:w,type:"storage",group:0,location:y})),{name:"result",type:"storage",group:0,location:l.length}]}}),_=Object.fromEntries(l.map(({name:w,input:y})=>[w,y.buffer]));_.result=o,m.setBindings(_);const v=o.device.beginComputePass({});o.device.statsManager.getStats(v1).get(w1).incrementCount(),m.dispatch(v,g.x,g.y,g.z),v.end(),o.device.submit(),m.destroy()}function S1(i,e,t){if(e.isConstant)return"";const n=wt(e.type);return`@group(0) @binding(${t}) var<storage, read> ${i}: array<${n}>;`}function E1(i,e,t){const n=wt(t),s=e.type===t?"":n,r=e.stride/e.ValueType.BYTES_PER_ELEMENT,o=e.offset/e.ValueType.BYTES_PER_ELEMENT;return e.isConstant?`fn read_${i}(_rowIndex: u32) -> array<${n}, ${e.size}> {
  return array<${n}, ${e.size}>(${M1(e,s)});
}`:`fn read_${i}(rowIndex: u32) -> array<${n}, ${e.size}> {
  var value: array<${n}, ${e.size}>;
  let rowOffset = ${o}u + rowIndex * ${r}u;
${Array.from({length:e.size},(a,c)=>s?`  value[${c}] = ${s}(${i}[rowOffset + ${c}u]);`:`  value[${c}] = ${i}[rowOffset + ${c}u];`).join(`
`)}
  return value;
}`}function C1(i,e){const t=wt(i.type);return`@group(0) @binding(${e}) var<storage, read_write> result: array<${t}>;`}function L1(i){const e=i.stride/i.ValueType.BYTES_PER_ELEMENT,t=i.offset/i.ValueType.BYTES_PER_ELEMENT;return`fn write_result(rowIndex: u32, value: array<${wt(i.type)}, ${i.size}>) {
  let rowOffset = ${t}u + rowIndex * ${e}u;
${Array.from({length:i.size},(s,r)=>`  result[rowOffset + ${r}u] = value[${r}];`).join(`
`)}
}`}function T1(i,e,t,n,s){let r="";if(s)for(let o=0;o<t.size;o++)r+=`  result[${o}] = ${s(o)};
`;else if(n){const o=b1(t.type),a=wt(t.type);for(let c=0;c<t.size;c++){const l=e.map(([u,f])=>c<f.size?wt(f.type)===a?`${u}[${c}]`:`${a}(${u}[${c}])`:o);r+=`  result[${c}] = ${i}(${l.join(", ")});
`}}else r+=`result = ${i}(${e.map(([o])=>o).join(", ")});`;return r.trimEnd()}function A1(i){return Array.isArray(i)?i.map((e,t)=>[`x${t}`,e]):Object.entries(i)}function M1(i,e){const t=i.value;if(!t)throw new Error(`Constant input ${i} is missing CPU values`);return Array.from({length:i.size},(n,s)=>fc(e,t[s]??0)).join(", ")}function I1(i,e){for(const t in e)i=i.replaceAll(`{${t}}`,e[t]);return i}const R1=({inputs:i,output:e,target:t})=>{const n=i.map((c,l)=>[`x${l}`,c]);O1(t.device.limits,n);const s=n.map(([c,l])=>`${c}: array<{TYPE}, ${l.size}>`).join(", ");let r=0;const o=n.map(([c,l])=>{const u=Array.from({length:l.size},(f,d)=>`  out[${r+d}] = ${c}[${d}];`).join(`
`);return r+=l.size,u}).join(`
`),a=`fn interleave(${s}) -> array<{TYPE}, {RESULT_LEN}> {
  var out: array<{TYPE}, {RESULT_LEN}>;
${o}
  return out;
}
`;return P1({module:{name:"interleave",source:a},inputs:i,output:e,outputBuffer:t}),{success:!0}};function O1(i,e){const n=e.filter(([,s])=>!s.isConstant).length+1;if(n>i.maxStorageBuffersPerShaderStage)throw new Error(`interleave() requires ${n} storage buffers, exceeding device limit ${i.maxStorageBuffersPerShaderStage}`);if(n>i.maxBindingsPerBindGroup)throw new Error(`interleave() requires ${n} bindings, exceeding bind group limit ${i.maxBindingsPerBindGroup}`)}class B1{constructor(e,{id:t,isTransitionAttribute:n}){this.packedBuffers={},this.device=e,this.id=t,this.isTransitionAttribute=n,this.device.type==="webgpu"&&lc.add("webgpu",{interleave:R1})}hasGroups(e){return this.device.type==="webgpu"&&Object.values(e).some(t=>!!t.settings.bufferGroup)}finalize(){for(const e of Object.values(this.packedBuffers))e.packed.destroy();this.packedBuffers={}}getBufferLayouts(e,t){const n=this._getPackedGroups(e,t,{requireValues:!1,excludeAttributes:{}});return this._getBufferLayouts(e,n,t)}getBindings(e,t,n,s){const r=this._getPackedGroups(e,n,{requireValues:!0,excludeAttributes:s}),o={},a=new Set;for(const c of r.values()){const l=!this.packedBuffers[c.id]||c.attributes.some(u=>!!t[u.id]);o[c.id]=this._getPackedBuffer(c,l);for(const u of c.attributes)a.add(u.id)}return{bufferLayouts:this._getBufferLayouts(e,r,n).filter(c=>{var l;return!s[c.name]&&!((l=e[c.name])!=null&&l.settings.isIndexed)}),buffers:o,groupedAttributeIds:a}}_getPackedGroups(e,t,{requireValues:n,excludeAttributes:s}){const r=new Map;for(const a of Object.values(e)){const c=a.settings.bufferGroup;if(!c)continue;const l=r.get(c)||[];l.push(a),r.set(c,l)}const o=new Map;for(const[a,c]of r){const l=this._getPackedGroup(a,c,t,n,s);l&&o.set(a,l)}return o}_getPackedGroup(e,t,n,s,r){if(t.length<2)return null;const o=t.map(g=>g.getBufferLayout(n)),a=o[0].stepMode,c=Math.max(1,t[0].numInstances),l=s&&t.every(g=>g.isConstant);for(let g=0;g<t.length;g++){const p=t[g],m=p.getAccessor(),_=m.size*m.bytesPerElement;if(r[p.id]||p.settings.isIndexed||p.settings.noAlloc||p.doublePrecision||this.isTransitionAttribute(p.id)||o[g].stepMode!==a||p.numInstances!==t[0].numInstances||(m.offset||0)!==0||(m.vertexOffset||0)!==0||Qe(m)!==_||s&&(p.isConstant?!p.getConstantValue()||p.getConstantValue().byteLength<_:!ArrayBuffer.isView(p.value)||p.value.byteLength<c*_))return null}const u={},f=[];let d=0;for(let g=0;g<t.length;g++){const p=t[g];d=Hf(d),u[p.id]=d;for(const m of o[g].attributes||[])f.push({...m,byteOffset:d+(m.byteOffset||0)});d+=Qe(p.getAccessor())}return d=Hf(d),{id:e,attributes:t,byteStride:d,byteOffsets:u,rowCount:c,layout:{name:e,byteStride:l?0:d,stepMode:a,attributes:f}}}_getBufferLayouts(e,t,n){const s=[],r=new Set,o=new Set;for(const a of t.values())for(const c of a.attributes)o.add(c.id);for(const a of Object.values(e)){const c=a.settings.bufferGroup,l=c&&t.get(c);l&&o.has(a.id)?r.has(l.id)||(s.push(l.layout),r.add(l.id)):s.push(a.getBufferLayout(n))}return s}_getPackedBuffer(e,t){const n=JSON.stringify({byteStride:e.layout.byteStride,attributes:e.layout.attributes}),s=this.packedBuffers[e.id];if((!s||s.layoutKey!==n)&&(t=!0),t){s&&(s.packed.destroy(),delete this.packedBuffers[e.id]);const r=this._interleavePackedGroup(e);return this.packedBuffers[e.id]={packed:r,layoutKey:n},r.buffer}if(!s)throw new Error(`Attribute buffer group ${e.id} has no packed buffer`);return s.packed.buffer}_interleavePackedGroup(e){const t=e.attributes.map(s=>this._getInterleaveInput(e,s)),n=a1(...t);return c1(this.device,n),n}_getInterleaveInput(e,t){const n=Qe(t.getAccessor()),s=e.byteOffsets[t.id];if($i(`${e.id}.${t.id} rowByteLength`,n),$i(`${e.id}.${t.id} groupByteOffset`,s),t.isConstant){const c=t.getConstantValue();if(!c)throw new Error(`Attribute group ${e.id} is missing constant value ${t.id}`);return $i(`${e.id}.${t.id} constant byteOffset`,c.byteOffset),new se({id:t.id,type:"uint32",size:n/4,isConstant:!0,value:new Uint32Array(c.buffer,c.byteOffset,n/Uint32Array.BYTES_PER_ELEMENT)})}const r=t.getBuffer(),o=t.byteOffset,a=t.getAccessor().stride||n;if($i(`${e.id}.${t.id} byteOffset`,o),$i(`${e.id}.${t.id} stride`,a),!r)throw new Error(`Attribute group ${e.id} cannot interleave missing buffer ${t.id}`);return new se({id:t.id,type:"uint32",size:n/4,offset:o,stride:a,length:e.rowCount,buffer:r})}}function Hf(i){return Math.ceil(i/4)*4}function $i(i,e){if(e%4!==0)throw new Error(`Attribute buffer groups require 32-bit alignment: ${i}=${e}`)}function Zo(i){const{source:e,target:t,start:n=0,size:s,getData:r}=i,o=i.end||t.length,a=e.length,c=o-n;if(a>c){t.set(e.subarray(0,c),n);return}if(t.set(e,n),!r)return;let l=a;for(;l<c;){const u=r(l,e);for(let f=0;f<s;f++)t[n+l]=u[f]||0,l++}}function k1({source:i,target:e,size:t,getData:n,sourceStartIndices:s,targetStartIndices:r}){if(!s||!r)return Zo({source:i,target:e,size:t,getData:n}),e;let o=0,a=0;const c=n&&((u,f)=>n(u+a,f)),l=Math.min(s.length,r.length);for(let u=1;u<l;u++){const f=s[u]*t,d=r[u]*t;Zo({source:i.subarray(o,f),target:e,start:a,end:d,size:t,getData:c}),o=f,a=d}return a<e.length&&Zo({source:[],target:e,start:a,size:t,getData:c}),e}function D1(i){const{device:e,settings:t,value:n}=i,s=new dp(e,t);return s.setData({value:n instanceof Float64Array?new Float64Array(0):new Float32Array(0),normalized:t.normalized}),s}function vp(i){switch(i){case 1:return"float";case 2:return"vec2";case 3:return"vec3";case 4:return"vec4";default:throw new Error(`No defined attribute type for size "${i}"`)}}function wp(i){switch(i){case 1:return"float32";case 2:return"float32x2";case 3:return"float32x3";case 4:return"float32x4";default:throw new Error("invalid type size")}}function xp(i){i.push(i.shift())}function F1(i,e){const{settings:t,value:n,size:s}=i,r=i.isDoublePrecisionBuffer?2:1;let o=0;const{shaderAttributes:a}=i.settings;if(a)for(const c of Object.values(a))o=Math.max(o,c.vertexOffset??0);return(t.noAlloc?n.length:(e+o)*s)*r}function Pp({device:i,source:e,target:t}){return(!t||t.byteLength<e.byteLength)&&(t==null||t.destroy(),t=i.createBuffer({byteLength:e.byteLength,usage:e.usage})),t}function Sp({device:i,buffer:e,attribute:t,fromLength:n,toLength:s,fromStartIndices:r,getData:o=a=>a}){const a=t.isDoublePrecisionBuffer?2:1,c=t.size*a,l=t.byteOffset,u=t.settings.bytesPerElement<4?l/t.settings.bytesPerElement*4:l,f=t.startIndices,d=r&&f,g=t.isConstant;if(!d&&e&&n>=s)return e;const p=t.value instanceof Float64Array?Float32Array:t.value.constructor,m=g?t.value:new p(t.getBuffer().readSyncWebGL(l,s*p.BYTES_PER_ELEMENT).buffer);if(t.settings.normalized&&!g){const y=o;o=(x,S)=>t.normalizeConstant(y(x,S))}const _=g?(y,x)=>o(m,x):(y,x)=>o(m.subarray(y,y+c),x),v=e?new Float32Array(e.readSyncWebGL(u,n*4).buffer):new Float32Array(0),w=new Float32Array(s);return k1({source:v,target:w,sourceStartIndices:r,targetStartIndices:f,size:c,getData:_}),(!e||e.byteLength<w.byteLength+u)&&(e==null||e.destroy(),e=i.createBuffer({byteLength:w.byteLength+u,usage:35050})),e.write(w,u),e}class Ep{constructor({device:e,attribute:t,timeline:n}){this.buffers=[],this.currentLength=0,this.device=e,this.transition=new Vr(n),this.attribute=t,this.attributeInTransition=D1(t),this.currentStartIndices=t.startIndices}get inProgress(){return this.transition.inProgress}start(e,t,n=1/0){this.settings=e,this.currentStartIndices=this.attribute.startIndices,this.currentLength=F1(this.attribute,t),this.transition.start({...e,duration:n})}update(){const e=this.transition.update();return e&&this.onUpdate(),e}setBuffer(e){const{stride:t}=this.attributeInTransition.getAccessor();this.attributeInTransition.setData({buffer:e,normalized:this.attribute.settings.normalized,value:this.attributeInTransition.value,stride:t})}cancel(){this.transition.cancel()}delete(){this.cancel();for(const e of this.buffers)e.destroy();this.buffers.length=0}}class z1 extends Ep{constructor({device:e,attribute:t,timeline:n}){super({device:e,attribute:t,timeline:n}),this.type="interpolation",this.hasUpdated=!1,this.transform=G1(e,t)}start(e,t){const n=this.currentLength,s=this.currentStartIndices;if(super.start(e,t,e.duration),e.duration<=0){this.transition.cancel();return}const{buffers:r,attribute:o}=this;this.hasUpdated&&xp(r),this.hasUpdated=!1,r[0]=Sp({device:this.device,buffer:r[0],attribute:o,fromLength:n,toLength:this.currentLength,fromStartIndices:s,getData:e.enter}),r[1]=Pp({device:this.device,source:r[0],target:r[1]}),this.setBuffer(r[1]);const{transform:a}=this,c=a.model;let l=Math.floor(this.currentLength/o.size);Cp(o)&&(l/=2),c.setVertexCount(l),o.isConstant?(c.setAttributes({aFrom:r[0]}),c.setConstantAttributes({aTo:o.value})):c.setAttributes({aFrom:r[0],aTo:o.getBuffer()}),a.transformFeedback.setBuffers({vCurrent:r[1]})}onUpdate(){const{duration:e,easing:t}=this.settings,{time:n}=this.transition;let s=n/e;t&&(s=t(s));const{model:r}=this.transform,o={time:s};r.shaderInputs.setProps({interpolation:o}),this.transform.run({discard:!0}),this.hasUpdated=!0}delete(){super.delete(),this.transform.destroy()}}const N1=`layout(std140) uniform interpolationUniforms {
  float time;
} interpolation;
`,Yf={name:"interpolation",vs:N1,uniformTypes:{time:"f32"}},U1=`#version 300 es
#define SHADER_NAME interpolation-transition-vertex-shader

in ATTRIBUTE_TYPE aFrom;
in ATTRIBUTE_TYPE aTo;
out ATTRIBUTE_TYPE vCurrent;

void main(void) {
  vCurrent = mix(aFrom, aTo, interpolation.time);
  gl_Position = vec4(0.0);
}
`,$1=`#version 300 es
#define SHADER_NAME interpolation-transition-vertex-shader

in ATTRIBUTE_TYPE aFrom;
in ATTRIBUTE_TYPE aFrom64Low;
in ATTRIBUTE_TYPE aTo;
in ATTRIBUTE_TYPE aTo64Low;
out ATTRIBUTE_TYPE vCurrent;
out ATTRIBUTE_TYPE vCurrent64Low;

vec2 mix_fp64(vec2 a, vec2 b, float x) {
  vec2 range = sub_fp64(b, a);
  return sum_fp64(a, mul_fp64(range, vec2(x, 0.0)));
}

void main(void) {
  for (int i=0; i<ATTRIBUTE_SIZE; i++) {
    vec2 value = mix_fp64(vec2(aFrom[i], aFrom64Low[i]), vec2(aTo[i], aTo64Low[i]), interpolation.time);
    vCurrent[i] = value.x;
    vCurrent64Low[i] = value.y;
  }
  gl_Position = vec4(0.0);
}
`;function Cp(i){return i.isDoublePrecisionBuffer}function G1(i,e){const t=e.size,n=vp(t),s=wp(t),r=e.getBufferLayout();return Cp(e)?new Sn(i,{vs:$1,bufferLayout:[{name:"aFrom",byteStride:8*t,attributes:[{attribute:"aFrom",format:s,byteOffset:0},{attribute:"aFrom64Low",format:s,byteOffset:4*t}]},{name:"aTo",byteStride:8*t,attributes:[{attribute:"aTo",format:s,byteOffset:0},{attribute:"aTo64Low",format:s,byteOffset:4*t}]}],modules:[vP,Yf],defines:{ATTRIBUTE_TYPE:n,ATTRIBUTE_SIZE:t},moduleSettings:{},varyings:["vCurrent","vCurrent64Low"],bufferMode:35980,disableWarnings:!0}):new Sn(i,{vs:U1,bufferLayout:[{name:"aFrom",format:s},{name:"aTo",format:r.attributes[0].format}],modules:[Yf],defines:{ATTRIBUTE_TYPE:n},varyings:["vCurrent"],disableWarnings:!0})}class j1 extends Ep{constructor({device:e,attribute:t,timeline:n}){super({device:e,attribute:t,timeline:n}),this.type="spring",this.texture=Z1(e),this.framebuffer=X1(e,this.texture),this.transform=q1(e,t)}start(e,t){const n=this.currentLength,s=this.currentStartIndices;super.start(e,t);const{buffers:r,attribute:o}=this;for(let c=0;c<2;c++)r[c]=Sp({device:this.device,buffer:r[c],attribute:o,fromLength:n,toLength:this.currentLength,fromStartIndices:s,getData:e.enter});r[2]=Pp({device:this.device,source:r[0],target:r[2]}),this.setBuffer(r[1]);const{model:a}=this.transform;a.setVertexCount(Math.floor(this.currentLength/o.size)),o.isConstant?a.setConstantAttributes({aTo:o.value}):a.setAttributes({aTo:o.getBuffer()})}onUpdate(){const{buffers:e,transform:t,framebuffer:n,transition:s}=this,r=this.settings;t.model.setAttributes({aPrev:e[0],aCur:e[1]}),t.transformFeedback.setBuffers({vNext:e[2]});const o={stiffness:r.stiffness,damping:r.damping};t.model.shaderInputs.setProps({spring:o}),t.run({framebuffer:n,discard:!1,parameters:{viewport:[0,0,1,1]},clearColor:[0,0,0,0]}),xp(e),this.setBuffer(e[1]),this.device.readPixelsToArrayWebGL(n)[0]>0||s.end()}delete(){super.delete(),this.transform.destroy(),this.texture.destroy(),this.framebuffer.destroy()}}const V1=`layout(std140) uniform springUniforms {
  float damping;
  float stiffness;
} spring;
`,W1={name:"spring",vs:V1,uniformTypes:{damping:"f32",stiffness:"f32"}},H1=`#version 300 es
#define SHADER_NAME spring-transition-vertex-shader

#define EPSILON 0.00001

in ATTRIBUTE_TYPE aPrev;
in ATTRIBUTE_TYPE aCur;
in ATTRIBUTE_TYPE aTo;
out ATTRIBUTE_TYPE vNext;
out float vIsTransitioningFlag;

ATTRIBUTE_TYPE getNextValue(ATTRIBUTE_TYPE cur, ATTRIBUTE_TYPE prev, ATTRIBUTE_TYPE dest) {
  ATTRIBUTE_TYPE velocity = cur - prev;
  ATTRIBUTE_TYPE delta = dest - cur;
  ATTRIBUTE_TYPE force = delta * spring.stiffness;
  ATTRIBUTE_TYPE resistance = velocity * spring.damping;
  return force - resistance + velocity + cur;
}

void main(void) {
  bool isTransitioning = length(aCur - aPrev) > EPSILON || length(aTo - aCur) > EPSILON;
  vIsTransitioningFlag = isTransitioning ? 1.0 : 0.0;

  vNext = getNextValue(aCur, aPrev, aTo);
  gl_Position = vec4(0, 0, 0, 1);
  gl_PointSize = 100.0;
}
`,Y1=`#version 300 es
#define SHADER_NAME spring-transition-is-transitioning-fragment-shader

in float vIsTransitioningFlag;

out vec4 fragColor;

void main(void) {
  if (vIsTransitioningFlag == 0.0) {
    discard;
  }
  fragColor = vec4(1.0);
}`;function q1(i,e){const t=vp(e.size),n=wp(e.size);return new Sn(i,{vs:H1,fs:Y1,bufferLayout:[{name:"aPrev",format:n},{name:"aCur",format:n},{name:"aTo",format:e.getBufferLayout().attributes[0].format}],varyings:["vNext"],modules:[W1],defines:{ATTRIBUTE_TYPE:t},parameters:{depthCompare:"always",blendColorOperation:"max",blendColorSrcFactor:"one",blendColorDstFactor:"one",blendAlphaOperation:"max",blendAlphaSrcFactor:"one",blendAlphaDstFactor:"one"}})}function Z1(i){return i.createTexture({data:new Uint8Array(4),format:"rgba8unorm",width:1,height:1})}function X1(i,e){return i.createFramebuffer({id:"spring-transition-is-transitioning-framebuffer",width:1,height:1,colorAttachments:[e]})}const K1={interpolation:z1,spring:j1};class Q1{constructor(e,{id:t,timeline:n}){if(!e)throw new Error("AttributeTransitionManager is constructed without device");this.id=t,this.device=e,this.timeline=n,this.transitions={},this.needsRedraw=!1,this.numInstances=1}finalize(){for(const e in this.transitions)this._removeTransition(e)}update({attributes:e,transitions:t,numInstances:n}){this.numInstances=n||1;for(const s in e){const r=e[s],o=r.getTransitionSetting(t);o&&this._updateAttribute(s,r,o)}for(const s in this.transitions){const r=e[s];(!r||!r.getTransitionSetting(t))&&this._removeTransition(s)}}hasAttribute(e){const t=this.transitions[e];return t&&t.inProgress}getAttributes(){const e={};for(const t in this.transitions){const n=this.transitions[t];n.inProgress&&(e[t]=n.attributeInTransition)}return e}run(){if(this.numInstances===0)return!1;for(const t in this.transitions)this.transitions[t].update()&&(this.needsRedraw=!0);const e=this.needsRedraw;return this.needsRedraw=!1,e}_removeTransition(e){this.transitions[e].delete(),delete this.transitions[e]}_updateAttribute(e,t,n){const s=this.transitions[e];let r=!s||s.type!==n.type;if(r){s&&this._removeTransition(e);const o=K1[n.type];o?this.transitions[e]=new o({attribute:t,timeline:this.timeline,device:this.device}):(Y.error(`unsupported transition type '${n.type}'`)(),r=!1)}(r||t.needsRedraw())&&(this.needsRedraw=!0,this.transitions[e].start(n,this.numInstances))}}const qf="attributeManager.invalidate",J1="attributeManager.updateStart",eA="attributeManager.updateEnd",tA="attribute.updateStart",iA="attribute.allocate",nA="attribute.updateEnd";class sA{constructor(e,{id:t="attribute-manager",stats:n,timeline:s}={}){this.mergeBoundsMemoized=kn(xE),this.id=t,this.device=e,this.attributes={},this.updateTriggers={},this.needsRedraw=!0,this.userData={},this.stats=n,this.attributeTransitionManager=new Q1(e,{id:`${t}-transitions`,timeline:s}),this.attributeBufferGroups=e.type==="webgpu"?new B1(e,{id:t,isTransitionAttribute:r=>this.attributeTransitionManager.hasAttribute(r)}):null,Object.seal(this)}finalize(){var e;(e=this.attributeBufferGroups)==null||e.finalize();for(const t in this.attributes)this.attributes[t].delete();this.attributeTransitionManager.finalize()}getNeedsRedraw(e={clearRedrawFlags:!1}){const t=this.needsRedraw;return this.needsRedraw=this.needsRedraw&&!e.clearRedrawFlags,t&&this.id}setNeedsRedraw(){this.needsRedraw=!0}add(e){this._add(e)}addInstanced(e){this._add(e,{stepMode:"instance"})}remove(e){for(const t of e)this.attributes[t]!==void 0&&(this.attributes[t].delete(),delete this.attributes[t])}invalidate(e,t){const n=this._invalidateTrigger(e,t);ye(qf,this,e,n)}invalidateAll(e){for(const t in this.attributes)this.attributes[t].setNeedsUpdate(t,e);ye(qf,this,"all")}update({data:e,numInstances:t,startIndices:n=null,transitions:s,props:r={},buffers:o={},context:a={}}){let c=!1;ye(J1,this),this.stats&&this.stats.get("Update Attributes").timeStart();for(const l in this.attributes){const u=this.attributes[l],f=u.settings.accessor;u.startIndices=n,u.numInstances=t,r[l]&&Y.removed(`props.${l}`,`data.attributes.${l}`)(),u.setExternalBuffer(o[l])||u.setBinaryValue(typeof f=="string"?o[f]:void 0,e.startIndices)||typeof f=="string"&&!o[f]&&u.setConstantValue(a,r[f])||u.needsUpdate()&&(c=!0,this._updateAttribute({attribute:u,numInstances:t,data:e,props:r,context:a})),this.needsRedraw=this.needsRedraw||u.needsRedraw()}c&&ye(eA,this,t),this.stats&&(this.stats.get("Update Attributes").timeEnd(),c&&this.stats.get("Attributes updated").incrementCount()),this.attributeTransitionManager.update({attributes:this.attributes,numInstances:t,transitions:s})}updateTransition(){const{attributeTransitionManager:e}=this,t=e.run();return this.needsRedraw=this.needsRedraw||t,t}getAttributes(){return{...this.attributes,...this.attributeTransitionManager.getAttributes()}}getBounds(e){const t=e.map(n=>{var s;return(s=this.attributes[n])==null?void 0:s.getBounds()});return this.mergeBoundsMemoized(t)}getChangedAttributes(e={clearChangedFlags:!1}){const{attributes:t,attributeTransitionManager:n}=this,s={...n.getAttributes()};for(const r in t){const o=t[r];o.needsRedraw(e)&&!n.hasAttribute(r)&&(s[r]=o)}return s}getBufferLayouts(e){return this.hasBufferGroups()?this.attributeBufferGroups.getBufferLayouts(this.getAttributes(),e):Object.values(this.getAttributes()).map(t=>t.getBufferLayout(e))}hasBufferGroups(){var e;return!!((e=this.attributeBufferGroups)!=null&&e.hasGroups(this.attributes))}getBufferGroupBindings(e,t,n={}){return this.attributeBufferGroups?this.attributeBufferGroups.getBindings(this.getAttributes(),e,t,n):{bufferLayouts:this.getBufferLayouts(t),buffers:{},groupedAttributeIds:new Set}}_add(e,t){for(const n in e){const s=e[n],r={...s,id:n,size:s.isIndexed&&1||s.size||1,...t};this.attributes[n]=new dp(this.device,r)}this._mapUpdateTriggersToAttributes()}_mapUpdateTriggersToAttributes(){const e={};for(const t in this.attributes)this.attributes[t].getUpdateTriggers().forEach(s=>{e[s]||(e[s]=[]),e[s].push(t)});this.updateTriggers=e}_invalidateTrigger(e,t){const{attributes:n,updateTriggers:s}=this,r=s[e];return r&&r.forEach(o=>{const a=n[o];a&&a.setNeedsUpdate(a.id,t)}),r}_updateAttribute(e){const{attribute:t,numInstances:n}=e;if(ye(tA,t),t.constant){t.setConstantValue(e.context,t.value);return}t.allocate(n)&&ye(iA,t,n),t.updateBuffer(e)&&(this.needsRedraw=!0,ye(nA,t,n))}}class rA extends Vr{get value(){return this._value}_onUpdate(){const{time:e,settings:{fromValue:t,toValue:n,duration:s,easing:r}}=this,o=r(e/s);this._value=Qs(t,n,o)}}const Zf=1e-5;function Xf(i,e,t,n,s){const r=e-i,a=(t-e)*s,c=-r*n;return a+c+r+e}function oA(i,e,t,n,s){if(Array.isArray(t)){const r=[];for(let o=0;o<t.length;o++)r[o]=Xf(i[o],e[o],t[o],n,s);return r}return Xf(i,e,t,n,s)}function Kf(i,e){if(Array.isArray(i)){let t=0;for(let n=0;n<i.length;n++){const s=i[n]-e[n];t+=s*s}return Math.sqrt(t)}return Math.abs(i-e)}class aA extends Vr{get value(){return this._currValue}_onUpdate(){const{fromValue:e,toValue:t,damping:n,stiffness:s}=this.settings,{_prevValue:r=e,_currValue:o=e}=this;let a=oA(r,o,t,n,s);const c=Kf(a,t),l=Kf(a,o);c<Zf&&l<Zf&&(a=t,this.end()),this._prevValue=o,this._currValue=a}}const cA={interpolation:rA,spring:aA};class lA{constructor(e){this.transitions=new Map,this.timeline=e}get active(){return this.transitions.size>0}add(e,t,n,s){const{transitions:r}=this;if(r.has(e)){const c=r.get(e),{value:l=c.settings.fromValue}=c;t=l,this.remove(e)}if(s=fp(s),!s)return;const o=cA[s.type];if(!o){Y.error(`unsupported transition type '${s.type}'`)();return}const a=new o(this.timeline);a.start({...s,fromValue:t,toValue:n}),r.set(e,a)}remove(e){const{transitions:t}=this;t.has(e)&&(t.get(e).cancel(),t.delete(e))}update(){const e={};for(const[t,n]of this.transitions)n.update(),e[t]=n.value,n.inProgress||this.remove(t);return e}clear(){for(const e of this.transitions.keys())this.remove(e)}}function uA(i){const e=i[_t];for(const t in e){const n=e[t],{validate:s}=n;if(s&&!s(i[t],n))throw new Error(`Invalid prop ${t}: ${i[t]}`)}}function fA(i,e){const t=Lp({newProps:i,oldProps:e,propTypes:i[_t],ignoreProps:{data:null,updateTriggers:null,extensions:null,transitions:null}}),n=hA(i,e);let s=!1;return n||(s=gA(i,e)),{dataChanged:n,propsChanged:t,updateTriggersChanged:s,extensionsChanged:pA(i,e),transitionsChanged:dA(i,e)}}function dA(i,e){if(!i.transitions)return!1;const t={},n=i[_t];let s=!1;for(const r in i.transitions){const o=n[r],a=o&&o.type;(a==="number"||a==="color"||a==="array")&&dc(i[r],e[r],o)&&(t[r]=!0,s=!0)}return s?t:!1}function Lp({newProps:i,oldProps:e,ignoreProps:t={},propTypes:n={},triggerName:s="props"}){if(e===i)return!1;if(typeof i!="object"||i===null)return`${s} changed shallowly`;if(typeof e!="object"||e===null)return`${s} changed shallowly`;for(const r of Object.keys(i))if(!(r in t)){if(!(r in e))return`${s}.${r} added`;const o=dc(i[r],e[r],n[r]);if(o)return`${s}.${r} ${o}`}for(const r of Object.keys(e))if(!(r in t)){if(!(r in i))return`${s}.${r} dropped`;if(!Object.hasOwnProperty.call(i,r)){const o=dc(i[r],e[r],n[r]);if(o)return`${s}.${r} ${o}`}}return!1}function dc(i,e,t){let n=t&&t.equal;return n&&!n(i,e,t)||!n&&(n=i&&e&&i.equals,n&&!n.call(i,e))?"changed deeply":!n&&e!==i?"changed shallowly":null}function hA(i,e){if(e===null)return"oldProps is null, initial diff";let t=!1;const{dataComparator:n,_dataDiff:s}=i;return n?n(i.data,e.data)||(t="Data comparator detected a change"):i.data!==e.data&&(t="A new data container was supplied"),t&&s&&(t=s(i.data,e.data)||t),t}function gA(i,e){if(e===null)return{all:!0};if("all"in i.updateTriggers&&Qf(i,e,"all"))return{all:!0};const t={};let n=!1;for(const s in i.updateTriggers)s!=="all"&&Qf(i,e,s)&&(t[s]=!0,n=!0);return n?t:!1}function pA(i,e){if(e===null)return!0;const t=e.extensions,{extensions:n}=i;if(n===t)return!1;if(!t||!n||n.length!==t.length)return!0;for(let s=0;s<n.length;s++)if(!n[s].equals(t[s]))return!0;return!1}function Qf(i,e,t){let n=i.updateTriggers[t];n=n??{};let s=e.updateTriggers[t];return s=s??{},Lp({oldProps:s,newProps:n,triggerName:t})}const mA="count(): argument not an object",_A="count(): argument not a container";function yA(i){if(!vA(i))throw new Error(mA);if(typeof i.count=="function")return i.count();if(Number.isFinite(i.size))return i.size;if(Number.isFinite(i.length))return i.length;if(bA(i))return Object.keys(i).length;throw new Error(_A)}function bA(i){return i!==null&&typeof i=="object"&&i.constructor===Object}function vA(i){return i!==null&&typeof i=="object"}function Jf(i,e){if(!e)return i;const t={...i,...e};if("defines"in e&&(t.defines={...i.defines,...e.defines}),"modules"in e&&(t.modules=(i.modules||[]).concat(e.modules),e.modules.some(n=>n.name==="project64"))){const n=t.modules.findIndex(s=>s.name==="project32");n>=0&&t.modules.splice(n,1)}if("inject"in e)if(!i.inject)t.inject=e.inject;else{const n={...i.inject};for(const s in e.inject)n[s]=(n[s]||"")+e.inject[s];t.inject=n}return t}const wA={minFilter:"linear",mipmapFilter:"linear",magFilter:"linear",addressModeU:"clamp-to-edge",addressModeV:"clamp-to-edge"},hc={};function xA(i,e,t,n){if(t instanceof he)return t;t.constructor&&t.constructor.name!=="Object"&&(t={data:t});let s=null;t.compressed&&(s={minFilter:"linear",mipmapFilter:t.data.length>1?"nearest":"linear"});const{width:r,height:o}=t.data,a=e.createTexture({...t,sampler:{...wA,...s,...n},mipLevels:e.getMipLevelCount(r,o)});return e.type==="webgl"?a.generateMipmapsWebGL():e.type==="webgpu"&&e.generateMipmapsWebGPU(a),hc[a.id]=i,a}function PA(i,e){!e||!(e instanceof he)||hc[e.id]===i&&(e.delete(),delete hc[e.id])}const SA={boolean:{validate(i,e){return!0},equal(i,e,t){return!!i==!!e}},number:{validate(i,e){return Number.isFinite(i)&&(!("max"in e)||i<=e.max)&&(!("min"in e)||i>=e.min)}},color:{validate(i,e){return e.optional&&!i||gc(i)&&(i.length===3||i.length===4)},equal(i,e,t){return Pe(i,e,1)}},accessor:{validate(i,e){const t=ur(i);return t==="function"||t===ur(e.value)},equal(i,e,t){return typeof e=="function"?!0:Pe(i,e,1)}},array:{validate(i,e){return e.optional&&!i||gc(i)},equal(i,e,t){const{compare:n}=t,s=Number.isInteger(n)?n:n?1:0;return n?Pe(i,e,s):i===e}},object:{equal(i,e,t){if(t.ignore)return!0;const{compare:n}=t,s=Number.isInteger(n)?n:n?1:0;return n?Pe(i,e,s):i===e}},function:{validate(i,e){return e.optional&&!i||typeof i=="function"},equal(i,e,t){return!t.compare&&t.ignore!==!1||i===e}},data:{transform:(i,e,t)=>{if(!i)return i;const{dataTransform:n}=t.props;return n?n(i):typeof i.shape=="string"&&i.shape.endsWith("-table")&&Array.isArray(i.data)?i.data:i}},image:{transform:(i,e,t)=>{const n=t.context;return!n||!n.device?null:xA(t.id,n.device,i,{...e.parameters,...t.props.textureParameters})},release:(i,e,t)=>{PA(t.id,i)}}};function EA(i){const e={},t={},n={};for(const[s,r]of Object.entries(i)){const o=r==null?void 0:r.deprecatedFor;if(o)n[s]=Array.isArray(o)?o:[o];else{const a=CA(s,r);e[s]=a,t[s]=a.value}}return{propTypes:e,defaultProps:t,deprecatedProps:n}}function CA(i,e){switch(ur(e)){case"object":return Gi(i,e);case"array":return Gi(i,{type:"array",value:e,compare:!1});case"boolean":return Gi(i,{type:"boolean",value:e});case"number":return Gi(i,{type:"number",value:e});case"function":return Gi(i,{type:"function",value:e,compare:!0});default:return{name:i,type:"unknown",value:e}}}function Gi(i,e){return"type"in e?{name:i,...SA[e.type],...e}:"value"in e?{name:i,type:ur(e.value),...e}:{name:i,type:"object",value:e}}function gc(i){return Array.isArray(i)||ArrayBuffer.isView(i)}function ur(i){return gc(i)?"array":i===null?"null":typeof i}function LA(i,e){let t;for(let r=e.length-1;r>=0;r--){const o=e[r];"extensions"in o&&(t=o.extensions)}const n=pc(i.constructor,t),s=Object.create(n);s[ar]=i,s[$t]={},s[gt]={};for(let r=0;r<e.length;++r){const o=e[r];for(const a in o)s[a]=o[a]}return Object.freeze(s),s}const TA="_mergedDefaultProps";function pc(i,e){if(!(i instanceof Yr.constructor))return{};let t=TA;if(e)for(const s of e){const r=s.constructor;r&&(t+=`:${r.extensionName||r.name}`)}const n=Tp(i,t);return n||(i[t]=AA(i,e||[]))}function AA(i,e){if(!i.prototype)return null;const n=Object.getPrototypeOf(i),s=pc(n),r=Tp(i,"defaultProps")||{},o=EA(r),a=Object.assign(Object.create(null),s,o.defaultProps),c=Object.assign(Object.create(null),s==null?void 0:s[_t],o.propTypes),l=Object.assign(Object.create(null),s==null?void 0:s[Oo],o.deprecatedProps);for(const u of e){const f=pc(u.constructor);f&&(Object.assign(a,f),Object.assign(c,f[_t]),Object.assign(l,f[Oo]))}return MA(a,i),RA(a,c),IA(a,l),a[_t]=c,a[Oo]=l,e.length===0&&!_l(i,"_propTypes")&&(i._propTypes=c),a}function MA(i,e){const t=BA(e);Object.defineProperties(i,{id:{writable:!0,value:t}})}function IA(i,e){for(const t in e)Object.defineProperty(i,t,{enumerable:!1,set(n){const s=`${this.id}: ${t}`;for(const r of e[t])_l(this,r)||(this[r]=n);Y.deprecated(s,e[t].join("/"))()}})}function RA(i,e){const t={},n={};for(const s in e){const r=e[s],{name:o,value:a}=r;r.async&&(t[o]=a,n[o]=OA(o))}i[ui]=t,i[$t]={},Object.defineProperties(i,n)}function OA(i){return{enumerable:!0,set(e){typeof e=="string"||e instanceof Promise||lp(e)?this[$t][i]=e:this[gt][i]=e},get(){if(this[gt]){if(i in this[gt])return this[gt][i]||this[ui][i];if(i in this[$t]){const e=this[ar]&&this[ar].internalState;if(e&&e.hasAsyncProp(i))return e.getAsyncProp(i)||this[ui][i]}}return this[ui][i]}}}function _l(i,e){return Object.prototype.hasOwnProperty.call(i,e)}function Tp(i,e){return _l(i,e)&&i[e]}function BA(i){const e=i.componentName;return e||Y.warn(`${i.name}.componentName not specified`)(),e||i.name}let kA=0;class Yr{constructor(...e){this.props=LA(this,e),this.id=this.props.id,this.count=kA++}clone(e){const{props:t}=this,n={};for(const s in t[ui])s in t[gt]?n[s]=t[gt][s]:s in t[$t]&&(n[s]=t[$t][s]);return new this.constructor({...t,...n,...e})}}Yr.componentName="Component";Yr.defaultProps={};const DA=Object.freeze({});class FA{constructor(e){this.component=e,this.asyncProps={},this.onAsyncPropUpdated=()=>{},this.oldProps=null,this.oldAsyncProps=null}finalize(){for(const e in this.asyncProps){const t=this.asyncProps[e];t&&t.type&&t.type.release&&t.type.release(t.resolvedValue,t.type,this.component)}this.asyncProps={},this.component=null,this.resetOldProps()}getOldProps(){return this.oldAsyncProps||this.oldProps||DA}resetOldProps(){this.oldAsyncProps=null,this.oldProps=this.component?this.component.props:null}hasAsyncProp(e){return e in this.asyncProps}getAsyncProp(e){const t=this.asyncProps[e];return t&&t.resolvedValue}isAsyncPropLoading(e){if(e){const t=this.asyncProps[e];return!!(t&&t.pendingLoadCount>0&&t.pendingLoadCount!==t.resolvedLoadCount)}for(const t in this.asyncProps)if(this.isAsyncPropLoading(t))return!0;return!1}reloadAsyncProp(e,t){this._watchPromise(e,Promise.resolve(t))}setAsyncProps(e){this.component=e[ar]||this.component;const t=e[gt]||{},n=e[$t]||e,s=e[ui]||{};for(const r in t){const o=t[r];this._createAsyncPropData(r,s[r]),this._updateAsyncProp(r,o),t[r]=this.getAsyncProp(r)}for(const r in n){const o=n[r];this._createAsyncPropData(r,s[r]),this._updateAsyncProp(r,o)}}_fetch(e,t){return null}_onResolve(e,t){}_onError(e,t){}_updateAsyncProp(e,t){if(this._didAsyncInputValueChange(e,t)){if(typeof t=="string"&&(t=this._fetch(e,t)),t instanceof Promise){this._watchPromise(e,t);return}if(lp(t)){this._resolveAsyncIterable(e,t);return}this._setPropValue(e,t)}}_freezeAsyncOldProps(){if(!this.oldAsyncProps&&this.oldProps){this.oldAsyncProps=Object.create(this.oldProps);for(const e in this.asyncProps)Object.defineProperty(this.oldAsyncProps,e,{enumerable:!0,value:this.oldProps[e]})}}_didAsyncInputValueChange(e,t){const n=this.asyncProps[e];return t===n.resolvedValue||t===n.lastValue?!1:(n.lastValue=t,!0)}_setPropValue(e,t){this._freezeAsyncOldProps();const n=this.asyncProps[e];n&&(t=this._postProcessValue(n,t),n.resolvedValue=t,n.pendingLoadCount++,n.resolvedLoadCount=n.pendingLoadCount)}_setAsyncPropValue(e,t,n){const s=this.asyncProps[e];s&&n>=s.resolvedLoadCount&&t!==void 0&&(this._freezeAsyncOldProps(),s.resolvedValue=t,s.resolvedLoadCount=n,this.onAsyncPropUpdated(e,t))}_watchPromise(e,t){const n=this.asyncProps[e];if(n){n.pendingLoadCount++;const s=n.pendingLoadCount;t.then(r=>{this.component&&(r=this._postProcessValue(n,r),this._setAsyncPropValue(e,r,s),this._onResolve(e,r))}).catch(r=>{this._onError(e,r)})}}async _resolveAsyncIterable(e,t){if(e!=="data"){this._setPropValue(e,t);return}const n=this.asyncProps[e];if(!n)return;n.pendingLoadCount++;const s=n.pendingLoadCount;let r=[],o=0;for await(const a of t){if(!this.component)return;const{dataTransform:c}=this.component.props;c?r=c(a,r):r=r.concat(a),Object.defineProperty(r,"__diff",{enumerable:!1,value:[{startRow:o,endRow:r.length}]}),o=r.length,this._setAsyncPropValue(e,r,s)}this._onResolve(e,r)}_postProcessValue(e,t){const n=e.type;return n&&this.component&&(n.release&&n.release(e.resolvedValue,n,this.component),n.transform)?n.transform(t,n,this.component):t}_createAsyncPropData(e,t){if(!this.asyncProps[e]){const s=this.component&&this.component.props[_t];this.asyncProps[e]={type:s&&s[e],lastValue:null,resolvedValue:t,pendingLoadCount:0,resolvedLoadCount:0}}}}class zA extends FA{constructor({attributeManager:e,layer:t}){super(t),this.attributeManager=e,this.needsRedraw=!0,this.needsUpdate=!0,this.subLayers=null,this.usesPickingColorCache=!1,this.disabledPickingIndices=[]}get layer(){return this.component}_fetch(e,t){const n=this.layer,s=n==null?void 0:n.props.fetch;return s?s(t,{propName:e,layer:n}):super._fetch(e,t)}_onResolve(e,t){const n=this.layer;if(n){const s=n.props.onDataLoad;e==="data"&&s&&s(t,{propName:e,layer:n})}}_onError(e,t){const n=this.layer;n&&n.raiseError(t,`loading ${e} of ${this.layer}`)}}const NA="layer.changeFlag",UA="layer.initialize",$A="layer.update",GA="layer.finalize",jA="layer.matched",ed=2**24-1,VA=Object.freeze([]),WA=kn(({oldViewport:i,viewport:e})=>i.equals(e));let Ae=new Uint8ClampedArray(0);function td(i){return i.rowIndexes||i.pickingColors||i.instancePickingColors}function Xo(i){return i.rowIndexes}function Ko(i){return i.pickingColors||i.instancePickingColors}const HA={data:{type:"data",value:VA,async:!0},dataComparator:{type:"function",value:null,optional:!0},_dataDiff:{type:"function",value:i=>i&&i.__diff,optional:!0},dataTransform:{type:"function",value:null,optional:!0},onDataLoad:{type:"function",value:null,optional:!0},onError:{type:"function",value:null,optional:!0},fetch:{type:"function",value:(i,{propName:e,layer:t,loaders:n,loadOptions:s,signal:r})=>{var c;const{resourceManager:o}=t.context;s=s||t.getLoadOptions(),n=n||t.props.loaders,r&&(s={...s,core:{...s==null?void 0:s.core,fetch:{...(c=s==null?void 0:s.core)==null?void 0:c.fetch,signal:r}}});let a=o.contains(i);return!a&&!s&&(o.add({resourceId:i,data:zs(i,n),persistent:!1}),a=!0),a?o.subscribe({resourceId:i,onChange:l=>{var u;return(u=t.internalState)==null?void 0:u.reloadAsyncProp(e,l)},consumerId:t.id,requestId:e}):zs(i,n,s)}},updateTriggers:{},visible:!0,pickable:!1,opacity:{type:"number",min:0,max:1,value:1},operation:"draw",onHover:{type:"function",value:null,optional:!0},onClick:{type:"function",value:null,optional:!0},onDragStart:{type:"function",value:null,optional:!0},onDrag:{type:"function",value:null,optional:!0},onDragEnd:{type:"function",value:null,optional:!0},coordinateSystem:"default",coordinateOrigin:{type:"array",value:[0,0,0],compare:!0},modelMatrix:{type:"array",value:null,compare:!0,optional:!0},wrapLongitude:!1,positionFormat:"XYZ",colorFormat:"RGBA",parameters:{type:"object",value:{},optional:!0,compare:2},loadOptions:{type:"object",value:null,optional:!0,ignore:!0},transitions:null,extensions:[],loaders:{type:"array",value:[],optional:!0,ignore:!0},getPolygonOffset:{type:"function",value:({layerIndex:i})=>[0,-i*100]},highlightedObjectIndex:null,autoHighlight:!1,highlightColor:{type:"accessor",value:[0,0,128,128]}};class xt extends Yr{constructor(){super(...arguments),this.internalState=null,this.lifecycle=ti.NO_STATE,this.parent=null}static get componentName(){return Object.prototype.hasOwnProperty.call(this,"layerName")?this.layerName:""}get root(){let e=this;for(;e.parent;)e=e.parent;return e}toString(){return`${this.constructor.layerName||this.constructor.name}({id: '${this.props.id}'})`}project(e){Q(this.internalState);const t=this.internalState.viewport||this.context.viewport,n=ol(e,{viewport:t,modelMatrix:this.props.modelMatrix,coordinateOrigin:this.props.coordinateOrigin,coordinateSystem:this.props.coordinateSystem}),[s,r,o]=nl(n,t.pixelProjectionMatrix);return e.length===2?[s,r]:[s,r,o]}unproject(e){return Q(this.internalState),(this.internalState.viewport||this.context.viewport).unproject(e)}projectPosition(e,t){Q(this.internalState);const n=this.internalState.viewport||this.context.viewport;return TE(e,{viewport:n,modelMatrix:this.props.modelMatrix,coordinateOrigin:this.props.coordinateOrigin,coordinateSystem:this.props.coordinateSystem,...t})}get isComposite(){return!1}get isDrawable(){return!0}setState(e){this.setChangeFlags({stateChanged:!0}),Object.assign(this.state,e),this.setNeedsRedraw()}setNeedsRedraw(){this.internalState&&(this.internalState.needsRedraw=!0)}setNeedsUpdate(){this.internalState&&(this.context.layerManager.setNeedsUpdate(String(this)),this.internalState.needsUpdate=!0)}get isLoaded(){return this.internalState?!this.internalState.isAsyncPropLoading():!1}get wrapLongitude(){return this.props.wrapLongitude}isPickable(){return this.props.pickable&&this.props.visible}getModels(){const e=this.state;return e&&(e.models||e.model&&[e.model])||[]}setShaderModuleProps(...e){for(const t of this.getModels())t.shaderInputs.setProps(...e)}getAttributeManager(){return this.internalState&&this.internalState.attributeManager}getCurrentLayer(){return this.internalState&&this.internalState.layer}getLoadOptions(){return this.props.loadOptions}use64bitPositions(){const{coordinateSystem:e}=this.props;return e==="default"||e==="lnglat"||e==="cartesian"}onHover(e,t){return this.props.onHover&&this.props.onHover(e,t)||!1}onClick(e,t){return this.props.onClick&&this.props.onClick(e,t)||!1}nullPickingColor(){return[0,0,0]}encodePickingColor(e,t=[]){return t[0]=e+1&255,t[1]=e+1>>8&255,t[2]=e+1>>8>>8&255,t}decodePickingColor(e){Q(e instanceof Uint8Array);const[t,n,s]=e;return t+n*256+s*65536-1}getNumInstances(){return Number.isFinite(this.props.numInstances)?this.props.numInstances:this.state&&this.state.numInstances!==void 0?this.state.numInstances:yA(this.props.data)}getStartIndices(){return this.props.startIndices?this.props.startIndices:this.state&&this.state.startIndices?this.state.startIndices:null}getBounds(){var e;return(e=this.getAttributeManager())==null?void 0:e.getBounds(["positions","instancePositions"])}getShaders(e){e=Jf(e,{disableWarnings:!0,modules:this.context.defaultShaderModules});for(const t of this.props.extensions)e=Jf(e,t.getShaders.call(this,t));return e}shouldUpdateState(e){return e.changeFlags.propsOrDataChanged}updateState(e){const t=this.getAttributeManager(),{dataChanged:n}=e.changeFlags;if(n&&t)if(Array.isArray(n))for(const s of n)t.invalidateAll(s);else t.invalidateAll();if(t){const{props:s}=e,r=this.internalState.hasPickingBuffer,o=Number.isInteger(s.highlightedObjectIndex)||!!s.pickable||s.extensions.some(a=>a.getNeedsPickingBuffer.call(this,a));if(r!==o){this.internalState.hasPickingBuffer=o;const a=td(t.attributes);a&&(o&&a.constant&&(a.constant=!1,t.invalidate(a.id)),!a.value&&!o&&(a.constant=!0,a.value=Xo(t.attributes)?[rr]:[0,0,0]))}}}finalizeState(e){for(const n of this.getModels())n.destroy();const t=this.getAttributeManager();t&&t.finalize(),this.context&&this.context.resourceManager.unsubscribe({consumerId:this.id}),this.internalState&&(this.internalState.uniformTransitions.clear(),this.internalState.finalize())}draw(e){for(const t of this.getModels())t.draw(e.renderPass)}getPickingInfo({info:e,mode:t,sourceLayer:n}){const{index:s}=e;return s>=0&&Array.isArray(this.props.data)&&(e.object=this.props.data[s]),e}raiseError(e,t){var n,s,r,o;t&&(e=new Error(`${t}: ${e.message}`,{cause:e})),(s=(n=this.props).onError)!=null&&s.call(n,e)||(o=(r=this.context)==null?void 0:r.onError)==null||o.call(r,e,this)}getNeedsRedraw(e={clearRedrawFlags:!1}){return this._getNeedsRedraw(e)}needsUpdate(){return this.internalState?this.internalState.needsUpdate||this.hasUniformTransition()||this.shouldUpdateState(this._getUpdateParams()):!1}hasUniformTransition(){var e;return((e=this.internalState)==null?void 0:e.uniformTransitions.active)||!1}activateViewport(e){if(!this.internalState)return;const t=this.internalState.viewport;this.internalState.viewport=e,(!t||!WA({oldViewport:t,viewport:e}))&&(this.setChangeFlags({viewportChanged:!0}),this.isComposite?this.needsUpdate()&&this.setNeedsUpdate():this._update())}invalidateAttribute(e="all"){const t=this.getAttributeManager();t&&(e==="all"?t.invalidateAll():t.invalidate(e))}updateAttributes(e){let t=!1;for(const n in e)e[n].layoutChanged()&&(t=!0);for(const n of this.getModels())this._setModelAttributes(n,e,t)}_updateAttributes(){const e=this.getAttributeManager();if(!e)return;const t=this.props,n=this.getNumInstances(),s=this.getStartIndices();e.update({data:t.data,numInstances:n,startIndices:s,props:t,transitions:t.transitions,buffers:t.data.attributes,context:this});const r=e.getChangedAttributes({clearChangedFlags:!0});this.updateAttributes(r)}_updateAttributeTransition(){const e=this.getAttributeManager();e&&e.updateTransition()}_updateUniformTransition(){const{uniformTransitions:e}=this.internalState;if(e.active){const t=e.update(),n=Object.create(this.props);for(const s in t)Object.defineProperty(n,s,{value:t[s]});return n}return this.props}calculateInstancePickingColors(e,{numInstances:t}){if(e.constant)return;const n=Math.floor(Ae.length/4);this.internalState.usesPickingColorCache=!0;const s=t>0&&Ae[0]===0;if(n<t||s){t>ed&&Y.warn("Layer has too many data objects. Picking might not be able to distinguish all objects.")(),Ae=vi.allocate(Ae,t,{size:4,copy:!0,maxCount:Math.max(t,ed)});const r=Math.floor(Ae.length/4),o=[0,0,0],a=s?0:n;for(let c=a;c<r;c++)this.encodePickingColor(c,o),Ae[c*4+0]=o[0],Ae[c*4+1]=o[1],Ae[c*4+2]=o[2],Ae[c*4+3]=0}e.value=Ae.subarray(0,t*4)}_setModelAttributes(e,t,n=!1){var c;if(!Object.keys(t).length)return;const s=this.getAttributeManager();if(s!=null&&s.hasBufferGroups()){this._setGroupedModelAttributes(e,s,t);return}if(n){const l=this.getAttributeManager();e.setBufferLayout(l.getBufferLayouts(e)),t=l.getAttributes()}const r=((c=e.userData)==null?void 0:c.excludeAttributes)||{},o={},a={};for(const l in t){if(r[l])continue;const u=t[l].getValue();for(const f in u){const d=u[f];d instanceof W?t[l].settings.isIndexed?e.setIndexBuffer(d):o[f]=d:d&&(a[f]=d)}}e.setAttributes(o),e.setConstantAttributes(a)}_setGroupedModelAttributes(e,t,n){var l;const s=((l=e.userData)==null?void 0:l.excludeAttributes)||{},r=t.getBufferGroupBindings(n,e,s);e.setBufferLayout(r.bufferLayouts);const o={...r.buffers},a={},c=t.getAttributes();for(const u in c){if(s[u]||r.groupedAttributeIds.has(u))continue;const f=c[u],d=f.getValue();for(const g in d){const p=d[g];p instanceof W?f.settings.isIndexed?e.setIndexBuffer(p):o[g]=p:p&&(a[g]=p)}}e.setAttributes(o),e.setConstantAttributes(a)}disablePickingIndex(e){const t=this.props.data;if(!("attributes"in t)){this._disablePickingIndex(e);return}const n=this.getAttributeManager().attributes,s=Xo(n),r=Ko(n),o=s&&t.attributes&&t.attributes[s.id];if(o&&o.value){const c=o.value;for(let l=0;l<t.length;l++){const u=s.getVertexOffset(l);c[u]===e&&this._disablePickingIndex(l)}return}const a=r&&t.attributes&&t.attributes[r.id];if(a&&a.value){const c=a.value,l=this.encodePickingColor(e);for(let u=0;u<t.length;u++){const f=r.getVertexOffset(u);c[f]===l[0]&&c[f+1]===l[1]&&c[f+2]===l[2]&&this._disablePickingIndex(u)}}else this._disablePickingIndex(e)}_disablePickingIndex(e){const t=this.getAttributeManager().attributes,n=Xo(t);if(n){const a=n.getVertexOffset(e),c=n.getVertexOffset(e+1),l=new Uint32Array(c-a);l.fill(rr),n.buffer.write(l,a*l.BYTES_PER_ELEMENT);return}const s=Ko(t);if(!s){this.internalState&&KS(this.internalState.disabledPickingIndices,e);return}const r=s.getVertexOffset(e),o=s.getVertexOffset(e+1);s.buffer.write(new Uint8Array(o-r),r)}restorePickingColors(){const e=this.getAttributeManager().attributes,t=td(e);if(!t){this.internalState&&(this.internalState.disabledPickingIndices.length=0);return}const n=Ko(e);this.internalState.usesPickingColorCache&&n&&n.value.buffer!==Ae.buffer&&(n.value=Ae.subarray(0,n.value.length)),t.updateSubBuffer({startOffset:0})}_initialize(){Q(!this.internalState),ye(UA,this);const e=this._getAttributeManager();this.internalState=new zA({attributeManager:e,layer:this}),this._clearChangeFlags(),this.state={},Object.defineProperty(this.state,"attributeManager",{get:()=>(Y.deprecated("layer.state.attributeManager","layer.getAttributeManager()")(),e)}),this.internalState.uniformTransitions=new lA(this.context.timeline),this.internalState.onAsyncPropUpdated=this._onAsyncPropUpdated.bind(this),this.internalState.setAsyncProps(this.props),this.initializeState(this.context);for(const t of this.props.extensions)t.initializeState.call(this,this.context,t);this.setChangeFlags({dataChanged:"init",propsChanged:"init",viewportChanged:!0,extensionsChanged:!0}),this._update()}_transferState(e){ye(jA,this,this===e);const{state:t,internalState:n}=e;this!==e&&(this.internalState=n,this.state=t,this.internalState.setAsyncProps(this.props),this._diffProps(this.props,this.internalState.getOldProps()))}_update(){const e=this.needsUpdate();if(ye($A,this,e),!e)return;this.context.stats.get("Layer updates").incrementCount();const t=this.props,n=this.context,s=this.internalState,r=n.viewport,o=this._updateUniformTransition();s.propsInTransition=o,n.viewport=s.viewport||r,this.props=o;try{const a=this._getUpdateParams(),c=this.getModels();if(n.device)this.updateState(a);else try{this.updateState(a)}catch{}for(const u of this.props.extensions)u.updateState.call(this,a,u);this.setNeedsRedraw(),this._updateAttributes();const l=this.getModels()[0]!==c[0];this._postUpdate(a,l)}finally{n.viewport=r,this.props=t,this._clearChangeFlags(),s.needsUpdate=!1,s.resetOldProps()}}_finalize(){ye(GA,this),this.finalizeState(this.context);for(const e of this.props.extensions)e.finalizeState.call(this,this.context,e)}_drawLayer({renderPass:e,shaderModuleProps:t=null,uniforms:n={},parameters:s={}}){this._updateAttributeTransition();const r=this.props,o=this.context;this.props=this.internalState.propsInTransition||r;try{t&&this.setShaderModuleProps(t);const{getPolygonOffset:a}=this.props,c=a&&a(n)||[0,0];o.device instanceof Dt&&o.device.setParametersWebGL({polygonOffset:c});const l=o.device instanceof Dt?null:YA(s);if(qA(this.getModels(),e,s,l),o.device instanceof Dt)o.device.withParametersWebGL(s,()=>{const u={renderPass:e,shaderModuleProps:t,uniforms:n,parameters:s,context:o};for(const f of this.props.extensions)f.draw.call(this,u,f);this.draw(u)});else{l!=null&&l.renderPassParameters&&e.setParameters(l.renderPassParameters);const u={renderPass:e,shaderModuleProps:t,uniforms:n,parameters:s,context:o};for(const f of this.props.extensions)f.draw.call(this,u,f);this.draw(u)}}finally{this.props=r}}getChangeFlags(){var e;return(e=this.internalState)==null?void 0:e.changeFlags}setChangeFlags(e){if(!this.internalState)return;const{changeFlags:t}=this.internalState;for(const s in e)if(e[s]){let r=!1;switch(s){case"dataChanged":const o=e[s],a=t[s];o&&Array.isArray(a)&&(t.dataChanged=Array.isArray(o)?a.concat(o):o,r=!0);default:t[s]||(t[s]=e[s],r=!0)}r&&ye(NA,this,s,e)}const n=!!(t.dataChanged||t.updateTriggersChanged||t.propsChanged||t.extensionsChanged);t.propsOrDataChanged=n,t.somethingChanged=n||t.viewportChanged||t.stateChanged}_clearChangeFlags(){this.internalState.changeFlags={dataChanged:!1,propsChanged:!1,updateTriggersChanged:!1,viewportChanged:!1,stateChanged:!1,extensionsChanged:!1,propsOrDataChanged:!1,somethingChanged:!1}}_diffProps(e,t){var s;const n=fA(e,t);if(n.updateTriggersChanged)for(const r in n.updateTriggersChanged)n.updateTriggersChanged[r]&&this.invalidateAttribute(r);if(n.transitionsChanged)for(const r in n.transitionsChanged)this.internalState.uniformTransitions.add(r,t[r],e[r],(s=e.transitions)==null?void 0:s[r]);return this.setChangeFlags(n)}validateProps(){uA(this.props)}updateAutoHighlight(e){this.props.autoHighlight&&!Number.isInteger(this.props.highlightedObjectIndex)&&this._updateAutoHighlight(e)}_updateAutoHighlight(e){const t={highlightedObjectColor:e.picked?e.color:null},{highlightColor:n}=this.props;e.picked&&typeof n=="function"&&(t.highlightColor=n(e)),this.setShaderModuleProps({picking:t}),this.setNeedsRedraw()}_getAttributeManager(){const e=this.context;return new sA(e.device,{id:this.props.id,stats:e.stats,timeline:e.timeline})}_postUpdate(e,t){const{props:n,oldProps:s}=e,r=this.state.model;r!=null&&r.isInstanced&&r.setInstanceCount(this.getNumInstances());const{autoHighlight:o,highlightedObjectIndex:a,highlightColor:c}=n;if(t||s.autoHighlight!==o||s.highlightedObjectIndex!==a||s.highlightColor!==c){const l={};Array.isArray(c)&&(l.highlightColor=c),(t||s.autoHighlight!==o||a!==s.highlightedObjectIndex)&&(l.highlightedObjectColor=Number.isFinite(a)&&a>=0?this.encodePickingColor(a):null),this.setShaderModuleProps({picking:l})}}_getUpdateParams(){return{props:this.props,oldProps:this.internalState.getOldProps(),context:this.context,changeFlags:this.internalState.changeFlags}}_getNeedsRedraw(e){if(!this.internalState)return!1;let t=!1;t=t||this.internalState.needsRedraw&&this.id;const n=this.getAttributeManager(),s=n?n.getNeedsRedraw(e):!1;if(t=t||s,t)for(const r of this.props.extensions)r.onNeedsRedraw.call(this,r);return this.internalState.needsRedraw=this.internalState.needsRedraw&&!e.clearRedrawFlags,t}_onAsyncPropUpdated(){this._diffProps(this.props,this.internalState.getOldProps()),this.setNeedsUpdate()}}xt.defaultProps=HA;xt.layerName="Layer";function YA(i){const{blendConstant:e,...t}=i;return e?{pipelineParameters:t,renderPassParameters:{blendConstant:e}}:{pipelineParameters:t}}function qA(i,e,t,n){for(const s of i)s.device.type==="webgpu"?(ZA(s,e),s.setParameters({...s.parameters,...n==null?void 0:n.pipelineParameters})):s.setParameters(t)}function ZA(i,e){var o,a;const t=e.props.framebuffer||(e.framebuffer??null);if(!t)return;const n=t.colorAttachments.map(c=>{var l;return((l=c==null?void 0:c.texture)==null?void 0:l.format)??null}),s=(a=(o=t.depthStencilAttachment)==null?void 0:o.texture)==null?void 0:a.format,r=i;(!XA(r.props.colorAttachmentFormats,n)||r.props.depthStencilAttachmentFormat!==s)&&(r.props.colorAttachmentFormats=n,r.props.depthStencilAttachmentFormat=s,r._setPipelineNeedsUpdate("attachment formats"))}function XA(i,e){if(i===e)return!0;if(!i||!e||i.length!==e.length)return!1;for(let t=0;t<i.length;t++)if(i[t]!==e[t])return!1;return!0}const KA="compositeLayer.renderLayers";class qr extends xt{get isComposite(){return!0}get isDrawable(){return!1}get isLoaded(){return super.isLoaded&&this.getSubLayers().every(e=>e.isLoaded)}getSubLayers(){return this.internalState&&this.internalState.subLayers||[]}initializeState(e){}setState(e){super.setState(e),this.setNeedsUpdate()}getPickingInfo({info:e}){const{object:t}=e;return t&&t.__source&&t.__source.parent&&t.__source.parent.id===this.id&&(e.object=t.__source.object,e.index=t.__source.index),e}filterSubLayer(e){return!0}shouldRenderSubLayer(e,t){return t&&t.length}getSubLayerClass(e,t){const{_subLayerProps:n}=this.props;return n&&n[e]&&n[e].type||t}getSubLayerRow(e,t,n){return e.__source={parent:this,object:t,index:n},e}getSubLayerAccessor(e){if(typeof e=="function"){const t={index:-1,data:this.props.data,target:[]};return(n,s)=>n&&n.__source?(t.index=n.__source.index,e(n.__source.object,t)):e(n,s)}return e}getSubLayerProps(e={}){var O;const{opacity:t,pickable:n,visible:s,parameters:r,getPolygonOffset:o,highlightedObjectIndex:a,autoHighlight:c,highlightColor:l,coordinateSystem:u,coordinateOrigin:f,wrapLongitude:d,positionFormat:g,modelMatrix:p,extensions:m,fetch:_,operation:v,_subLayerProps:w}=this.props,y={id:"",updateTriggers:{},opacity:t,pickable:n,visible:s,parameters:r,getPolygonOffset:o,highlightedObjectIndex:a,autoHighlight:c,highlightColor:l,coordinateSystem:u,coordinateOrigin:f,wrapLongitude:d,positionFormat:g,modelMatrix:p,extensions:m,fetch:_,operation:v},x=w&&e.id&&w[e.id],S=x&&x.updateTriggers,C=e.id||"sublayer";if(x){const B=this.props[_t],D=e.type?e.type._propTypes:{};for(const k in x){const N=D[k]||B[k];N&&N.type==="accessor"&&(x[k]=this.getSubLayerAccessor(x[k]))}}Object.assign(y,e,x),y.id=`${this.props.id}-${C}`,y.updateTriggers={all:(O=this.props.updateTriggers)==null?void 0:O.all,...e.updateTriggers,...S};for(const B of m){const D=B.getSubLayerProps.call(this,B);D&&Object.assign(y,D,{updateTriggers:Object.assign(y.updateTriggers,D.updateTriggers)})}return y}_updateAutoHighlight(e){for(const t of this.getSubLayers())t.updateAutoHighlight(e)}_getAttributeManager(){return null}_postUpdate(e,t){let n=this.internalState.subLayers;const s=!n||this.needsUpdate();if(s){const r=this.renderLayers();n=wi(r,Boolean),this.internalState.subLayers=n}ye(KA,this,s,n);for(const r of n)r.parent=this}}qr.layerName="CompositeLayer";const Qt=Math.PI/180,id=180/Math.PI,Ts=6370972,pt=256,nd=.75,QA=.35,JA=1.15;function eM(){const i=pt/Ts,e=Math.PI/180*pt;return{unitsPerMeter:[i,i,i],unitsPerMeter2:[0,0,0],metersPerUnit:[1/i,1/i,1/i],unitsPerDegree:[e,e,i],unitsPerDegree2:[0,0,0],degreesPerUnit:[1/e,1/e,1/i]}}class yl extends Ai{constructor(e={}){const{longitude:t=0,bearing:n=0,pitch:s=0,zoom:r=0,nearZMultiplier:o=.5,farZMultiplier:a=1,resolution:c=10}=e;let{latitude:l=0,height:u,altitude:f=1.5,fovy:d}=e;l=Math.max(Math.min(l,90),-90),u=u||1,d?f=il(d):d=wn(f);const g=Math.max(Math.min(l,Ke),-Ke),p=Math.pow(2,r-pe(g)),m=s*Qt,_=e.nearZ??o,v=e.farZ??(f+pt*2*p/u/Math.max(Math.cos(m),.1))*a,w=new Ge().lookAt({eye:[0,-f,0],up:[0,0,1]}).rotateX(-m).rotateY(-n*Qt).rotateX(l*Qt).rotateZ(-t*Qt).scale(p/u);super({...e,height:u,viewMatrix:w,longitude:t,latitude:l,zoom:r,distanceScales:eM(),fovy:d,focalDistance:f,near:_,far:v}),this.scale=p,this.latitude=l,this.longitude=t,this.bearing=n,this.pitch=s,this.fovy=d,this.resolution=c}get projectionMode(){return xe.GLOBE}getDistanceScales(){return this.distanceScales}getBounds(e={}){const t={targetZ:e.z||0},n=this.unproject([0,this.height/2],t),s=this.unproject([this.width/2,0],t),r=this.unproject([this.width,this.height/2],t),o=this.unproject([this.width/2,this.height],t);return r[0]<this.longitude&&(r[0]+=360),n[0]>this.longitude&&(n[0]-=360),[Math.min(n[0],r[0],s[0],o[0]),Math.min(n[1],r[1],s[1],o[1]),Math.max(n[0],r[0],s[0],o[0]),Math.max(n[1],r[1],s[1],o[1])]}_getRayToGlobe(e,{topLeft:t=!0,targetZ:n}={}){const[s,r]=e,o=t?r:this.height-r,{pixelUnprojectionMatrix:a}=this,c=Qo(a,[s,o,-1,1]),l=Qo(a,[s,o,1,1]),u=((n||0)/Ts+1)*pt,f=_o(og([],c,l)),d=_o(c),g=_o(l),m=4*((4*d*g-(f-d-g)**2)/16)/f;return{rayStartPosition:c,rayEndPosition:l,radius:u,rayLengthSquared:f,rayStartDistanceSquared:d,distanceToCenterSquared:m}}_getRayDistanceToGlobeCenterRatio(e,t){const{distanceToCenterSquared:n,radius:s}=this._getRayToGlobe(e,t);return Math.sqrt(Math.max(0,n))/s}getZoomAnchorStrength(e){const t=this._getRayDistanceToGlobeCenterRatio(e);return t>JA?0:1-Math.max(0,Math.min(1,(t-nd)/(1-nd)))*(1-QA)}unproject(e,{topLeft:t=!0,targetZ:n}={}){const[s,r,o]=e,a=t?r:this.height-r,{pixelUnprojectionMatrix:c}=this;let l;if(Number.isFinite(o))l=Qo(c,[s,a,o,1]);else{const{rayStartPosition:g,rayEndPosition:p,radius:m,rayLengthSquared:_,rayStartDistanceSquared:v,distanceToCenterSquared:w}=this._getRayToGlobe(e,{topLeft:t,targetZ:n}),y=Math.sqrt(v-w),x=Math.sqrt(Math.max(0,m*m-w)),S=(y-x)/Math.sqrt(_);l=px([],g,p,S)}const[u,f,d]=this.unprojectPosition(l);return Number.isFinite(o)?[u,f,d]:Number.isFinite(n)?[u,f,n]:[u,f]}projectPosition(e){const[t,n,s=0]=e,r=t*Qt,o=n*Qt,a=Math.cos(o),c=(s/Ts+1)*pt;return[Math.sin(r)*a*c,-Math.cos(r)*a*c,Math.sin(o)*c]}unprojectPosition(e){const[t,n,s]=e,r=ag(e),o=Math.asin(s/r),c=Math.atan2(t,-n)*id,l=o*id,u=(r/pt-1)*Ts;return[c,l,u]}projectFlat(e){return e}unprojectFlat(e){return e}panByPosition(e,t,n){if(!n){const d=this.getZoomAnchorStrength(t);if(d===0)return{longitude:this.longitude,latitude:this.latitude};const g=this.unproject(t),p=xn(e[0]-g[0]+180,360)-180,m=this.longitude+p*d,_=Math.max(Math.min(this.latitude+(e[1]-g[1])*d,90),-90);return{longitude:m,latitude:_}}const[s,r,o]=e,c=.25/Math.pow(2,this.zoom-pe(this.latitude)),l=s+c*(n[0]-t[0]);let u=r-c*(n[1]-t[1]);u=Math.max(Math.min(u,90),-90);const f={longitude:l,latitude:u,zoom:o-pe(r)};return f.zoom+=pe(f.latitude),f}}yl.displayName="GlobeViewport";function pe(i,e){e&&(i=Math.max(Math.min(i,Ke),-Ke));const t=Math.PI*Math.cos(i*Math.PI/180);return Math.log2(t)}function Qo(i,e){const t=Ti([],e,i);return Qc(t,t,1/t[3]),t}const Jt=Math.PI/180,Jo=180/Math.PI;class re{static toPosition(e,t){const n=t*Jt,s=e*Jt,r=Math.cos(n);return[r*Math.cos(s),r*Math.sin(s),Math.sin(n)]}static toLngLat(e){return[Math.atan2(e[1],e[0])*Jo,Math.asin(ae(e[2],-1,1))*Jo]}static tangentBasis(e,t){const n=t*Jt,s=e*Jt,r=Math.sin(n),o=Math.cos(n),a=Math.sin(s),c=Math.cos(s);return{N:[-r*c,-r*a,o],E:[-a,c,0]}}static upVector(e,t,n){const{N:s,E:r}=re.tangentBasis(e,t),o=n*Jt,a=Math.cos(o),c=Math.sin(o);return[s[0]*a+r[0]*c,s[1]*a+r[1]*c,s[2]*a+r[2]*c]}static bearing(e,t,n){const{N:s,E:r}=re.tangentBasis(t,n);return Math.atan2(en(e,r),en(e,s))*Jo}static cameraFrame(e,t,n){const s=re.toPosition(e,t),r=re.upVector(e,t,n),{N:o,E:a}=re.tangentBasis(e,t),c=n*Jt,l=Math.cos(c),u=Math.sin(c),f=[a[0]*l-o[0]*u,a[1]*l-o[1]*u,a[2]*l-o[2]*u];return{position:s,up:r,axisHorizontal:Rt([],s,f),axisVertical:Rt([],s,r),longitude:e,latitude:t,bearing:n}}static angularDistance(e,t){const n=re.toPosition(e.longitude,e.latitude),s=re.toPosition(t.longitude,t.latitude);return Math.acos(ae(en(n,s),-1,1))}static greatCircleAxis(e,t){const n=re.toPosition(e.longitude,e.latitude),s=re.toPosition(t.longitude,t.latitude);return rg([],Rt([],n,s))}static rotate(e,t,n){const s=new uP().fromAxisRotation(t,n);return Zc([],e,s)}static rotateFrame(e,t,n,s){let r=re.rotate(e.position,e.axisHorizontal,t);r=re.rotate(r,e.axisVertical,n);let o=re.rotate(e.up,e.axisHorizontal,t);o=re.rotate(o,e.axisVertical,n);const[a,c]=re.toLngLat(r),l=s?0:re.bearing(o,a,c);return{...e,position:r,up:o,longitude:a,latitude:c,bearing:l}}}const tM=1/(1-Math.exp(-5)),iM=i=>(1-Math.exp(-5*i))*tM;class sd extends Ug{constructor(e){const t="axis"in e;super({compare:["longitude","latitude"],extract:t?["longitude","latitude","zoom","bearing"]:["longitude","latitude","zoom"],required:["longitude","latitude"]}),t?(this._mode="rotation",this._axis=e.axis,this._totalAngle=e.totalAngle):(this._mode="linear",this._targetLongitude=e.targetLongitude)}initializeProps(e,t){const n=super.initializeProps(e,t);return this._startZoom=e.zoom,this._mode==="rotation"?this._startFrame={...re.cameraFrame(e.longitude,e.latitude,e.bearing||0),axisHorizontal:this._axis}:n.end.longitude=this._targetLongitude,n}interpolateProps(e,t,n){if(this._mode==="rotation"){const{longitude:a,latitude:c,bearing:l}=re.rotateFrame(this._startFrame,this._totalAngle*n,0),u=this._startZoom+pe(c,!0)-pe(this._startFrame.latitude,!0);return{bearing:l,longitude:a,latitude:c,zoom:u}}const s=e.longitude+(t.longitude-e.longitude)*n,r=e.latitude+(t.latitude-e.latitude)*n,o=this._startZoom+pe(r,!0)-pe(e.latitude,!0);return{longitude:s,latitude:r,zoom:o}}}const nt=Math.PI/180,nM=180/Math.PI;function rd(i,e=0){const t=Math.min(180,i)*nt;return pt*2*Math.sin(t/2)*Math.pow(2,e)}function ei(i,e=0){const t=i/Math.pow(2,e);return Math.asin(Math.min(1,t/pt/2))*2*nM}class sM extends Vg{constructor(e){const{startPanPos:t,startPanCameraFrame:n,startPanAngularRate:s,startPanLockBearing:r,...o}=e;o.normalize=!1,super(o);const a=this._state;t!==void 0&&(a.startPanPos=t),n!==void 0&&(a.startPanCameraFrame=n),s!==void 0&&(a.startPanAngularRate=s),r!==void 0&&(a.startPanLockBearing=r)}panStart({pos:e}){const{latitude:t,longitude:n,zoom:s,bearing:r=0}=this.getViewportProps(),o=re.cameraFrame(n,t,r),a=Math.abs(r)<1;a&&(o.axisHorizontal=[0,0,1]);const l=.25/Math.pow(2,s-pe(t,!0))*nt;return this._getUpdatedState({startPanPos:e,startPanCameraFrame:o,startPanAngularRate:l,startPanLockBearing:a,startZoom:s})}pan({pos:e,startPos:t}){const n=this.getState(),s=n.startPanPos||t;if(!s)return this;const r=n.startPanCameraFrame,o=n.startPanAngularRate,a=n.startZoom??this.getViewportProps().zoom;if(!r||!o)return this;const c=s[0]-e[0],l=s[1]-e[1];let u=c*o,f=-l*o;const d=n.startPanLockBearing;if(d){const m=Math.cos(r.latitude*nt);u=c*o/Math.max(m,.25);const _=(Ke-r.latitude)*nt,v=-(Ke+r.latitude)*nt;f=ae(f,v,_)}const g=re.rotateFrame(r,u,f,d),p=a+pe(g.latitude,!0)-pe(r.latitude,!0);return this._getUpdatedState({longitude:g.longitude,latitude:g.latitude,bearing:g.bearing,zoom:p})}panEnd(){return this._getUpdatedState({startPanPos:null,startPanCameraFrame:null,startPanAngularRate:null,startPanLockBearing:null,startZoom:null})}_panFromCenter(e){const{width:t,height:n}=this.getViewportProps(),s=[t/2,n/2];return this.panStart({pos:s}).pan({pos:[s[0]+e[0],s[1]+e[1]]}).panEnd()}applyConstraints(e){const t=e,n=t[At];delete t[At];const{latitude:s,maxBounds:r}=e;if(e.zoom=this._constrainZoom(e.zoom,e),n){const a=this.makeViewport(e);Object.assign(e,a.panByPosition(n.position,n.screenPosition))}(e.longitude<-180||e.longitude>180)&&(e.longitude=xn(e.longitude+180,360)-180),e.latitude=ae(e.latitude,-90,90),(e.bearing<-180||e.bearing>180)&&(e.bearing=xn(e.bearing+180,360)-180),e.pitch=ae(e.pitch,e.minPitch,e.maxPitch);const o=r?cr(e.width,e.height,e.maxBoundsPadding):null;if(r&&o&&(o.width>=0&&(e.longitude=ae(e.longitude,r[0][0],r[1][0])),o.height>=0&&(e.latitude=ae(e.latitude,r[0][1],r[1][1]))),r&&o){const a=this.makeViewport({...e,bearing:0,pitch:0}),c=Gg(a,[e.longitude,e.latitude],o),l=e.zoom-pe(s),u=r[1][0]-r[0][0],f=r[1][1]-r[0][1];if(o.height>=0&&f>0&&f<180){const d=Math.min(ei(o.height,l),f),g=o.height?d*c.bottom/o.height:ei(c.bottom,l),p=o.height?d*c.top/o.height:ei(c.top,l);e.latitude=ae(e.latitude,r[0][1]+g,r[1][1]-p)}if(o.width>=0&&u>0&&u<360){const d=Math.min(ei(o.width/Math.cos(e.latitude*nt),l),u),g=o.width?d*c.left/o.width:ei(c.left/Math.cos(e.latitude*nt),l),p=o.width?d*c.right/o.width:ei(c.right/Math.cos(e.latitude*nt),l);e.longitude=ae(e.longitude,r[0][0]+g,r[1][0]-p)}}return e.latitude!==s&&(e.zoom+=pe(e.latitude,!0)-pe(s,!0)),e}_constrainZoom(e,t){t||(t=this.getViewportProps());const{maxZoom:n,maxBounds:s}=t;let{minZoom:r}=t;if(s!==null&&t.width>0&&t.height>0){const c=cr(t.width,t.height,t.maxBoundsPadding),l=s[0][1],u=s[1][1],f=Math.sign(l)===Math.sign(u)?Math.min(Math.abs(l),Math.abs(u)):0,d=pe(0),g=rd(s[1][0]-s[0][0])*Math.cos(f*nt),p=rd(s[1][1]-s[0][1]);c.width>0&&g>0&&(r=Math.max(r,Math.log2(c.width/g)+d)),c.height>0&&p>0&&(r=Math.max(r,Math.log2(c.height/p)+d)),r>n&&(r=n)}const a=pe(t.latitude,!0)-pe(0,!0);return ae(e,r+a,n+a)}}class rM extends $g{constructor(){super(...arguments),this.ControllerState=sM,this.transition={transitionDuration:300,transitionInterpolator:new cl({transitionProps:{compare:["longitude","latitude","zoom","bearing","pitch"],required:["longitude","latitude","zoom"]}})},this.dragMode="pan",this._panHistory=[]}getZoomPosition(e){const t=super.getZoomPosition(e),n=this.makeViewport(this.controllerState.getViewportProps());return!(n instanceof yl)||n.getZoomAnchorStrength(t)>0?t:n.project([n.longitude,n.latitude])}_onPanStart(e){return this._panHistory=[],super._onPanStart(e)}_onMultiPanStart(e){return this._panHistory=[],super._onMultiPanStart(e)}_onPanMove(e){if(!this.dragPan)return!1;const t=this.getCenter(e),n=this.controllerState.pan({pos:t});this.updateViewport(n,{transitionDuration:0},{isDragging:!0,isPanning:!0});const{longitude:s,latitude:r}=n.getViewportProps();return this._panHistory.push({longitude:s,latitude:r,timestamp:Date.now()}),this._panHistory.length>5&&this._panHistory.shift(),!0}_onPanMoveEnd(e){const{inertia:t}=this;if(this.dragPan&&t&&this._panHistory.length>=2){const s=this._panHistory[0],r=this._panHistory[this._panHistory.length-1],o=r.timestamp-s.timestamp;if(o>0){const a=this.controllerState.getViewportProps(),c=this.controllerState.getState(),u=re.angularDistance(s,r)/o;if(u>1e-6){const f=u*t/2;let d,g,p;if(c.startPanLockBearing){let _=r.longitude-s.longitude;_>180?_-=360:_<-180&&(_+=360);const v=r.latitude-s.latitude,w=_/o,y=v/o;g=a.longitude+w*t/2,p=ae(a.latitude+y*t/2,-90,90),d=new sd({targetLongitude:g})}else{const _=re.greatCircleAxis(s,r),v=re.cameraFrame(a.longitude,a.latitude,a.bearing||0),w=re.rotateFrame({...v,axisHorizontal:_},f,0);g=w.longitude,p=ae(w.latitude,-90,90),d=new sd({axis:_,totalAngle:f})}const m=this.controllerState.panEnd();return this.updateViewport(m,{transitionInterpolator:d,transitionDuration:t,transitionEasing:iM,longitude:g,latitude:p},{isDragging:!1,isPanning:!0}),this._panHistory=[],!0}}}this._panHistory=[];const n=this.controllerState.panEnd();return this.updateViewport(n,null,{isDragging:!1,isPanning:!1}),!0}}const oM={cullMode:"back"};class Ap extends Ng{constructor(e={}){super({...e,parameters:{...oM,...e.parameters}})}getViewportType(e){return e.zoom>12?ot:yl}get ControllerType(){return rM}}Ap.displayName="GlobeView";class Mp{constructor(e){this.indexStarts=[0],this.vertexStarts=[0],this.vertexCount=0,this.instanceCount=0;const{attributes:t={}}=e;this.typedArrayManager=vi,this.attributes={},this._attributeDefs=t,this.opts=e,this.updateGeometry(e)}updateGeometry(e){Object.assign(this.opts,e);const{data:t,buffers:n={},getGeometry:s,geometryBuffer:r,positionFormat:o,dataChanged:a,normalize:c=!0}=this.opts;if(this.data=t,this.getGeometry=s,this.positionSize=r&&r.size||(o==="XY"?2:3),this.buffers=n,this.normalize=c,r&&(Q(t.startIndices),this.getGeometry=this.getGeometryFromBuffer(r),c||(n.vertexPositions=r)),this.geometryBuffer=n.vertexPositions,Array.isArray(a))for(const l of a)this._rebuildGeometry(l);else this._rebuildGeometry()}updatePartialGeometry({startRow:e,endRow:t}){this._rebuildGeometry({startRow:e,endRow:t})}getGeometryFromBuffer(e){const t=e.value||e;return ArrayBuffer.isView(t)?up(t,{size:this.positionSize,offset:e.offset,stride:e.stride,startIndices:this.data.startIndices}):null}_allocate(e,t){const{attributes:n,buffers:s,_attributeDefs:r,typedArrayManager:o}=this;for(const a in r)if(a in s)o.release(n[a]),n[a]=null;else{const c=r[a];c.copy=t,n[a]=o.allocate(n[a],e,c)}}_forEachGeometry(e,t,n){const{data:s,getGeometry:r}=this,{iterable:o,objectInfo:a}=Ii(s,t,n);for(const c of o){a.index++;const l=r?r(c,a):null;e(l,a.index)}}_rebuildGeometry(e){if(!this.data)return;let{indexStarts:t,vertexStarts:n,instanceCount:s}=this;const{data:r,geometryBuffer:o}=this,{startRow:a=0,endRow:c=1/0}=e||{},l={};if(e||(t=[0],n=[0]),this.normalize||!o)this._forEachGeometry((f,d)=>{const g=f&&this.normalizeGeometry(f);l[d]=g,n[d+1]=n[d]+(g?this.getGeometrySize(g):0)},a,c),s=n[n.length-1];else if(n=r.startIndices,s=n[r.length]||0,ArrayBuffer.isView(o))s=s||o.length/this.positionSize;else if(o instanceof W){const f=this.positionSize*4;s=s||o.byteLength/f}else if(o.buffer){const f=o.stride||this.positionSize*4;s=s||o.buffer.byteLength/f}else if(o.value){const f=o.value,d=o.stride/f.BYTES_PER_ELEMENT||this.positionSize;s=s||f.length/d}this._allocate(s,!!e),this.indexStarts=t,this.vertexStarts=n,this.instanceCount=s;const u={};this._forEachGeometry((f,d)=>{const g=l[d]||f;u.vertexStart=n[d],u.indexStart=t[d];const p=d<n.length-1?n[d+1]:s;u.geometrySize=p-n[d],u.geometryIndex=d,this.updateGeometryAttributes(g,u)},a,c),this.vertexCount=t[t.length-1]}}function Ip(i){var e;return i.getCenterElevation?i.getCenterElevation():(e=i.getCameraTargetElevation)==null?void 0:e.call(i)}function Rp(i){var t,n;let e="mercator";try{e=((n=(t=i.getProjection)==null?void 0:t.call(i))==null?void 0:n.type)||"mercator"}catch{}if(e==="globe")return"globe";if(e!=="mercator")throw new Error(`Unsupported MapLibre projection: ${String(e)}`);return"mercator"}function aM(i,e){if(od(i))return i;if(od(e))return e;throw new Error("MapLibreOverlay interleaved rendering requires MapLibre GL JS 4.5.1 or later")}function od(i){if(!i||typeof i!="object")return!1;const e=i;return Number.isFinite(e.nearZ)&&Number.isFinite(e.farZ)}const cM="deck-maplibre-layer-group-last";function cn(i){return i.props.beforeId?`deck-maplibre-layer-group-before:${i.props.beforeId}`:cM}const xi="maplibre",Ft=new WeakMap;function lM(i,e){if(Ft.has(i))throw new Error("MapLibreOverlay supports one interleaved overlay per map");const t=i.getCanvas().getContext("webgl2");if(!t)throw new Error("MapLibreOverlay interleaved rendering requires WebGL2.");const{device:n,...s}=e,r=new Hr({...s,gl:t});try{return uM(i,r)}catch(o){throw Op(i)===r?Bp(i):r.finalize(),o}}function ea(i,e){return e?{depthWriteEnabled:!0,depthCompare:"less-equal",depthBias:0,blend:!0,blendColorSrcFactor:"src-alpha",blendColorDstFactor:"one-minus-src-alpha",blendAlphaSrcFactor:"one",blendAlphaDstFactor:"one-minus-src-alpha",blendColorOperation:"add",blendAlphaOperation:"add"}:{}}function fr(i){return Rp(i)==="globe"?new Ap({id:xi}):new ll({id:xi})}function En(i){const{lng:e,lat:t}=i.getCenter(),n=i.getPadding(),s={longitude:(e+540)%360-180,latitude:t,zoom:i.getZoom(),bearing:i.getBearing(),pitch:i.getPitch(),padding:{top:n.top??0,bottom:n.bottom??0,left:n.left??0,right:n.right??0},repeat:i.getRenderWorldCopies()},r=Ip(i);return typeof r=="number"&&Number.isFinite(r)&&(s.position=[0,0,r]),s}function uM(i,e){if(Ft.get(i))throw new Error("MapLibreOverlay supports one interleaved overlay per map");const n=e.props._customRender,s=e.props.onLoad,r={deck:e,watchingMove:!1,moveListener:()=>{e.isInitialized?mc(e,i):kp(i,r)},renderListener:()=>{e.isInitialized&&(hM(e,i),dM(e,i))}};Ft.set(i,r);const o={...e.props,_customRender:()=>{i.triggerRepaint(),n==null||n("")}};return o.views||(o.views=fr(i)),Object.assign(o,{width:null,height:null,touchAction:"unset",viewState:En(i)}),e.isInitialized?ad(i,r):o.onLoad=()=>{Ft.get(i)===r&&(ad(i,r),mc(e,i)),s==null||s()},e.setProps(o),i.on("render",r.renderListener),e}function Op(i){var e;return(e=Ft.get(i))==null?void 0:e.deck}function Bp(i){const e=Ft.get(i);e&&(kp(i,e),i.off("render",e.renderListener),e.deck.finalize(),Ft.delete(i))}function fM(i,e,t,n){if(!i.isInitialized)return;let{currentViewport:s}=i.userData,r=!1;s||(s=Dp(i,e,n),i.userData.currentViewport=s,r=!0),s&&i._drawLayers("maplibre-repaint",{viewports:[s],layerFilter:o=>i.props.layerFilter&&!i.props.layerFilter(o)?!1:o.layer.props.beforeId===t.beforeId,clearStack:r,clearCanvas:!1})}function ad(i,e){e.watchingMove||(e.watchingMove=!0,i.on("move",e.moveListener))}function kp(i,e){e.watchingMove&&(e.watchingMove=!1,i.off("move",e.moveListener))}function Dp(i,e,t){const n=En(e),s=i.getView(xi)||fr(e);if(t){s.props.nearZMultiplier=.2;const r=e.getCanvas().clientHeight;r>0&&Number.isFinite(t.nearZ)&&Number.isFinite(t.farZ)&&(n.nearZ=t.nearZ/r,n.farZ=t.farZ/r)}return s.makeViewport({width:i.width,height:i.height,viewState:n})}function dM(i,e){var a,c,l,u;const n=wi(i.props.layers,Boolean).some(f=>f&&!e.getLayer(cn(f)));let s=i.getViewports();const r=s.findIndex(f=>f.id===xi),o=s.length>1||r<0;if(n||o){if(r>=0){s=s.slice();const f=Dp(i,e);f?s[r]=f:s.splice(r,1)}i._drawLayers("maplibre-repaint",{viewports:s,layerFilter:f=>(!i.props.layerFilter||i.props.layerFilter(f))&&(f.viewport.id!==xi||!e.getLayer(cn(f.layer))),clearCanvas:!1})}else{const f=i.device,d=f==null?void 0:f.gl;(c=(a=i.props).onBeforeRender)==null||c.call(a,{device:f,gl:d}),(u=(l=i.props).onAfterRender)==null||u.call(l,{device:f,gl:d})}i.userData.currentViewport=null}function hM(i,e){var s;const t=Ip(e),n=i.props.viewState;Number.isFinite(t)&&((s=n==null?void 0:n.position)==null?void 0:s[2])!==t&&mc(i,e)}function mc(i,e){i.setProps({viewState:En(e)}),i.needsRedraw({clearRedrawFlags:!0})}class gM{constructor(e){this.type="custom",this.map=null,Q(e.id,"id is required"),this.id=e.id,this.renderingMode=e.renderingMode||"3d",this.beforeId=e.beforeId}onAdd(e){this.map=e}onRemove(){this.map=null}render(e,t,n){if(!this.map)return;const s=Op(this.map);s&&fM(s,this.map,this,aM(t,n))}}const cd=new WeakMap;function fs(i,e,t){if(!i||!i.isStyleLoaded())return;let n=cd.get(i);n||(n=new Map,cd.set(i,n));const s=wi(t,Boolean),r=new Set(s.map(cn));if(e!==t){const o=wi(e,Boolean),a=new Set(o.map(cn));for(const c of a)!r.has(c)&&n.has(c)&&(i.getLayer(c)&&i.removeLayer(c),n.delete(c))}for(const o of s){const a=cn(o);if(n.has(a)){i.getLayer(a)||i.addLayer(n.get(a),o.props.beforeId);continue}if(i.getLayer(a))throw new Error(`MapLibre style already contains a non-deck layer with id ${a}`);const c=new gM({id:a,beforeId:o.props.beforeId});n.set(a,c),i.addLayer(c,o.props.beforeId)}for(const o of r){const a=n.get(o),c=i.getLayersOrder(),l=a.beforeId?c.indexOf(a.beforeId):c.length;if(l<0)continue;c.indexOf(o)!==l-1&&i.moveLayer(o,a.beforeId)}}class pM{constructor(e){this._handleStyleChange=()=>{var n;fs(this._map,this._props.layers,this._props.layers),this._map&&Rp(this._map)&&((n=this._deck)==null||n.setProps({views:this._getViews(this._map)}))},this._updateContainerSize=()=>{if(this._map&&this._container){const{clientWidth:n,clientHeight:s}=this._map.getContainer();Object.assign(this._container.style,{width:`${n}px`,height:`${s}px`})}},this._updateViewState=()=>{const n=this._deck,s=this._map;n&&s&&(n.setProps({views:this._getViews(s),viewState:En(s)}),n.isInitialized&&n.redraw())},this._handleMouseEvent=n=>{const s=this._deck;if(!s||!s.isInitialized)return;const r={type:n.type,offsetCenter:n.point||{x:0,y:0},srcEvent:n},o=this._lastMouseDownPoint;switch(!n.point&&o&&n.originalEvent instanceof MouseEvent&&(r.deltaX=n.originalEvent.clientX-o.clientX,r.deltaY=n.originalEvent.clientY-o.clientY,r.offsetCenter={x:o.x+r.deltaX,y:o.y+r.deltaY}),r.type){case"mousedown":if(s._onPointerDown(r),!(n.originalEvent instanceof MouseEvent))return;this._lastMouseDownPoint={...r.offsetCenter,clientX:n.originalEvent.clientX,clientY:n.originalEvent.clientY};break;case"dragstart":r.type="panstart",s._onEvent(r);break;case"drag":r.type="panmove",s._onEvent(r);break;case"dragend":r.type="panend",s._onEvent(r);break;case"click":r.tapCount=1,s._onEvent(r);break;case"dblclick":r.type="click",r.tapCount=2,s._onEvent(r);break;case"mousemove":r.type="pointermove",s._onPointerMove(r);break;case"mouseout":r.type="pointerleave",s._onPointerMove(r);break;default:return}};const{interleaved:t=!1}=e;this._interleaved=t,this._props=this._filterProps(e)}_filterProps(e){const{interleaved:t,useDevicePixels:n,device:s,...r}=e;return this._interleaved||(n!==void 0&&Object.assign(r,{useDevicePixels:n}),s!==void 0&&Object.assign(r,{device:s})),r}setProps(e){this._interleaved&&e.layers&&fs(this._map,this._props.layers,e.layers),Object.assign(this._props,this._filterProps(e)),this._deck&&this._map&&this._deck.setProps({...this._props,views:this._getViews(this._map),parameters:{...ea(this._map,this._interleaved),...this._props.parameters}})}onAdd(e){this._map=e;try{return this._interleaved?this._onAddInterleaved(e):this._onAddOverlaid(e)}catch(t){throw this._deck&&(this._interleaved?this._onRemoveInterleaved(e):this._onRemoveOverlaid(e)),this._deck=void 0,this._map=void 0,this._container=void 0,t}}onRemove(e){const t=this._map;t&&(this._interleaved?this._onRemoveInterleaved(t):this._onRemoveOverlaid(t)),this._deck=void 0,this._map=void 0,this._container=void 0}getDefaultPosition(){return"top-left"}pickObject(e){return Q(this._deck),this._deck.pickObject(e)}pickMultipleObjects(e){return Q(this._deck),this._deck.pickMultipleObjects(e)}pickObjects(e){return Q(this._deck),this._deck.pickObjects(e)}finalize(){var e;(e=this._map)==null||e.removeControl(this)}getCanvas(){return this._map?this._interleaved?this._map.getCanvas():this._deck.getCanvas():null}_onAddOverlaid(e){var n;const t=document.createElement("div");return Object.assign(t.style,{position:"absolute",left:0,top:0,textAlign:"initial",pointerEvents:"none"}),this._container=t,this._deck=new Hr({...this._props,parent:t,deviceProps:{...this._props.deviceProps,createCanvasContext:{...typeof((n=this._props.deviceProps)==null?void 0:n.createCanvasContext)=="object"?this._props.deviceProps.createCanvasContext:void 0,pixelSizeSource:"css-dpr"}},parameters:{...ea(e,!1),...this._props.parameters},views:this._getViews(e),viewState:En(e)}),e.on("resize",this._updateContainerSize),e.on("render",this._updateViewState),e.on("mousedown",this._handleMouseEvent),e.on("dragstart",this._handleMouseEvent),e.on("drag",this._handleMouseEvent),e.on("dragend",this._handleMouseEvent),e.on("mousemove",this._handleMouseEvent),e.on("mouseout",this._handleMouseEvent),e.on("click",this._handleMouseEvent),e.on("dblclick",this._handleMouseEvent),this._updateContainerSize(),t}_onAddInterleaved(e){return this._deck=lM(e,{...this._props,views:this._getViews(e),parameters:{...ea(e,!0),...this._props.parameters}}),e.on("styledata",this._handleStyleChange),fs(e,[],this._props.layers),document.createElement("div")}_onRemoveOverlaid(e){var t,n;e.off("resize",this._updateContainerSize),e.off("render",this._updateViewState),e.off("mousedown",this._handleMouseEvent),e.off("dragstart",this._handleMouseEvent),e.off("drag",this._handleMouseEvent),e.off("dragend",this._handleMouseEvent),e.off("mousemove",this._handleMouseEvent),e.off("mouseout",this._handleMouseEvent),e.off("click",this._handleMouseEvent),e.off("dblclick",this._handleMouseEvent),(t=this._deck)==null||t.finalize(),(n=this._container)==null||n.remove()}_onRemoveInterleaved(e){e.off("styledata",this._handleStyleChange);try{fs(e,this._props.layers,[])}finally{Bp(e)}}_getViews(e){if(!this._props.views)return fr(e);const t=Array.isArray(this._props.views)?this._props.views:[this._props.views];return t.some(s=>s.id===xi)?this._props.views:[fr(e),...t]}}const ld=`layout(std140) uniform iconUniforms {
  float sizeScale;
  vec2 iconsTextureDim;
  float sizeBasis;
  float sizeMinPixels;
  float sizeMaxPixels;
  bool billboard;
  highp int sizeUnits;
  float alphaCutoff;
} icon;
`,mM={name:"icon",vs:ld,fs:ld,uniformTypes:{sizeScale:"f32",iconsTextureDim:"vec2<f32>",sizeBasis:"f32",sizeMinPixels:"f32",sizeMaxPixels:"f32",billboard:"f32",sizeUnits:"i32",alphaCutoff:"f32"}},_M=`#version 300 es
#define SHADER_NAME icon-layer-vertex-shader
in vec2 positions;
in vec3 instancePositions;
in vec3 instancePositions64Low;
in float instanceSizes;
in float instanceAngles;
in vec4 instanceColors;
#ifdef USE_ROW_INDEXES
in float rowIndexes;
#endif
in vec4 instanceIconFrames;
in float instanceColorModes;
in vec2 instanceOffsets;
in vec2 instancePixelOffset;
out float vColorMode;
out vec4 vColor;
out vec2 vTextureCoords;
out vec2 uv;
vec2 rotate_by_angle(vec2 vertex, float angle) {
float angle_radian = angle * PI / 180.0;
float cos_angle = cos(angle_radian);
float sin_angle = sin(angle_radian);
mat2 rotationMatrix = mat2(cos_angle, -sin_angle, sin_angle, cos_angle);
return rotationMatrix * vertex;
}
void main(void) {
geometry.worldPosition = instancePositions;
geometry.uv = positions;
#ifdef USE_ROW_INDEXES
geometry.pickingColor = picking_getPickingColorFromIndex(rowIndexes);
#else
geometry.pickingColor = picking_getPickingColorFromInstanceID();
#endif
uv = positions;
vec2 iconSize = instanceIconFrames.zw;
float sizePixels = clamp(
project_size_to_pixel(instanceSizes * icon.sizeScale, icon.sizeUnits),
icon.sizeMinPixels, icon.sizeMaxPixels
);
float iconConstraint = icon.sizeBasis == 0.0 ? iconSize.x : iconSize.y;
float instanceScale = iconConstraint == 0.0 ? 0.0 : sizePixels / iconConstraint;
vec2 pixelOffset = positions / 2.0 * iconSize + instanceOffsets;
pixelOffset = rotate_by_angle(pixelOffset, instanceAngles) * instanceScale;
pixelOffset += instancePixelOffset;
pixelOffset.y *= -1.0;
if (icon.billboard)  {
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, vec3(0.0), geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
vec3 offset = vec3(pixelOffset, 0.0);
DECKGL_FILTER_SIZE(offset, geometry);
gl_Position.xy += project_pixel_size_to_clipspace(offset.xy);
} else {
vec3 offset_common = vec3(project_pixel_size(pixelOffset), 0.0);
DECKGL_FILTER_SIZE(offset_common, geometry);
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, offset_common, geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
}
vTextureCoords = mix(
instanceIconFrames.xy,
instanceIconFrames.xy + iconSize,
(positions.xy + 1.0) / 2.0
) / icon.iconsTextureDim;
vColor = instanceColors;
DECKGL_FILTER_COLOR(vColor, geometry);
vColorMode = instanceColorModes;
}
`,yM=`#version 300 es
#define SHADER_NAME icon-layer-fragment-shader
precision highp float;
uniform sampler2D iconsTexture;
in float vColorMode;
in vec4 vColor;
in vec2 vTextureCoords;
in vec2 uv;
out vec4 fragColor;
void main(void) {
geometry.uv = uv;
vec4 texColor = texture(iconsTexture, vTextureCoords);
vec3 color = mix(texColor.rgb, vColor.rgb, vColorMode);
float a = texColor.a * layer.opacity * vColor.a;
if (a < icon.alphaCutoff) {
discard;
}
fragColor = vec4(color, a);
DECKGL_FILTER_COLOR(fragColor, geometry);
}
`,bM=`struct IconUniforms {
  sizeScale: f32,
  iconsTextureDim: vec2<f32>,
  sizeBasis: f32,
  sizeMinPixels: f32,
  sizeMaxPixels: f32,
  billboard: i32,
  sizeUnits: i32,
  alphaCutoff: f32
};

@group(0) @binding(auto) var<uniform> icon: IconUniforms;
@group(0) @binding(auto) var iconsTexture : texture_2d<f32>;
@group(0) @binding(auto) var iconsTextureSampler : sampler;

fn rotate_by_angle(vertex: vec2<f32>, angle_deg: f32) -> vec2<f32> {
  let angle_radian = angle_deg * PI / 180.0;
  let c = cos(angle_radian);
  let s = sin(angle_radian);
  let rotation = mat2x2<f32>(vec2<f32>(c, s), vec2<f32>(-s, c));
  return rotation * vertex;
}

struct Attributes {
  @builtin(instance_index) instanceIndex : u32,
  @location(0) positions: vec2<f32>,

  @location(1) instancePositions: vec3<f32>,
  @location(2) instancePositions64Low: vec3<f32>,
  @location(3) instanceSizes: f32,
  @location(4) instanceAngles: f32,
  @location(5) instanceColors: vec4<f32>,
  @location(6) instanceIconFrames: vec4<f32>,
  @location(7) instanceColorModes: f32,
  @location(8) instanceOffsets: vec2<f32>,
  @location(9) instancePixelOffset: vec2<f32>,
  PICKING_COLOR_ATTRIBUTE
};

struct Varyings {
  @builtin(position) position: vec4<f32>,

  @location(0) vColorMode: f32,
  @location(1) vColor: vec4<f32>,
  @location(2) vTextureCoords: vec2<f32>,
  @location(3) uv: vec2<f32>,
  @location(4) pickingColor: vec3<f32>,
};

@vertex
fn vertexMain(inp: Attributes) -> Varyings {
  // write geometry fields used by filters + FS
  geometry.worldPosition = inp.instancePositions;
  geometry.uv = inp.positions;
  geometry.pickingColor = PICKING_COLOR_VALUE;

  var outp: Varyings;
  outp.uv = inp.positions;

  let iconSize = inp.instanceIconFrames.zw;

  // convert size in meters to pixels, then clamp
  let sizePixels = clamp(
    project_unit_size_to_pixel(inp.instanceSizes * icon.sizeScale, icon.sizeUnits),
    icon.sizeMinPixels, icon.sizeMaxPixels
  );

  // scale icon height to match instanceSize
  let iconConstraint = select(iconSize.y, iconSize.x, icon.sizeBasis == 0.0);
  let instanceScale = select(sizePixels / iconConstraint, 0.0, iconConstraint == 0.0);

  // scale and rotate vertex in "pixel" units; then add per-instance pixel offset
  var pixelOffset = inp.positions / 2.0 * iconSize + inp.instanceOffsets;
  pixelOffset = rotate_by_angle(pixelOffset, inp.instanceAngles) * instanceScale;
  pixelOffset = pixelOffset + inp.instancePixelOffset;
  pixelOffset.y = pixelOffset.y * -1.0;

  if (icon.billboard != 0) {
    var pos = project_position_to_clipspace(inp.instancePositions, inp.instancePositions64Low, vec3<f32>(0.0)); // TODO, &geometry.position);
    // DECKGL_FILTER_GL_POSITION(pos, geometry);

    var offset = vec3<f32>(pixelOffset, 0.0);
    // DECKGL_FILTER_SIZE(offset, geometry);
    let clipOffset = project_pixel_size_to_clipspace(offset.xy);
    pos = vec4<f32>(pos.x + clipOffset.x, pos.y + clipOffset.y, pos.z, pos.w);
    outp.position = pos;
  } else {
    var offset_common = vec3<f32>(project_pixel_size_vec2(pixelOffset), 0.0);
    // DECKGL_FILTER_SIZE(offset_common, geometry);
    var pos = project_position_to_clipspace(inp.instancePositions, inp.instancePositions64Low, offset_common); // TODO, &geometry.position);
    // DECKGL_FILTER_GL_POSITION(pos, geometry);
    outp.position = pos;
  }

  let uvMix = (inp.positions.xy + vec2<f32>(1.0, 1.0)) * 0.5;
  outp.vTextureCoords = mix(inp.instanceIconFrames.xy, inp.instanceIconFrames.xy + iconSize, uvMix) / icon.iconsTextureDim;

  outp.vColor = inp.instanceColors;
  // DECKGL_FILTER_COLOR(outp.vColor, geometry);

  outp.vColorMode = inp.instanceColorModes;
  outp.pickingColor = geometry.pickingColor;

  return outp;
}

@fragment
fn fragmentMain(inp: Varyings) -> @location(0) vec4<f32> {
  // expose to deck.gl filter hooks
  geometry.uv = inp.uv;

  let texColor = textureSample(iconsTexture, iconsTextureSampler, inp.vTextureCoords);

  // if colorMode == 0, use pixel color from the texture
  // if colorMode == 1 (or picking), use texture as transparency mask
  let rgb = mix(texColor.rgb, inp.vColor.rgb, inp.vColorMode);
  let a = texColor.a * layer.opacity * inp.vColor.a;

  if (a < icon.alphaCutoff) {
    discard;
  }

  if (picking.isActive > 0.5) {
    if (!picking_isColorValid(inp.pickingColor)) {
      discard;
    }
    return vec4<f32>(inp.pickingColor, 1.0);
  }

  var fragColor = deckgl_premultiplied_alpha(vec4<f32>(rgb, a));

  if (picking.isHighlightActive > 0.5) {
    let highlightedObjectColor = picking_normalizeColor(picking.highlightedObjectColor);
    if (picking_isColorZero(abs(inp.pickingColor - highlightedObjectColor))) {
      let highLightAlpha = picking.highlightColor.a;
      let blendedAlpha = highLightAlpha + fragColor.a * (1.0 - highLightAlpha);
      if (blendedAlpha > 0.0) {
        let highLightRatio = highLightAlpha / blendedAlpha;
        fragColor = vec4<f32>(
          mix(fragColor.rgb, picking.highlightColor.rgb, highLightRatio),
          blendedAlpha
        );
      } else {
        fragColor = vec4<f32>(fragColor.rgb, 0.0);
      }
    }
  }

  return fragColor;
}
`;function vM(i){return bM.replace("PICKING_COLOR_ATTRIBUTE",i?"@location(10) rowIndexes: u32,":"").replace("PICKING_COLOR_VALUE",i?"picking_getPickingColorFromIndex(inp.rowIndexes)":"picking_getPickingColorFromIndex(inp.instanceIndex)")}const wM=1024,xM=4,ud=()=>{},fd={minFilter:"linear",mipmapFilter:"linear",magFilter:"linear",addressModeU:"clamp-to-edge",addressModeV:"clamp-to-edge"},PM={x:0,y:0,width:0,height:0};function SM(i){return Math.pow(2,Math.ceil(Math.log2(i)))}function EM(i,e,t,n){const s=Math.min(t/e.width,n/e.height),r=Math.floor(e.width*s),o=Math.floor(e.height*s);return s===1?{image:e,width:r,height:o}:(i.canvas.height=o,i.canvas.width=r,i.clearRect(0,0,r,o),i.drawImage(e,0,0,e.width,e.height,0,0,r,o),{image:i.canvas,width:r,height:o})}function Cn(i){return i&&(i.id||i.url)}function Fp(i){const{device:e}=i;e.type==="webgl"?i.generateMipmapsWebGL():e.type==="webgpu"&&e.generateMipmapsWebGPU(i)}function CM(i,e,t,n){const{width:s,height:r,device:o}=i,a=o.createTexture({format:"rgba8unorm",width:e,height:t,sampler:n,mipLevels:o.getMipLevelCount(e,t)}),c=o.createCommandEncoder();c.copyTextureToTexture({sourceTexture:i,destinationTexture:a,width:s,height:r});const l=c.finish();return o.submit(l),Fp(a),i.destroy(),a}function dd(i,e,t){for(let n=0;n<e.length;n++){const{icon:s,xOffset:r}=e[n],o=Cn(s);i[o]={...s,x:r,y:t}}}function LM({icons:i,buffer:e,mapping:t={},xOffset:n=0,yOffset:s=0,rowHeight:r=0,canvasWidth:o}){let a=[];for(let c=0;c<i.length;c++){const l=i[c],u=Cn(l);if(!t[u]){const{height:f,width:d}=l;n+d+e>o&&(dd(t,a,s),n=0,s=r+s+e,r=0,a=[]),a.push({icon:l,xOffset:n}),n=n+d+e,r=Math.max(r,f)}}return a.length>0&&dd(t,a,s),{mapping:t,rowHeight:r,xOffset:n,yOffset:s,canvasWidth:o,canvasHeight:SM(r+s+e)}}function TM(i,e,t){if(!i||!e)return null;t=t||{};const n={},{iterable:s,objectInfo:r}=Ii(i);for(const o of s){r.index++;const a=e(o,r),c=Cn(a);if(!a)throw new Error("Icon is missing.");if(!a.url)throw new Error("Icon url is missing.");!n[c]&&(!t[c]||a.url!==t[c].url)&&(n[c]={...a,source:o,sourceIndex:r.index})}return n}class AM{constructor(e,{onUpdate:t=ud,onError:n=ud}){this._loadOptions=null,this._texture=null,this._externalTexture=null,this._mapping={},this._samplerParameters=null,this._pendingCount=0,this._autoPacking=!1,this._xOffset=0,this._yOffset=0,this._rowHeight=0,this._buffer=xM,this._canvasWidth=wM,this._canvasHeight=0,this._canvas=null,this.device=e,this.onUpdate=t,this.onError=n}finalize(){var e;(e=this._texture)==null||e.delete()}getTexture(){return this._texture||this._externalTexture}getIconMapping(e){const t=this._autoPacking?Cn(e):e;return this._mapping[t]||PM}setProps({loadOptions:e,autoPacking:t,iconAtlas:n,iconMapping:s,textureParameters:r}){var o;e&&(this._loadOptions=e),t!==void 0&&(this._autoPacking=t),s&&(this._mapping=s),n&&((o=this._texture)==null||o.delete(),this._texture=null,this._externalTexture=n),r&&(this._samplerParameters=r)}get isLoaded(){return this._pendingCount===0}packIcons(e,t){if(!this._autoPacking||typeof document>"u")return;const n=Object.values(TM(e,t,this._mapping)||{});if(n.length>0){const{mapping:s,xOffset:r,yOffset:o,rowHeight:a,canvasHeight:c}=LM({icons:n,buffer:this._buffer,canvasWidth:this._canvasWidth,mapping:this._mapping,rowHeight:this._rowHeight,xOffset:this._xOffset,yOffset:this._yOffset});this._rowHeight=a,this._mapping=s,this._xOffset=r,this._yOffset=o,this._canvasHeight=c,this._texture||(this._texture=this.device.createTexture({format:"rgba8unorm",data:null,width:this._canvasWidth,height:this._canvasHeight,sampler:this._samplerParameters||fd,mipLevels:this.device.getMipLevelCount(this._canvasWidth,this._canvasHeight)})),this._texture.height!==this._canvasHeight&&(this._texture=CM(this._texture,this._canvasWidth,this._canvasHeight,this._samplerParameters||fd)),this.onUpdate(!0),this._canvas=this._canvas||document.createElement("canvas"),this._loadIcons(n)}}_loadIcons(e){const t=this._canvas.getContext("2d",{willReadFrequently:!0});for(const n of e)this._pendingCount++,zs(n.url,this._loadOptions).then(s=>{var _;const r=Cn(n),o=this._mapping[r],{x:a,y:c,width:l,height:u}=o,{image:f,width:d,height:g}=EM(t,s,l,u),p=a+(l-d)/2,m=c+(u-g)/2;(_=this._texture)==null||_.copyExternalImage({image:f,x:p,y:m,width:d,height:g}),o.x=p,o.y=m,o.width=d,o.height=g,this._texture&&Fp(this._texture),this.onUpdate(d!==l||g!==u)}).catch(s=>{this.onError({url:n.url,source:n.source,sourceIndex:n.sourceIndex,loadOptions:this._loadOptions,error:s})}).finally(()=>{this._pendingCount--})}}const zp=[0,0,0,255],MM={iconAtlas:{type:"image",value:null,async:!0},iconMapping:{type:"object",value:{},async:!0},sizeScale:{type:"number",value:1,min:0},billboard:!0,sizeUnits:"pixels",sizeBasis:"height",sizeMinPixels:{type:"number",min:0,value:0},sizeMaxPixels:{type:"number",min:0,value:Number.MAX_SAFE_INTEGER},alphaCutoff:{type:"number",value:.05,min:0,max:1},getPosition:{type:"accessor",value:i=>i.position},getIcon:{type:"accessor",value:i=>i.icon},getColor:{type:"accessor",value:zp},getSize:{type:"accessor",value:1},getAngle:{type:"accessor",value:0},getPixelOffset:{type:"accessor",value:[0,0]},onIconError:{type:"function",value:null,optional:!0},textureParameters:{type:"object",ignore:!0,value:null}};class Zr extends xt{getShaders(){var t,n;const e=!!((n=(t=this.props.data)==null?void 0:t.attributes)!=null&&n.rowIndexes);return super.getShaders({vs:_M,fs:yM,source:vM(e),defines:e?{USE_ROW_INDEXES:!0}:{},modules:[Dn,Bn,zn,mM]})}initializeState(){var t,n;this.state={iconManager:new AM(this.context.device,{onUpdate:this._onUpdate.bind(this),onError:this._onError.bind(this)})},this.getAttributeManager().addInstanced({instancePositions:{size:3,type:"float64",fp64:this.use64bitPositions(),transition:!0,accessor:"getPosition"},instanceSizes:{size:1,transition:!0,bufferGroup:"icon-instance-data",accessor:"getSize",defaultValue:1},instanceIconDefs:{size:7,bufferGroup:"icon-instance-data",accessor:"getIcon",transform:this.getInstanceIconDef,shaderAttributes:{instanceOffsets:{size:2,elementOffset:0},instanceIconFrames:{size:4,elementOffset:2},instanceColorModes:{size:1,elementOffset:6}}},instanceColors:{size:this.props.colorFormat.length,type:"unorm8",transition:!0,bufferGroup:"icon-instance-data",accessor:"getColor",defaultValue:zp},instanceAngles:{size:1,transition:!0,bufferGroup:"icon-instance-data",accessor:"getAngle"},instancePixelOffset:{size:2,transition:!0,bufferGroup:"icon-instance-data",accessor:"getPixelOffset"},...(n=(t=this.props.data)==null?void 0:t.attributes)!=null&&n.rowIndexes?{rowIndexes:{size:1,type:"uint32",noAlloc:!0}}:{}})}updateState(e){var g;super.updateState(e);const{props:t,oldProps:n,changeFlags:s}=e,r=this.getAttributeManager(),{iconAtlas:o,iconMapping:a,data:c,getIcon:l,textureParameters:u}=t,{iconManager:f}=this.state;if(typeof o=="string")return;const d=o||this.internalState.isAsyncPropLoading("iconAtlas");f.setProps({loadOptions:t.loadOptions,autoPacking:!d,iconAtlas:o,iconMapping:d?a:null,textureParameters:u}),d?n.iconMapping!==t.iconMapping&&r.invalidate("getIcon"):(s.dataChanged||s.updateTriggersChanged&&(s.updateTriggersChanged.all||s.updateTriggersChanged.getIcon))&&f.packIcons(c,l),s.extensionsChanged&&((g=this.state.model)==null||g.destroy(),this.state.model=this._getModel(),r.invalidateAll())}get isLoaded(){return super.isLoaded&&this.state.iconManager.isLoaded}finalizeState(e){super.finalizeState(e),this.state.iconManager.finalize()}draw({uniforms:e}){this._drawModel(this.state.model)}_drawModel(e){const{sizeScale:t,sizeBasis:n,sizeMinPixels:s,sizeMaxPixels:r,sizeUnits:o,billboard:a,alphaCutoff:c}=this.props,{iconManager:l}=this.state,u=l.getTexture();if(u){const f={iconsTexture:u,iconsTextureDim:[u.width,u.height],sizeUnits:at[o],sizeScale:t,sizeBasis:n==="height"?1:0,sizeMinPixels:s,sizeMaxPixels:r,billboard:a,alphaCutoff:c};e.shaderInputs.setProps({icon:f}),e.draw(this.context.renderPass)}}_getModel(e=this.props.id){const t=[-1,-1,1,-1,-1,1,1,1];return new Ue(this.context.device,{...this.getShaders(),id:e,bufferLayout:this.getAttributeManager().getBufferLayouts(),geometry:new Ut({topology:"triangle-strip",attributes:{positions:{size:2,value:new Float32Array(t)}}}),isInstanced:!0})}_onUpdate(e){var t;e?((t=this.getAttributeManager())==null||t.invalidate("getIcon"),this.setNeedsUpdate()):this.setNeedsRedraw()}_onError(e){var n;const t=(n=this.getCurrentLayer())==null?void 0:n.props.onIconError;t?t(e):Y.error(e.error.message)()}getInstanceIconDef(e){const{x:t,y:n,width:s,height:r,mask:o,anchorX:a=s/2,anchorY:c=r/2}=this.state.iconManager.getIconMapping(e);return[s/2-a,r/2-c,t,n,s,r,o?1:0]}}Zr.defaultProps=MM;Zr.layerName="IconLayer";const hd=`layout(std140) uniform scatterplotUniforms {
  float radiusScale;
  float radiusMinPixels;
  float radiusMaxPixels;
  float lineWidthScale;
  float lineWidthMinPixels;
  float lineWidthMaxPixels;
  float stroked;
  float filled;
  bool antialiasing;
  bool billboard;
  highp int radiusUnits;
  highp int lineWidthUnits;
} scatterplot;
`,IM={name:"scatterplot",vs:hd,fs:hd,source:"",uniformTypes:{radiusScale:"f32",radiusMinPixels:"f32",radiusMaxPixels:"f32",lineWidthScale:"f32",lineWidthMinPixels:"f32",lineWidthMaxPixels:"f32",stroked:"f32",filled:"f32",antialiasing:"f32",billboard:"f32",radiusUnits:"i32",lineWidthUnits:"i32"}},RM=`#version 300 es
#define SHADER_NAME scatterplot-layer-vertex-shader
in vec3 positions;
in vec3 instancePositions;
in vec3 instancePositions64Low;
in float instanceRadius;
in float instanceLineWidths;
in vec4 instanceFillColors;
in vec4 instanceLineColors;
#ifdef USE_ROW_INDEXES
in float rowIndexes;
#endif
in vec2 instancePixelOffset;
out vec4 vFillColor;
out vec4 vLineColor;
out vec2 unitPosition;
out float innerUnitRadius;
out float outerRadiusPixels;
void main(void) {
geometry.worldPosition = instancePositions;
outerRadiusPixels = clamp(
project_size_to_pixel(scatterplot.radiusScale * instanceRadius, scatterplot.radiusUnits),
scatterplot.radiusMinPixels, scatterplot.radiusMaxPixels
);
float lineWidthPixels = clamp(
project_size_to_pixel(scatterplot.lineWidthScale * instanceLineWidths, scatterplot.lineWidthUnits),
scatterplot.lineWidthMinPixels, scatterplot.lineWidthMaxPixels
);
outerRadiusPixels += scatterplot.stroked * lineWidthPixels / 2.0;
float edgePadding = scatterplot.antialiasing ? (outerRadiusPixels + SMOOTH_EDGE_RADIUS) / outerRadiusPixels : 1.0;
unitPosition = edgePadding * positions.xy;
geometry.uv = unitPosition;
#ifdef USE_ROW_INDEXES
geometry.pickingColor = picking_getPickingColorFromIndex(rowIndexes);
#else
geometry.pickingColor = picking_getPickingColorFromInstanceID();
#endif
innerUnitRadius = 1.0 - scatterplot.stroked * lineWidthPixels / outerRadiusPixels;
if (scatterplot.billboard) {
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, vec3(0.0), geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
vec3 offset = edgePadding * positions * outerRadiusPixels;
offset.xy += instancePixelOffset;
DECKGL_FILTER_SIZE(offset, geometry);
gl_Position.xy += project_pixel_size_to_clipspace(offset.xy);
} else {
vec3 offset = edgePadding * positions * project_pixel_size(outerRadiusPixels);
offset.xy += project_pixel_size(instancePixelOffset);
DECKGL_FILTER_SIZE(offset, geometry);
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, offset, geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
}
vFillColor = vec4(instanceFillColors.rgb, instanceFillColors.a * layer.opacity);
DECKGL_FILTER_COLOR(vFillColor, geometry);
vLineColor = vec4(instanceLineColors.rgb, instanceLineColors.a * layer.opacity);
DECKGL_FILTER_COLOR(vLineColor, geometry);
}
`,OM=`#version 300 es
#define SHADER_NAME scatterplot-layer-fragment-shader
precision highp float;
in vec4 vFillColor;
in vec4 vLineColor;
in vec2 unitPosition;
in float innerUnitRadius;
in float outerRadiusPixels;
out vec4 fragColor;
void main(void) {
geometry.uv = unitPosition;
float distToCenter = length(unitPosition) * outerRadiusPixels;
float inCircle = scatterplot.antialiasing ?
smoothedge(distToCenter, outerRadiusPixels) :
step(distToCenter, outerRadiusPixels);
if (inCircle == 0.0) {
discard;
}
if (scatterplot.stroked > 0.5) {
float isLine = scatterplot.antialiasing ?
smoothedge(innerUnitRadius * outerRadiusPixels, distToCenter) :
step(innerUnitRadius * outerRadiusPixels, distToCenter);
if (scatterplot.filled > 0.5) {
fragColor = mix(vFillColor, vLineColor, isLine);
} else {
if (isLine == 0.0) {
discard;
}
fragColor = vec4(vLineColor.rgb, vLineColor.a * isLine);
}
} else if (scatterplot.filled < 0.5) {
discard;
} else {
fragColor = vFillColor;
}
fragColor.a *= inCircle;
DECKGL_FILTER_COLOR(fragColor, geometry);
}
`,BM=`// Main shaders

struct ScatterplotUniforms {
  radiusScale: f32,
  radiusMinPixels: f32,
  radiusMaxPixels: f32,
  lineWidthScale: f32,
  lineWidthMinPixels: f32,
  lineWidthMaxPixels: f32,
  stroked: f32,
  filled: i32,
  antialiasing: i32,
  billboard: i32,
  radiusUnits: i32,
  lineWidthUnits: i32,
};

@group(0) @binding(0) var<uniform> scatterplot: ScatterplotUniforms;

struct Attributes {
  @builtin(instance_index) instanceIndex : u32,
  @builtin(vertex_index) vertexIndex : u32,
  @location(0) positions: vec3<f32>,
  @location(1) instancePositions: vec3<f32>,
  @location(2) instancePositions64Low: vec3<f32>,
  @location(3) instanceRadius: f32,
  @location(4) instanceLineWidths: f32,
  @location(5) instanceFillColors: vec4<f32>,
  @location(6) instanceLineColors: vec4<f32>,
  @location(7) instancePixelOffset: vec2<f32>,
  PICKING_COLOR_ATTRIBUTE
};

struct Varyings {
  @builtin(position) position: vec4<f32>,
  @location(0) vFillColor: vec4<f32>,
  @location(1) vLineColor: vec4<f32>,
  @location(2) unitPosition: vec2<f32>,
  @location(3) innerUnitRadius: f32,
  @location(4) outerRadiusPixels: f32,
  @location(5) pickingColor: vec3<f32>,
  @location(6) clipCoordinates: vec2<f32>,
};

@vertex
fn vertexMain(attributes: Attributes) -> Varyings {
  var varyings: Varyings;

  // Draw an inline geometry constant array clip space triangle to verify that rendering works.
  // var positions = array<vec2<f32>, 3>(vec2(0.0, 0.5), vec2(-0.5, -0.5), vec2(0.5, -0.5));
  // if (attributes.instanceIndex == 0) {
  //   varyings.position = vec4<f32>(positions[attributes.vertexIndex], 0.0, 1.0);
  //   return varyings;
  // }

  geometry.worldPosition = attributes.instancePositions;

  // Multiply out radius and clamp to limits
  varyings.outerRadiusPixels = clamp(
    project_unit_size_to_pixel(scatterplot.radiusScale * attributes.instanceRadius, scatterplot.radiusUnits),
    scatterplot.radiusMinPixels, scatterplot.radiusMaxPixels
  );

  // Multiply out line width and clamp to limits
  let lineWidthPixels = clamp(
    project_unit_size_to_pixel(scatterplot.lineWidthScale * attributes.instanceLineWidths, scatterplot.lineWidthUnits),
    scatterplot.lineWidthMinPixels, scatterplot.lineWidthMaxPixels
  );

  // outer radius needs to offset by half stroke width
  varyings.outerRadiusPixels += scatterplot.stroked * lineWidthPixels / 2.0;
  // Expand geometry to accommodate edge smoothing
  // WGSL selects the second value when the condition is true, so keep the antialiased path second.
  let edgePadding = select(
    1.0,
    (varyings.outerRadiusPixels + SMOOTH_EDGE_RADIUS) / varyings.outerRadiusPixels,
    scatterplot.antialiasing != 0
  );

  // position on the containing square in [-1, 1] space
  varyings.unitPosition = edgePadding * attributes.positions.xy;
  geometry.uv = varyings.unitPosition;
  geometry.pickingColor = PICKING_COLOR_VALUE;

  varyings.innerUnitRadius = 1.0 - scatterplot.stroked * lineWidthPixels / varyings.outerRadiusPixels;

  if (scatterplot.billboard != 0) {
    let projectedPosition = project_position_to_clipspace_and_commonspace(
      attributes.instancePositions,
      attributes.instancePositions64Low,
      vec3<f32>(0.0)
    );
    geometry.position = projectedPosition.commonPosition;
    varyings.position = projectedPosition.clipPosition;
    // DECKGL_FILTER_GL_POSITION(varyings.position, geometry);
    var offset = edgePadding * attributes.positions * varyings.outerRadiusPixels;
    offset = vec3<f32>(offset.xy + attributes.instancePixelOffset, offset.z);
    // DECKGL_FILTER_SIZE(offset, geometry);
    let clipPixels = project_pixel_size_to_clipspace(offset.xy);
    varyings.position = vec4<f32>(varyings.position.x + clipPixels.x, varyings.position.y + clipPixels.y, varyings.position.z, varyings.position.w);
    geometry.position = vec4<f32>(
      geometry.position.xy + project_pixel_size_vec2(offset.xy),
      geometry.position.zw
    );
  } else {
    var offset = edgePadding * attributes.positions * project_pixel_size_float(varyings.outerRadiusPixels);
    offset = vec3<f32>(offset.xy + project_pixel_size_vec2(attributes.instancePixelOffset), offset.z);
    // DECKGL_FILTER_SIZE(offset, geometry);
    let projectedPosition = project_position_to_clipspace_and_commonspace(
      attributes.instancePositions,
      attributes.instancePositions64Low,
      offset
    );
    geometry.position = projectedPosition.commonPosition;
    varyings.position = projectedPosition.clipPosition;
    // DECKGL_FILTER_GL_POSITION(varyings.position, geometry);
  }

  varyings.clipCoordinates = geometry.position.xy;
  clip_filterPosition(&varyings.position, geometry.worldPosition.xy);

  // Apply opacity to instance color, or return instance picking color
  varyings.vFillColor = vec4<f32>(attributes.instanceFillColors.rgb, attributes.instanceFillColors.a * layer.opacity);
  // DECKGL_FILTER_COLOR(varyings.vFillColor, geometry);
  varyings.vLineColor = vec4<f32>(attributes.instanceLineColors.rgb, attributes.instanceLineColors.a * layer.opacity);
  // DECKGL_FILTER_COLOR(varyings.vLineColor, geometry);
  varyings.pickingColor = geometry.pickingColor;

  return varyings;
}

@fragment
fn fragmentMain(varyings: Varyings) -> @location(0) vec4<f32> {
  // var geometry: Geometry;
  // geometry.uv = unitPosition;

  let distToCenter = length(varyings.unitPosition) * varyings.outerRadiusPixels;
  let inCircle = select(
    step(distToCenter, varyings.outerRadiusPixels),
    smoothedge(distToCenter, varyings.outerRadiusPixels),
    scatterplot.antialiasing != 0
  );

  if (inCircle == 0.0) {
    discard;
  }

  var fragColor: vec4<f32>;

  if (scatterplot.stroked != 0) {
    let isLine = select(
      step(varyings.innerUnitRadius * varyings.outerRadiusPixels, distToCenter),
      smoothedge(varyings.innerUnitRadius * varyings.outerRadiusPixels, distToCenter),
      scatterplot.antialiasing != 0
    );

    if (scatterplot.filled != 0) {
      fragColor = mix(varyings.vFillColor, varyings.vLineColor, isLine);
    } else {
      if (isLine == 0.0) {
        discard;
      }
      fragColor = vec4<f32>(varyings.vLineColor.rgb, varyings.vLineColor.a * isLine);
    }
  } else if (scatterplot.filled == 0) {
    discard;
  } else {
    fragColor = varyings.vFillColor;
  }

  fragColor.a *= inCircle;

  clip_filterColor(varyings.clipCoordinates);

  if (picking.isActive > 0.5) {
    if (!picking_isColorValid(varyings.pickingColor)) {
      discard;
    }
    return vec4<f32>(varyings.pickingColor, 1.0);
  }

  if (picking.isHighlightActive > 0.5) {
    let highlightedObjectColor = picking_normalizeColor(picking.highlightedObjectColor);
    if (picking_isColorZero(abs(varyings.pickingColor - highlightedObjectColor))) {
      let highLightAlpha = picking.highlightColor.a;
      let blendedAlpha = highLightAlpha + fragColor.a * (1.0 - highLightAlpha);
      if (blendedAlpha > 0.0) {
        let highLightRatio = highLightAlpha / blendedAlpha;
        fragColor = vec4<f32>(
          mix(fragColor.rgb, picking.highlightColor.rgb, highLightRatio),
          blendedAlpha
        );
      } else {
        fragColor = vec4<f32>(fragColor.rgb, 0.0);
      }
    }
  }

  // Apply premultiplied alpha as required by transparent canvas
  fragColor = deckgl_premultiplied_alpha(fragColor);

  return fragColor;
  // return vec4<f32>(0, 0, 1, 1);
}
`;function kM(i){return BM.replace("PICKING_COLOR_ATTRIBUTE",i?"@location(8) rowIndexes: u32,":"").replace("PICKING_COLOR_VALUE",i?"picking_getPickingColorFromIndex(attributes.rowIndexes)":"picking_getPickingColorFromIndex(attributes.instanceIndex)")}const _c=0,Np=1,DM=`struct ClipUniforms {
  enabled: i32,
  mode: i32,
  bounds: vec4<f32>,
};

@group(2) @binding(auto) var<uniform> clipUniforms: ClipUniforms;

fn clip_isInBounds(coordinates: vec2<f32>) -> bool {
  return coordinates.x >= clipUniforms.bounds.x &&
    coordinates.y >= clipUniforms.bounds.y &&
    coordinates.x < clipUniforms.bounds.z &&
    coordinates.y < clipUniforms.bounds.w;
}

fn clip_filterPosition(position: ptr<function, vec4<f32>>, instanceCoordinates: vec2<f32>) {
  if (
    clipUniforms.enabled != 0 &&
    clipUniforms.mode == ${Np} &&
    !clip_isInBounds(instanceCoordinates)
  ) {
    *position = vec4<f32>(2.0, 2.0, 2.0, 1.0);
  }
}

fn clip_filterColor(geometryCoordinates: vec2<f32>) {
  if (
    clipUniforms.enabled != 0 &&
    clipUniforms.mode == ${_c} &&
    !clip_isInBounds(geometryCoordinates)
  ) {
    discard;
  }
}
`,bl={name:"clip",source:DM,props:{},uniforms:{},bindingLayout:[{name:"clip",group:2}],uniformTypes:{enabled:"i32",mode:"i32",bounds:"vec4<f32>"},defaultUniforms:{enabled:0,mode:_c,bounds:[0,0,1,1]},getUniforms(i={}){const e={};return i.enabled!==void 0&&(e.enabled=i.enabled?1:0),i.mode!==void 0&&(e.mode=i.mode==="instance"?Np:_c),i.bounds!==void 0&&(e.bounds=i.bounds),e}},gd=[0,0,0,255],FM={radiusUnits:"meters",radiusScale:{type:"number",min:0,value:1},radiusMinPixels:{type:"number",min:0,value:0},radiusMaxPixels:{type:"number",min:0,value:Number.MAX_SAFE_INTEGER},lineWidthUnits:"meters",lineWidthScale:{type:"number",min:0,value:1},lineWidthMinPixels:{type:"number",min:0,value:0},lineWidthMaxPixels:{type:"number",min:0,value:Number.MAX_SAFE_INTEGER},stroked:!1,filled:!0,billboard:!1,antialiasing:!0,getPosition:{type:"accessor",value:i=>i.position},getRadius:{type:"accessor",value:1},getFillColor:{type:"accessor",value:gd},getLineColor:{type:"accessor",value:gd},getLineWidth:{type:"accessor",value:1},getPixelOffset:{type:"accessor",value:[0,0]},strokeWidth:{deprecatedFor:"getLineWidth"},outline:{deprecatedFor:"stroked"},getColor:{deprecatedFor:["getFillColor","getLineColor"]}};class Xr extends xt{getShaders(){var t,n;const e=!!((n=(t=this.props.data)==null?void 0:t.attributes)!=null&&n.rowIndexes);return super.getShaders({vs:RM,fs:OM,source:kM(e),defines:e?{USE_ROW_INDEXES:!0}:{},modules:[Dn,Bn,zn,IM,...this.context.device.type==="webgpu"?[bl]:[]]})}initializeState(){var t,n;const e=(n=(t=this.props.data)==null?void 0:t.attributes)!=null&&n.rowIndexes?{rowIndexes:{size:1,type:"uint32",noAlloc:!0}}:{};this.getAttributeManager().addInstanced({instancePositions:{size:3,type:"float64",fp64:this.use64bitPositions(),transition:!0,accessor:"getPosition"},instanceRadius:{size:1,transition:!0,accessor:"getRadius",defaultValue:1,bufferGroup:"scatterplot-instance-data"},instanceFillColors:{size:this.props.colorFormat.length,transition:!0,type:"unorm8",accessor:"getFillColor",defaultValue:[0,0,0,255],bufferGroup:"scatterplot-instance-data"},instanceLineColors:{size:this.props.colorFormat.length,transition:!0,type:"unorm8",accessor:"getLineColor",defaultValue:[0,0,0,255],bufferGroup:"scatterplot-instance-data"},instanceLineWidths:{size:1,transition:!0,accessor:"getLineWidth",defaultValue:1,bufferGroup:"scatterplot-instance-data"},instancePixelOffset:{size:2,transition:!0,accessor:"getPixelOffset",bufferGroup:"scatterplot-instance-data"},...e})}updateState(e){var t;super.updateState(e),e.changeFlags.extensionsChanged&&((t=this.state.model)==null||t.destroy(),this.state.model=this._getModel(),this.getAttributeManager().invalidateAll())}draw({uniforms:e}){const{radiusUnits:t,radiusScale:n,radiusMinPixels:s,radiusMaxPixels:r,stroked:o,filled:a,billboard:c,antialiasing:l,lineWidthUnits:u,lineWidthScale:f,lineWidthMinPixels:d,lineWidthMaxPixels:g}=this.props,p={stroked:o,filled:a,billboard:c,antialiasing:l,radiusUnits:at[t],radiusScale:n,radiusMinPixels:s,radiusMaxPixels:r,lineWidthUnits:at[u],lineWidthScale:f,lineWidthMinPixels:d,lineWidthMaxPixels:g},m=this.state.model;m.shaderInputs.setProps({scatterplot:p}),m.draw(this.context.renderPass)}_getModel(){const e=[-1,-1,0,1,-1,0,-1,1,0,1,1,0];return new Ue(this.context.device,{...this.getShaders(),id:this.props.id,bufferLayout:this.getAttributeManager().getBufferLayouts(),geometry:new Ut({topology:"triangle-strip",attributes:{positions:{size:3,value:new Float32Array(e)}}}),isInstanced:!0})}}Xr.defaultProps=FM;Xr.layerName="ScatterplotLayer";const Up={CLOCKWISE:1,COUNTER_CLOCKWISE:-1};function $p(i,e,t={}){return zM(i,t)!==e?(UM(i,t),!0):!1}function zM(i,e={}){return Math.sign(NM(i,e))}const pd={x:0,y:1,z:2};function NM(i,e={}){const{start:t=0,end:n=i.length,plane:s="xy"}=e,r=e.size||2;let o=0;const a=pd[s[0]],c=pd[s[1]];for(let l=t,u=n-r;l<n;l+=r)o+=(i[l+a]-i[u+a])*(i[l+c]+i[u+c]),u=l;return o/2}function UM(i,e){const{start:t=0,end:n=i.length,size:s=2}=e,r=(n-t)/s,o=Math.floor(r/2);for(let a=0;a<o;++a){const c=t+a*s,l=t+(r-1-a)*s;for(let u=0;u<s;++u){const f=i[c+u];i[c+u]=i[l+u],i[l+u]=f}}}function Ne(i,e){const t=e.length,n=i.length;if(n>0){let s=!0;for(let r=0;r<t;r++)if(i[n-t+r]!==e[r]){s=!1;break}if(s)return!1}for(let s=0;s<t;s++)i[n+s]=e[s];return!0}function yc(i,e){const t=e.length;for(let n=0;n<t;n++)i[n]=e[n]}function Ln(i,e,t,n,s=[]){const r=n+e*t;for(let o=0;o<t;o++)s[o]=i[r+o];return s}function bc(i,e,t,n,s=[]){let r,o;if(t&8)r=(n[3]-i[1])/(e[1]-i[1]),o=3;else if(t&4)r=(n[1]-i[1])/(e[1]-i[1]),o=1;else if(t&2)r=(n[2]-i[0])/(e[0]-i[0]),o=2;else if(t&1)r=(n[0]-i[0])/(e[0]-i[0]),o=0;else return null;for(let a=0;a<i.length;a++)s[a]=(o&1)===a?n[o]:r*(e[a]-i[a])+i[a];return s}function As(i,e){let t=0;return i[0]<e[0]?t|=1:i[0]>e[2]&&(t|=2),i[1]<e[1]?t|=4:i[1]>e[3]&&(t|=8),t}function Gp(i,e){const{size:t=2,broken:n=!1,gridResolution:s=10,gridOffset:r=[0,0],startIndex:o=0,endIndex:a=i.length}=e||{},c=(a-o)/t;let l=[];const u=[l],f=Ln(i,0,t,o);let d,g;const p=Vp(f,s,r,[]),m=[];Ne(l,f);for(let _=1;_<c;_++){for(d=Ln(i,_,t,o,d),g=As(d,p);g;){bc(f,d,g,p,m);const v=As(m,p);v&&(bc(f,m,v,p,m),g=v),Ne(l,m),yc(f,m),GM(p,s,g),n&&l.length>t&&(l=[],u.push(l),Ne(l,f)),g=As(d,p)}Ne(l,d),yc(f,d)}return n?u:u[0]}const md=0,$M=1;function jp(i,e=null,t){if(!i.length)return[];const{size:n=2,gridResolution:s=10,gridOffset:r=[0,0],edgeTypes:o=!1}=t||{},a=[],c=[{pos:i,types:o?new Array(i.length/n).fill($M):null,holes:e||[]}],l=[[],[]];let u=[];for(;c.length;){const{pos:f,types:d,holes:g}=c.shift();jM(f,n,g[0]||f.length,l),u=Vp(l[0],s,r,u);const p=As(l[1],u);if(p){let m=_d(f,d,n,0,g[0]||f.length,u,p);const _={pos:m[0].pos,types:m[0].types,holes:[]},v={pos:m[1].pos,types:m[1].types,holes:[]};c.push(_,v);for(let w=0;w<g.length;w++)m=_d(f,d,n,g[w],g[w+1]||f.length,u,p),m[0]&&(_.holes.push(_.pos.length),_.pos=ds(_.pos,m[0].pos),o&&(_.types=ds(_.types,m[0].types))),m[1]&&(v.holes.push(v.pos.length),v.pos=ds(v.pos,m[1].pos),o&&(v.types=ds(v.types,m[1].types)))}else{const m={positions:f};o&&(m.edgeTypes=d),g.length&&(m.holeIndices=g),a.push(m)}}return a}function _d(i,e,t,n,s,r,o){const a=(s-n)/t,c=[],l=[],u=[],f=[],d=[];let g,p,m;const _=Ln(i,a-1,t,n);let v=Math.sign(o&8?_[1]-r[3]:_[0]-r[2]),w=e&&e[a-1],y=0,x=0;for(let S=0;S<a;S++)g=Ln(i,S,t,n,g),p=Math.sign(o&8?g[1]-r[3]:g[0]-r[2]),m=e&&e[n/t+S],p&&v&&v!==p&&(bc(_,g,o,r,d),Ne(c,d)&&u.push(w),Ne(l,d)&&f.push(w)),p<=0?(Ne(c,g)&&u.push(m),y-=p):u.length&&(u[u.length-1]=md),p>=0?(Ne(l,g)&&f.push(m),x+=p):f.length&&(f[f.length-1]=md),yc(_,g),v=p,w=m;return[y?{pos:c,types:e&&u}:null,x?{pos:l,types:e&&f}:null]}function Vp(i,e,t,n){const s=Math.floor((i[0]-t[0])/e)*e+t[0],r=Math.floor((i[1]-t[1])/e)*e+t[1];return n[0]=s,n[1]=r,n[2]=s+e,n[3]=r+e,n}function GM(i,e,t){t&8?(i[1]+=e,i[3]+=e):t&4?(i[1]-=e,i[3]-=e):t&2?(i[0]+=e,i[2]+=e):t&1&&(i[0]-=e,i[2]-=e)}function jM(i,e,t,n){let s=1/0,r=-1/0,o=1/0,a=-1/0;for(let c=0;c<t;c+=e){const l=i[c],u=i[c+1];s=l<s?l:s,r=l>r?l:r,o=u<o?u:o,a=u>a?u:a}return n[0][0]=s,n[0][1]=o,n[1][0]=r,n[1][1]=a,n}function ds(i,e){for(let t=0;t<e.length;t++)i.push(e[t]);return i}const VM=85.051129;function WM(i,e){const{size:t=2,startIndex:n=0,endIndex:s=i.length,normalize:r=!0}=e||{},o=i.slice(n,s);Wp(o,t,0,s-n);const a=Gp(o,{size:t,broken:!0,gridResolution:360,gridOffset:[-180,-180]});if(r)for(const c of a)Hp(c,t);return a}function HM(i,e=null,t){const{size:n=2,normalize:s=!0,edgeTypes:r=!1}=t||{};e=e||[];const o=[],a=[];let c=0,l=0;for(let f=0;f<=e.length;f++){const d=e[f]||i.length,g=l,p=YM(i,n,c,d);for(let m=p;m<d;m++)o[l++]=i[m];for(let m=c;m<p;m++)o[l++]=i[m];Wp(o,n,g,l),qM(o,n,g,l,t==null?void 0:t.maxLatitude),c=d,a[f]=l}a.pop();const u=jp(o,a,{size:n,gridResolution:360,gridOffset:[-180,-180],edgeTypes:r});if(s)for(const f of u)Hp(f.positions,n);return u}function YM(i,e,t,n){let s=-1,r=-1;for(let o=t+1;o<n;o+=e){const a=Math.abs(i[o]);a>s&&(s=a,r=o-1)}return r}function qM(i,e,t,n,s=VM){const r=i[t],o=i[n-e];if(Math.abs(r-o)>180){const a=Ln(i,0,e,t);a[0]+=Math.round((o-r)/360)*360,Ne(i,a),a[1]=Math.sign(a[1])*s,Ne(i,a),a[0]=r,Ne(i,a)}}function Wp(i,e,t,n){let s=i[0],r;for(let o=t;o<n;o+=e){r=i[o];const a=r-s;(a>180||a<-180)&&(r-=Math.round(a/360)*360),i[o]=s=r}}function Hp(i,e){let t;const n=i.length/e;for(let r=0;r<n&&(t=i[r*e],(t+180)%360===0);r++);const s=-Math.round(t/360)*360;if(s!==0)for(let r=0;r<n;r++)i[r*e]+=s}function ZM(i,e,t,n){let s;if(Array.isArray(i[0])){const r=i.length*e;s=new Array(r);for(let o=0;o<i.length;o++)for(let a=0;a<e;a++)s[o*e+a]=i[o][a]||0}else s=i;return t?Gp(s,{size:e,gridResolution:t}):n?WM(s,{size:e}):s}const XM=1,KM=2,ji=4;class QM extends Mp{constructor(e){super({...e,attributes:{positions:{size:3,padding:18,initialize:!0,type:e.fp64?Float64Array:Float32Array},segmentTypes:{size:1,type:e.isWebGPU?Float32Array:Uint8ClampedArray}}})}get(e){return this.attributes[e]}getPathSegmentIndices(e){const t=this.attributes.segmentTypes,n=this.vertexStarts[e],s=Math.min(this.vertexStarts[e+1]??this.instanceCount,this.instanceCount),r=[];for(let o=n;o<s-1;o++)(t[o]&ji)===0&&r.push(o);return r.length&&(t[n]&ji)!==0&&r.unshift(r.pop()),r}getGeometryFromBuffer(e){return this.normalize||this.opts.isWebGPU?super.getGeometryFromBuffer(e):null}normalizeGeometry(e){return this.normalize?ZM(e,this.positionSize,this.opts.resolution,this.opts.wrapLongitude):e}getGeometrySize(e){if(yd(e)){let n=0;for(const s of e)n+=this.getGeometrySize(s);return n}const t=this.getPathLength(e);return t<2?0:this.isClosed(e)?t<3?0:t+2:t}updateGeometryAttributes(e,t){if(t.geometrySize!==0)if(e&&yd(e))for(const n of e){const s=this.getGeometrySize(n);t.geometrySize=s,this.updateGeometryAttributes(n,t),t.vertexStart+=s}else this._updateSegmentTypes(e,t),this._updatePositions(e,t)}_updateSegmentTypes(e,t){const n=this.attributes.segmentTypes,s=e?this.isClosed(e):!1,{vertexStart:r,geometrySize:o}=t;n.fill(0,r,r+o),s?(n[r]=ji,n[r+o-2]=ji):(n[r]+=XM,n[r+o-2]+=KM),n[r+o-1]=ji}_updatePositions(e,t){const{positions:n}=this.attributes;if(!n||!e)return;const{vertexStart:s,geometrySize:r}=t,o=new Array(3);for(let a=s,c=0;c<r;a++,c++)this.getPointOnPath(e,c,o),n[a*3]=o[0],n[a*3+1]=o[1],n[a*3+2]=o[2]}getPathLength(e){return e.length/this.positionSize}getPointOnPath(e,t,n=[]){const{positionSize:s}=this;t*s>=e.length&&(t+=1-e.length/s);const r=t*s;return n[0]=e[r],n[1]=e[r+1],n[2]=s===3&&e[r+2]||0,n}isClosed(e){if(!this.normalize)return!!this.opts.loop;const{positionSize:t}=this,n=e.length-t;return e[0]===e[n]&&e[1]===e[n+1]&&(t===2||e[2]===e[n+2])}}function yd(i){return Array.isArray(i[0])}const JM=`struct PathUniforms {
  widthScale: f32,
  widthMinPixels: f32,
  widthMaxPixels: f32,
  jointType: f32,
  capType: f32,
  miterLimit: f32,
  billboard: f32,
  widthUnits: i32,
};

@group(0) @binding(auto)
var<uniform> path: PathUniforms;
`,bd=`layout(std140) uniform pathUniforms {
  float widthScale;
  float widthMinPixels;
  float widthMaxPixels;
  float jointType;
  float capType;
  float miterLimit;
  bool billboard;
  highp int widthUnits;
} path;
`,eI={name:"path",source:JM,vs:bd,fs:bd,uniformTypes:{widthScale:"f32",widthMinPixels:"f32",widthMaxPixels:"f32",jointType:"f32",capType:"f32",miterLimit:"f32",billboard:"f32",widthUnits:"i32"}},tI=`const EPSILON: f32 = 0.001;
const ZERO_OFFSET: vec3<f32> = vec3<f32>(0.0, 0.0, 0.0);

struct JoinResult {
  offset: vec3<f32>,
  cornerOffset: vec2<f32>,
  miterLength: f32,
  pathPosition: vec2<f32>,
  pathLength: f32,
  jointType: f32,
};

struct Attributes {
  @location(0) positions: vec2<f32>,
  @location(1) instanceTypes: f32,
  @location(2) instanceLeftPositions: vec3<f32>,
  @location(3) instanceStartPositions: vec3<f32>,
  @location(4) instanceEndPositions: vec3<f32>,
  @location(5) instanceRightPositions: vec3<f32>,
  @location(6) instanceLeftPositions64Low: vec3<f32>,
  @location(7) instanceStartPositions64Low: vec3<f32>,
  @location(8) instanceEndPositions64Low: vec3<f32>,
  @location(9) instanceRightPositions64Low: vec3<f32>,
  @location(10) instanceStrokeWidths: f32,
  @location(11) instanceColors: vec4<f32>,
  @location(12) rowIndexes: u32,
};

struct Varyings {
  @builtin(position) position: vec4<f32>,
  @location(0) vColor: vec4<f32>,
  @location(1) vCornerOffset: vec2<f32>,
  @location(2) vMiterLength: f32,
  @location(3) vPathPosition: vec2<f32>,
  @location(4) vPathLength: f32,
  @location(5) vJointType: f32,
  // Location 6 is reserved for TripsLayer's injected vTime varying.
  @location(7) clipCoordinates: vec2<f32>,
#ifdef DASH_ENABLED
  @location(8) vPathBounds: vec2<f32>,
#endif
};

fn flipIfTrue(flag: bool) -> f32 {
  return select(1.0, -1.0, flag);
}

fn clipLine(position: vec4<f32>, refPosition: vec4<f32>) -> vec4<f32> {
  if (position.w < EPSILON) {
    let r = (EPSILON - refPosition.w) / (position.w - refPosition.w);
    return refPosition + (position - refPosition) * r;
  }
  return position;
}

#ifdef DASH_ENABLED
// Return the visible interval of the original segment before clipLine moves either endpoint.
fn getClippedPathRange(startW: f32, endW: f32) -> vec2<f32> {
  let startClipped = startW < EPSILON;
  let endClipped = endW < EPSILON;
  if (startClipped && endClipped) {
    return vec2<f32>(0.0, 0.0);
  }
  if (startClipped || endClipped) {
    let intersection = clamp((EPSILON - startW) / (endW - startW), 0.0, 1.0);
    if (startClipped) {
      return vec2<f32>(intersection, 1.0);
    }
    return vec2<f32>(0.0, intersection);
  }
  return vec2<f32>(0.0, 1.0);
}
#endif

fn getLineJoinOffset(
  prevPoint: vec3<f32>,
  currPoint: vec3<f32>,
  nextPoint: vec3<f32>,
  width: vec2<f32>,
#ifdef DASH_ENABLED
  sourcePathLength: f32,
  sourcePathRange: vec2<f32>,
#endif
#ifdef ANTIALIASING
  coverageScale: f32,
#endif
  positions: vec2<f32>,
  instanceTypes: f32
) -> JoinResult {
  let isEnd = positions.x > 0.0;
  let sideOfPath = positions.y;
  let isJoint = select(0.0, 1.0, sideOfPath == 0.0);

  var deltaA3 = currPoint - prevPoint;
  var deltaB3 = nextPoint - currPoint;

  let rotationResult = project_needs_rotation(currPoint);
  if (path.billboard == 0.0 && rotationResult.needsRotation) {
    deltaA3 = rotationResult.transform * deltaA3;
    deltaB3 = rotationResult.transform * deltaB3;
  }

  let deltaA = deltaA3.xy / width;
  let deltaB = deltaB3.xy / width;

  let lenA = length(deltaA);
  let lenB = length(deltaB);

  let dirA = select(vec2<f32>(0.0, 0.0), normalize(deltaA), lenA > 0.0);
  let dirB = select(vec2<f32>(0.0, 0.0), normalize(deltaB), lenB > 0.0);

  let perpA = vec2<f32>(-dirA.y, dirA.x);
  let perpB = vec2<f32>(-dirB.y, dirB.x);

  var tangent = dirA + dirB;
  tangent = select(perpA, normalize(tangent), length(tangent) > 0.0);
  let miterVec = vec2<f32>(-tangent.y, tangent.x);
  let dir = select(dirB, dirA, isEnd);
  let perp = select(perpB, perpA, isEnd);
#ifdef DASH_ENABLED
  let segmentLength2D = select(lenB, lenA, isEnd);

  // Extrusion happens in the XY plane, so segmentLength2D is a 2D length and pathPosition.y
  // below measures 2D distance along the segment. For a path that also moves in Z the true
  // arc length is longer by this ratio. Scaling pathLength and pathPosition.y by it makes
  // the coordinate measure real 3D distance while leaving the joint tests unchanged, since
  // they compare the two against each other and both are scaled alike. Billboard mode
  // extrudes in clip space, where the perspective divide has already reduced the segment to
  // its screen projection, so its complete common-space length is supplied by the caller.
  // Mirrors path-layer-vertex.glsl.ts.
  let currDelta3 = select(deltaB3, deltaA3, isEnd);
  let currLength2D = length(currDelta3.xy);
  // Do not clamp a valid denominator to EPSILON: high-zoom Web Mercator deltas are often
  // smaller than that in common space, and changing their scale corrupts even flat paths.
  let safeLength2D = select(1.0, currLength2D, currLength2D > 0.0);
  var arcLengthRatio = 1.0;
  var pathPositionOffset = 0.0;
  var pathLength = segmentLength2D;
  if (path.billboard != 0.0) {
    // clipLine may shorten the visible screen-space segment. Preserve the corresponding interval
    // of the complete common-space arclength instead of compressing the full dash period into the
    // visible span. Keep pathLength complete so justification is stable as the camera clips it.
    let visiblePathLength = sourcePathLength * (sourcePathRange.y - sourcePathRange.x);
    arcLengthRatio = 0.0;
    if (segmentLength2D > 0.0) {
      arcLengthRatio = visiblePathLength / segmentLength2D;
    }
    pathPositionOffset = sourcePathLength * sourcePathRange.x;
    pathLength = sourcePathLength;
  } else if (currLength2D > 0.0) {
    arcLengthRatio = length(currDelta3) / safeLength2D;
    pathLength = segmentLength2D * arcLengthRatio;
  }
#else
  let pathLength = select(lenB, lenA, isEnd);
#endif

  let sinHalfA = abs(dot(miterVec, perp));
  let cosHalfA = abs(dot(dirA, miterVec));
  let turnDirection = flipIfTrue(dirA.x * dirB.y >= dirA.y * dirB.x);
  let cornerPosition = sideOfPath * turnDirection;

  var miterSize = 1.0 / max(sinHalfA, EPSILON);
  miterSize = mix(
    min(miterSize, max(lenA, lenB) / max(cosHalfA, EPSILON)),
    miterSize,
    step(0.0, cornerPosition)
  );

  var offsetVec =
    mix(miterVec * miterSize, perp, step(0.5, cornerPosition)) *
    (sideOfPath + isJoint * turnDirection);

  let isStartCap = lenA == 0.0 || (!isEnd && (instanceTypes == 1.0 || instanceTypes == 3.0));
  let isEndCap = lenB == 0.0 || (isEnd && (instanceTypes == 2.0 || instanceTypes == 3.0));
  let isCap = isStartCap || isEndCap;

  var jointType = path.jointType;
  if (isCap) {
    offsetVec = mix(
      perp * sideOfPath,
      dir * path.capType * 4.0 * flipIfTrue(isStartCap),
      isJoint
    );
    jointType = path.capType;
  }

#ifdef ANTIALIASING
  let coverageOffsetVec = offsetVec * coverageScale;
  var miterLength = dot(coverageOffsetVec, miterVec * turnDirection);
#else
  var miterLength = dot(offsetVec, miterVec * turnDirection);
#endif
  miterLength = select(miterLength, isJoint, isCap);

#ifdef ANTIALIASING
  let offsetFromStartOfPath = coverageOffsetVec + deltaA * select(0.0, 1.0, isEnd);
#else
  let offsetFromStartOfPath = offsetVec + deltaA * select(0.0, 1.0, isEnd);
#endif
  let pathPosition = vec2<f32>(
    dot(offsetFromStartOfPath, perp),
#ifdef DASH_ENABLED
    pathPositionOffset + dot(offsetFromStartOfPath, dir) * arcLengthRatio
#else
    dot(offsetFromStartOfPath, dir)
#endif
  );
  let isValid = step(f32(instanceTypes), 3.5);
#ifdef ANTIALIASING
  var offset = vec3<f32>(coverageOffsetVec * width * isValid, 0.0);
#else
  var offset = vec3<f32>(offsetVec * width * isValid, 0.0);
#endif

  if (path.billboard == 0.0 && rotationResult.needsRotation) {
    offset = rotationResult.transform * offset;
  }

#ifdef ANTIALIASING
  return JoinResult(
    offset, coverageOffsetVec, miterLength, pathPosition, pathLength, jointType
  );
#else
  return JoinResult(offset, offsetVec, miterLength, pathPosition, pathLength, jointType);
#endif
}

@vertex
fn vertexMain(attributes: Attributes) -> Varyings {
  var varyings: Varyings;

  geometry.pickingColor = picking_getPickingColorFromIndex(attributes.rowIndexes);

  let isEnd = attributes.positions.x;

  let prevPosition = mix(attributes.instanceLeftPositions, attributes.instanceStartPositions, isEnd);
  let prevPosition64Low = mix(
    attributes.instanceLeftPositions64Low,
    attributes.instanceStartPositions64Low,
    isEnd
  );
  let currPosition = mix(attributes.instanceStartPositions, attributes.instanceEndPositions, isEnd);
  let currPosition64Low = mix(
    attributes.instanceStartPositions64Low,
    attributes.instanceEndPositions64Low,
    isEnd
  );
  let nextPosition = mix(attributes.instanceEndPositions, attributes.instanceRightPositions, isEnd);
  let nextPosition64Low = mix(
    attributes.instanceEndPositions64Low,
    attributes.instanceRightPositions64Low,
    isEnd
  );

  geometry.worldPosition = currPosition;

  let widthPixels =
    clamp(
      project_unit_size_to_pixel(attributes.instanceStrokeWidths * path.widthScale, path.widthUnits),
      path.widthMinPixels,
      path.widthMaxPixels
    ) / 2.0;

  if (path.billboard != 0.0) {
#ifdef DASH_ENABLED
    let prevProjection = project_position_to_clipspace_and_commonspace(
      prevPosition, prevPosition64Low, ZERO_OFFSET
    );
    let nextProjection = project_position_to_clipspace_and_commonspace(
      nextPosition, nextPosition64Low, ZERO_OFFSET
    );
    let prevPositionCommon = prevProjection.commonPosition.xyz;
    let nextPositionCommon = nextProjection.commonPosition.xyz;
    var prevPositionScreen = prevProjection.clipPosition;
    var nextPositionScreen = nextProjection.clipPosition;
#else
    var prevPositionScreen = project_position_to_clipspace(
      prevPosition, prevPosition64Low, ZERO_OFFSET
    );
    var nextPositionScreen = project_position_to_clipspace(
      nextPosition, nextPosition64Low, ZERO_OFFSET
    );
#endif
    let currProjection = project_position_to_clipspace_and_commonspace(
      currPosition, currPosition64Low, ZERO_OFFSET
    );
    geometry.position = currProjection.commonPosition;
    var currPositionScreen = currProjection.clipPosition;
#ifdef DASH_ENABLED
    let currPositionCommon = currProjection.commonPosition.xyz;
    let sourcePathStartScreen = mix(currPositionScreen, prevPositionScreen, isEnd);
    let sourcePathEndScreen = mix(nextPositionScreen, currPositionScreen, isEnd);
    let billboardPathRange = getClippedPathRange(
      sourcePathStartScreen.w, sourcePathEndScreen.w
    );
#endif

    prevPositionScreen = clipLine(prevPositionScreen, currPositionScreen);
    nextPositionScreen = clipLine(nextPositionScreen, currPositionScreen);
    currPositionScreen = clipLine(currPositionScreen, mix(nextPositionScreen, prevPositionScreen, isEnd));

#ifdef ANTIALIASING
    let coverageScale = select(
      1.0,
      (widthPixels + 0.5 / project.devicePixelRatio) / max(widthPixels, 1e-6),
      widthPixels > 0.0
    );
#endif
#ifdef DASH_ENABLED
    let currentDeltaCommon = select(
      nextPositionCommon - currPositionCommon,
      currPositionCommon - prevPositionCommon,
      isEnd > 0.0
    );
    let billboardPathLength = select(
      0.0,
      length(currentDeltaCommon) * project.scale / (widthPixels * project.focalDistance),
      widthPixels > 0.0
    );
#endif
    let join = getLineJoinOffset(
      prevPositionScreen.xyz / prevPositionScreen.w,
      currPositionScreen.xyz / currPositionScreen.w,
      nextPositionScreen.xyz / nextPositionScreen.w,
      project_pixel_size_to_clipspace(vec2<f32>(widthPixels, widthPixels)),
#ifdef DASH_ENABLED
      billboardPathLength,
      billboardPathRange,
#endif
#ifdef ANTIALIASING
      coverageScale,
#endif
      attributes.positions,
      attributes.instanceTypes
    );
#ifdef DASH_ENABLED
    // Phase and justification use the complete source segment, while cap and joint coverage
    // must still recognize the endpoints moved by clipLine.
    varyings.vPathBounds = billboardPathLength * billboardPathRange;
#endif

    geometry.uv = join.pathPosition;
    varyings.position = vec4<f32>(
      currPositionScreen.xyz + join.offset * currPositionScreen.w,
      currPositionScreen.w
    );
    varyings.vCornerOffset = join.cornerOffset;
    varyings.vMiterLength = join.miterLength;
    varyings.vPathPosition = join.pathPosition;
    varyings.vPathLength = join.pathLength;
    varyings.vJointType = join.jointType;
  } else {
    let prevPositionCommon = project_position_vec3_f64(prevPosition, prevPosition64Low);
    let currPositionCommon = project_position_vec3_f64(currPosition, currPosition64Low);
    let nextPositionCommon = project_position_vec3_f64(nextPosition, nextPosition64Low);

    let width = vec2<f32>(
      project_pixel_size_float(widthPixels),
      project_pixel_size_float(widthPixels)
    );
#ifdef ANTIALIASING
    let coverageScale = select(
      1.0,
      (widthPixels + 0.5 / project.devicePixelRatio) / max(widthPixels, 1e-6),
      widthPixels > 0.0
    );
#endif
    let join = getLineJoinOffset(
      prevPositionCommon,
      currPositionCommon,
      nextPositionCommon,
      width,
#ifdef DASH_ENABLED
      1.0,
      vec2<f32>(0.0, 1.0),
#endif
#ifdef ANTIALIASING
      coverageScale,
#endif
      attributes.positions,
      attributes.instanceTypes
    );
#ifdef DASH_ENABLED
    varyings.vPathBounds = vec2<f32>(0.0, join.pathLength);
#endif

    geometry.position = vec4<f32>(currPositionCommon + join.offset, 1.0);
    geometry.uv = join.pathPosition;
    varyings.position = project_common_position_to_clipspace(geometry.position);
    varyings.vCornerOffset = join.cornerOffset;
    varyings.vMiterLength = join.miterLength;
    varyings.vPathPosition = join.pathPosition;
    varyings.vPathLength = join.pathLength;
    varyings.vJointType = join.jointType;
  }

  varyings.clipCoordinates = geometry.position.xy;
  clip_filterPosition(&varyings.position, geometry.worldPosition.xy);

  varyings.vColor = vec4<f32>(
    attributes.instanceColors.rgb,
    attributes.instanceColors.a * layer.opacity
  );
  return varyings;
}

@fragment
fn fragmentMain(varyings: Varyings) -> @location(0) vec4<f32> {
  geometry.uv = varyings.vPathPosition;

#ifdef ANTIALIASING
  // Coordinates of the outer silhouette, in units of half-width: rounded joints and caps are
  // bounded by the corner offset, everywhere else by the edge of the stroke. Dividing by the
  // screen-space derivative converts the distance to the boundary into device pixels, which stays
  // correct under perspective foreshortening and under extensions that rescale the stroke.
#ifdef DASH_ENABLED
  let isCorner =
    varyings.vPathPosition.y < varyings.vPathBounds.x ||
    varyings.vPathPosition.y > varyings.vPathBounds.y;
#else
  let isCorner = varyings.vPathPosition.y < 0.0 || varyings.vPathPosition.y > varyings.vPathLength;
#endif
  let isRound = varyings.vJointType > 0.5;

  // Distance to the silhouette in device pixels, from the derivative of the coordinate that
  // bounds it. Computed before the discards below: derivatives need uniform control flow and are
  // undefined after a discard in the quad. See dev-docs/RFCs/v9.4/analytic-antialiasing-rfc.md
  let bodyCoord = abs(varyings.vPathPosition.x);
  let cornerCoord = length(varyings.vCornerOffset);
  // Both evaluated so each derivative stays on one field across the corner/body boundary
  let bodyPixels = (1.0 - bodyCoord) / max(fwidth(bodyCoord), 1e-6);
  let cornerPixels = (1.0 - cornerCoord) / max(fwidth(cornerCoord), 1e-6);
#ifdef PATH_STYLE_OFFSET
  // Rounded corners still intersect the stroke-width envelope. Extensions may remap
  // vPathPosition.x independently of vCornerOffset, as PathStyleExtension does for offsets.
  let edgePixels = select(bodyPixels, min(cornerPixels, bodyPixels), isRound && isCorner);
#else
  let edgePixels = select(bodyPixels, cornerPixels, isRound && isCorner);
#endif

  // Fragments outside the coverage ramp must not write depth or picking colors.
  if (edgePixels <= -SMOOTH_EDGE_RADIUS) {
    discard;
  }

  if (isCorner) {
    if (!isRound && varyings.vMiterLength > path.miterLimit + 1.0) {
      discard;
    }
  }

  var color = varyings.vColor;

  // Feather one device pixel across the width only, before premultiplication. edgePixels is a
  // signed device-pixel distance and SMOOTH_EDGE_RADIUS is 0.5, so this ramps across one pixel.
  color.a *= smoothedge(0.0, edgePixels);
#else
#ifdef DASH_ENABLED
  if (
    varyings.vPathPosition.y < varyings.vPathBounds.x ||
    varyings.vPathPosition.y > varyings.vPathBounds.y
  ) {
#else
  if (
    varyings.vPathPosition.y < 0.0 ||
    varyings.vPathPosition.y > varyings.vPathLength
  ) {
#endif
    if (varyings.vJointType > 0.5 && length(varyings.vCornerOffset) > 1.0) {
      discard;
    }
    if (
      varyings.vJointType < 0.5 &&
      varyings.vMiterLength > path.miterLimit + 1.0
    ) {
      discard;
    }
  }
#endif

  // Fragment-layer injections that discard pixels must run after analytic coverage derivatives.
  // See TripsLayer, which rejects fragments outside of the active time window at this anchor.
  // DECKGL_FILTER_COLOR
  clip_filterColor(varyings.clipCoordinates);
#ifdef ANTIALIASING
  return deckgl_premultiplied_alpha(color);
#else
  return deckgl_premultiplied_alpha(varyings.vColor);
#endif
}
`,iI=`#version 300 es
#define SHADER_NAME path-layer-vertex-shader
in vec2 positions;
in float instanceTypes;
in vec3 instanceStartPositions;
in vec3 instanceEndPositions;
in vec3 instanceLeftPositions;
in vec3 instanceRightPositions;
in vec3 instanceLeftPositions64Low;
in vec3 instanceStartPositions64Low;
in vec3 instanceEndPositions64Low;
in vec3 instanceRightPositions64Low;
in float instanceStrokeWidths;
in vec4 instanceColors;
in float rowIndexes;
uniform float opacity;
out vec4 vColor;
out vec2 vCornerOffset;
out float vMiterLength;
out vec2 vPathPosition;
out float vPathLength;
out float vJointType;
#ifdef DASH_ENABLED
out vec2 vPathBounds;
#endif
const float EPSILON = 0.001;
const vec3 ZERO_OFFSET = vec3(0.0);
float flipIfTrue(bool flag) {
return -(float(flag) * 2. - 1.);
}
vec3 getLineJoinOffset(
vec3 prevPoint, vec3 currPoint, vec3 nextPoint,
vec2 width
#ifdef DASH_ENABLED
, float sourcePathLength, vec2 sourcePathRange
#endif
#ifdef ANTIALIASING
, float coverageScale
#endif
) {
bool isEnd = positions.x > 0.0;
float sideOfPath = positions.y;
float isJoint = float(sideOfPath == 0.0);
vec3 deltaA3 = (currPoint - prevPoint);
vec3 deltaB3 = (nextPoint - currPoint);
mat3 rotationMatrix;
bool needsRotation = !path.billboard && project_needs_rotation(currPoint, rotationMatrix);
if (needsRotation) {
deltaA3 = deltaA3 * rotationMatrix;
deltaB3 = deltaB3 * rotationMatrix;
}
vec2 deltaA = deltaA3.xy / width;
vec2 deltaB = deltaB3.xy / width;
float lenA = length(deltaA);
float lenB = length(deltaB);
vec2 dirA = lenA > 0. ? normalize(deltaA) : vec2(0.0, 0.0);
vec2 dirB = lenB > 0. ? normalize(deltaB) : vec2(0.0, 0.0);
vec2 perpA = vec2(-dirA.y, dirA.x);
vec2 perpB = vec2(-dirB.y, dirB.x);
vec2 tangent = dirA + dirB;
tangent = length(tangent) > 0. ? normalize(tangent) : perpA;
vec2 miterVec = vec2(-tangent.y, tangent.x);
vec2 dir = isEnd ? dirA : dirB;
vec2 perp = isEnd ? perpA : perpB;
float L = isEnd ? lenA : lenB;
#ifdef DASH_ENABLED
vec3 currDelta3 = isEnd ? deltaA3 : deltaB3;
float currLength2D = length(currDelta3.xy);
float arcLengthRatio = 1.0;
float pathPositionOffset = 0.0;
float pathLength = L;
if (path.billboard) {
float visiblePathLength = sourcePathLength * (sourcePathRange.y - sourcePathRange.x);
arcLengthRatio = L > 0.0 ? visiblePathLength / L : 0.0;
pathPositionOffset = sourcePathLength * sourcePathRange.x;
pathLength = sourcePathLength;
} else if (currLength2D > 0.0) {
arcLengthRatio = length(currDelta3) / currLength2D;
pathLength = L * arcLengthRatio;
}
#endif
float sinHalfA = abs(dot(miterVec, perp));
float cosHalfA = abs(dot(dirA, miterVec));
float turnDirection = flipIfTrue(dirA.x * dirB.y >= dirA.y * dirB.x);
float cornerPosition = sideOfPath * turnDirection;
float miterSize = 1.0 / max(sinHalfA, EPSILON);
miterSize = mix(
min(miterSize, max(lenA, lenB) / max(cosHalfA, EPSILON)),
miterSize,
step(0.0, cornerPosition)
);
vec2 offsetVec = mix(miterVec * miterSize, perp, step(0.5, cornerPosition))
* (sideOfPath + isJoint * turnDirection);
bool isStartCap = lenA == 0.0 || (!isEnd && (instanceTypes == 1.0 || instanceTypes == 3.0));
bool isEndCap = lenB == 0.0 || (isEnd && (instanceTypes == 2.0 || instanceTypes == 3.0));
bool isCap = isStartCap || isEndCap;
if (isCap) {
offsetVec = mix(perp * sideOfPath, dir * path.capType * 4.0 * flipIfTrue(isStartCap), isJoint);
vJointType = path.capType;
} else {
vJointType = path.jointType;
}
#ifdef ANTIALIASING
vec2 coverageOffsetVec = offsetVec * coverageScale;
#ifdef DASH_ENABLED
vPathLength = pathLength;
#else
vPathLength = L;
#endif
vCornerOffset = coverageOffsetVec;
vMiterLength = dot(vCornerOffset, miterVec * turnDirection);
vMiterLength = isCap ? isJoint : vMiterLength;
vec2 offsetFromStartOfPath = coverageOffsetVec + deltaA * float(isEnd);
vPathPosition = vec2(
dot(offsetFromStartOfPath, perp),
#ifdef DASH_ENABLED
pathPositionOffset + dot(offsetFromStartOfPath, dir) * arcLengthRatio
#else
dot(offsetFromStartOfPath, dir)
#endif
);
geometry.uv = vPathPosition;
float isValid = step(instanceTypes, 3.5);
vec3 offset = vec3(coverageOffsetVec * width * isValid, 0.0);
#else
#ifdef DASH_ENABLED
vPathLength = pathLength;
#else
vPathLength = L;
#endif
vCornerOffset = offsetVec;
vMiterLength = dot(vCornerOffset, miterVec * turnDirection);
vMiterLength = isCap ? isJoint : vMiterLength;
vec2 offsetFromStartOfPath = vCornerOffset + deltaA * float(isEnd);
vPathPosition = vec2(
dot(offsetFromStartOfPath, perp),
#ifdef DASH_ENABLED
pathPositionOffset + dot(offsetFromStartOfPath, dir) * arcLengthRatio
#else
dot(offsetFromStartOfPath, dir)
#endif
);
geometry.uv = vPathPosition;
float isValid = step(instanceTypes, 3.5);
vec3 offset = vec3(offsetVec * width * isValid, 0.0);
#endif
if (needsRotation) {
offset = rotationMatrix * offset;
}
return offset;
}
void clipLine(inout vec4 position, vec4 refPosition) {
if (position.w < EPSILON) {
float r = (EPSILON - refPosition.w) / (position.w - refPosition.w);
position = refPosition + (position - refPosition) * r;
}
}
#ifdef DASH_ENABLED
vec2 getClippedPathRange(float startW, float endW) {
bool startClipped = startW < EPSILON;
bool endClipped = endW < EPSILON;
if (startClipped && endClipped) {
return vec2(0.0);
}
if (startClipped || endClipped) {
float intersection = clamp((EPSILON - startW) / (endW - startW), 0.0, 1.0);
return startClipped ? vec2(intersection, 1.0) : vec2(0.0, intersection);
}
return vec2(0.0, 1.0);
}
#endif
void main() {
geometry.pickingColor = picking_getPickingColorFromIndex(rowIndexes);
vColor = vec4(instanceColors.rgb, instanceColors.a * layer.opacity);
float isEnd = positions.x;
vec3 prevPosition = mix(instanceLeftPositions, instanceStartPositions, isEnd);
vec3 prevPosition64Low = mix(instanceLeftPositions64Low, instanceStartPositions64Low, isEnd);
vec3 currPosition = mix(instanceStartPositions, instanceEndPositions, isEnd);
vec3 currPosition64Low = mix(instanceStartPositions64Low, instanceEndPositions64Low, isEnd);
vec3 nextPosition = mix(instanceEndPositions, instanceRightPositions, isEnd);
vec3 nextPosition64Low = mix(instanceEndPositions64Low, instanceRightPositions64Low, isEnd);
geometry.worldPosition = currPosition;
vec2 widthPixels = vec2(clamp(
project_size_to_pixel(instanceStrokeWidths * path.widthScale, path.widthUnits),
path.widthMinPixels, path.widthMaxPixels) / 2.0);
vec3 width;
if (path.billboard) {
#ifdef DASH_ENABLED
vec4 prevPositionCommon;
vec4 nextPositionCommon;
vec4 prevPositionScreen = project_position_to_clipspace(
prevPosition, prevPosition64Low, ZERO_OFFSET, prevPositionCommon
);
#else
vec4 prevPositionScreen = project_position_to_clipspace(
prevPosition, prevPosition64Low, ZERO_OFFSET
);
#endif
vec4 currPositionScreen = project_position_to_clipspace(currPosition, currPosition64Low, ZERO_OFFSET, geometry.position);
#ifdef DASH_ENABLED
vec4 nextPositionScreen = project_position_to_clipspace(
nextPosition, nextPosition64Low, ZERO_OFFSET, nextPositionCommon
);
#else
vec4 nextPositionScreen = project_position_to_clipspace(
nextPosition, nextPosition64Low, ZERO_OFFSET
);
#endif
#ifdef DASH_ENABLED
vec4 sourcePathStartScreen = mix(currPositionScreen, prevPositionScreen, isEnd);
vec4 sourcePathEndScreen = mix(nextPositionScreen, currPositionScreen, isEnd);
vec2 billboardPathRange = getClippedPathRange(
sourcePathStartScreen.w, sourcePathEndScreen.w
);
#endif
clipLine(prevPositionScreen, currPositionScreen);
clipLine(nextPositionScreen, currPositionScreen);
clipLine(currPositionScreen, mix(nextPositionScreen, prevPositionScreen, isEnd));
width = vec3(widthPixels, 0.0);
DECKGL_FILTER_SIZE(width, geometry);
#ifdef ANTIALIASING
vec2 coveragePadding = vec2(0.5 / project.devicePixelRatio);
float coverageScale = length(width.xy) > 0.0
? length(width.xy + coveragePadding) / length(width.xy)
: 1.0;
#endif
#ifdef DASH_ENABLED
vec3 currentDeltaCommon = isEnd > 0.0
? geometry.position.xyz - prevPositionCommon.xyz
: nextPositionCommon.xyz - geometry.position.xyz;
float billboardPathLength = width.x > 0.0
? length(currentDeltaCommon) * project.scale / (width.x * project.focalDistance)
: 0.0;
#endif
vec3 offset = getLineJoinOffset(
prevPositionScreen.xyz / prevPositionScreen.w,
currPositionScreen.xyz / currPositionScreen.w,
nextPositionScreen.xyz / nextPositionScreen.w,
project_pixel_size_to_clipspace(width.xy)
#ifdef DASH_ENABLED
,
billboardPathLength, billboardPathRange
#endif
#ifdef ANTIALIASING
,
coverageScale
#endif
);
#ifdef DASH_ENABLED
vPathBounds = billboardPathLength * billboardPathRange;
#endif
DECKGL_FILTER_GL_POSITION(currPositionScreen, geometry);
gl_Position = vec4(currPositionScreen.xyz + offset * currPositionScreen.w, currPositionScreen.w);
} else {
prevPosition = project_position(prevPosition, prevPosition64Low);
currPosition = project_position(currPosition, currPosition64Low);
nextPosition = project_position(nextPosition, nextPosition64Low);
width = vec3(project_pixel_size(widthPixels), 0.0);
DECKGL_FILTER_SIZE(width, geometry);
#ifdef ANTIALIASING
vec2 coveragePadding = project_pixel_size(vec2(0.5 / project.devicePixelRatio));
float coverageScale = length(width.xy) > 0.0
? length(width.xy + coveragePadding) / length(width.xy)
: 1.0;
#endif
vec3 offset = getLineJoinOffset(
prevPosition, currPosition, nextPosition, width.xy
#ifdef DASH_ENABLED
, 1.0, vec2(0.0, 1.0)
#endif
#ifdef ANTIALIASING
, coverageScale
#endif
);
#ifdef DASH_ENABLED
vPathBounds = vec2(0.0, vPathLength);
#endif
geometry.position = vec4(currPosition + offset, 1.0);
gl_Position = project_common_position_to_clipspace(geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
}
DECKGL_FILTER_COLOR(vColor, geometry);
}
`,nI=`#version 300 es
#define SHADER_NAME path-layer-fragment-shader
precision highp float;
in vec4 vColor;
in vec2 vCornerOffset;
in float vMiterLength;
in vec2 vPathPosition;
in float vPathLength;
in float vJointType;
#ifdef DASH_ENABLED
in vec2 vPathBounds;
#endif
out vec4 fragColor;
void main(void) {
geometry.uv = vPathPosition;
#ifdef ANTIALIASING
#ifdef DASH_ENABLED
bool isCorner = vPathPosition.y < vPathBounds.x || vPathPosition.y > vPathBounds.y;
#else
bool isCorner = vPathPosition.y < 0.0 || vPathPosition.y > vPathLength;
#endif
bool isRound = vJointType > 0.5;
float bodyCoord = abs(vPathPosition.x);
float cornerCoord = length(vCornerOffset);
float bodyPixels = (1.0 - bodyCoord) / max(fwidth(bodyCoord), 1e-6);
float cornerPixels = (1.0 - cornerCoord) / max(fwidth(cornerCoord), 1e-6);
#ifdef PATH_STYLE_OFFSET
float edgePixels = isRound && isCorner ? min(cornerPixels, bodyPixels) : bodyPixels;
#else
float edgePixels = isRound && isCorner ? cornerPixels : bodyPixels;
#endif
if (edgePixels <= -SMOOTH_EDGE_RADIUS) {
discard;
}
if (isCorner) {
if (!isRound && vMiterLength > path.miterLimit + 1.0) {
discard;
}
}
fragColor = vColor;
fragColor.a *= smoothedge(0.0, edgePixels);
#else
#ifdef DASH_ENABLED
if (vPathPosition.y < vPathBounds.x || vPathPosition.y > vPathBounds.y) {
#else
if (vPathPosition.y < 0.0 || vPathPosition.y > vPathLength) {
#endif
if (vJointType > 0.5 && length(vCornerOffset) > 1.0) {
discard;
}
if (vJointType < 0.5 && vMiterLength > path.miterLimit + 1.0) {
discard;
}
}
fragColor = vColor;
#endif
DECKGL_FILTER_COLOR(fragColor, geometry);
}
`,Yp=[0,0,0,255],sI={widthUnits:"meters",widthScale:{type:"number",min:0,value:1},widthMinPixels:{type:"number",min:0,value:0},widthMaxPixels:{type:"number",min:0,value:Number.MAX_SAFE_INTEGER},jointRounded:!1,capRounded:!1,miterLimit:{type:"number",min:0,value:4},antialiasing:!1,billboard:!1,_pathType:null,getPath:{type:"accessor",value:i=>i.path},getColor:{type:"accessor",value:Yp},getWidth:{type:"accessor",value:1},rounded:{deprecatedFor:["jointRounded","capRounded"]}},ta={enter:(i,e)=>e.length?e.subarray(e.length-i.length):i};function rI(i){if(i.isGeospatial)return null;const{unitsPerMeter:e}=i.distanceScales;return[e[0],e[1],e[2]]}function vd(i,e){return i===e||!!(i&&e&&i.length===e.length&&i.every((t,n)=>t===e[n]))}class $n extends xt{getShaders(){const{antialiasing:e}=this.props;return super.getShaders({vs:iI,fs:nI,source:tI,defines:e?{ANTIALIASING:1}:{},modules:[Dn,Bn,zn,eI,...this.context.device.type==="webgpu"?[bl]:[]]})}get wrapLongitude(){return!1}getBounds(){var e;return this.context.device.type==="webgpu"?null:(e=this.getAttributeManager())==null?void 0:e.getBounds(["vertexPositions"])}getPathProjectionScale(e){var o;const t=this.props.coordinateSystem;if(!!!((o=this.getAttributeManager())!=null&&o.getAttributes().instanceDashOffsets))return null;if(e instanceof ot&&e.zoom>=12&&(t==="default"||t==="lnglat"||t==="cartesian")){const a=jr.getUniforms({viewport:e,coordinateSystem:t,coordinateOrigin:this.props.coordinateOrigin,autoWrapLongitude:this.wrapLongitude});return[e.projectionMode,a.coordinateOrigin[1],a.commonOrigin[1],...a.commonUnitsPerWorldUnit,...a.commonUnitsPerWorldUnit2,a.commonUnitsPerMeter[2]]}const r=rI(e);return r?[e.projectionMode,...r]:[e.projectionMode]}shouldUpdateState(e){var n,s;const{viewport:t}=this.context;return super.shouldUpdateState(e)||((n=this.state)==null?void 0:n.tessellationResolution)!==t.resolution||!vd((s=this.state)==null?void 0:s.pathProjectionScale,this.getPathProjectionScale(t))}initializeState(){const t=this.context.device.type==="webgpu";this.getAttributeManager().addInstanced({...t?{pathPositions:{size:24,type:"float32",transition:!1,accessor:"getPath",update:this.calculateWebGPUPositions,shaderAttributes:{instanceLeftPositions:{size:3,elementOffset:0},instanceStartPositions:{size:3,elementOffset:3},instanceEndPositions:{size:3,elementOffset:6},instanceRightPositions:{size:3,elementOffset:9},instanceLeftPositions64Low:{size:3,elementOffset:12},instanceStartPositions64Low:{size:3,elementOffset:15},instanceEndPositions64Low:{size:3,elementOffset:18},instanceRightPositions64Low:{size:3,elementOffset:21}},noAlloc:!0}}:{vertexPositions:{size:3,vertexOffset:1,type:"float64",fp64:this.use64bitPositions(),transition:ta,accessor:"getPath",update:this.calculatePositions,noAlloc:!0,shaderAttributes:{instanceLeftPositions:{vertexOffset:0},instanceStartPositions:{vertexOffset:1},instanceEndPositions:{vertexOffset:2},instanceRightPositions:{vertexOffset:3}}}},instanceTypes:{size:1,type:t?"float32":"uint8",update:this.calculateSegmentTypes,noAlloc:!0},instanceStrokeWidths:{size:1,accessor:"getWidth",transition:t?!1:ta,defaultValue:1,bufferGroup:"path-instance-data"},instanceColors:{size:this.props.colorFormat.length,type:"unorm8",accessor:"getColor",transition:t?!1:ta,defaultValue:Yp,bufferGroup:"path-instance-data"},rowIndexes:{size:1,type:"uint32",accessor:(s,{index:r})=>s&&s.__source?s.__source.index:r,bufferGroup:"path-instance-data"}}),this.setState({pathTesselator:new QM({fp64:this.use64bitPositions(),isWebGPU:t}),tessellationResolution:this.context.viewport.resolution,pathProjectionScale:this.getPathProjectionScale(this.context.viewport)})}updateState(e){var g;super.updateState(e);const{props:t,oldProps:n,changeFlags:s}=e,r=this.getAttributeManager(),{viewport:o}=this.context,a=this.state.tessellationResolution!==o.resolution,c=this.getPathProjectionScale(o),l=!vd(this.state.pathProjectionScale,c),f=s.updateTriggersChanged&&(s.updateTriggersChanged.all||s.updateTriggersChanged.getPath)||t._pathType!==n._pathType||t.positionFormat!==n.positionFormat||t.wrapLongitude!==n.wrapLongitude||a;if(s.dataChanged||f){const{pathTesselator:p}=this.state,m=t.data.attributes||{};p.updateGeometry({data:t.data,geometryBuffer:m.getPath,buffers:m,normalize:!t._pathType,loop:t._pathType==="loop",getGeometry:t.getPath,positionFormat:t.positionFormat,wrapLongitude:t.wrapLongitude,resolution:o.resolution,dataChanged:f?void 0:s.dataChanged}),this.setState({numInstances:p.instanceCount,startIndices:p.vertexStarts,tessellationResolution:o.resolution,pathProjectionScale:c}),!s.dataChanged||f?r.invalidateAll():l&&r.invalidate("instanceDashOffsets")}else l&&(this.setState({pathProjectionScale:c}),r.invalidate("instanceDashOffsets"));(s.extensionsChanged||t.antialiasing!==n.antialiasing)&&((g=this.state.model)==null||g.destroy(),this.state.model=this._getModel(),r.invalidateAll())}getPickingInfo(e){const t=super.getPickingInfo(e),{index:n}=t,s=this.props.data;return s[0]&&s[0].__source&&(t.object=s.find(r=>r.__source.index===n)),t}disablePickingIndex(e){const t=this.props.data;if(t[0]&&t[0].__source)for(let n=0;n<t.length;n++)t[n].__source.index===e&&this._disablePickingIndex(n);else super.disablePickingIndex(e)}draw({uniforms:e}){const{jointRounded:t,capRounded:n,billboard:s,miterLimit:r,widthUnits:o,widthScale:a,widthMinPixels:c,widthMaxPixels:l}=this.props,u=this.state.model,f={jointType:Number(t),capType:Number(n),billboard:s,widthUnits:at[o],widthScale:a,miterLimit:r,widthMinPixels:c,widthMaxPixels:l};u.shaderInputs.setProps({path:f}),u.draw(this.context.renderPass)}_getModel(){const e=[0,1,2,1,4,2,1,3,4,3,5,4],t=[0,0,0,-1,0,1,1,-1,1,1,1,0];return new Ue(this.context.device,{...this.getShaders(),id:this.props.id,bufferLayout:this.getAttributeManager().getBufferLayouts(),geometry:new Ut({topology:"triangle-list",attributes:{indices:new Uint16Array(e),positions:{value:new Float32Array(t),size:2}}}),isInstanced:!0})}calculatePositions(e){const{pathTesselator:t}=this.state;e.startIndices=t.vertexStarts,e.value=t.get("positions")}calculateSegmentTypes(e){const{pathTesselator:t}=this.state;e.startIndices=t.vertexStarts,e.value=t.get("segmentTypes")}calculateWebGPUPositions(e){const{pathTesselator:t}=this.state,n=t.get("positions");if(!n){e.value=null;return}const s=t.instanceCount,r=new Float32Array(s*24),o=[-1,0,1,2];for(let a=0;a<s;a++){const c=a*24;for(let l=0;l<4;l++){const u=a+o[l],f=c+l*3;for(let d=0;d<3;d++){const g=u>=0&&u<s?n[u*3+d]:0,p=Math.fround(g);r[f+d]=p,r[f+d+12]=g-p}}}e.startIndices=t.vertexStarts,e.value=r}}$n.defaultProps=sI;$n.layerName="PathLayer";var hs={exports:{}},wd;function oI(){if(wd)return hs.exports;wd=1,hs.exports=i,hs.exports.default=i;function i(b,P,E){E=E||2;var A=P&&P.length,T=A?P[0]*E:b.length,I=e(b,0,T,E,!0),R=[];if(!I||I.next===I.prev)return R;var U,V,j,oe,ie,Z,me;if(A&&(I=c(b,P,I,E)),b.length>80*E){U=j=b[0],V=oe=b[1];for(var ne=E;ne<T;ne+=E)ie=b[ne],Z=b[ne+1],ie<U&&(U=ie),Z<V&&(V=Z),ie>j&&(j=ie),Z>oe&&(oe=Z);me=Math.max(j-U,oe-V),me=me!==0?32767/me:0}return n(I,R,E,U,V,me,0),R}function e(b,P,E,A,T){var I,R;if(T===G(b,P,E,A)>0)for(I=P;I<E;I+=A)R=F(I,b[I],b[I+1],R);else for(I=E-A;I>=P;I-=A)R=F(I,b[I],b[I+1],R);return R&&x(R,R.next)&&(z(R),R=R.next),R}function t(b,P){if(!b)return b;P||(P=b);var E=b,A;do if(A=!1,!E.steiner&&(x(E,E.next)||y(E.prev,E,E.next)===0)){if(z(E),E=P=E.prev,E===E.next)break;A=!0}else E=E.next;while(A||E!==P);return P}function n(b,P,E,A,T,I,R){if(b){!R&&I&&g(b,A,T,I);for(var U=b,V,j;b.prev!==b.next;){if(V=b.prev,j=b.next,I?r(b,A,T,I):s(b)){P.push(V.i/E|0),P.push(b.i/E|0),P.push(j.i/E|0),z(b),b=j.next,U=j.next;continue}if(b=j,b===U){R?R===1?(b=o(t(b),P,E),n(b,P,E,A,T,I,2)):R===2&&a(b,P,E,A,T,I):n(t(b),P,E,A,T,I,1);break}}}}function s(b){var P=b.prev,E=b,A=b.next;if(y(P,E,A)>=0)return!1;for(var T=P.x,I=E.x,R=A.x,U=P.y,V=E.y,j=A.y,oe=T<I?T<R?T:R:I<R?I:R,ie=U<V?U<j?U:j:V<j?V:j,Z=T>I?T>R?T:R:I>R?I:R,me=U>V?U>j?U:j:V>j?V:j,ne=A.next;ne!==P;){if(ne.x>=oe&&ne.x<=Z&&ne.y>=ie&&ne.y<=me&&v(T,U,I,V,R,j,ne.x,ne.y)&&y(ne.prev,ne,ne.next)>=0)return!1;ne=ne.next}return!0}function r(b,P,E,A){var T=b.prev,I=b,R=b.next;if(y(T,I,R)>=0)return!1;for(var U=T.x,V=I.x,j=R.x,oe=T.y,ie=I.y,Z=R.y,me=U<V?U<j?U:j:V<j?V:j,ne=oe<ie?oe<Z?oe:Z:ie<Z?ie:Z,Ri=U>V?U>j?U:j:V>j?V:j,Oi=oe>ie?oe>Z?oe:Z:ie>Z?ie:Z,Pl=m(me,ne,P,E,A),Sl=m(Ri,Oi,P,E,A),X=b.prevZ,K=b.nextZ;X&&X.z>=Pl&&K&&K.z<=Sl;){if(X.x>=me&&X.x<=Ri&&X.y>=ne&&X.y<=Oi&&X!==T&&X!==R&&v(U,oe,V,ie,j,Z,X.x,X.y)&&y(X.prev,X,X.next)>=0||(X=X.prevZ,K.x>=me&&K.x<=Ri&&K.y>=ne&&K.y<=Oi&&K!==T&&K!==R&&v(U,oe,V,ie,j,Z,K.x,K.y)&&y(K.prev,K,K.next)>=0))return!1;K=K.nextZ}for(;X&&X.z>=Pl;){if(X.x>=me&&X.x<=Ri&&X.y>=ne&&X.y<=Oi&&X!==T&&X!==R&&v(U,oe,V,ie,j,Z,X.x,X.y)&&y(X.prev,X,X.next)>=0)return!1;X=X.prevZ}for(;K&&K.z<=Sl;){if(K.x>=me&&K.x<=Ri&&K.y>=ne&&K.y<=Oi&&K!==T&&K!==R&&v(U,oe,V,ie,j,Z,K.x,K.y)&&y(K.prev,K,K.next)>=0)return!1;K=K.nextZ}return!0}function o(b,P,E){var A=b;do{var T=A.prev,I=A.next.next;!x(T,I)&&S(T,A,A.next,I)&&D(T,I)&&D(I,T)&&(P.push(T.i/E|0),P.push(A.i/E|0),P.push(I.i/E|0),z(A),z(A.next),A=b=I),A=A.next}while(A!==b);return t(A)}function a(b,P,E,A,T,I){var R=b;do{for(var U=R.next.next;U!==R.prev;){if(R.i!==U.i&&w(R,U)){var V=N(R,U);R=t(R,R.next),V=t(V,V.next),n(R,P,E,A,T,I,0),n(V,P,E,A,T,I,0);return}U=U.next}R=R.next}while(R!==b)}function c(b,P,E,A){var T=[],I,R,U,V,j;for(I=0,R=P.length;I<R;I++)U=P[I]*A,V=I<R-1?P[I+1]*A:b.length,j=e(b,U,V,A,!1),j===j.next&&(j.steiner=!0),T.push(_(j));for(T.sort(l),I=0;I<T.length;I++)E=u(T[I],E);return E}function l(b,P){return b.x-P.x}function u(b,P){var E=f(b,P);if(!E)return P;var A=N(E,b);return t(A,A.next),t(E,E.next)}function f(b,P){var E=P,A=b.x,T=b.y,I=-1/0,R;do{if(T<=E.y&&T>=E.next.y&&E.next.y!==E.y){var U=E.x+(T-E.y)*(E.next.x-E.x)/(E.next.y-E.y);if(U<=A&&U>I&&(I=U,R=E.x<E.next.x?E:E.next,U===A))return R}E=E.next}while(E!==P);if(!R)return null;var V=R,j=R.x,oe=R.y,ie=1/0,Z;E=R;do A>=E.x&&E.x>=j&&A!==E.x&&v(T<oe?A:I,T,j,oe,T<oe?I:A,T,E.x,E.y)&&(Z=Math.abs(T-E.y)/(A-E.x),D(E,b)&&(Z<ie||Z===ie&&(E.x>R.x||E.x===R.x&&d(R,E)))&&(R=E,ie=Z)),E=E.next;while(E!==V);return R}function d(b,P){return y(b.prev,b,P.prev)<0&&y(P.next,b,b.next)<0}function g(b,P,E,A){var T=b;do T.z===0&&(T.z=m(T.x,T.y,P,E,A)),T.prevZ=T.prev,T.nextZ=T.next,T=T.next;while(T!==b);T.prevZ.nextZ=null,T.prevZ=null,p(T)}function p(b){var P,E,A,T,I,R,U,V,j=1;do{for(E=b,b=null,I=null,R=0;E;){for(R++,A=E,U=0,P=0;P<j&&(U++,A=A.nextZ,!!A);P++);for(V=j;U>0||V>0&&A;)U!==0&&(V===0||!A||E.z<=A.z)?(T=E,E=E.nextZ,U--):(T=A,A=A.nextZ,V--),I?I.nextZ=T:b=T,T.prevZ=I,I=T;E=A}I.nextZ=null,j*=2}while(R>1);return b}function m(b,P,E,A,T){return b=(b-E)*T|0,P=(P-A)*T|0,b=(b|b<<8)&16711935,b=(b|b<<4)&252645135,b=(b|b<<2)&858993459,b=(b|b<<1)&1431655765,P=(P|P<<8)&16711935,P=(P|P<<4)&252645135,P=(P|P<<2)&858993459,P=(P|P<<1)&1431655765,b|P<<1}function _(b){var P=b,E=b;do(P.x<E.x||P.x===E.x&&P.y<E.y)&&(E=P),P=P.next;while(P!==b);return E}function v(b,P,E,A,T,I,R,U){return(T-R)*(P-U)>=(b-R)*(I-U)&&(b-R)*(A-U)>=(E-R)*(P-U)&&(E-R)*(I-U)>=(T-R)*(A-U)}function w(b,P){return b.next.i!==P.i&&b.prev.i!==P.i&&!B(b,P)&&(D(b,P)&&D(P,b)&&k(b,P)&&(y(b.prev,b,P.prev)||y(b,P.prev,P))||x(b,P)&&y(b.prev,b,b.next)>0&&y(P.prev,P,P.next)>0)}function y(b,P,E){return(P.y-b.y)*(E.x-P.x)-(P.x-b.x)*(E.y-P.y)}function x(b,P){return b.x===P.x&&b.y===P.y}function S(b,P,E,A){var T=O(y(b,P,E)),I=O(y(b,P,A)),R=O(y(E,A,b)),U=O(y(E,A,P));return!!(T!==I&&R!==U||T===0&&C(b,E,P)||I===0&&C(b,A,P)||R===0&&C(E,b,A)||U===0&&C(E,P,A))}function C(b,P,E){return P.x<=Math.max(b.x,E.x)&&P.x>=Math.min(b.x,E.x)&&P.y<=Math.max(b.y,E.y)&&P.y>=Math.min(b.y,E.y)}function O(b){return b>0?1:b<0?-1:0}function B(b,P){var E=b;do{if(E.i!==b.i&&E.next.i!==b.i&&E.i!==P.i&&E.next.i!==P.i&&S(E,E.next,b,P))return!0;E=E.next}while(E!==b);return!1}function D(b,P){return y(b.prev,b,b.next)<0?y(b,P,b.next)>=0&&y(b,b.prev,P)>=0:y(b,P,b.prev)<0||y(b,b.next,P)<0}function k(b,P){var E=b,A=!1,T=(b.x+P.x)/2,I=(b.y+P.y)/2;do E.y>I!=E.next.y>I&&E.next.y!==E.y&&T<(E.next.x-E.x)*(I-E.y)/(E.next.y-E.y)+E.x&&(A=!A),E=E.next;while(E!==b);return A}function N(b,P){var E=new L(b.i,b.x,b.y),A=new L(P.i,P.x,P.y),T=b.next,I=P.prev;return b.next=P,P.prev=b,E.next=T,T.prev=E,A.next=E,E.prev=A,I.next=A,A.prev=I,A}function F(b,P,E,A){var T=new L(b,P,E);return A?(T.next=A.next,T.prev=A,A.next.prev=T,A.next=T):(T.prev=T,T.next=T),T}function z(b){b.next.prev=b.prev,b.prev.next=b.next,b.prevZ&&(b.prevZ.nextZ=b.nextZ),b.nextZ&&(b.nextZ.prevZ=b.prevZ)}function L(b,P,E){this.i=b,this.x=P,this.y=E,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}i.deviation=function(b,P,E,A){var T=P&&P.length,I=T?P[0]*E:b.length,R=Math.abs(G(b,0,I,E));if(T)for(var U=0,V=P.length;U<V;U++){var j=P[U]*E,oe=U<V-1?P[U+1]*E:b.length;R-=Math.abs(G(b,j,oe,E))}var ie=0;for(U=0;U<A.length;U+=3){var Z=A[U]*E,me=A[U+1]*E,ne=A[U+2]*E;ie+=Math.abs((b[Z]-b[ne])*(b[me+1]-b[Z+1])-(b[Z]-b[me])*(b[ne+1]-b[Z+1]))}return R===0&&ie===0?0:Math.abs((ie-R)/R)};function G(b,P,E,A){for(var T=0,I=P,R=E-A;I<E;I+=A)T+=(b[R]-b[I])*(b[I+1]+b[R+1]),R=I;return T}return i.flatten=function(b){for(var P=b[0][0].length,E={vertices:[],holes:[],dimensions:P},A=0,T=0;T<b.length;T++){for(var I=0;I<b[T].length;I++)for(var R=0;R<P;R++)E.vertices.push(b[T][I][R]);T>0&&(A+=b[T-1].length,E.holes.push(A))}return E},hs.exports}var aI=oI();const cI=cm(aI),gs=Up.CLOCKWISE,xd=Up.COUNTER_CLOCKWISE,mt={};function lI(i){if(i=i&&i.positions||i,!Array.isArray(i)&&!ArrayBuffer.isView(i))throw new Error("invalid polygon")}function Xi(i){return"positions"in i?i.positions:i}function Ms(i){return"holeIndices"in i?i.holeIndices:null}function uI(i){return Array.isArray(i[0])}function fI(i){return i.length>=1&&i[0].length>=2&&Number.isFinite(i[0][0])}function dI(i){const e=i[0],t=i[i.length-1];return e[0]===t[0]&&e[1]===t[1]&&e[2]===t[2]}function hI(i,e,t,n){for(let s=0;s<e;s++)if(i[t+s]!==i[n-e+s])return!1;return!0}function Pd(i,e,t,n,s){let r=e;const o=t.length;for(let a=0;a<o;a++)for(let c=0;c<n;c++)i[r++]=t[a][c]||0;if(!dI(t))for(let a=0;a<n;a++)i[r++]=t[0][a]||0;return mt.start=e,mt.end=r,mt.size=n,$p(i,s,mt),r}function Sd(i,e,t,n,s=0,r,o){r=r||t.length;const a=r-s;if(a<=0)return e;let c=e;for(let l=0;l<a;l++)i[c++]=t[s+l];if(!hI(t,n,s,r))for(let l=0;l<n;l++)i[c++]=t[s+l];return mt.start=e,mt.end=c,mt.size=n,$p(i,o,mt),c}function qp(i,e){lI(i);const t=[],n=[];if("positions"in i){const{positions:s,holeIndices:r}=i;if(r){let o=0;for(let a=0;a<=r.length;a++)o=Sd(t,o,s,e,r[a-1],r[a],a===0?gs:xd),n.push(o);return n.pop(),{positions:t,holeIndices:n}}i=s}if(!uI(i))return Sd(t,0,i,e,0,t.length,gs),t;if(!fI(i)){let s=0;for(const[r,o]of i.entries())s=Pd(t,s,o,e,r===0?gs:xd),n.push(s);return n.pop(),{positions:t,holeIndices:n}}return Pd(t,0,i,e,gs),t}function ia(i,e,t){const n=i.length/3;let s=0;for(let r=0;r<n;r++){const o=(r+1)%n;s+=i[r*3+e]*i[o*3+t],s-=i[o*3+e]*i[r*3+t]}return Math.abs(s/2)}function Ed(i,e,t,n){const s=i.length/3;for(let r=0;r<s;r++){const o=r*3,a=i[o+0],c=i[o+1],l=i[o+2];i[o+e]=a,i[o+t]=c,i[o+n]=l}}function gI(i,e,t,n){let s=Ms(i);s&&(s=s.map(a=>a/e));let r=Xi(i);const o=n&&e===3;if(t){const a=r.length;r=r.slice();const c=[];for(let l=0;l<a;l+=e){c[0]=r[l],c[1]=r[l+1],o&&(c[2]=r[l+2]);const u=t(c);r[l]=u[0],r[l+1]=u[1],o&&(r[l+2]=u[2])}}if(o){const a=ia(r,0,1),c=ia(r,0,2),l=ia(r,1,2);if(!a&&!c&&!l)return[];a>c&&a>l||(c>l?(t||(r=r.slice()),Ed(r,0,2,1)):(t||(r=r.slice()),Ed(r,2,0,1)))}return cI(r,s,e)}class pI extends Mp{constructor(e){const{fp64:t,IndexType:n=Uint32Array}=e;super({...e,attributes:{positions:{size:3,type:t?Float64Array:Float32Array},vertexValid:{type:Uint16Array,size:1},indices:{type:n,size:1}}})}get(e){const{attributes:t}=this;return e==="indices"?t.indices&&t.indices.subarray(0,this.vertexCount):t[e]}updateGeometry(e){super.updateGeometry(e);const t=this.buffers.indices;if(t)this.vertexCount=(t.value||t).length;else if(this.data&&!this.getGeometry)throw new Error("missing indices buffer")}normalizeGeometry(e){if(this.normalize){const t=qp(e,this.positionSize);return this.opts.resolution?jp(Xi(t),Ms(t),{size:this.positionSize,gridResolution:this.opts.resolution,edgeTypes:!0}):this.opts.wrapLongitude?HM(Xi(t),Ms(t),{size:this.positionSize,maxLatitude:86,edgeTypes:!0}):t}return e}getGeometrySize(e){if(Cd(e)){let t=0;for(const n of e)t+=this.getGeometrySize(n);return t}return Xi(e).length/this.positionSize}getGeometryFromBuffer(e){return this.normalize||!this.buffers.indices?super.getGeometryFromBuffer(e):null}updateGeometryAttributes(e,t){if(e&&Cd(e))for(const n of e){const s=this.getGeometrySize(n);t.geometrySize=s,this.updateGeometryAttributes(n,t),t.vertexStart+=s,t.indexStart=this.indexStarts[t.geometryIndex+1]}else{const n=e;this._updateIndices(n,t),this._updatePositions(n,t),this._updateVertexValid(n,t)}}_updateIndices(e,{geometryIndex:t,vertexStart:n,indexStart:s}){const{attributes:r,indexStarts:o,typedArrayManager:a}=this;let c=r.indices;if(!c||!e)return;let l=s;const u=gI(e,this.positionSize,this.opts.preproject,this.opts.full3d);c=a.allocate(c,s+u.length,{copy:!0});for(let f=0;f<u.length;f++)c[l++]=u[f]+n;o[t+1]=s+u.length,r.indices=c}_updatePositions(e,{vertexStart:t,geometrySize:n}){const{attributes:{positions:s},positionSize:r}=this;if(!s||!e)return;const o=Xi(e);for(let a=t,c=0;c<n;a++,c++){const l=o[c*r],u=o[c*r+1],f=r>2?o[c*r+2]:0;s[a*3]=l,s[a*3+1]=u,s[a*3+2]=f}}_updateVertexValid(e,{vertexStart:t,geometrySize:n}){const{positionSize:s}=this,r=this.attributes.vertexValid,o=e&&Ms(e);if(e&&e.edgeTypes?r.set(e.edgeTypes,t):r.fill(1,t,t+n),o)for(let a=0;a<o.length;a++)r[t+o[a]/s-1]=0;r[t+n-1]=0}}function Cd(i){return Array.isArray(i)&&i.length>0&&!Number.isFinite(i[0])}const mI=`struct SolidPolygonUniforms {
  extruded: f32,
  isWireframe: f32,
  elevationScale: f32,
};

@group(0) @binding(auto) var<uniform> solidPolygon: SolidPolygonUniforms;
`,Ld=`layout(std140) uniform solidPolygonUniforms {
  bool extruded;
  bool isWireframe;
  float elevationScale;
} solidPolygon;
`,_I={name:"solidPolygon",source:mI,vs:Ld,fs:Ld,uniformTypes:{extruded:"f32",isWireframe:"f32",elevationScale:"f32"}},Zp=`in vec4 fillColors;
in vec4 lineColors;
in float rowIndexes;
out vec4 vColor;
struct PolygonProps {
vec3 positions;
vec3 positions64Low;
vec3 normal;
float elevations;
};
vec3 project_offset_normal(vec3 vector) {
if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT ||
project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT_OFFSETS) {
return normalize(vector * project.commonUnitsPerWorldUnit);
}
return project_normal(vector);
}
void calculatePosition(PolygonProps props) {
vec3 pos = props.positions;
vec3 pos64Low = props.positions64Low;
vec3 normal = props.normal;
vec4 colors = solidPolygon.isWireframe ? lineColors : fillColors;
geometry.worldPosition = props.positions;
geometry.pickingColor = picking_getPickingColorFromIndex(rowIndexes);
if (solidPolygon.extruded) {
pos.z += props.elevations * solidPolygon.elevationScale;
}
gl_Position = project_position_to_clipspace(pos, pos64Low, vec3(0.), geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
if (solidPolygon.extruded) {
#ifdef IS_SIDE_VERTEX
normal = project_offset_normal(normal);
#else
normal = project_normal(normal);
#endif
geometry.normal = normal;
vec3 lightColor = lighting_getLightColor(colors.rgb, project.cameraPosition, geometry.position.xyz, geometry.normal);
vColor = vec4(lightColor, colors.a * layer.opacity);
} else {
vColor = vec4(colors.rgb, colors.a * layer.opacity);
}
DECKGL_FILTER_COLOR(vColor, geometry);
}
`,yI=`#version 300 es
#define SHADER_NAME solid-polygon-layer-vertex-shader
in vec3 vertexPositions;
in vec3 vertexPositions64Low;
in float elevations;
${Zp}
void main(void) {
PolygonProps props;
props.positions = vertexPositions;
props.positions64Low = vertexPositions64Low;
props.elevations = elevations;
props.normal = vec3(0.0, 0.0, 1.0);
calculatePosition(props);
}
`,bI=`#version 300 es
#define SHADER_NAME solid-polygon-layer-vertex-shader-side
#define IS_SIDE_VERTEX
in vec2 positions;
in vec3 vertexPositions;
in vec3 nextVertexPositions;
in vec3 vertexPositions64Low;
in vec3 nextVertexPositions64Low;
in float elevations;
in float instanceVertexValid;
${Zp}
void main(void) {
if(instanceVertexValid < 0.5){
gl_Position = vec4(0.);
return;
}
PolygonProps props;
vec3 pos;
vec3 pos64Low;
vec3 nextPos;
vec3 nextPos64Low;
#if RING_WINDING_ORDER_CW == 1
pos = vertexPositions;
pos64Low = vertexPositions64Low;
nextPos = nextVertexPositions;
nextPos64Low = nextVertexPositions64Low;
#else
pos = nextVertexPositions;
pos64Low = nextVertexPositions64Low;
nextPos = vertexPositions;
nextPos64Low = vertexPositions64Low;
#endif
props.positions = mix(pos, nextPos, positions.x);
props.positions64Low = mix(pos64Low, nextPos64Low, positions.x);
props.normal = vec3(
pos.y - nextPos.y + (pos64Low.y - nextPos64Low.y),
nextPos.x - pos.x + (nextPos64Low.x - pos64Low.x),
0.0);
props.elevations = elevations * positions.y;
calculatePosition(props);
}
`,vI=`#version 300 es
#define SHADER_NAME solid-polygon-layer-fragment-shader
precision highp float;
in vec4 vColor;
out vec4 fragColor;
void main(void) {
fragColor = vColor;
geometry.uv = vec2(0.);
DECKGL_FILTER_COLOR(fragColor, geometry);
}
`;function Xp(){return`fn project_offset_normal(vector: vec3<f32>) -> vec3<f32> {
  if (project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT ||
      project.coordinateSystem == COORDINATE_SYSTEM_LNGLAT_OFFSETS) {
    return normalize(vector * project.commonUnitsPerWorldUnit);
  }
  return project_normal(vector);
}

fn apply_polygon_color(
  colors: vec4<f32>,
  normal: vec3<f32>,
  position: vec4<f32>
) -> vec4<f32> {
  if (solidPolygon.extruded > 0.5) {
    let lightColor = lighting_getLightColor2(
      colors.rgb,
      project.cameraPosition,
      position.xyz,
      normal
    );
    return vec4<f32>(lightColor, colors.a * layer.opacity);
  }
  return vec4<f32>(colors.rgb, colors.a * layer.opacity);
}
`}function Kp(){return`@fragment
fn fragmentMain(inp: Varyings) -> @location(0) vec4<f32> {
  geometry.uv = vec2<f32>(0.0, 0.0);

  clip_filterColor(inp.clipCoordinates);

  if (picking.isActive > 0.5) {
    if (!picking_isColorValid(inp.pickingColor)) {
      discard;
    }
    return vec4<f32>(inp.pickingColor, 1.0);
  }

  var fragColor = inp.vColor;

  if (picking.isHighlightActive > 0.5) {
    let highlightedObjectColor = picking_normalizeColor(picking.highlightedObjectColor);
    if (picking_isColorZero(abs(inp.pickingColor - highlightedObjectColor))) {
      let highLightAlpha = picking.highlightColor.a;
      let blendedAlpha = highLightAlpha + fragColor.a * (1.0 - highLightAlpha);
      if (blendedAlpha > 0.0) {
        let highLightRatio = highLightAlpha / blendedAlpha;
        fragColor = vec4<f32>(
          mix(fragColor.rgb, picking.highlightColor.rgb, highLightRatio),
          blendedAlpha
        );
      } else {
        fragColor = vec4<f32>(fragColor.rgb, 0.0);
      }
    }
  }

  return deckgl_premultiplied_alpha(fragColor);
}
`}function wI(){return`${Xp()}

struct Attributes {
  @location(0) vertexPositions: vec3<f32>,
  @location(1) vertexPositions64Low: vec3<f32>,
  @location(2) elevations: f32,
  @location(3) fillColors: vec4<f32>,
  @location(4) lineColors: vec4<f32>,
  @location(5) rowIndexes: u32,
};

struct Varyings {
  @builtin(position) position: vec4<f32>,
  @location(0) vColor: vec4<f32>,
  @location(1) pickingColor: vec3<f32>,
  @location(2) clipCoordinates: vec2<f32>,
};

@vertex
fn vertexMain(attributes: Attributes) -> Varyings {
  var outp: Varyings;

  var pos = attributes.vertexPositions;
  if (solidPolygon.extruded > 0.5) {
    pos.z += attributes.elevations * solidPolygon.elevationScale;
  }

  geometry.worldPosition = attributes.vertexPositions;
  geometry.pickingColor = picking_getPickingColorFromIndex(attributes.rowIndexes);

  let projectedPosition = project_position_to_clipspace_and_commonspace(
    pos,
    attributes.vertexPositions64Low,
    vec3<f32>(0.0)
  );
  geometry.position = projectedPosition.commonPosition;
  outp.position = projectedPosition.clipPosition;

  let normal = project_normal(vec3<f32>(0.0, 0.0, 1.0));
  geometry.normal = normal;

  let colors = select(
    attributes.fillColors,
    attributes.lineColors,
    solidPolygon.isWireframe > 0.5
  );
  outp.vColor = apply_polygon_color(colors, normal, geometry.position);
  outp.pickingColor = geometry.pickingColor;

  outp.clipCoordinates = geometry.position.xy;
  clip_filterPosition(&outp.position, geometry.worldPosition.xy);

  return outp;
}

${Kp()}
`}function xI(i){return`const RING_WINDING_ORDER_CW: bool = ${i?"true":"false"};

${Xp()}

struct Attributes {
  @location(0) positions: vec2<f32>,
  @location(1) vertexPositions: vec3<f32>,
  @location(2) vertexPositions64Low: vec3<f32>,
  @location(3) nextVertexPositions: vec3<f32>,
  @location(4) nextVertexPositions64Low: vec3<f32>,
  @location(5) vertexValid: f32,
  @location(6) elevations: f32,
  @location(7) fillColors: vec4<f32>,
  @location(8) lineColors: vec4<f32>,
  @location(9) rowIndexes: u32,
};

struct Varyings {
  @builtin(position) position: vec4<f32>,
  @location(0) vColor: vec4<f32>,
  @location(1) pickingColor: vec3<f32>,
  @location(2) clipCoordinates: vec2<f32>,
};

@vertex
fn vertexMain(attributes: Attributes) -> Varyings {
  var outp: Varyings;
  outp.position = vec4<f32>(0.0);
  outp.vColor = vec4<f32>(0.0);
  outp.pickingColor = picking_getPickingColorFromIndex(attributes.rowIndexes);
  outp.clipCoordinates = vec2<f32>(0.0);

  if (attributes.vertexValid < 0.5) {
    return outp;
  }

  let pos = select(attributes.nextVertexPositions, attributes.vertexPositions, RING_WINDING_ORDER_CW);
  let pos64Low = select(
    attributes.nextVertexPositions64Low,
    attributes.vertexPositions64Low,
    RING_WINDING_ORDER_CW
  );
  let nextPos = select(attributes.vertexPositions, attributes.nextVertexPositions, RING_WINDING_ORDER_CW);
  let nextPos64Low = select(
    attributes.vertexPositions64Low,
    attributes.nextVertexPositions64Low,
    RING_WINDING_ORDER_CW
  );

  let position = mix(pos, nextPos, attributes.positions.x);
  let position64Low = mix(pos64Low, nextPos64Low, attributes.positions.x);

  var worldPosition = position;
  if (solidPolygon.extruded > 0.5) {
    worldPosition.z += attributes.elevations * attributes.positions.y * solidPolygon.elevationScale;
  }

  geometry.worldPosition = position;
  geometry.pickingColor = picking_getPickingColorFromIndex(attributes.rowIndexes);

  let projectedPosition = project_position_to_clipspace_and_commonspace(
    worldPosition,
    position64Low,
    vec3<f32>(0.0)
  );
  geometry.position = projectedPosition.commonPosition;
  outp.position = projectedPosition.clipPosition;

  let normal = project_offset_normal(vec3<f32>(
    pos.y - nextPos.y + (pos64Low.y - nextPos64Low.y),
    nextPos.x - pos.x + (nextPos64Low.x - pos64Low.x),
    0.0
  ));
  geometry.normal = normal;

  let colors = select(
    attributes.fillColors,
    attributes.lineColors,
    solidPolygon.isWireframe > 0.5
  );
  outp.vColor = apply_polygon_color(colors, normal, geometry.position);
  outp.pickingColor = geometry.pickingColor;

  outp.clipCoordinates = geometry.position.xy;
  clip_filterPosition(&outp.position, geometry.worldPosition.xy);

  return outp;
}

${Kp()}
`}function PI(i,e){return i==="top"?wI():xI(e)}const dr=[0,0,0,255],SI={filled:!0,extruded:!1,wireframe:!1,_normalize:!0,_windingOrder:"CW",_full3d:!1,elevationScale:{type:"number",min:0,value:1},getPolygon:{type:"accessor",value:i=>i.polygon},getElevation:{type:"accessor",value:1e3},getFillColor:{type:"accessor",value:dr},getLineColor:{type:"accessor",value:dr},material:!0},ps={enter:(i,e)=>e.length?e.subarray(e.length-i.length):i};class Kr extends xt{getShaders(e){const t=!this.props._normalize&&this.props._windingOrder==="CCW"?0:1;return super.getShaders({vs:e==="top"?yI:bI,fs:vI,source:PI(e,!!t),defines:{RING_WINDING_ORDER_CW:t},modules:[Dn,Bn,_g,zn,_I,...this.context.device.type==="webgpu"?[bl]:[]]})}get wrapLongitude(){return!1}getBounds(){var e;return(e=this.getAttributeManager())==null?void 0:e.getBounds(["vertexPositions"])}initializeState(){const{viewport:e}=this.context;let{coordinateSystem:t}=this.props;const{_full3d:n}=this.props;e.isGeospatial&&t==="default"&&(t="lnglat");let s;t==="lnglat"&&(n?s=e.projectPosition.bind(e):s=e.projectFlat.bind(e)),this.setState({numInstances:0,polygonTesselator:new pI({preproject:s,fp64:this.use64bitPositions(),IndexType:Uint32Array})});const r=this.getAttributeManager(),o=!0,a=this.context.device.type==="webgpu";r.add({indices:{size:1,isIndexed:!0,update:this.calculateIndices,noAlloc:o},vertexPositions:{size:3,type:"float64",stepMode:"dynamic",fp64:this.use64bitPositions(),transition:ps,accessor:"getPolygon",update:this.calculatePositions,noAlloc:o,shaderAttributes:{nextVertexPositions:{vertexOffset:1}}},[a?"vertexValid":"instanceVertexValid"]:{size:1,type:a?"float32":"uint16",stepMode:"instance",update:this.calculateVertexValid,noAlloc:o},elevations:{size:1,stepMode:"dynamic",transition:ps,accessor:"getElevation",bufferGroup:"solid-polygon-instance-data"},fillColors:{size:this.props.colorFormat.length,type:"unorm8",stepMode:"dynamic",transition:ps,accessor:"getFillColor",defaultValue:dr,bufferGroup:"solid-polygon-instance-data"},lineColors:{size:this.props.colorFormat.length,type:"unorm8",stepMode:"dynamic",transition:ps,accessor:"getLineColor",defaultValue:dr,bufferGroup:"solid-polygon-instance-data"},rowIndexes:{size:1,type:"uint32",stepMode:"dynamic",accessor:(c,{index:l})=>c&&c.__source?c.__source.index:l,bufferGroup:"solid-polygon-instance-data"}})}getPickingInfo(e){const t=super.getPickingInfo(e),{index:n}=t,s=this.props.data;return s[0]&&s[0].__source&&(t.object=s.find(r=>r.__source.index===n)),t}disablePickingIndex(e){const t=this.props.data;if(t[0]&&t[0].__source)for(let n=0;n<t.length;n++)t[n].__source.index===e&&this._disablePickingIndex(n);else super.disablePickingIndex(e)}draw({uniforms:e}){const{extruded:t,filled:n,wireframe:s,elevationScale:r}=this.props,{topModel:o,sideModel:a,wireframeModel:c,polygonTesselator:l}=this.state,u={extruded:!!t,elevationScale:r,isWireframe:!1};c&&s&&(c.setInstanceCount(l.instanceCount-1),c.shaderInputs.setProps({solidPolygon:{...u,isWireframe:!0}}),c.draw(this.context.renderPass)),a&&n&&(a.setInstanceCount(l.instanceCount-1),a.shaderInputs.setProps({solidPolygon:u}),a.draw(this.context.renderPass)),o&&n&&(o.setVertexCount(l.vertexCount),o.shaderInputs.setProps({solidPolygon:u}),o.draw(this.context.renderPass))}updateState(e){var a;super.updateState(e),this.updateGeometry(e);const{props:t,oldProps:n,changeFlags:s}=e,r=this.getAttributeManager();(s.extensionsChanged||t.filled!==n.filled||t.extruded!==n.extruded)&&((a=this.state.models)==null||a.forEach(c=>c.destroy()),this.setState(this._getModels()),r.invalidateAll())}updateGeometry({props:e,oldProps:t,changeFlags:n}){if(n.dataChanged||n.updateTriggersChanged&&(n.updateTriggersChanged.all||n.updateTriggersChanged.getPolygon)){const{polygonTesselator:r}=this.state,o=e.data.attributes||{};r.updateGeometry({data:e.data,normalize:e._normalize,geometryBuffer:o.getPolygon,buffers:o,getGeometry:e.getPolygon,positionFormat:e.positionFormat,wrapLongitude:e.wrapLongitude,resolution:this.context.viewport.resolution,fp64:this.use64bitPositions(),dataChanged:n.dataChanged,full3d:e._full3d}),this.setState({numInstances:r.instanceCount,startIndices:r.vertexStarts}),n.dataChanged||this.getAttributeManager().invalidateAll()}}_getModels(){const{id:e,filled:t,extruded:n}=this.props;let s,r,o;if(t){const a=this.getShaders("top");a.defines={...a.defines,NON_INSTANCED_MODEL:1};let c=this.getAttributeManager().getBufferLayouts({isInstanced:!1});this.context.device.type==="webgpu"&&(c=c.filter(l=>l.name!=="indices"&&l.name!=="vertexValid"&&l.name!=="instanceVertexValid"&&l.name!=="nextVertexPositions")),s=new Ue(this.context.device,{...a,id:`${e}-top`,topology:"triangle-list",bufferLayout:c,isIndexed:!0,userData:{excludeAttributes:{vertexValid:!0,instanceVertexValid:!0,nextVertexPositions:!0}}})}if(n){let a=this.getAttributeManager().getBufferLayouts({isInstanced:!0});this.context.device.type==="webgpu"&&(a=a.filter(c=>c.name!=="indices")),r=new Ue(this.context.device,{...this.getShaders("side"),id:`${e}-side`,bufferLayout:a,geometry:new Ut({topology:"triangle-strip",attributes:{positions:{size:2,value:new Float32Array([1,0,0,0,1,1,0,1])}}}),isInstanced:!0,userData:{excludeAttributes:{indices:!0}}}),o=new Ue(this.context.device,{...this.getShaders("side"),id:`${e}-wireframe`,bufferLayout:a,geometry:new Ut({topology:"line-strip",attributes:{positions:{size:2,value:new Float32Array([1,0,0,0,0,1,1,1])}}}),isInstanced:!0,userData:{excludeAttributes:{indices:!0}}})}return{models:[r,o,s].filter(Boolean),topModel:s,sideModel:r,wireframeModel:o}}calculateIndices(e){const{polygonTesselator:t}=this.state;e.startIndices=t.indexStarts,e.value=t.get("indices")}calculatePositions(e){const{polygonTesselator:t}=this.state;e.startIndices=t.vertexStarts,e.value=t.get("positions")}calculateVertexValid(e){var s,r;const t=(r=(s=this.props.data.attributes)==null?void 0:s.instanceVertexValid)==null?void 0:r.value,n=this.context.device.type==="webgpu"&&t?t:this.state.polygonTesselator.get("vertexValid");e.value=this.context.device.type==="webgpu"&&n?Float32Array.from(n):n}}Kr.defaultProps=SI;Kr.layerName="SolidPolygonLayer";function Qp({data:i,getIndex:e,dataRange:t,replace:n}){const{startRow:s=0,endRow:r=1/0}=t,o=i.length;let a=o,c=o;for(let d=0;d<o;d++){const g=e(i[d]);if(a>d&&g>=s&&(a=d),g>=r){c=d;break}}let l=a;const f=c-a!==n.length?i.slice(c):void 0;for(let d=0;d<n.length;d++)i[l++]=n[d];if(f){for(let d=0;d<f.length;d++)i[l++]=f[d];i.length=l}return{startRow:a,endRow:a+n.length}}const Jp=[0,0,0,255],EI=[0,0,0,255],CI={stroked:!0,filled:!0,extruded:!1,elevationScale:1,wireframe:!1,_normalize:!0,_windingOrder:"CW",lineWidthUnits:"meters",lineWidthScale:1,lineWidthMinPixels:0,lineWidthMaxPixels:Number.MAX_SAFE_INTEGER,lineJointRounded:!1,lineMiterLimit:4,lineAntialiasing:!1,getPolygon:{type:"accessor",value:i=>i.polygon},getFillColor:{type:"accessor",value:EI},getLineColor:{type:"accessor",value:Jp},getLineWidth:{type:"accessor",value:1},getElevation:{type:"accessor",value:1e3},material:!0};class oi extends qr{initializeState(){this.state={paths:[],pathsDiff:null},this.props.getLineDashArray&&Y.removed("getLineDashArray","PathStyleExtension")()}updateState({changeFlags:e}){const t=e.dataChanged||e.updateTriggersChanged&&(e.updateTriggersChanged.all||e.updateTriggersChanged.getPolygon);if(t&&Array.isArray(e.dataChanged)){const n=this.state.paths.slice(),s=e.dataChanged.map(r=>Qp({data:n,getIndex:o=>o.__source.index,dataRange:r,replace:this._getPaths(r)}));this.setState({paths:n,pathsDiff:s})}else t&&this.setState({paths:this._getPaths(),pathsDiff:null})}_getPaths(e={}){const{data:t,getPolygon:n,positionFormat:s,_normalize:r}=this.props,o=[],a=s==="XY"?2:3,{startRow:c,endRow:l}=e,{iterable:u,objectInfo:f}=Ii(t,c,l);for(const d of u){f.index++;let g=n(d,f);r&&(g=qp(g,a));const{holeIndices:p}=g,m=g.positions||g;if(p)for(let _=0;_<=p.length;_++){const v=m.slice(p[_-1]||0,p[_]||m.length);o.push(this.getSubLayerRow({path:v},d,f.index))}else o.push(this.getSubLayerRow({path:m},d,f.index))}return o}renderLayers(){const{data:e,_dataDiff:t,stroked:n,filled:s,extruded:r,wireframe:o,_normalize:a,_windingOrder:c,elevationScale:l,transitions:u,positionFormat:f}=this.props,{lineWidthUnits:d,lineWidthScale:g,lineWidthMinPixels:p,lineWidthMaxPixels:m,lineJointRounded:_,lineMiterLimit:v,lineAntialiasing:w,lineDashJustified:y}=this.props,{getFillColor:x,getLineColor:S,getLineWidth:C,getLineDashArray:O,getElevation:B,getPolygon:D,updateTriggers:k,material:N}=this.props,{paths:F,pathsDiff:z}=this.state,L=this.getSubLayerClass("fill",Kr),G=this.getSubLayerClass("stroke",$n),b=this.shouldRenderSubLayer("fill",F)&&new L({_dataDiff:t,extruded:r,elevationScale:l,filled:s,wireframe:o,_normalize:a,_windingOrder:c,getElevation:B,getFillColor:x,getLineColor:r&&o?S:Jp,material:N,transitions:u},this.getSubLayerProps({id:"fill",updateTriggers:k&&{getPolygon:k.getPolygon,getElevation:k.getElevation,getFillColor:k.getFillColor,lineColors:r&&o,getLineColor:k.getLineColor}}),{data:e,positionFormat:f,getPolygon:D}),P=!r&&n&&this.shouldRenderSubLayer("stroke",F)&&new G({_dataDiff:z&&(()=>z),widthUnits:d,widthScale:g,widthMinPixels:p,widthMaxPixels:m,jointRounded:_,miterLimit:v,antialiasing:w,dashJustified:y,_pathType:"loop",transitions:u&&{getWidth:u.getLineWidth,getColor:u.getLineColor,getPath:u.getPolygon},getColor:this.getSubLayerAccessor(S),getWidth:this.getSubLayerAccessor(C),getDashArray:this.getSubLayerAccessor(O)},this.getSubLayerProps({id:"stroke",updateTriggers:k&&{getWidth:k.getLineWidth,getColor:k.getLineColor,getDashArray:k.getLineDashArray}}),{data:F,positionFormat:f,getPath:E=>E.path});return[!r&&b,P,r&&b]}}oi.layerName="PolygonLayer";oi.defaultProps=CI;function LI(i,e){if(!i)return null;const t="startIndices"in i?i.startIndices[e]:e,n=i.featureIds.value[t];return t!==-1?TI(i,n,t):null}function TI(i,e,t){const n={properties:{...i.properties[e]}};for(const s in i.numericProps)n.properties[s]=i.numericProps[s].value[t];return n}function AI(i){const e={points:null,lines:null,polygons:null};for(const t in e){const n=i[t].globalFeatureIds.value;e[t]=new Uint32Array(n)}return e}const Td=`layout(std140) uniform sdfUniforms {
  float gamma;
  bool enabled;
  float buffer;
  float outlineBuffer;
  vec4 outlineColor;
} sdf;
`,MI={name:"sdf",vs:Td,fs:Td,uniformTypes:{gamma:"f32",enabled:"f32",buffer:"f32",outlineBuffer:"f32",outlineColor:"vec4<f32>"}},ln={none:0,start:1,center:2,end:3},II=`layout(std140) uniform textUniforms {
  highp vec2 cutoffPixels;
  highp ivec2 align;
  highp float fontSize;
  bool flipY;
} text;

#define ALIGN_MODE_START ${ln.start}
#define ALIGN_MODE_CENTER ${ln.center}
#define ALIGN_MODE_END ${ln.end}
`,em={name:"text",vs:II,getUniforms:({contentCutoffPixels:i=[0,0],contentAlignHorizontal:e="none",contentAlignVertical:t="none",fontSize:n,viewport:s})=>({cutoffPixels:i,align:[ln[e],ln[t]],fontSize:n,flipY:(s==null?void 0:s.flipY)??!1}),uniformTypes:{cutoffPixels:"vec2<f32>",align:"vec2<i32>",fontSize:"f32",flipY:"f32"}},RI=`#version 300 es
#define SHADER_NAME multi-icon-layer-vertex-shader
in vec2 positions;
in vec3 instancePositions;
in vec3 instancePositions64Low;
in float instanceSizes;
in float instanceAngles;
in vec4 instanceColors;
in float rowIndexes;
in vec4 instanceIconFrames;
in float instanceColorModes;
in vec2 instanceOffsets;
in vec2 instancePixelOffset;
in vec4 instanceClipRect;
out float vColorMode;
out vec4 vColor;
out vec2 vTextureCoords;
out vec2 uv;
vec2 rotate_by_angle(vec2 vertex, float angle) {
float angle_radian = angle * PI / 180.0;
float cos_angle = cos(angle_radian);
float sin_angle = sin(angle_radian);
mat2 rotationMatrix = mat2(cos_angle, -sin_angle, sin_angle, cos_angle);
return rotationMatrix * vertex;
}
float getPixelOffsetFromAlignment(float anchor, float extent, float clipStart, float clipEnd, int mode) {
if (clipEnd < clipStart) return 0.0;
if (mode == ALIGN_MODE_START) {
return max(- (anchor + clipStart), 0.0);
}
if (mode == ALIGN_MODE_CENTER) {
float _min = max(0., anchor + clipStart);
float _max = min(extent, anchor + clipEnd);
return _min < _max ? (_min + _max) / 2.0 - anchor : 0.0;
}
if (mode == ALIGN_MODE_END) {
return min(extent - (anchor + clipEnd), 0.);
}
return 0.0;
}
void main(void) {
geometry.worldPosition = instancePositions;
geometry.uv = positions;
geometry.pickingColor = picking_getPickingColorFromIndex(rowIndexes);
uv = positions;
vec2 iconSize = instanceIconFrames.zw;
float sizePixels = clamp(
project_size_to_pixel(instanceSizes * icon.sizeScale, icon.sizeUnits),
icon.sizeMinPixels, icon.sizeMaxPixels
);
float instanceScale = sizePixels / text.fontSize;
vec2 pixelOffset = positions / 2.0 * iconSize + instanceOffsets;
pixelOffset = rotate_by_angle(pixelOffset, instanceAngles) * instanceScale;
pixelOffset += instancePixelOffset;
pixelOffset.y *= -1.0;
vec2 anchorPosScreen;
if (icon.billboard)  {
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, vec3(0.0), geometry.position);
anchorPosScreen = gl_Position.xy / gl_Position.w;
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
vec3 offset = vec3(pixelOffset, 0.0);
DECKGL_FILTER_SIZE(offset, geometry);
gl_Position.xy += project_pixel_size_to_clipspace(offset.xy);
} else {
vec3 offset_common = vec3(project_pixel_size(pixelOffset), 0.0);
if (text.flipY) {
offset_common.y *= -1.;
}
DECKGL_FILTER_SIZE(offset_common, geometry);
vec4 anchorPos = project_position_to_clipspace(instancePositions, instancePositions64Low, vec3(0.0));
anchorPosScreen = anchorPos.xy / anchorPos.w;
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, offset_common, geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
}
anchorPosScreen = vec2(anchorPosScreen.x + 1.0, 1.0 - anchorPosScreen.y) / 2.0 * project.viewportSize / project.devicePixelRatio;
vec2 xy = project_size_to_pixel(instanceClipRect.xy);
vec2 wh = project_size_to_pixel(instanceClipRect.zw);
if (text.flipY) {
xy.y = -xy.y - wh.y;
}
if (text.align.x > 0 || text.align.y > 0) {
vec2 viewportPixels = project.viewportSize / project.devicePixelRatio;
vec2 scrollPixels = vec2(
getPixelOffsetFromAlignment(anchorPosScreen.x, viewportPixels.x, xy.x, xy.x + wh.x, text.align.x),
-getPixelOffsetFromAlignment(anchorPosScreen.y, viewportPixels.y, -xy.y - wh.y, -xy.y, text.align.y)
);
pixelOffset += scrollPixels;
gl_Position.xy += project_pixel_size_to_clipspace(scrollPixels);
}
if (instanceClipRect.z >= 0.) {
if (pixelOffset.x < xy.x || pixelOffset.x > xy.x + wh.x) {
gl_Position = vec4(0.0);
}
else if (text.cutoffPixels.x > 0.) {
float vpWidth = project.viewportSize.x / project.devicePixelRatio;
float l = max(anchorPosScreen.x + xy.x, 0.0);
float r = min(anchorPosScreen.x + xy.x + wh.x, vpWidth);
if (r - l < text.cutoffPixels.x) {
gl_Position = vec4(0.0);
}
}
}
if (instanceClipRect.w >= 0.) {
if (pixelOffset.y < xy.y || pixelOffset.y > xy.y + wh.y) {
gl_Position = vec4(0.0);
}
else if (text.cutoffPixels.y > 0.) {
float vpHeight = project.viewportSize.y / project.devicePixelRatio;
float t = max(anchorPosScreen.y - xy.y - wh.y, 0.0);
float b = min(anchorPosScreen.y - xy.y, vpHeight);
if (b - t < text.cutoffPixels.y) {
gl_Position = vec4(0.0);
}
}
}
vTextureCoords = mix(
instanceIconFrames.xy,
instanceIconFrames.xy + iconSize,
(positions.xy + 1.0) / 2.0
) / icon.iconsTextureDim;
vColor = instanceColors;
DECKGL_FILTER_COLOR(vColor, geometry);
vColorMode = instanceColorModes;
}
`,OI=`#version 300 es
#define SHADER_NAME multi-icon-layer-fragment-shader
precision highp float;
uniform sampler2D iconsTexture;
in vec4 vColor;
in vec2 vTextureCoords;
in vec2 uv;
out vec4 fragColor;
void main(void) {
geometry.uv = uv;
if (!bool(picking.isActive)) {
float alpha = texture(iconsTexture, vTextureCoords).a;
vec4 color = vColor;
if (sdf.enabled) {
float distance = alpha;
alpha = smoothstep(sdf.buffer - sdf.gamma, sdf.buffer + sdf.gamma, distance);
if (sdf.outlineBuffer > 0.0) {
float inFill = alpha;
float inBorder = smoothstep(sdf.outlineBuffer - sdf.gamma, sdf.outlineBuffer + sdf.gamma, distance);
color = mix(sdf.outlineColor, vColor, inFill);
alpha = inBorder;
}
}
float a = alpha * color.a;
if (a < icon.alphaCutoff) {
discard;
}
fragColor = vec4(color.rgb, a * layer.opacity);
}
DECKGL_FILTER_COLOR(fragColor, geometry);
}
`;function BI({collision:i=!1}={}){return`struct IconUniforms {
  sizeScale: f32,
  iconsTextureDim: vec2<f32>,
  sizeBasis: f32,
  sizeMinPixels: f32,
  sizeMaxPixels: f32,
  billboard: i32,
  sizeUnits: i32,
  alphaCutoff: f32
};

struct TextUniforms {
  cutoffPixels: vec2<f32>,
  align: vec2<i32>,
  fontSize: f32,
  flipY: f32
};

struct SdfUniforms {
  gamma: f32,
  enabled: f32,
  buffer: f32,
  outlineBuffer: f32,
  outlineColor: vec4<f32>
};

${i?`struct CollisionUniforms {
  sort: i32,
  enabled: i32
};
`:""}

const ALIGN_MODE_START: i32 = 1;
const ALIGN_MODE_CENTER: i32 = 2;
const ALIGN_MODE_END: i32 = 3;

@group(0) @binding(auto) var<uniform> icon: IconUniforms;
@group(0) @binding(auto) var<uniform> text: TextUniforms;
@group(0) @binding(auto) var<uniform> sdf: SdfUniforms;
${i?"@group(0) @binding(auto) var<uniform> collision: CollisionUniforms;":""}
@group(0) @binding(auto) var iconsTexture : texture_2d<f32>;
@group(0) @binding(auto) var iconsTextureSampler : sampler;
${i?`@group(0) @binding(auto) var collision_texture : texture_2d<f32>;
`:""}

fn rotate_by_angle(vertex: vec2<f32>, angle_deg: f32) -> vec2<f32> {
  let angle_radian = angle_deg * PI / 180.0;
  let c = cos(angle_radian);
  let s = sin(angle_radian);
  let rotation = mat2x2<f32>(vec2<f32>(c, -s), vec2<f32>(s, c));
  return rotation * vertex;
}

fn get_pixel_offset_from_alignment(
  anchor: f32,
  extent: f32,
  clipStart: f32,
  clipEnd: f32,
  mode: i32
) -> f32 {
  if (clipEnd < clipStart) {
    return 0.0;
  }
  if (mode == ALIGN_MODE_START) {
    return max(-(anchor + clipStart), 0.0);
  }
  if (mode == ALIGN_MODE_CENTER) {
    let minValue = max(0.0, anchor + clipStart);
    let maxValue = min(extent, anchor + clipEnd);
    if (minValue < maxValue) {
      return (minValue + maxValue) / 2.0 - anchor;
    }
    return 0.0;
  }
  if (mode == ALIGN_MODE_END) {
    return min(extent - (anchor + clipEnd), 0.0);
  }
  return 0.0;
}

${i?`fn collision_match(texCoords: vec2<f32>, pickingColor: vec3<f32>) -> f32 {
  let textureSize = vec2<i32>(textureDimensions(collision_texture));
  let pixelCoords = clamp(
    vec2<i32>(texCoords * vec2<f32>(textureSize)),
    vec2<i32>(0),
    textureSize - vec2<i32>(1)
  );
  let collisionPickingColor = textureLoad(collision_texture, pixelCoords, 0);
  let delta = dot(abs(collisionPickingColor.rgb - pickingColor), vec3<f32>(1.0));
  return step(delta, 0.001);
}

fn collision_is_visible(texCoords: vec2<f32>, pickingColor: vec3<f32>) -> f32 {
  if (collision.enabled == 0) {
    return 1.0;
  }

  var accumulator = 0.0;
  let stepSize = vec2<f32>(1.0) / project.viewportSize;

  for (var i: i32 = -2; i <= 2; i = i + 1) {
    for (var j: i32 = -2; j <= 2; j = j + 1) {
      let delta = vec2<f32>(f32(j), f32(i)) * stepSize;
      accumulator = accumulator + collision_match(texCoords + delta, pickingColor);
    }
  }

  return pow(accumulator / 25.0, 2.2);
}
`:""}

struct Attributes {
  @location(0) positions: vec2<f32>,

  @location(1) instancePositions: vec3<f32>,
  @location(2) instancePositions64Low: vec3<f32>,
  @location(3) instanceSizes: f32,
  @location(4) instanceAngles: f32,
  @location(5) instanceColors: vec4<f32>,
  @location(6) instanceIconFrames: vec4<f32>,
  @location(7) instanceColorModes: f32,
  @location(8) instanceOffsets: vec2<f32>,
  @location(9) instancePixelOffset: vec2<f32>,
  @location(10) rowIndexes: u32,
  @location(11) instanceClipRect: vec4<f32>,
  ${i?"@location(12) collisionPriorities: f32,":""}
};

struct Varyings {
  @builtin(position) position: vec4<f32>,

  @location(0) vColorMode: f32,
  @location(1) vColor: vec4<f32>,
  @location(2) vTextureCoords: vec2<f32>,
  @location(3) uv: vec2<f32>,
  @location(4) pickingColor: vec3<f32>,
};

@vertex
fn vertexMain(inp: Attributes) -> Varyings {
  geometry.worldPosition = inp.instancePositions;
  geometry.uv = inp.positions;
  geometry.pickingColor = picking_getPickingColorFromIndex(inp.rowIndexes);

  var outp: Varyings;
  outp.uv = inp.positions;

  let iconSize = inp.instanceIconFrames.zw;

  let sizePixels = clamp(
    project_unit_size_to_pixel(inp.instanceSizes * icon.sizeScale, icon.sizeUnits),
    icon.sizeMinPixels, icon.sizeMaxPixels
  );
  let instanceScale = sizePixels / text.fontSize;

  var pixelOffset = inp.positions / 2.0 * iconSize + inp.instanceOffsets;
  pixelOffset = rotate_by_angle(pixelOffset, inp.instanceAngles) * instanceScale;
  pixelOffset = pixelOffset + inp.instancePixelOffset;
  pixelOffset.y = pixelOffset.y * -1.0;

  var pos: vec4<f32>;
  var anchorPosScreen: vec2<f32>;
  if (icon.billboard != 0) {
    pos = project_position_to_clipspace(inp.instancePositions, inp.instancePositions64Low, vec3<f32>(0.0));
    anchorPosScreen = pos.xy / pos.w;

    let clipOffset = project_pixel_size_to_clipspace(pixelOffset);
    pos = vec4<f32>(pos.x + clipOffset.x, pos.y + clipOffset.y, pos.z, pos.w);
  } else {
    var offsetCommon = vec3<f32>(project_pixel_size_vec2(pixelOffset), 0.0);
    if (text.flipY > 0.5) {
      offsetCommon.y = offsetCommon.y * -1.0;
    }
    let anchorPos = project_position_to_clipspace(inp.instancePositions, inp.instancePositions64Low, vec3<f32>(0.0));
    anchorPosScreen = anchorPos.xy / anchorPos.w;
    pos = project_position_to_clipspace(inp.instancePositions, inp.instancePositions64Low, offsetCommon);
  }

  anchorPosScreen = vec2<f32>(anchorPosScreen.x + 1.0, 1.0 - anchorPosScreen.y) / 2.0 *
    project.viewportSize / project.devicePixelRatio;
  var xy = project_size_vec2(inp.instanceClipRect.xy) * project.scale;
  var wh = project_size_vec2(inp.instanceClipRect.zw) * project.scale;

  if (text.flipY > 0.5) {
    xy.y = -xy.y - wh.y;
  }
  if (text.align.x > 0 || text.align.y > 0) {
    let viewportPixels = project.viewportSize / project.devicePixelRatio;
    let scrollPixels = vec2<f32>(
      get_pixel_offset_from_alignment(anchorPosScreen.x, viewportPixels.x, xy.x, xy.x + wh.x, text.align.x),
      -get_pixel_offset_from_alignment(anchorPosScreen.y, viewportPixels.y, -xy.y - wh.y, -xy.y, text.align.y)
    );
    pixelOffset = pixelOffset + scrollPixels;
    let scrollClipOffset = project_pixel_size_to_clipspace(scrollPixels);
    pos.x = pos.x + scrollClipOffset.x;
    pos.y = pos.y + scrollClipOffset.y;
  }

  if (inp.instanceClipRect.z >= 0.0) {
    if (pixelOffset.x < xy.x || pixelOffset.x > xy.x + wh.x) {
      pos = vec4<f32>(0.0);
    } else if (text.cutoffPixels.x > 0.0) {
      let viewportWidth = project.viewportSize.x / project.devicePixelRatio;
      let left = max(anchorPosScreen.x + xy.x, 0.0);
      let right = min(anchorPosScreen.x + xy.x + wh.x, viewportWidth);
      if (right - left < text.cutoffPixels.x) {
        pos = vec4<f32>(0.0);
      }
    }
  }
  if (inp.instanceClipRect.w >= 0.0) {
    if (pixelOffset.y < xy.y || pixelOffset.y > xy.y + wh.y) {
      pos = vec4<f32>(0.0);
    } else if (text.cutoffPixels.y > 0.0) {
      let viewportHeight = project.viewportSize.y / project.devicePixelRatio;
      let top = max(anchorPosScreen.y - xy.y - wh.y, 0.0);
      let bottom = min(anchorPosScreen.y - xy.y, viewportHeight);
      if (bottom - top < text.cutoffPixels.y) {
        pos = vec4<f32>(0.0);
      }
    }
  }

  ${i?`  if (collision.sort != 0) {
    pos.z = -0.001 * inp.collisionPriorities * pos.w;
  }
  `:""}

  let uvMix = (inp.positions.xy + vec2<f32>(1.0, 1.0)) * 0.5;
  outp.vTextureCoords = mix(inp.instanceIconFrames.xy, inp.instanceIconFrames.xy + iconSize, uvMix) / icon.iconsTextureDim;

  outp.position = pos;
  outp.vColor = inp.instanceColors;
  outp.vColorMode = inp.instanceColorModes;
  outp.pickingColor = picking_getPickingColorFromIndex(inp.rowIndexes);

  return outp;
}

@fragment
fn fragmentMain(inp: Varyings) -> @location(0) vec4<f32> {
  geometry.uv = inp.uv;

  let texColor = textureSample(iconsTexture, iconsTextureSampler, inp.vTextureCoords);
  var alpha = texColor.a;
  var color = inp.vColor;

  if (sdf.enabled > 0.5) {
    let distance = alpha;
    alpha = smoothstep(sdf.buffer - sdf.gamma, sdf.buffer + sdf.gamma, distance);

    if (sdf.outlineBuffer > 0.0) {
      let inFill = alpha;
      let inBorder = smoothstep(sdf.outlineBuffer - sdf.gamma, sdf.outlineBuffer + sdf.gamma, distance);
      color = mix(sdf.outlineColor, inp.vColor, inFill);
      alpha = inBorder;
    }
  } else if (inp.vColorMode == 0.0) {
    color = texColor;
  }

  var a = alpha * color.a * layer.opacity;
  if (a < icon.alphaCutoff) {
    discard;
  }

  if (picking.isActive > 0.5) {
    if (!picking_isColorValid(inp.pickingColor)) {
      discard;
    }
    return vec4<f32>(inp.pickingColor, 1.0);
  }

  ${i?`  let collisionFade = collision_is_visible(inp.position.xy / project.viewportSize, inp.pickingColor);
  a = a * collisionFade;
  if (a <= 0.0001) {
    discard;
  }
  `:""}

  var fragColor = deckgl_premultiplied_alpha(vec4<f32>(color.rgb, a));

  if (picking.isHighlightActive > 0.5) {
    let highlightedObjectColor = picking_normalizeColor(picking.highlightedObjectColor);
    if (picking_isColorZero(abs(inp.pickingColor - highlightedObjectColor))) {
      let highLightAlpha = picking.highlightColor.a;
      let blendedAlpha = highLightAlpha + fragColor.a * (1.0 - highLightAlpha);
      if (blendedAlpha > 0.0) {
        let highLightRatio = highLightAlpha / blendedAlpha;
        fragColor = vec4<f32>(
          mix(fragColor.rgb, picking.highlightColor.rgb, highLightRatio),
          blendedAlpha
        );
      } else {
        fragColor = vec4<f32>(fragColor.rgb, 0.0);
      }
    }
  }

  return fragColor;
}
`}const kI=BI(),na=192/256,DI={getIconOffsets:{type:"accessor",value:i=>i.offsets},getContentBox:{type:"accessor",value:[0,0,-1,-1]},fontSize:1,alphaCutoff:.001,smoothing:.1,outlineWidth:0,outlineColor:{type:"color",value:[0,0,0,255]},contentCutoffPixels:{type:"array",value:[0,0]},contentAlignHorizontal:"none",contentAlignVertical:"none"};class vl extends Zr{getShaders(){const e=super.getShaders();return{...e,modules:[...e.modules,em,MI],vs:RI,fs:OI,source:kI}}initializeState(){super.initializeState();const e=this.getAttributeManager(),t=e.attributes.instanceIconDefs;t.settings.update=this.calculateInstanceIconDefs,e.addInstanced({rowIndexes:{type:"uint32",size:1,bufferGroup:"icon-instance-data",accessor:(n,{index:s})=>s},instanceClipRect:{size:4,bufferGroup:"icon-instance-data",accessor:"getContentBox",defaultValue:[0,0,-1,-1]}})}updateState(e){var o;super.updateState(e);const{props:t,oldProps:n,changeFlags:s}=e,{outlineColor:r}=t;if(s.extensionsChanged){(o=this.state.fillModel)==null||o.destroy();const a=this.context.device.type==="webgpu"?this._getModel(`${this.props.id}-fill`):void 0;this.setState({fillModel:a,models:a?[this.state.model,a]:[this.state.model]})}if(s.updateTriggersChanged&&(s.updateTriggersChanged.getIcon||s.updateTriggersChanged.getIconOffsets)&&this.getAttributeManager().invalidate("instanceIconDefs"),r!==n.outlineColor){const a=[r[0]/255,r[1]/255,r[2]/255,(r[3]??255)/255];this.setState({outlineColor:a})}!t.sdf&&t.outlineWidth&&Y.warn(`${this.id}: fontSettings.sdf is required to render outline`)()}draw(e){const{sdf:t,smoothing:n,fontSize:s,outlineWidth:r,contentCutoffPixels:o,contentAlignHorizontal:a,contentAlignVertical:c}=this.props,{outlineColor:l}=this.state,u=r?Math.max(n,na*(1-r)):-1,f=this.state.model,d={buffer:na,outlineBuffer:u,gamma:n,enabled:!!t,outlineColor:l},g={contentCutoffPixels:o,contentAlignHorizontal:a,contentAlignVertical:c,fontSize:s,viewport:this.context.viewport};if(f.shaderInputs.setProps({sdf:d,text:g}),super.draw(e),t&&r){const{iconManager:p}=this.state;if(p.getTexture()){const _=this.state.fillModel||f;_.shaderInputs.setProps({sdf:{...d,outlineBuffer:na},text:g}),this._drawModel(_)}}}calculateInstanceIconDefs(e,{startRow:t,endRow:n}){const{data:s,getIcon:r,getIconOffsets:o}=this.props;let a=e.getVertexOffset(t);const c=e.value,{iterable:l,objectInfo:u}=Ii(s,t,n);for(const f of l){u.index++;const d=r(f,u),g=o(f,u);if(d){let p=0;for(const m of Array.from(d)){const _=super.getInstanceIconDef(m);_[0]=g[p*2],_[1]+=g[p*2+1],_[6]=1,c.set(_,a),a+=e.size,p++}}}}}vl.defaultProps=DI;vl.layerName="MultiIconLayer";const un=1e20,wl=new Float64Array(256);for(let i=0;i<256;i++){const e=.5-Math.pow(i/255,.45454545454545453);wl[i]=e*Math.abs(e)}wl[255]=-un;class FI{constructor({fontSize:e=24,buffer:t=3,radius:n=8,cutoff:s=.25,fontFamily:r="sans-serif",fontWeight:o="normal",fontStyle:a="normal",lang:c=null}={}){t=this.buffer=Math.round(t),this.radius=n,this.cutoff=s,this.lang=c;const l=this.size=Math.ceil(e)+t*4,u=this._createCanvas(l),f=this.ctx=u.getContext("2d",{willReadFrequently:!0});f.font=`${a} ${o} ${e}px ${r}`,f.textBaseline="alphabetic",f.textAlign="left",f.fillStyle="black",c&&(f.lang=c);const g=(this.maxGlyphDim=l-t)+2*t;this.gridOuter=new Float64Array(g*g),this.gridInner=new Float64Array(g*g),this.f=new Float64Array(g),this.z=new Float64Array(g+1),this.v=new Uint16Array(g)}_createCanvas(e){if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(e,e);const t=document.createElement("canvas");return t.width=t.height=e,t}draw(e){const{width:t,actualBoundingBoxAscent:n,actualBoundingBoxDescent:s,actualBoundingBoxLeft:r,actualBoundingBoxRight:o}=this.ctx.measureText(e),a=Math.ceil(n),c=Math.floor(-r),l=Math.max(0,Math.min(this.maxGlyphDim,Math.ceil(o)-c)),u=Math.max(0,Math.min(this.maxGlyphDim,a+Math.ceil(s))),f=l+2*this.buffer,d=u+2*this.buffer,g=f*d,p=new Uint8ClampedArray(g),m={data:p,width:f,height:d,glyphWidth:l,glyphHeight:u,glyphTop:a,glyphLeft:c,glyphAdvance:t};if(l===0||u===0)return m;const{ctx:_,buffer:v,gridInner:w,gridOuter:y}=this;_.clearRect(v,v,l,u),_.fillText(e,v-c,v+a);const x=_.getImageData(v,v,l,u);y.fill(un,0,g),w.fill(0,0,g);let S=3;for(let D=0;D<u;D++){let k=(D+v)*f+v;for(let N=0;N<l;N++,S+=4,k++){const F=x.data[S];if(F===0)continue;const z=wl[F];y[k]=Math.max(0,z),w[k]=Math.max(0,-z)}}Ad(y,0,0,f,d,f,this.f,this.v,this.z,v);const C=Math.min(v,1);Ad(w,v-C,v-C,l+2*C,u+2*C,f,this.f,this.v,this.z);const O=255/this.radius,B=255*(1-this.cutoff);for(let D=0;D<g;D++){const k=Math.sqrt(y[D])-Math.sqrt(w[D]);p[D]=B-O*k}return m}}function Ad(i,e,t,n,s,r,o,a,c,l=0){for(let u=e+l;u<e+n-l;u++)Md(i,t*r+u,r,s,o,a,c);for(let u=t;u<t+s;u++)Md(i,u*r+e,1,n,o,a,c)}function Md(i,e,t,n,s,r,o){r[0]=0,o[0]=-un,o[1]=un,s[0]=i[e];for(let a=1,c=0;a<n;a++){const l=s[a]=i[e+a*t],u=a*a;let f;do{const d=r[c];f=(l-s[d]+u-d*d)/(a-d)/2}while(f<=o[c]&&--c>-1);c++,r[c]=a,o[c]=f,o[c+1]=un}for(let a=0,c=0;a<n;a++){for(;o[c+1]<a;)c++;const l=r[c],u=a-l;i[e+a*t]=s[l]+u*u}}const zI=32,NI=[];function UI(i){return Math.pow(2,Math.ceil(Math.log2(i)))}function $I({characterSet:i,measureText:e,buffer:t,maxCanvasWidth:n,mapping:s={},xOffset:r=0,yOffsetMin:o=0,yOffsetMax:a=0}){let c=r,l=o,u=a;for(const f of i)if(!s[f]){const{advance:d,width:g,ascent:p,descent:m}=e(f),_=p+m;c+g+t*2>n&&(c=0,l=u),s[f]={x:c+t,y:l+t,width:g,height:_,advance:d,anchorX:g/2,anchorY:p},c+=g+t*2,u=Math.max(u,l+_+t*2)}return{mapping:s,xOffset:c,yOffsetMin:l,yOffsetMax:u,canvasHeight:UI(u)}}function tm(i,e,t,n){var r;let s=0;for(let o=e;o<t;o++){const a=i[o];s+=((r=n[a])==null?void 0:r.advance)||0}return s}function im(i,e,t,n,s,r){let o=e,a=0;for(let c=e;c<t;c++){const l=tm(i,c,c+1,s);a+l>n&&(o<c&&r.push(c),o=c,a=0),a+=l}return a}function GI(i,e,t,n,s,r){let o=e,a=e,c=e,l=0;for(let u=e;u<t;u++)if((i[u]===" "||i[u+1]===" "||u+1===t)&&(c=u+1),c>a){let f=tm(i,a,c,s);l+f>n&&(o<a&&(r.push(a),o=a,l=0),f>n&&(f=im(i,a,c,n,s,r),o=r[r.length-1])),a=c,l+=f}return l}function jI(i,e,t,n,s=0,r){r===void 0&&(r=i.length);const o=[];return e==="break-all"?im(i,s,r,t,n,o):GI(i,s,r,t,n,o),o}function VI(i,e,t,n,s,r){let o=0,a=0;for(let c=e;c<t;c++){const l=i[c],u=n[l];u&&(a=Math.max(a,u.height))}for(let c=e;c<t;c++){const l=i[c],u=n[l];u?(s[c]=o+u.anchorX,o+=u.advance):(Y.warn(`Missing character: ${l} (${l.codePointAt(0)})`)(),s[c]=o,o+=zI)}r[0]=o,r[1]=a}function WI(i,e,t,n,s,r){const o=Array.from(i),a=o.length,c=new Array(a),l=new Array(a),u=new Array(a),f=(n==="break-word"||n==="break-all")&&isFinite(s)&&s>0,d=[0,0],g=[0,0];let p=0,m=e+t/2,_=0,v=0;for(let w=0;w<=a;w++){const y=o[w];if((y===`
`||w===a)&&(v=w),v>_){const x=f?jI(o,n,s,r,_,v):NI;for(let S=0;S<=x.length;S++){const C=S===0?_:x[S-1],O=S<x.length?x[S]:v;VI(o,C,O,r,c,g);for(let B=C;B<O;B++)l[B]=m,u[B]=g[0];p++,m+=t,d[0]=Math.max(d[0],g[0])}_=v}y===`
`&&(c[_]=0,l[_]=0,u[_]=0,_++)}return d[1]=p*t,{x:c,y:l,rowWidth:u,size:d}}function HI({value:i,length:e,stride:t,offset:n,startIndices:s,characterSet:r}){const o=i.BYTES_PER_ELEMENT,a=t?t/o:1,c=n?n/o:0,l=s[e]||Math.ceil((i.length-c)/a),u=r&&new Set,f=new Array(e);let d=i;if(a>1||c>0){const g=i.constructor;d=new g(l);for(let p=0;p<l;p++)d[p]=i[p*a+c]}for(let g=0;g<e;g++){const p=s[g],m=s[g+1]||l,_=d.subarray(p,m);f[g]=String.fromCodePoint.apply(null,_),u&&_.forEach(u.add,u)}if(u)for(const g of u)r.add(String.fromCodePoint(g));return{texts:f,characterCount:l}}class nm{constructor(e=5){this._cache={},this._order=[],this.limit=e}get(e){const t=this._cache[e];return t&&(this._deleteOrder(e),this._appendOrder(e)),t}set(e,t){this._cache[e]?(this.delete(e),this._cache[e]=t,this._appendOrder(e)):(Object.keys(this._cache).length===this.limit&&this.delete(this._order[0]),this._cache[e]=t,this._appendOrder(e))}delete(e){this._cache[e]&&(delete this._cache[e],this._deleteOrder(e))}_deleteOrder(e){const t=this._order.indexOf(e);t>=0&&this._order.splice(t,1)}_appendOrder(e){this._order.push(e)}}function YI(){const i=[];for(let e=32;e<128;e++)i.push(String.fromCharCode(e));return i}const hi={fontFamily:"Monaco, monospace",fontWeight:"normal",characterSet:YI(),fontSize:64,buffer:4,sdf:!1,cutoff:.25,radius:12,smoothing:.1},Id=1024,Rd=.9,Od=.3,sm=3;let hr=new nm(sm);function qI(i,e){let t;typeof e=="string"?t=new Set(Array.from(e)):t=new Set(e);const n=hr.get(i);if(!n)return t;for(const s in n.mapping)t.has(s)&&t.delete(s);return t}function ZI(i,e){for(let t=0;t<i.length;t++)e.data[4*t+3]=i[t]}function Bd(i,e,t,n){i.font=`${n} ${t}px ${e}`,i.fillStyle="#000",i.textBaseline="alphabetic",i.textAlign="left"}function XI(i,e,t){if(t===void 0){const s=i.measureText("A");return s.fontBoundingBoxAscent?{advance:0,width:0,ascent:Math.ceil(s.fontBoundingBoxAscent),descent:Math.ceil(s.fontBoundingBoxDescent)}:{advance:0,width:0,ascent:e*Rd,descent:e*Od}}const n=i.measureText(t);return n.actualBoundingBoxAscent?{advance:n.width,width:Math.ceil(n.actualBoundingBoxRight-n.actualBoundingBoxLeft),ascent:Math.ceil(n.actualBoundingBoxAscent),descent:Math.ceil(n.actualBoundingBoxDescent)}:{advance:n.width,width:n.width,ascent:e*Rd,descent:e*Od}}function KI(i){Y.assert(Number.isFinite(i)&&i>=sm,"Invalid cache limit"),hr=new nm(i)}class QI{constructor(){this.props={...hi}}get atlas(){return this._atlas}get mapping(){return this._atlas&&this._atlas.mapping}setProps(e={}){Object.assign(this.props,e),e._getFontRenderer&&(this._getFontRenderer=e._getFontRenderer),this._key=this._getKey();const t=qI(this._key,this.props.characterSet),n=hr.get(this._key);if(n&&t.size===0){this._atlas!==n&&(this._atlas=n);return}const s=this._generateFontAtlas(t,n);this._atlas=s,hr.set(this._key,s)}_generateFontAtlas(e,t){const{fontFamily:n,fontWeight:s,fontSize:r,buffer:o,sdf:a,radius:c,cutoff:l}=this.props;let u=t&&t.data;u||(u=document.createElement("canvas"),u.width=Id);const f=u.getContext("2d",{willReadFrequently:!0});Bd(f,n,r,s);const d=x=>XI(f,r,x);let g;this._getFontRenderer?g=this._getFontRenderer(this.props):a&&(g={measure:d,draw:JI(this.props)});const{mapping:p,canvasHeight:m,xOffset:_,yOffsetMin:v,yOffsetMax:w}=$I({measureText:x=>g?g.measure(x):d(x),buffer:o,characterSet:e,maxCanvasWidth:Id,...t&&{mapping:t.mapping,xOffset:t.xOffset,yOffsetMin:t.yOffsetMin,yOffsetMax:t.yOffsetMax}});if(u.height!==m){const x=u.height>0?f.getImageData(0,0,u.width,u.height):null;u.height=m,x&&f.putImageData(x,0,0)}if(Bd(f,n,r,s),g)for(const x of e){const S=p[x],C=S.width,{data:O,left:B=0,top:D=0}=g.draw(x),k=S.x-B,N=S.y-D,F=Math.max(0,Math.round(k)),z=Math.max(0,Math.round(N)),L=Math.min(O.width,u.width-F),G=Math.min(O.height,u.height-z);f.putImageData(O,F,z,0,0,L,G),S.x=F,S.y=z,S.width=L,S.height=G,S.anchorX+=L/2-B-C/2,S.anchorY+=D}else for(const x of e){const S=p[x];f.fillText(x,S.x,S.y+S.anchorY)}const y=g?g.measure():d();return{baselineOffset:(y.ascent-y.descent)/2,xOffset:_,yOffsetMin:v,yOffsetMax:w,mapping:p,data:u,width:u.width,height:u.height}}_getKey(){const{fontFamily:e,fontWeight:t,fontSize:n,buffer:s,sdf:r,radius:o,cutoff:a}=this.props;return r?`${e} ${t} ${n} ${s} ${o} ${a}`:`${e} ${t} ${n} ${s}`}}function JI({fontSize:i,buffer:e,radius:t,cutoff:n,fontFamily:s,fontWeight:r}){const o=new FI({fontSize:i,buffer:e,radius:t,cutoff:n,fontFamily:s,fontWeight:`${r}`});return a=>{const{data:c,width:l,height:u}=o.draw(a),f=new ImageData(l,u);return ZI(c,f),{data:f,left:e,top:e}}}const eR=`struct TextBackgroundUniforms {
  billboard: f32,
  sizeScale: f32,
  sizeMinPixels: f32,
  sizeMaxPixels: f32,
  borderRadius: vec4<f32>,
  padding: vec4<f32>,
  sizeUnits: i32,
  stroked: f32,
};

@group(0) @binding(auto) var<uniform> textBackground: TextBackgroundUniforms;
`,kd=`layout(std140) uniform textBackgroundUniforms {
  bool billboard;
  float sizeScale;
  float sizeMinPixels;
  float sizeMaxPixels;
  vec4 borderRadius;
  vec4 padding;
  highp int sizeUnits;
  bool stroked;
} textBackground;
`,tR={name:"textBackground",source:eR,vs:kd,fs:kd,uniformTypes:{billboard:"f32",sizeScale:"f32",sizeMinPixels:"f32",sizeMaxPixels:"f32",borderRadius:"vec4<f32>",padding:"vec4<f32>",sizeUnits:"i32",stroked:"f32"}},iR=`#version 300 es
#define SHADER_NAME text-background-layer-vertex-shader
in vec2 positions;
in vec3 instancePositions;
in vec3 instancePositions64Low;
in vec4 instanceRects;
in vec4 instanceClipRect;
in float instanceSizes;
in float instanceAngles;
in vec2 instancePixelOffsets;
in float instanceLineWidths;
in vec4 instanceFillColors;
in vec4 instanceLineColors;
out vec4 vFillColor;
out vec4 vLineColor;
out float vLineWidth;
out vec2 uv;
out vec2 dimensions;
vec2 rotate_by_angle(vec2 vertex, float angle) {
float angle_radian = radians(angle);
float cos_angle = cos(angle_radian);
float sin_angle = sin(angle_radian);
mat2 rotationMatrix = mat2(cos_angle, -sin_angle, sin_angle, cos_angle);
return rotationMatrix * vertex;
}
void main(void) {
geometry.worldPosition = instancePositions;
geometry.uv = positions;
geometry.pickingColor = picking_getPickingColorFromInstanceID();
uv = positions;
vLineWidth = instanceLineWidths;
float sizePixels = clamp(
project_size_to_pixel(instanceSizes * textBackground.sizeScale, textBackground.sizeUnits),
textBackground.sizeMinPixels, textBackground.sizeMaxPixels
);
float instanceScale = sizePixels / text.fontSize;
dimensions = instanceRects.zw * instanceScale + textBackground.padding.xy + textBackground.padding.zw;
vec2 pixelOffset = (positions * instanceRects.zw + instanceRects.xy) * instanceScale + mix(-textBackground.padding.xy, textBackground.padding.zw, positions);
pixelOffset = rotate_by_angle(pixelOffset, instanceAngles);
pixelOffset += instancePixelOffsets;
pixelOffset.y *= -1.0;
vec2 xy = project_size_to_pixel(instanceClipRect.xy);
vec2 wh = project_size_to_pixel(instanceClipRect.zw);
if (text.flipY) {
xy.y = -xy.y - wh.y;
}
if (instanceClipRect.z >= 0.0) {
dimensions.x = wh.x;
pixelOffset.x = xy.x + uv.x * wh.x + mix(-textBackground.padding.x, textBackground.padding.z, uv.x);
}
if (instanceClipRect.w >= 0.0) {
dimensions.y = wh.y;
pixelOffset.y = xy.y + uv.y * wh.y + mix(-textBackground.padding.y, textBackground.padding.w, uv.y);
}
if (textBackground.billboard)  {
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, vec3(0.0), geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
vec3 offset = vec3(pixelOffset, 0.0);
DECKGL_FILTER_SIZE(offset, geometry);
gl_Position.xy += project_pixel_size_to_clipspace(offset.xy);
} else {
vec3 offset_common = vec3(project_pixel_size(pixelOffset), 0.0);
if (text.flipY) {
offset_common.y *= -1.;
}
DECKGL_FILTER_SIZE(offset_common, geometry);
gl_Position = project_position_to_clipspace(instancePositions, instancePositions64Low, offset_common, geometry.position);
DECKGL_FILTER_GL_POSITION(gl_Position, geometry);
}
vFillColor = vec4(instanceFillColors.rgb, instanceFillColors.a * layer.opacity);
DECKGL_FILTER_COLOR(vFillColor, geometry);
vLineColor = vec4(instanceLineColors.rgb, instanceLineColors.a * layer.opacity);
DECKGL_FILTER_COLOR(vLineColor, geometry);
}
`,nR=`#version 300 es
#define SHADER_NAME text-background-layer-fragment-shader
precision highp float;
in vec4 vFillColor;
in vec4 vLineColor;
in float vLineWidth;
in vec2 uv;
in vec2 dimensions;
out vec4 fragColor;
float round_rect(vec2 p, vec2 size, vec4 radii) {
vec2 pixelPositionCB = (p - 0.5) * size;
vec2 sizeCB = size * 0.5;
float maxBorderRadius = min(size.x, size.y) * 0.5;
vec4 borderRadius = vec4(min(radii, maxBorderRadius));
borderRadius.xy =
(pixelPositionCB.x > 0.0) ? borderRadius.xy : borderRadius.zw;
borderRadius.x = (pixelPositionCB.y > 0.0) ? borderRadius.x : borderRadius.y;
vec2 q = abs(pixelPositionCB) - sizeCB + borderRadius.x;
return -(min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - borderRadius.x);
}
float rect(vec2 p, vec2 size) {
vec2 pixelPosition = p * size;
return min(min(pixelPosition.x, size.x - pixelPosition.x),
min(pixelPosition.y, size.y - pixelPosition.y));
}
vec4 get_stroked_fragColor(float dist) {
float isBorder = smoothedge(dist, vLineWidth);
return mix(vFillColor, vLineColor, isBorder);
}
void main(void) {
geometry.uv = uv;
if (textBackground.borderRadius != vec4(0.0)) {
float distToEdge = round_rect(uv, dimensions, textBackground.borderRadius);
float shapeAlpha = smoothedge(-distToEdge, 0.0);
if (shapeAlpha == 0.0) {
discard;
}
if (textBackground.stroked) {
fragColor = get_stroked_fragColor(distToEdge);
} else {
fragColor = vFillColor;
}
fragColor.a *= shapeAlpha;
} else {
if (textBackground.stroked) {
float distToEdge = rect(uv, dimensions);
fragColor = get_stroked_fragColor(distToEdge);
} else {
fragColor = vFillColor;
}
}
DECKGL_FILTER_COLOR(fragColor, geometry);
}
`,sR=`struct TextUniforms {
  cutoffPixels: vec2<f32>,
  align: vec2<i32>,
  fontSize: f32,
  flipY: f32,
};

@group(0) @binding(auto) var<uniform> text: TextUniforms;

fn rotate_by_angle(vertex: vec2<f32>, angle: f32) -> vec2<f32> {
  let angleRadian = radians(angle);
  let cosine = cos(angleRadian);
  let sine = sin(angleRadian);
  let rotationMatrix = mat2x2<f32>(
    vec2<f32>(cosine, -sine),
    vec2<f32>(sine, cosine)
  );
  return rotationMatrix * vertex;
}

struct Attributes {
  @builtin(instance_index) instanceIndex: u32,
  @location(0) positions: vec2<f32>,
  @location(1) instancePositions: vec3<f32>,
  @location(2) instancePositions64Low: vec3<f32>,
  @location(3) instanceSizes: f32,
  @location(4) instanceAngles: f32,
  @location(5) instanceRects: vec4<f32>,
  @location(6) instanceClipRect: vec4<f32>,
  @location(7) instancePixelOffsets: vec2<f32>,
  @location(8) instanceFillColors: vec4<f32>,
  @location(9) instanceLineColors: vec4<f32>,
  @location(10) instanceLineWidths: f32,
};

struct Varyings {
  @builtin(position) position: vec4<f32>,
  @location(0) vFillColor: vec4<f32>,
  @location(1) vLineColor: vec4<f32>,
  @location(2) vLineWidth: f32,
  @location(3) uv: vec2<f32>,
  @location(4) dimensions: vec2<f32>,
  @location(5) pickingColor: vec3<f32>,
};

@vertex
fn vertexMain(attributes: Attributes) -> Varyings {
  geometry.worldPosition = attributes.instancePositions;
  geometry.uv = attributes.positions;
  geometry.pickingColor = picking_getPickingColorFromIndex(attributes.instanceIndex);

  var varyings: Varyings;
  varyings.uv = attributes.positions;
  varyings.vLineWidth = attributes.instanceLineWidths;

  let sizePixels = clamp(
    project_unit_size_to_pixel(
      attributes.instanceSizes * textBackground.sizeScale,
      textBackground.sizeUnits
    ),
    textBackground.sizeMinPixels,
    textBackground.sizeMaxPixels
  );
  let instanceScale = sizePixels / text.fontSize;

  varyings.dimensions = attributes.instanceRects.zw * instanceScale +
    textBackground.padding.xy + textBackground.padding.zw;

  var pixelOffset =
    (attributes.positions * attributes.instanceRects.zw + attributes.instanceRects.xy) *
      instanceScale +
    mix(-textBackground.padding.xy, textBackground.padding.zw, attributes.positions);
  pixelOffset = rotate_by_angle(pixelOffset, attributes.instanceAngles);
  pixelOffset = pixelOffset + attributes.instancePixelOffsets;
  pixelOffset.y = pixelOffset.y * -1.0;

  var xy = project_size_vec2(attributes.instanceClipRect.xy) * project.scale;
  let wh = project_size_vec2(attributes.instanceClipRect.zw) * project.scale;
  if (text.flipY > 0.5) {
    xy.y = -xy.y - wh.y;
  }
  if (attributes.instanceClipRect.z >= 0.0) {
    varyings.dimensions.x = wh.x;
    pixelOffset.x = xy.x + varyings.uv.x * wh.x + mix(
      -textBackground.padding.x,
      textBackground.padding.z,
      varyings.uv.x
    );
  }
  if (attributes.instanceClipRect.w >= 0.0) {
    varyings.dimensions.y = wh.y;
    pixelOffset.y = xy.y + varyings.uv.y * wh.y + mix(
      -textBackground.padding.y,
      textBackground.padding.w,
      varyings.uv.y
    );
  }

  if (textBackground.billboard > 0.5) {
    var position = project_position_to_clipspace(
      attributes.instancePositions,
      attributes.instancePositions64Low,
      vec3<f32>(0.0)
    );
    let clipOffset = project_pixel_size_to_clipspace(pixelOffset);
    position = vec4<f32>(
      position.x + clipOffset.x,
      position.y + clipOffset.y,
      position.z,
      position.w
    );
    varyings.position = position;
  } else {
    var offsetCommon = vec3<f32>(project_pixel_size_vec2(pixelOffset), 0.0);
    if (text.flipY > 0.5) {
      offsetCommon.y = offsetCommon.y * -1.0;
    }
    varyings.position = project_position_to_clipspace(
      attributes.instancePositions,
      attributes.instancePositions64Low,
      offsetCommon
    );
  }

  varyings.vFillColor = vec4<f32>(
    attributes.instanceFillColors.rgb,
    attributes.instanceFillColors.a * layer.opacity
  );
  varyings.vLineColor = vec4<f32>(
    attributes.instanceLineColors.rgb,
    attributes.instanceLineColors.a * layer.opacity
  );
  varyings.pickingColor = geometry.pickingColor;
  return varyings;
}

fn round_rect(point: vec2<f32>, size: vec2<f32>, radii: vec4<f32>) -> f32 {
  let pixelPosition = (point - 0.5) * size;
  let halfSize = size * 0.5;
  let maxBorderRadius = min(size.x, size.y) * 0.5;
  var borderRadius = min(radii, vec4<f32>(maxBorderRadius));

  borderRadius = select(borderRadius.zwxy, borderRadius, pixelPosition.x > 0.0);
  let radius = select(borderRadius.y, borderRadius.x, pixelPosition.y > 0.0);
  let q = abs(pixelPosition) - halfSize + radius;
  return -(min(max(q.x, q.y), 0.0) + length(max(q, vec2<f32>(0.0))) - radius);
}

fn rect(point: vec2<f32>, size: vec2<f32>) -> f32 {
  let pixelPosition = point * size;
  return min(
    min(pixelPosition.x, size.x - pixelPosition.x),
    min(pixelPosition.y, size.y - pixelPosition.y)
  );
}

fn get_stroked_frag_color(
  distanceToEdge: f32,
  lineWidth: f32,
  fillColor: vec4<f32>,
  lineColor: vec4<f32>
) -> vec4<f32> {
  let isBorder = smoothedge(distanceToEdge, lineWidth);
  return mix(fillColor, lineColor, isBorder);
}

@fragment
fn fragmentMain(varyings: Varyings) -> @location(0) vec4<f32> {
  geometry.uv = varyings.uv;
  var fragColor: vec4<f32>;

  if (any(textBackground.borderRadius != vec4<f32>(0.0))) {
    let distanceToEdge = round_rect(
      varyings.uv,
      varyings.dimensions,
      textBackground.borderRadius
    );
    let shapeAlpha = smoothedge(-distanceToEdge, 0.0);
    if (shapeAlpha == 0.0) {
      discard;
    }
    if (textBackground.stroked > 0.5) {
      fragColor = get_stroked_frag_color(
        distanceToEdge,
        varyings.vLineWidth,
        varyings.vFillColor,
        varyings.vLineColor
      );
    } else {
      fragColor = varyings.vFillColor;
    }
    fragColor.a = fragColor.a * shapeAlpha;
  } else if (textBackground.stroked > 0.5) {
    let distanceToEdge = rect(varyings.uv, varyings.dimensions);
    fragColor = get_stroked_frag_color(
      distanceToEdge,
      varyings.vLineWidth,
      varyings.vFillColor,
      varyings.vLineColor
    );
  } else {
    fragColor = varyings.vFillColor;
  }

  if (picking.isActive > 0.5) {
    if (!picking_isColorValid(varyings.pickingColor)) {
      discard;
    }
    return vec4<f32>(varyings.pickingColor, 1.0);
  }

  if (picking.isHighlightActive > 0.5) {
    let highlightedObjectColor = picking_normalizeColor(picking.highlightedObjectColor);
    if (picking_isColorZero(abs(varyings.pickingColor - highlightedObjectColor))) {
      let highlightAlpha = picking.highlightColor.a;
      let blendedAlpha = highlightAlpha + fragColor.a * (1.0 - highlightAlpha);
      if (blendedAlpha > 0.0) {
        let highlightRatio = highlightAlpha / blendedAlpha;
        fragColor = vec4<f32>(
          mix(fragColor.rgb, picking.highlightColor.rgb, highlightRatio),
          blendedAlpha
        );
      } else {
        fragColor = vec4<f32>(fragColor.rgb, 0.0);
      }
    }
  }

  return deckgl_premultiplied_alpha(fragColor);
}
`,rR={billboard:!0,sizeScale:1,sizeUnits:"pixels",sizeMinPixels:0,sizeMaxPixels:Number.MAX_SAFE_INTEGER,fontSize:1,borderRadius:{type:"object",value:0},padding:{type:"array",value:[0,0,0,0]},getPosition:{type:"accessor",value:i=>i.position},getSize:{type:"accessor",value:1},getAngle:{type:"accessor",value:0},getPixelOffset:{type:"accessor",value:[0,0]},getBoundingRect:{type:"accessor",value:[0,0,0,0]},getClipRect:{type:"accessor",value:[0,0,-1,-1]},getFillColor:{type:"accessor",value:[0,0,0,255]},getLineColor:{type:"accessor",value:[0,0,0,255]},getLineWidth:{type:"accessor",value:1}};class xl extends xt{getShaders(){return super.getShaders({vs:iR,fs:nR,source:sR,modules:[Dn,Bn,zn,tR,em]})}initializeState(){this.getAttributeManager().addInstanced({instancePositions:{size:3,type:"float64",fp64:this.use64bitPositions(),transition:!0,accessor:"getPosition"},instanceSizes:{size:1,transition:!0,bufferGroup:"text-background-instance-data",accessor:"getSize",defaultValue:1},instanceAngles:{size:1,transition:!0,bufferGroup:"text-background-instance-data",accessor:"getAngle"},instanceRects:{size:4,bufferGroup:"text-background-instance-data",accessor:"getBoundingRect"},instanceClipRect:{size:4,bufferGroup:"text-background-instance-data",accessor:"getClipRect",defaultValue:[0,0,-1,-1]},instancePixelOffsets:{size:2,transition:!0,bufferGroup:"text-background-instance-data",accessor:"getPixelOffset"},instanceFillColors:{size:4,transition:!0,type:"unorm8",accessor:"getFillColor",defaultValue:[0,0,0,255]},instanceLineColors:{size:4,transition:!0,type:"unorm8",accessor:"getLineColor",defaultValue:[0,0,0,255]},instanceLineWidths:{size:1,transition:!0,bufferGroup:"text-background-instance-data",accessor:"getLineWidth",defaultValue:1}})}updateState(e){var n;super.updateState(e);const{changeFlags:t}=e;t.extensionsChanged&&((n=this.state.model)==null||n.destroy(),this.state.model=this._getModel(),this.getAttributeManager().invalidateAll())}draw({uniforms:e}){const{billboard:t,sizeScale:n,sizeUnits:s,sizeMinPixels:r,sizeMaxPixels:o,getLineWidth:a,fontSize:c}=this.props;let{padding:l,borderRadius:u}=this.props;l.length<4&&(l=[l[0],l[1],l[0],l[1]]),Array.isArray(u)||(u=[u,u,u,u]);const f=this.state.model,d={billboard:t,stroked:!!a,borderRadius:u,padding:l,sizeUnits:at[s],sizeScale:n,sizeMinPixels:r,sizeMaxPixels:o},g={fontSize:c,viewport:this.context.viewport};f.shaderInputs.setProps({textBackground:d,text:g}),f.draw(this.context.renderPass)}_getModel(){const e=[0,0,1,0,0,1,1,1];return new Ue(this.context.device,{...this.getShaders(),id:this.props.id,bufferLayout:this.getAttributeManager().getBufferLayouts(),geometry:new Ut({topology:"triangle-strip",vertexCount:4,attributes:{positions:{size:2,value:new Float32Array(e)}}}),isInstanced:!0})}}xl.defaultProps=rR;xl.layerName="TextBackgroundLayer";const Dd={start:1,middle:0,end:-1},Fd={top:1,center:0,bottom:-1},sa=[0,0,0,255],oR=1,aR={billboard:!0,sizeScale:1,sizeUnits:"pixels",sizeMinPixels:0,sizeMaxPixels:Number.MAX_SAFE_INTEGER,background:!1,getBackgroundColor:{type:"accessor",value:[255,255,255,255]},getBorderColor:{type:"accessor",value:sa},getBorderWidth:{type:"accessor",value:0},backgroundBorderRadius:{type:"object",value:0},backgroundPadding:{type:"array",value:[0,0,0,0]},characterSet:{type:"object",value:hi.characterSet},fontFamily:hi.fontFamily,fontWeight:hi.fontWeight,lineHeight:oR,outlineWidth:{type:"number",value:0,min:0},outlineColor:{type:"color",value:sa},fontSettings:{type:"object",value:{},compare:1},wordBreak:"break-word",maxWidth:{type:"number",value:-1},contentCutoffPixels:{type:"array",value:[0,0]},contentAlignHorizontal:"none",contentAlignVertical:"none",getText:{type:"accessor",value:i=>i.text},getPosition:{type:"accessor",value:i=>i.position},getColor:{type:"accessor",value:sa},getSize:{type:"accessor",value:32},getAngle:{type:"accessor",value:0},getTextAnchor:{type:"accessor",value:"middle"},getAlignmentBaseline:{type:"accessor",value:"center"},getPixelOffset:{type:"accessor",value:[0,0]},getContentBox:{type:"accessor",value:[0,0,-1,-1]},backgroundColor:{deprecatedFor:["background","getBackgroundColor"]}};class Qr extends qr{constructor(){super(...arguments),this.getBoundingRect=(e,t)=>{const{size:[n,s]}=this.transformParagraph(e,t),{getTextAnchor:r,getAlignmentBaseline:o}=this.props,a=Dd[typeof r=="function"?r(e,t):r],c=Fd[typeof o=="function"?o(e,t):o];return[(a-1)*n/2,(c-1)*s/2,n,s]},this.getIconOffsets=(e,t)=>{const{getTextAnchor:n,getAlignmentBaseline:s}=this.props,{x:r,y:o,rowWidth:a,size:[,c]}=this.transformParagraph(e,t),l=Dd[typeof n=="function"?n(e,t):n],u=Fd[typeof s=="function"?s(e,t):s],f=r.length,d=new Array(f*2);let g=0;for(let p=0;p<f;p++)d[g++]=(l-1)*a[p]/2+r[p],d[g++]=(u-1)*c/2+o[p];return d}}initializeState(){this.state={styleVersion:0,fontAtlasManager:new QI},this.props.maxWidth>0&&Y.once(1,"v8.9 breaking change: TextLayer maxWidth is now relative to text size")()}updateState(e){const{props:t,oldProps:n,changeFlags:s}=e;(s.dataChanged||s.updateTriggersChanged&&(s.updateTriggersChanged.all||s.updateTriggersChanged.getText))&&this._updateText(),(this._updateFontAtlas()||t.lineHeight!==n.lineHeight||t.wordBreak!==n.wordBreak||t.maxWidth!==n.maxWidth)&&this.setState({styleVersion:this.state.styleVersion+1})}getPickingInfo({info:e}){return e.object=e.index>=0?this.props.data[e.index]:null,e}_updateFontAtlas(){const{fontSettings:e,fontFamily:t,fontWeight:n,_getFontRenderer:s}=this.props,{fontAtlasManager:r,characterSet:o}=this.state,a={...e,characterSet:o,fontFamily:t,fontWeight:n,_getFontRenderer:s};if(!r.mapping)return r.setProps(a),!0;for(const c in a)if(a[c]!==r.props[c])return r.setProps(a),!0;return!1}_updateText(){var c;const{data:e,characterSet:t}=this.props,n=(c=e.attributes)==null?void 0:c.getText;let{getText:s}=this.props,r=e.startIndices,o;const a=t==="auto"&&new Set;if(n&&r){const{texts:l,characterCount:u}=HI({...ArrayBuffer.isView(n)?{value:n}:n,length:e.length,startIndices:r,characterSet:a});o=u,s=(f,{index:d})=>l[d]}else{const{iterable:l,objectInfo:u}=Ii(e);r=[0],o=0;for(const f of l){u.index++;const d=Array.from(s(f,u)||"");a&&d.forEach(a.add,a),o+=d.length,r.push(o)}}this.setState({getText:s,startIndices:r,numInstances:o,characterSet:a||t})}transformParagraph(e,t){const{fontAtlasManager:n}=this.state,s=n.mapping,{baselineOffset:r}=n.atlas,{fontSize:o}=n.props,a=this.state.getText,{wordBreak:c,lineHeight:l,maxWidth:u}=this.props,f=a(e,t)||"";return WI(f,r,l*o,c,u*o,s)}renderLayers(){const{startIndices:e,numInstances:t,getText:n,fontAtlasManager:{atlas:s,mapping:r},styleVersion:o}=this.state,{data:a,_dataDiff:c,getPosition:l,getColor:u,getSize:f,getAngle:d,getPixelOffset:g,getBackgroundColor:p,getBorderColor:m,getBorderWidth:_,getContentBox:v,backgroundBorderRadius:w,backgroundPadding:y,background:x,billboard:S,fontSettings:C,outlineWidth:O,outlineColor:B,sizeScale:D,sizeUnits:k,sizeMinPixels:N,sizeMaxPixels:F,contentCutoffPixels:z,contentAlignHorizontal:L,contentAlignVertical:G,transitions:b,updateTriggers:P}=this.props,E=this.getSubLayerClass("characters",vl),A=this.getSubLayerClass("background",xl),{fontSize:T}=this.state.fontAtlasManager.props;return[x&&new A({getFillColor:p,getLineColor:m,getLineWidth:_,borderRadius:w,padding:y,getPosition:l,getSize:f,getAngle:d,getPixelOffset:g,getClipRect:v,billboard:S,sizeScale:D,sizeUnits:k,sizeMinPixels:N,sizeMaxPixels:F,fontSize:T,transitions:b&&{getPosition:b.getPosition,getAngle:b.getAngle,getSize:b.getSize,getFillColor:b.getBackgroundColor,getLineColor:b.getBorderColor,getLineWidth:b.getBorderWidth,getPixelOffset:b.getPixelOffset}},this.getSubLayerProps({id:"background",updateTriggers:{getPosition:P.getPosition,getAngle:P.getAngle,getSize:P.getSize,getFillColor:P.getBackgroundColor,getLineColor:P.getBorderColor,getLineWidth:P.getBorderWidth,getPixelOffset:P.getPixelOffset,getBoundingRect:{getText:P.getText,getTextAnchor:P.getTextAnchor,getAlignmentBaseline:P.getAlignmentBaseline,styleVersion:o}}}),{data:a.attributes&&a.attributes.background?{length:a.length,attributes:a.attributes.background}:a,_dataDiff:c,autoHighlight:!1,getBoundingRect:this.getBoundingRect}),new E({sdf:C.sdf,smoothing:Number.isFinite(C.smoothing)?C.smoothing:hi.smoothing,outlineWidth:O/(C.radius||hi.radius),outlineColor:B,iconAtlas:s,iconMapping:r,getPosition:l,getColor:u,getSize:f,getAngle:d,getPixelOffset:g,getContentBox:v,billboard:S,sizeScale:D,sizeUnits:k,sizeMinPixels:N,sizeMaxPixels:F,fontSize:T,contentCutoffPixels:z,contentAlignHorizontal:L,contentAlignVertical:G,transitions:b&&{getPosition:b.getPosition,getAngle:b.getAngle,getColor:b.getColor,getSize:b.getSize,getPixelOffset:b.getPixelOffset,getContentBox:b.getContentBox}},this.getSubLayerProps({id:"characters",updateTriggers:{all:P.getText,getPosition:P.getPosition,getAngle:P.getAngle,getColor:P.getColor,getSize:P.getSize,getPixelOffset:P.getPixelOffset,getContentBox:P.getContentBox,getIconOffsets:{getTextAnchor:P.getTextAnchor,getAlignmentBaseline:P.getAlignmentBaseline,styleVersion:o}}}),{data:a,_dataDiff:c,startIndices:e,numInstances:t,getIconOffsets:this.getIconOffsets,getIcon:n})]}static set fontAtlasCacheLimit(e){KI(e)}}Qr.defaultProps=aR;Qr.layerName="TextLayer";const Is={circle:{type:Xr,props:{filled:"filled",stroked:"stroked",lineWidthMaxPixels:"lineWidthMaxPixels",lineWidthMinPixels:"lineWidthMinPixels",lineWidthScale:"lineWidthScale",lineWidthUnits:"lineWidthUnits",pointRadiusMaxPixels:"radiusMaxPixels",pointRadiusMinPixels:"radiusMinPixels",pointRadiusScale:"radiusScale",pointRadiusUnits:"radiusUnits",pointAntialiasing:"antialiasing",pointBillboard:"billboard",getFillColor:"getFillColor",getLineColor:"getLineColor",getLineWidth:"getLineWidth",getPointRadius:"getRadius"}},icon:{type:Zr,props:{iconAtlas:"iconAtlas",iconMapping:"iconMapping",iconSizeMaxPixels:"sizeMaxPixels",iconSizeMinPixels:"sizeMinPixels",iconSizeScale:"sizeScale",iconSizeUnits:"sizeUnits",iconAlphaCutoff:"alphaCutoff",iconBillboard:"billboard",getIcon:"getIcon",getIconAngle:"getAngle",getIconColor:"getColor",getIconPixelOffset:"getPixelOffset",getIconSize:"getSize"}},text:{type:Qr,props:{textSizeMaxPixels:"sizeMaxPixels",textSizeMinPixels:"sizeMinPixels",textSizeScale:"sizeScale",textSizeUnits:"sizeUnits",textBackground:"background",textBackgroundPadding:"backgroundPadding",textFontFamily:"fontFamily",textFontWeight:"fontWeight",textLineHeight:"lineHeight",textMaxWidth:"maxWidth",textOutlineColor:"outlineColor",textOutlineWidth:"outlineWidth",textWordBreak:"wordBreak",textCharacterSet:"characterSet",textBillboard:"billboard",textFontSettings:"fontSettings",getText:"getText",getTextAngle:"getAngle",getTextColor:"getColor",getTextPixelOffset:"getPixelOffset",getTextSize:"getSize",getTextAnchor:"getTextAnchor",getTextAlignmentBaseline:"getAlignmentBaseline",getTextBackgroundColor:"getBackgroundColor",getTextBorderColor:"getBorderColor",getTextBorderWidth:"getBorderWidth"}}},Rs={type:$n,props:{lineWidthUnits:"widthUnits",lineWidthScale:"widthScale",lineWidthMinPixels:"widthMinPixels",lineWidthMaxPixels:"widthMaxPixels",lineJointRounded:"jointRounded",lineCapRounded:"capRounded",lineMiterLimit:"miterLimit",lineBillboard:"billboard",lineAntialiasing:"antialiasing",getLineColor:"getColor",getLineWidth:"getWidth"}},vc={type:Kr,props:{extruded:"extruded",filled:"filled",wireframe:"wireframe",elevationScale:"elevationScale",material:"material",_full3d:"_full3d",getElevation:"getElevation",getFillColor:"getFillColor",getLineColor:"getLineColor"}};function Vi({type:i,props:e}){const t={};for(const n in e)t[n]=i.defaultProps[e[n]];return t}function ra(i,e,t="getPosition"){const{transitions:n,updateTriggers:s}=i.props,r={updateTriggers:{},transitions:n&&{[t]:n.geometry}};for(const o in e){const a=e[o];let c=i.props[o];o.startsWith("get")&&(c=i.getSubLayerAccessor(c),r.updateTriggers[a]=s[o],n&&(r.transitions[a]=n[o])),r[a]=c}return r}function cR(i){if(Array.isArray(i))return i;switch(Y.assert(i.type,"GeoJSON does not have type"),i.type){case"Feature":return[i];case"FeatureCollection":return Y.assert(Array.isArray(i.features),"GeoJSON does not have features array"),i.features;default:return[{geometry:i}]}}function zd(i,e,t={}){const n={pointFeatures:[],lineFeatures:[],polygonFeatures:[],polygonOutlineFeatures:[]},{startRow:s=0,endRow:r=i.length}=t;for(let o=s;o<r;o++){const a=i[o],{geometry:c}=a;if(c)if(c.type==="GeometryCollection"){Y.assert(Array.isArray(c.geometries),"GeoJSON does not have geometries array");const{geometries:l}=c;for(let u=0;u<l.length;u++){const f=l[u];Nd(f,n,e,a,o)}}else Nd(c,n,e,a,o)}return n}function Nd(i,e,t,n,s){const{type:r,coordinates:o}=i,{pointFeatures:a,lineFeatures:c,polygonFeatures:l,polygonOutlineFeatures:u}=e;if(!uR(r,o)){Y.warn(`${r} coordinates are malformed`)();return}switch(r){case"Point":a.push(t({geometry:i},n,s));break;case"MultiPoint":o.forEach(f=>{a.push(t({geometry:{type:"Point",coordinates:f}},n,s))});break;case"LineString":c.push(t({geometry:i},n,s));break;case"MultiLineString":o.forEach(f=>{c.push(t({geometry:{type:"LineString",coordinates:f}},n,s))});break;case"Polygon":l.push(t({geometry:i},n,s)),o.forEach(f=>{u.push(t({geometry:{type:"LineString",coordinates:f}},n,s))});break;case"MultiPolygon":o.forEach(f=>{l.push(t({geometry:{type:"Polygon",coordinates:f}},n,s)),f.forEach(d=>{u.push(t({geometry:{type:"LineString",coordinates:d}},n,s))})});break}}const lR={Point:1,MultiPoint:2,LineString:2,MultiLineString:3,Polygon:3,MultiPolygon:4};function uR(i,e){let t=lR[i];for(Y.assert(t,`Unknown GeoJSON type ${i}`);e&&--t>0;)e=e[0];return e&&Number.isFinite(e[0])}function rm(){return{points:{},lines:{},polygons:{},polygonsOutline:{}}}function ms(i){return i.geometry.coordinates}function fR(i,e){const t=rm(),{pointFeatures:n,lineFeatures:s,polygonFeatures:r,polygonOutlineFeatures:o}=i;return t.points.data=n,t.points._dataDiff=e.pointFeatures&&(()=>e.pointFeatures),t.points.getPosition=ms,t.lines.data=s,t.lines._dataDiff=e.lineFeatures&&(()=>e.lineFeatures),t.lines.getPath=ms,t.polygons.data=r,t.polygons._dataDiff=e.polygonFeatures&&(()=>e.polygonFeatures),t.polygons.getPolygon=ms,t.polygonsOutline.data=o,t.polygonsOutline._dataDiff=e.polygonOutlineFeatures&&(()=>e.polygonOutlineFeatures),t.polygonsOutline.getPath=ms,t}function dR(i){const e=rm(),{points:t,lines:n,polygons:s}=i,r=AI(i);e.points.data={length:t.positions.value.length/t.positions.size,attributes:{...t.attributes,getPosition:t.positions,rowIndexes:{size:1,type:"uint32",value:r.points}},properties:t.properties,numericProps:t.numericProps,featureIds:t.featureIds},e.lines.data={length:n.pathIndices.value.length-1,startIndices:n.pathIndices.value,attributes:{...n.attributes,getPath:n.positions,rowIndexes:{size:1,type:"uint32",value:r.lines}},properties:n.properties,numericProps:n.numericProps,featureIds:n.featureIds},e.lines._pathType="open";const o=s.positions.value.length/s.positions.size,a=Array(o).fill(1);for(const c of s.primitivePolygonIndices.value)a[c-1]=0;return e.polygons.data={length:s.polygonIndices.value.length-1,startIndices:s.polygonIndices.value,attributes:{...s.attributes,getPolygon:s.positions,instanceVertexValid:{size:1,value:new Uint16Array(a)},rowIndexes:{size:1,type:"uint32",value:r.polygons}},properties:s.properties,numericProps:s.numericProps,featureIds:s.featureIds},e.polygons._normalize=!1,s.triangles&&(e.polygons.data.attributes.indices=s.triangles.value),e.polygonsOutline.data={length:s.primitivePolygonIndices.value.length-1,startIndices:s.primitivePolygonIndices.value,attributes:{...s.attributes,getPath:s.positions,rowIndexes:{size:1,type:"uint32",value:r.polygons}},properties:s.properties,numericProps:s.numericProps,featureIds:s.featureIds},e.polygonsOutline._pathType="open",e}const hR=["points","linestrings","polygons"],gR={...Vi(Is.circle),...Vi(Is.icon),...Vi(Is.text),...Vi(Rs),...Vi(vc),stroked:!0,filled:!0,extruded:!1,wireframe:!1,_full3d:!1,iconAtlas:{type:"object",value:null},iconMapping:{type:"object",value:{}},getIcon:{type:"accessor",value:i=>i.properties.icon},getText:{type:"accessor",value:i=>i.properties.text},pointType:"circle",getRadius:{deprecatedFor:"getPointRadius"}};class gr extends qr{initializeState(){this.state={layerProps:{},features:{},featuresDiff:{}}}updateState({props:e,changeFlags:t}){if(!t.dataChanged)return;const{data:n}=this.props,s=n&&"points"in n&&"polygons"in n&&"lines"in n;this.setState({binary:s}),s?this._updateStateBinary({props:e,changeFlags:t}):this._updateStateJSON({props:e,changeFlags:t})}_updateStateBinary({props:e,changeFlags:t}){const n=dR(e.data);this.setState({layerProps:n})}_updateStateJSON({props:e,changeFlags:t}){const n=cR(e.data),s=this.getSubLayerRow.bind(this);let r={};const o={};if(Array.isArray(t.dataChanged)){const c=this.state.features;for(const l in c)r[l]=c[l].slice(),o[l]=[];for(const l of t.dataChanged){const u=zd(n,s,l);for(const f in c)o[f].push(Qp({data:r[f],getIndex:d=>d.__source.index,dataRange:l,replace:u[f]}))}}else r=zd(n,s);const a=fR(r,o);this.setState({features:r,featuresDiff:o,layerProps:a})}getPickingInfo(e){const t=super.getPickingInfo(e),{index:n,sourceLayer:s}=t;return t.featureType=hR.find(r=>s.id.startsWith(`${this.id}-${r}-`)),n>=0&&s.id.startsWith(`${this.id}-points-text`)&&this.state.binary&&(t.index=this.props.data.points.globalFeatureIds.value[n]),t}_updateAutoHighlight(e){const t=`${this.id}-points-`,n=e.featureType==="points";for(const s of this.getSubLayers())s.id.startsWith(t)===n&&s.updateAutoHighlight(e)}_renderPolygonLayer(){var o;const{extruded:e,wireframe:t}=this.props,{layerProps:n}=this.state,s="polygons-fill",r=this.shouldRenderSubLayer(s,(o=n.polygons)==null?void 0:o.data)&&this.getSubLayerClass(s,vc.type);if(r){const a=ra(this,vc.props,"getPolygon"),c=e&&t;return c||delete a.getLineColor,a.updateTriggers.lineColors=c,new r(a,this.getSubLayerProps({id:s,updateTriggers:a.updateTriggers}),n.polygons)}return null}_renderLineLayers(){var c,l;const{extruded:e,stroked:t}=this.props,{layerProps:n}=this.state,s="polygons-stroke",r="linestrings",o=!e&&t&&this.shouldRenderSubLayer(s,(c=n.polygonsOutline)==null?void 0:c.data)&&this.getSubLayerClass(s,Rs.type),a=this.shouldRenderSubLayer(r,(l=n.lines)==null?void 0:l.data)&&this.getSubLayerClass(r,Rs.type);if(o||a){const u=ra(this,Rs.props,"getPath");return[o&&new o(u,this.getSubLayerProps({id:s,updateTriggers:u.updateTriggers}),n.polygonsOutline),a&&new a(u,this.getSubLayerProps({id:r,updateTriggers:u.updateTriggers}),n.lines)]}return null}_renderPointLayers(){var a;const{pointType:e}=this.props,{layerProps:t,binary:n}=this.state;let{highlightedObjectIndex:s}=this.props;!n&&Number.isFinite(s)&&(s=t.points.data.findIndex(c=>c.__source.index===s));const r=new Set(e.split("+")),o=[];for(const c of r){const l=`points-${c}`,u=Is[c],f=u&&this.shouldRenderSubLayer(l,(a=t.points)==null?void 0:a.data)&&this.getSubLayerClass(l,u.type);if(f){const d=ra(this,u.props);let g=t.points;if(c==="text"&&n){const{rowIndexes:p,...m}=g.data.attributes;g={...g,data:{...g.data,attributes:m}}}o.push(new f(d,this.getSubLayerProps({id:l,updateTriggers:d.updateTriggers,highlightedObjectIndex:s}),g))}}return o}renderLayers(){const{extruded:e}=this.props,t=this._renderPolygonLayer(),n=this._renderLineLayers(),s=this._renderPointLayers();return[!e&&t,n,s,e&&t]}getSubLayerAccessor(e){const{binary:t}=this.state;return!t||typeof e!="function"?super.getSubLayerAccessor(e):(n,s)=>{const{data:r,index:o}=s,a=LI(r,o);return e(a,s)}}}gr.layerName="GeoJsonLayer";gr.defaultProps=gR;const De={gray1:"#111111",gray2:"#191919",gray3:"#222222",gray4:"#2a2a2a",gray5:"#313131",gray6:"#3a3a3a",gray7:"#484848",gray8:"#606060",gray9:"#6e6e6e",gray10:"#7b7b7b",gray11:"#b4b4b4",gray12:"#eeeeee"},Wi={teal9:"#12a594",teal11:"#0bd8b6"},pr=i=>[parseInt(i.slice(1,3),16),parseInt(i.slice(3,5),16),parseInt(i.slice(5,7),16)],Te=(i,e=255)=>[...pr(i),e],oa={ambient:.6,diffuse:.5,shininess:0,specularColor:pr(De.gray1)},we={building:Te(De.gray11),faded:Te(De.gray9),ghost:Te(De.gray9,90),selected:Te(De.gray11,36),modelled:Te(De.gray11,66),boundary:Te(De.gray11,180),point:Te(Wi.teal9),pointSelected:Te(Wi.teal11),text:Te(De.gray12),unknown:Te(De.gray11),ground:Te(Wi.teal9,82),floor:Te(Wi.teal9,145),floorEdge:Te(Wi.teal11,180)};function Ud(i){return i.features.flatMap(e=>(e.geometry.type==="Polygon"?[e.geometry.coordinates]:e.geometry.coordinates).map(t=>({...e.properties,polygon:t})))}function $d(i,e){return i.map(t=>t.map(n=>[n[0],n[1],e]))}function _s(i){const e=i.getCenter();return{longitude:e.lng,latitude:e.lat,zoom:i.getZoom(),pitch:i.getPitch(),bearing:i.getBearing()}}function Gd(i,e){const t=i.getContainer().clientWidth<=700,n=i.cameraForBounds([[e.bounds[0],e.bounds[1]],[e.bounds[2],e.bounds[3]]],{padding:t?{top:150,bottom:130,left:24,right:24}:{top:120,bottom:100,left:72,right:72},bearing:-25,maxZoom:16.2}),s=n==null?void 0:n.center,r=s&&("lng"in s?[s.lng,s.lat]:Array.isArray(s)?s:[s.lon,s.lat]);return{longitude:(r==null?void 0:r[0])??103.8395,latitude:(r==null?void 0:r[1])??1.2854,zoom:(n==null?void 0:n.zoom)??15,pitch:55,bearing:-25}}function pR(i){const{data:e,filter:t,selectedId:n}=i,s=Ce.useRef(null),r=Ce.useRef(null),o=Ce.useRef(null),a=Ce.useRef(i);a.current=i;const[c,l]=Ce.useState(!1),[u,f]=Ce.useState(i.initialCamera),d=Ce.useMemo(()=>Ud(e.buildings),[e]),g=Ce.useMemo(()=>Ud(e.floor_coverage),[e]),p=Ce.useMemo(()=>e.aeds.filter(y=>t==="all"||y.floor_group===t),[e,t]),m=p.find(y=>y.aed_id===n),_=Ce.useMemo(()=>{const y=(m==null?void 0:m.aed_id)??null,x=g.filter(L=>y?L.aed_ids.includes(y):t==="all"||L.groups.includes(t)),S=!!(y&&x.length),C=new Set(x.map(L=>L.building_id)),O=L=>C.has(L.building_id)||L.building_id===(m==null?void 0:m.building_id),B=d.filter(L=>!O(L)),D=new Set(S&&m?B.filter(L=>{const G=L.polygon[0];if(!(G!=null&&G.length))return!1;const b=G.reduce((I,R)=>[Math.min(I[0],R[0]),Math.min(I[1],R[1]),Math.max(I[2],R[0]),Math.max(I[3],R[1])],[1/0,1/0,-1/0,-1/0]),P=Math.max(b[0],Math.min(b[2],m.longitude)),E=Math.max(b[1],Math.min(b[3],m.latitude)),A=(P-m.longitude)*111320*Math.cos(m.latitude*Math.PI/180),T=(E-m.latitude)*111320;return Math.hypot(A,T)<=180}):[]),k=e.ground_coverage.features.filter(L=>y?L.properties.scope==="device"&&L.properties.aed_id===y:L.properties.scope==="aggregate"&&L.properties.group===t),N=new Set(p.map(L=>L.aed_id)),F=L=>{const G=(L==null?void 0:L.aed_ids.filter(b=>N.has(b)))??[];G.length&&a.current.onSelectAED(G[(G.indexOf(y??"")+1)%G.length])},z=x.flatMap(L=>$d(L.polygon,L.top_m).map(G=>({path:G})));return[new gr({id:"case-boundary",data:e.boundary,filled:!1,stroked:!0,getLineColor:we.boundary,getLineWidth:.5,lineWidthUnits:"pixels",pickable:!1}),new gr({id:"case-ground-reach",data:{type:"FeatureCollection",features:k},filled:!0,stroked:!1,getFillColor:we.ground,pickable:!1}),new oi({id:"case-buildings",data:B.filter(L=>!D.has(L)),getPolygon:L=>L.polygon,getElevation:L=>L.display_height,extruded:!0,wireframe:!1,stroked:!1,pickable:!0,getFillColor:y?we.faded:we.building,material:oa,updateTriggers:{getFillColor:[y,t]},onClick:L=>{var G;return F(L.object),!!((G=L.object)!=null&&G.aed_ids.length)}}),new oi({id:"case-nearby-context-cutaway",data:[...D],getPolygon:L=>L.polygon,getElevation:L=>L.display_height,extruded:!0,wireframe:!1,stroked:!1,pickable:!0,getFillColor:we.ghost,parameters:{depthWriteEnabled:!1},material:oa,onClick:L=>{var G;return F(L.object),!!((G=L.object)!=null&&G.aed_ids.length)}}),new oi({id:"case-buildings-cutaway",data:d.filter(O),getPolygon:L=>L.polygon,getElevation:L=>L.display_height,extruded:!0,wireframe:!1,stroked:!1,pickable:!0,getFillColor:L=>L.building_id===(m==null?void 0:m.building_id)?we.selected:we.modelled,parameters:{depthWriteEnabled:!1},material:oa,updateTriggers:{getFillColor:[y,t]},onClick:L=>{var G;return F(L.object),!!((G=L.object)!=null&&G.aed_ids.length)}}),new oi({id:"case-floor-reach",data:x,getPolygon:L=>$d(L.polygon,L.base_m),getElevation:L=>L.top_m-L.base_m,extruded:!0,wireframe:!1,stroked:!1,pickable:!1,getFillColor:we.floor,material:!1}),new $n({id:"case-floor-edges",data:z,getPath:L=>L.path,getColor:we.floorEdge,getWidth:.5,widthUnits:"pixels",pickable:!1}),new Xr({id:"case-aeds",data:p,pickable:!0,billboard:!0,getPosition:L=>[L.longitude,L.latitude,Math.max(.6,L.display_z)],radiusUnits:"pixels",getRadius:L=>L.aed_id===y?7:4.5,filled:!0,stroked:!0,lineWidthUnits:"pixels",getLineWidth:.5,getLineColor:we.text,getFillColor:L=>L.aed_id===y?we.pointSelected:L.floor_group==="unknown"?we.unknown:we.point,updateTriggers:{getRadius:y,getFillColor:y},parameters:{depthCompare:"always",depthWriteEnabled:!1},onClick:L=>(L.object&&a.current.onSelectAED(L.object.aed_id),!0)}),new Qr({id:"case-aed-floors",data:p.filter(L=>L.floor_num!==1||L.aed_id===y),getPosition:L=>[L.longitude,L.latitude,Math.max(.6,L.display_z)],getText:L=>L.floor_num===null?"Floor unknown":`L${L.floor_num}`,getColor:we.text,getSize:12,sizeUnits:"pixels",getPixelOffset:[10,0],getTextAnchor:"start",getAlignmentBaseline:"center",fontFamily:"Arial, sans-serif",fontWeight:500,billboard:!0,pickable:!0,parameters:{depthCompare:"always",depthWriteEnabled:!1},onClick:L=>(L.object&&a.current.onSelectAED(L.object.aed_id),!0)})]},[e,d,g,t,m,p]),v=Ce.useRef(_);v.current=_,Ce.useEffect(()=>{if(!s.current)return;let y=!1,x=!1,S,C;const O=new AbortController;l(!1);const B=()=>{y||a.current.onError("3D view unavailable")};return(async()=>{try{const k=await fetch("./map/basemap-radix.json",{signal:O.signal});if(!k.ok)throw new Error("Basemap unavailable");const N=await k.json();if(y||!s.current)return;N.layers=N.layers.filter(b=>!("source-layer"in b&&b["source-layer"]==="buildings"));const F=new mm.Map({container:s.current,style:N,center:[103.8395,1.2854],zoom:15,pitch:55,bearing:-25,attributionControl:!1,minZoom:13,maxZoom:20,minPitch:0,maxPitch:70,scrollZoom:!1,doubleClickZoom:!1,boxZoom:!1,keyboard:!1,dragPan:!0,dragRotate:!0,touchZoomRotate:!0,touchPitch:!0,cooperativeGestures:matchMedia("(pointer: coarse)").matches,fadeDuration:0,renderWorldCopies:!1,canvasContextAttributes:{antialias:!0}});r.current=F;const z=a.current.initialCamera??Gd(F,e);F.jumpTo({center:[z.longitude,z.latitude],zoom:z.zoom,pitch:z.pitch,bearing:z.bearing}),f(_s(F));const L=()=>{if(y)return;const b=_s(F);f(b),a.current.onCamera(b)};F.on("moveend",L),F.on("webglcontextlost",B);const G=F.getCanvas();G.tabIndex=0,G.setAttribute("aria-label","Pearl’s Hill 3D model. Arrow keys pan. Camera controls rotate, tilt and zoom."),G.addEventListener("keydown",b=>{if(y||!x||document.activeElement!==G||b.altKey||b.ctrlKey||b.metaKey)return;const E={ArrowLeft:[-70,0],ArrowRight:[70,0],ArrowUp:[0,-70],ArrowDown:[0,70]}[b.key];E&&(b.preventDefault(),F.panBy(E,{duration:matchMedia("(prefers-reduced-motion: reduce)").matches?0:250,easing:A=>1-(1-A)**3}))},{signal:O.signal}),F.on("load",()=>{if(y)return;const b=new rl({ambientLight:new Mg({color:pr(De.gray12),intensity:1}),directionalLight:new Ya({color:pr(De.gray12),intensity:1,direction:[-3,-4,-8]})}),P=new pM({interleaved:!0,layers:v.current,effects:[b],pickingRadius:6,onError:B,onAfterRender:()=>{y||x||(x=!0,clearTimeout(C),l(!0),a.current.onReady())}});o.current=P,F.addControl(P)}),S=new ResizeObserver(()=>{y||F.resize()}),S.observe(s.current),C=setTimeout(()=>{x||B()},35e3)}catch(k){!y&&!(k instanceof DOMException&&k.name==="AbortError")&&B()}})(),()=>{y=!0,O.abort(),clearTimeout(C),S==null||S.disconnect(),r.current&&(a.current.onCamera(_s(r.current)),r.current.remove(),r.current=null),o.current=null}},[e]),Ce.useEffect(()=>{var y;(y=o.current)==null||y.setProps({layers:_})},[_]);const w=y=>{const x=r.current;if(!x||!c)return;const S=y==="reset"?Gd(x,e):_s(x);y==="in"&&(S.zoom=Math.min(20,S.zoom+.75)),y==="out"&&(S.zoom=Math.max(13,S.zoom-.75)),y==="left"&&(S.bearing-=30),y==="right"&&(S.bearing+=30),y==="up"&&(S.pitch=Math.min(70,S.pitch+15)),y==="down"&&(S.pitch=Math.max(0,S.pitch-15)),x.easeTo({center:[S.longitude,S.latitude],zoom:S.zoom,bearing:S.bearing,pitch:S.pitch,duration:matchMedia("(prefers-reduced-motion: reduce)").matches?0:250,easing:C=>1-(1-C)**3})};return le.jsxs("div",{className:"case3d-renderer","data-ready":c,"data-bearing":u==null?void 0:u.bearing.toFixed(2),"data-pitch":u==null?void 0:u.pitch.toFixed(2),"data-zoom":u==null?void 0:u.zoom.toFixed(3),children:[le.jsx("div",{className:"case3d-canvas",ref:s}),le.jsxs("div",{className:"case3d-camera",role:"group","aria-label":"3D camera controls",children:[le.jsx("button",{disabled:!c,title:"Zoom in","aria-label":"Zoom in 3D model",onClick:()=>w("in"),children:le.jsx(lm,{})}),le.jsx("button",{disabled:!c,title:"Zoom out","aria-label":"Zoom out 3D model",onClick:()=>w("out"),children:le.jsx(um,{})}),le.jsx("button",{disabled:!c,title:"Rotate left","aria-label":"Rotate model left",onClick:()=>w("left"),children:le.jsx(fm,{})}),le.jsx("button",{disabled:!c,title:"Rotate right","aria-label":"Rotate model right",onClick:()=>w("right"),children:le.jsx(dm,{})}),le.jsx("button",{disabled:!c,title:"Increase tilt","aria-label":"Increase model tilt",onClick:()=>w("up"),children:le.jsx(hm,{})}),le.jsx("button",{disabled:!c,title:"Decrease tilt","aria-label":"Decrease model tilt",onClick:()=>w("down"),children:le.jsx(gm,{})}),le.jsx("button",{disabled:!c,title:"Reset view","aria-label":"Reset 3D view",onClick:()=>w("reset"),children:le.jsx(pm,{})})]}),le.jsxs("div",{className:"case3d-attribution",children:[le.jsx("a",{href:"https://www.openstreetmap.org/copyright",target:"_blank",rel:"noreferrer",children:"© OpenStreetMap"}),le.jsx("a",{href:"https://carto.com/attributions",target:"_blank",rel:"noreferrer",children:"© CARTO"})]})]})}const xR=Object.freeze(Object.defineProperty({__proto__:null,default:pR},Symbol.toStringTag,{value:"Module"}));export{FT as A,Sn as B,Qa as C,se as G,Ue as M,he as T,Vw as a,Ui as b,b1 as c,wR as d,fc as e,mP as f,wt as g,p1 as h,m1 as i,_1 as j,R1 as k,xR as l,P1 as r};
